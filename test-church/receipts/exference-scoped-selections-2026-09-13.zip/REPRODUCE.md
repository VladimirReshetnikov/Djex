# Exference scoped-selection repair

Start from Djex commit 108abf1ebd6abf5f6f8efe2d1dbccee22b27d0d0. Apply the
source.patch under exference-selections-validation-v2, or overlay its source/
files. The full source and binary hash manifests are in results.json. Build
the targets recorded by diagnostics/exference-selections-build-v10.log using
GHC 9.12.4, -Werror and one job. The frozen controller records the direct
suite commands and bounds. Adapt machine-local executable/output paths for a
new run; do not overwrite this archive. Retained failed v1 and the enumeration
experiment have distinct source snapshots and must not be mixed with v2.

The first full run exhausted memory in the existing cyclic-pattern arity test
because the experimental erasure forced a whole pattern list. v2 restores lazy
projection and checks malformed selected class arities before their arguments.
The earlier enumeration-only run constructed terms but independent checking
rejected their unspecified constraint-only variables. Temporary Debug.Trace
instrumentation appears only in that experiment, not the final source.

The reduction-witness folder is a separate design check: both files compile,
and Lean checks four closed examples and reports no axioms for either fold.
The finite Python model note is retained without its generator. These are not
synthesis acceptances and add no Church behavior cells. Native integration
has a separate Leant receipt and is not certified by this Haskell archive.
