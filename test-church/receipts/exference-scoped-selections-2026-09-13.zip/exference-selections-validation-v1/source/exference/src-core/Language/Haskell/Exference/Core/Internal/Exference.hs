{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE MonadComprehensions #-}

-- | The Exference search engine proper: the priority-queue-driven best-first
-- search over t'SearchNode's, the validation of inputs, environments,
-- queries, and options, and the result projections in both the historical
-- chunk API and the shared query envelope.  Every public entrance validates
-- once and hands the raw lazy engine a sealed artifact whose constructor is
-- private, so nothing unchecked reaches 'stateStep'.
module Language.Haskell.Exference.Core.Internal.Exference
  ( findExpressions
  , findExpressionsWithAllocators
  , findExpressionsWithAllocatorsUsingLegacyStateStepForTesting
  , findEngineCandidatesWithAllocatorsForTesting
  , findEngineCandidatesWithAllocatorsUsingLegacyStateStepForTesting
  , findTypedQueryResultsInEnvironmentEither
  , findQueryResultsInEnvironmentEither
  , findTypedQueryResultsInEnvironmentWithCheckedOptions
  , findQueryResultsInEnvironmentWithCheckedOptions
  , findTypedQueryResultsInEnvironmentWithCheckedOptionsAndCandidates
  , findTypedQueryResultsInEnvironmentWithCheckedOptionsAndAssignments
  , findTypedQueryResultsWithAllocators
  , findQueryResultsWithAllocators
  , typedQueryProjectionStrictnessForTesting
  , queryProjectionStrictnessForTesting
  , compatibilityProjectionStrictnessForTesting
  , prepareExferenceInput
  , prepareExferenceQuery
  , ExferenceInput (..)
  , ExferenceEnvironment
  , ExferenceQuery (..)
  , CheckedExferenceOptions
  , ExferenceOutputElement
  , ExferenceChunkElement (..)
  , ExferenceBatchMetadata (..)
  , ExferenceCandidate
  , ExferenceResult
  , ExferenceTypedCandidate
  , ExferenceTypedResult
  , SearchCompletion (..)
  , SearchStatus (..)
  , constraintsRelaxedAtStep
  , mergeQueueWithCapacity
  , naturalPruningReasons
  , projectCompatibilityBindingUsages
  , typeComplexity
  , ExferenceInputError (..)
  , isExferenceOptionError
  , mkExferenceEnvironment
  , mkExferenceEnvironmentWithSchemes
  , exferenceEnvironmentContainsBinding
  , exferenceEnvironmentBindingScheme
  , checkExferenceOptions
  , validateExferenceQuery
  , validateExferenceInput
  )
where



import Language.Haskell.Exference.Core.Types
import Language.Haskell.Exference.Core.TypeUtils
import Language.Haskell.Exference.Core.Expression
import Language.Haskell.Exference.Core.Declaration
  ( validatePreparedFunctionSchemes )
import Language.Haskell.Exference.Core.Internal.Candidate
  ( ExferenceCandidate
  , ExferenceSourceTypeVariableHintError
  , ExferenceSourceTypeVariableHints
  , ExferenceTypeVariableHints
  , projectValidatedCandidate
  , typeVariableHintsWithPlan
  )
import Language.Haskell.Exference.Core.Internal.ExpressionCheck
import Language.Haskell.Exference.Core.Score
import Language.Haskell.Exference.Core.ExferenceStats
import Language.Haskell.Exference.Core.FunctionBinding
import Language.Haskell.Exference.Core.RigidInstantiation
import Language.Haskell.Exference.Core.Internal.FlexibleIds
import Language.Haskell.Exference.Core.Internal.VariableSupply
import Language.Haskell.Exference.Core.Unify
import Language.Haskell.Exference.Core.ConstraintSolver
import Language.Haskell.Exference.Core.Internal.ExferenceNode
import Language.Haskell.Exference.Core.Internal.ExferenceNodeBuilder
import Language.Haskell.Exference.Core.Internal.Polytype
import Language.Haskell.Exference.Core.Internal.RigidScope
  ( escapingRigidConstraints
  , emptyRigidScope
  , nestedRigidProvenance
  , registerRigidScope
  )
import Language.Haskell.Exference.Core.Internal.ScopedConstraint
import Language.Haskell.Exference.Core.Internal.SearchControl
import Language.Haskell.Exference.Core.Internal.Options
  ( ExferenceHeuristicsConfig (..)
  , ExferenceOptions (..)
  , heuristicFields
  )
import qualified Language.Haskell.Synthesis.Count as SharedCount
import qualified Language.Haskell.Synthesis.Collection as SharedCollection
import qualified Language.Haskell.Synthesis.Search as SharedSearch
import qualified Language.Haskell.Synthesis.Generated as SharedGenerated
import qualified Language.Haskell.Synthesis.CandidateQuality as SharedQuality
import qualified Language.Haskell.Synthesis.Name as SynthesisName
import qualified Language.Haskell.Synthesis.Candidate as SharedCandidate
import qualified Language.Haskell.Synthesis.Query as SharedQuery
import qualified Language.Haskell.Synthesis.Internal.TypedCandidate
  as SharedTypedCandidate
import qualified Language.Haskell.Synthesis.Type as SharedType
import qualified Language.Haskell.Synthesis.TypeAtom as SharedTypeAtom

import qualified Data.PQueue.Prio.Max as Q
import qualified Data.Map.Strict as M
import qualified Data.IntMap.Strict as IntMap
import qualified Data.IntSet as IntSet
import qualified Data.Set as S
import qualified Data.Sequence as Seq
import qualified Data.List as L

import Data.Maybe (fromMaybe, isJust, listToMaybe, maybeToList)
import Control.Monad ( mzero, forM, unless, void, when )
import Control.Applicative ( (<|>) )
import Data.List ( find, partition, sortBy, unfoldr )
import Data.Monoid ( Any(..) )
import Data.Foldable ( traverse_ )
import Data.List.NonEmpty (NonEmpty ((:|)))
import Numeric.Natural (Natural)
import Control.Monad.Trans.Class ( lift )
import Control.Monad.Trans.State.Lazy
  ( StateT(..), gets, modify, state
  , execStateT, runStateT
  )

-- | The historical all-in-one search input: goal, environment, and search
-- limits in a single record.  It is validated by 'prepareExferenceInput'
-- before any search runs; the newer split API uses t'ExferenceEnvironment'
-- and t'ExferenceQuery' instead.
data ExferenceInput = ExferenceInput
  { input_goalType    :: HsType                 -- ^ try to find a expression
                                                -- of this type
  , input_envFuncs    :: [FunctionBinding]      -- ^ the list of functions
                                                -- that may be used
  , input_envDeconsS  :: [DeconstructorBinding] -- ^ the list of deconstructors
                                                -- that may be used for pattern
                                                -- matching
  , input_envClasses  :: StaticClassEnv
  , input_allowUnused :: Bool                   -- ^ if false, forbid solutions
                                                -- where any bind is unused
  , input_allowConstraints :: Bool              -- ^ if true, allow solutions
                                                -- that have unproven
                                                -- constraints remaining.
  , input_allowConstraintsStopStep :: Int       -- ^ stop ignoring
                                                -- tc-constraints after this
                                                -- step to have some chance to
                                                -- find some solution.
  , input_multiPM     :: Bool                   -- ^ pattern match on
                                                -- multi-constructor data types
                                                -- if true. serverly increases
                                                -- search space (decreases
                                                -- performance).
  , input_maxSteps    :: Int                    -- ^ maximum processed nodes
  , input_maxQueueSize :: Maybe Int             -- ^ keep the best N queued nodes
  , input_maxDepth    :: Maybe Penalty          -- ^ optional heuristic-depth cap
  , input_heuristicsConfig :: ExferenceHeuristicsConfig
  }
  deriving (Show)

-- | A finite search environment whose names, types, constraints, ratings, and
-- generated syntax have been checked once.  The constructor remains private:
-- removing a binding for one query is safe, but adding or replacing one must
-- cross 'mkExferenceEnvironment' again.
data ExferenceEnvironment = ExferenceEnvironment
  !EnvDictionary
  !RigidInstantiationContext
  !(M.Map QualifiedName HsType)

-- | The query-varying half of an Exference search input.
--
-- Exact shared names in 'queryExcludedBindings' are unavailable to both proof
-- search and the independent result checker.  This lets a frontend prevent a
-- generated definition from accidentally referring to the binding it shadows
-- without revalidating the otherwise unchanged environment.
data ExferenceQuery = ExferenceQuery
  { queryGoalType :: HsType
  , queryExcludedBindings :: S.Set SynthesisName.Name
  , querySearchOptions :: ExferenceOptions
      -- ^ Exact grouped search policy retained from the checked request.
  }
  deriving (Eq, Show)

-- | Search controls that crossed their complete validation boundary.  The
-- constructor stays private even inside the package: checked adapters can
-- preserve option-before-elaboration diagnostics without giving preparation
-- a second authority over the same fields.
data CheckedExferenceOptions = CheckedExferenceOptions !ExferenceOptions

-- | A query sealed together with the exact environment and rigid-variable
-- plan against which it was validated.  Keeping this artifact private makes
-- it impossible for the raw lazy engine to recompute fallible derived state,
-- or to run a checked query against a different environment by mistake.
data CheckedExferenceQuery = CheckedExferenceQuery
  !ExferenceEnvironment
  !ExferenceQuery
  !(M.Map QualifiedName [HsType])
  !(M.Map QualifiedName [[HsType]])
  !RigidInstantiationPlan

-- | Why an input, environment, query, or option set was rejected before any
-- search ran.  Validation reports the first failure in the historical guard
-- order; 'isExferenceOptionError' separates option failures from goal and
-- environment failures.
data ExferenceInputError
  = NestedForallInGoal HsType
  | NestedForallInBinding QualifiedName HsType
  | NestedForallInDeconstructor HsType
  | NestedForallInConstraint ConstraintSite HsConstraint
  | InvalidInputType HsType SynthesisTypeError
  | DeconstructorInputWithoutNominalHead HsType
  | UnsupportedDeconstructorTypeHead QualifiedName
  | UnboundDeconstructorFieldVariables
      QualifiedName -- ^ Nominal datatype head.
      QualifiedName -- ^ Constructor whose fields escape the parameter scope.
      [TVarId]      -- ^ Escaping flexible IDs, in ascending order.
  | InvalidGeneratedBinding QualifiedName SharedGenerated.RenderError
  | InvalidGeneratedConstructor QualifiedName SharedGenerated.RenderError
  | DuplicateFunctionNames [QualifiedName]
  | InvalidFunctionScheme QualifiedName
  | DuplicateDeconstructorNames [QualifiedName]
  | DuplicateConstructorNames [QualifiedName]
  | InvalidClassConstraint ClassEnvError
  | InvalidMaxSteps Int
  | InvalidConstraintDeferralSteps Int
  | InvalidMaxQueueSize Int
  | InvalidMaxDepth Penalty
  | InvalidHeuristic String Penalty
  | RigidIdentifierExhaustion RigidInstantiationError
  | InvalidSourceTypeVariableHints ExferenceSourceTypeVariableHintError
  deriving (Eq)

-- | Whether a rejected input failed on its search options rather than the
-- query or environment. Living beside the type with a complete case, this
-- classification cannot silently drift when a constructor is added; the
-- stable adapter uses it to keep option failures source-free, mirroring
-- Djinn's structural options/query error split.
isExferenceOptionError :: ExferenceInputError -> Bool
isExferenceOptionError failure = case failure of
  NestedForallInGoal{} -> False
  NestedForallInBinding{} -> False
  NestedForallInDeconstructor{} -> False
  NestedForallInConstraint{} -> False
  InvalidInputType{} -> False
  DeconstructorInputWithoutNominalHead{} -> False
  UnsupportedDeconstructorTypeHead{} -> False
  UnboundDeconstructorFieldVariables{} -> False
  InvalidGeneratedBinding{} -> False
  InvalidGeneratedConstructor{} -> False
  DuplicateFunctionNames{} -> False
  InvalidFunctionScheme{} -> False
  DuplicateDeconstructorNames{} -> False
  DuplicateConstructorNames{} -> False
  InvalidClassConstraint{} -> False
  InvalidMaxSteps{} -> True
  InvalidConstraintDeferralSteps{} -> True
  InvalidMaxQueueSize{} -> True
  InvalidMaxDepth{} -> True
  InvalidHeuristic{} -> True
  RigidIdentifierExhaustion{} -> False
  InvalidSourceTypeVariableHints{} -> False

instance Show ExferenceInputError where
  showsPrec precedence failure = showParen (precedence > 10)
    $ showString $ renderExferenceInputError failure

renderExferenceInputError :: ExferenceInputError -> String
renderExferenceInputError failure = case failure of
  NestedForallInGoal typeExpression ->
    constructor "NestedForallInGoal" [sourceType typeExpression]
  NestedForallInBinding name typeExpression -> constructor
    "NestedForallInBinding" [show name, sourceType typeExpression]
  NestedForallInDeconstructor typeExpression -> constructor
    "NestedForallInDeconstructor" [sourceType typeExpression]
  NestedForallInConstraint site constraint -> constructor
    "NestedForallInConstraint" [show site, sourceConstraint constraint]
  InvalidInputType typeExpression typeFailure -> constructor
    "InvalidInputType" [sourceType typeExpression, show typeFailure]
  DeconstructorInputWithoutNominalHead typeExpression -> constructor
    "DeconstructorInputWithoutNominalHead" [sourceType typeExpression]
  UnsupportedDeconstructorTypeHead name -> constructor
    "UnsupportedDeconstructorTypeHead" [show name]
  UnboundDeconstructorFieldVariables typeName fieldConstructor variables ->
    constructor "UnboundDeconstructorFieldVariables"
      [show typeName, show fieldConstructor, show variables]
  InvalidGeneratedBinding name renderFailure -> constructor
    "InvalidGeneratedBinding" [show name, show renderFailure]
  InvalidGeneratedConstructor name renderFailure -> constructor
    "InvalidGeneratedConstructor" [show name, show renderFailure]
  DuplicateFunctionNames names ->
    constructor "DuplicateFunctionNames" [show names]
  InvalidFunctionScheme name ->
    constructor "InvalidFunctionScheme" [show name]
  DuplicateDeconstructorNames names ->
    constructor "DuplicateDeconstructorNames" [show names]
  DuplicateConstructorNames names ->
    constructor "DuplicateConstructorNames" [show names]
  InvalidClassConstraint classFailure ->
    constructor "InvalidClassConstraint" [show classFailure]
  InvalidMaxSteps maximumSteps ->
    constructor "InvalidMaxSteps" [show maximumSteps]
  InvalidConstraintDeferralSteps steps ->
    constructor "InvalidConstraintDeferralSteps" [show steps]
  InvalidMaxQueueSize maximumSize ->
    constructor "InvalidMaxQueueSize" [show maximumSize]
  InvalidMaxDepth maximumDepth ->
    constructor "InvalidMaxDepth" [show maximumDepth]
  InvalidHeuristic fieldName value ->
    constructor "InvalidHeuristic" [show fieldName, show value]
  RigidIdentifierExhaustion rigidFailure ->
    constructor "RigidIdentifierExhaustion" [show rigidFailure]
  InvalidSourceTypeVariableHints hintFailure ->
    constructor "InvalidSourceTypeVariableHints" [show hintFailure]
 where
  constructor name fields = unwords $ name : fields
  sourceType typeExpression = "(" ++ showHsType M.empty typeExpression ++ ")"
  sourceConstraint constraint =
    "(" ++ showHsConstraint M.empty constraint ++ ")"

-- | One historical search result: the checked expression, the type-class
-- constraints left unresolved for it, and the statistics of the step that
-- produced it.
type ExferenceOutputElement = (Expression, [HsConstraint], ExferenceStats)

-- | How far the search had progressed when a chunk was emitted.  Only
-- 'SearchExhausted' makes the absence of a result conclusive; every other
-- terminal value records a bound or namespace limit that discarded work.
data SearchCompletion
  = SearchRunning
    -- ^ Retained search nodes remain after this chunk.
  | SearchExhausted
    -- ^ No retained nodes remain and no node was discarded by a configured
    -- bound. Failure is conclusive for this search calculus and environment.
  | SearchStepLimitReached
    -- ^ Retained nodes remain, but the configured step budget is spent.
  | SearchPruned
    -- ^ No retained nodes remain, but queue or depth bounds discarded nodes;
    -- absence of an answer is therefore not a non-inhabitation result.
  | SearchIdentifierSpaceExhausted
    -- ^ One or more branches could not be represented in a finite internal
    -- identifier namespace, so exhaustion of the retained queue is not
    -- conclusive.
  deriving (Eq, Show)

-- | Historical progress summary attached to every t'ExferenceChunkElement':
-- the completion state plus running totals of nodes discarded by the queue
-- and depth bounds so far.
data SearchStatus = SearchStatus
  { searchCompletion :: SearchCompletion
  -- These historical counters cannot represent every exact engine total.
  -- Engine-produced values saturate; modern batch metadata remains lossless.
  , searchQueuePruned :: Int
  , searchDepthPruned :: Int
  }
  deriving (Eq, Show)

-- | The historical per-step output of 'findExpressions': the search status
-- after the step, the cumulative usage count of every environment binding,
-- and the solutions found in that step (often none).  It is a saturating
-- projection of the exact engine batch produced by the shared search API.
data ExferenceChunkElement = ExferenceChunkElement
  { chunkStatus :: SearchStatus
  -- Historical compatibility metadata remains machine-sized. Engine-produced
  -- counts saturate here. Canonical results retain exact totals independently.
  , chunkBindingUsages :: M.Map QualifiedName Int
  , chunkElements :: [ExferenceOutputElement]
  }

-- Only independently checked search output can inhabit the engine batch.
-- Keep the constructor private so the total canonical projector cannot be
-- applied accidentally before type, scope, completeness, and syntax checks.
data ValidatedEngineCandidate = ValidatedEngineCandidate
  Expression
  [HsConstraint]
  ExferenceStats
  ExferenceTermGraphAvailability

-- Stable within one deterministic query trace: the engine step identifies the
-- producing batch and the pre-filter branch index identifies the candidate.
candidateIdentity :: Int -> Natural -> Natural
candidateIdentity step branch = pairNatural (fromIntegral $ max 0 step) branch
 where
  pairNatural left right = ((sum' * (sum' + 1)) `div` 2) + right
   where
    sum' = left + right

-- The engine stores the lossless shared batch natively. Historical chunks are
-- a saturating compatibility projection, never an intermediate authority for
-- canonical query results.
type EngineBatch =
  SharedSearch.SearchBatch ExferenceBatchMetadata ValidatedEngineCandidate

-- | One Exference engine batch in the backend-neutral query envelope.
type ExferenceResult =
  SharedQuery.QueryResult ExferenceBatchMetadata ExferenceCandidate

-- | A checked compatibility candidate paired with the exact result of
-- retaining its typed term graph.  Construction stays private to the engine
-- boundary which independently validated both projections.
type ExferenceTypedCandidate =
  SharedTypedCandidate.TypedCandidate
    ExferenceTermGraphAbsence HsType TVarId ExferenceCandidate

-- | One Exference engine batch whose candidates retain typed graph results.
type ExferenceTypedResult =
  SharedQuery.QueryResult ExferenceBatchMetadata ExferenceTypedCandidate

-- | An unfinished node paired with its next goal. Only this representation
-- may enter 'stateStep'; completed branches use the separate ready form.
data ScheduledNode = ScheduledNode !TGoal SearchNode

-- A completed branch keeps its original discovery identity even when a
-- cheaper unfinished branch delays its admission. Its exact scope and term
-- remain together until the independent result checker runs.
data ReadySolution = ReadySolution !Int !Natural SearchNode

data FrontierEntry
  = Unfinished !ScheduledNode
  | Ready !ReadySolution

-- Ready branches win exact priority ties. Both kinds of pending work share
-- the configured queue bound; there is no separate unbounded result buffer.
type RatedNodes = Q.MaxPQueue (Priority, Bool) FrontierEntry

-- Recursive inspection multiplies outstanding goals, so ordinary priority
-- pruning can discard every fully inspected branch before any leaf is solved.
-- A second bounded lane protects that construction strategy without assigning
-- artificial expression depth to its whole-value siblings.
data RecursiveCasePolicy
  = OptionalRecursiveCases
  | EagerRecursiveCases

-- | Which private implementation expands one popped node.  Production uses
-- the explicit ordered action list; the historical monolithic action remains
-- reachable only through internal test observers as a differential oracle.
data StateStepRoute
  = OrderedStateStepActions
  | LegacyStateStepAction

data FindExpressionsState = FindExpressionsState
  { findSteps :: Int -- number of steps already performed
  , findQueuePruned :: !Natural
  , findDepthPruned :: !Natural
  , findIdentifierSpaceExhausted :: Bool
  , findBindingUsages :: BindingUsages
  , findQueue :: RatedNodes
  , findEagerCaseQueue :: RatedNodes
  , findNextCasePolicy :: RecursiveCasePolicy
  }

-- Keep the search trace productive by retaining the historical lazy state
-- transformer. An empty priority queue terminates the unfold through Maybe.
popBestNode
  :: StateT FindExpressionsState Maybe (RecursiveCasePolicy, FrontierEntry)
popBestNode = StateT $ \searchState -> do
  let preferred = findNextCasePolicy searchState
      selected
        | Q.null $ caseQueue preferred searchState = otherCasePolicy preferred
        | otherwise = preferred
  (node, remaining) <- Q.maxView $ caseQueue selected searchState
  return
    ( (selected, node)
    , (setCaseQueue selected remaining searchState)
        { findNextCasePolicy = otherCasePolicy selected }
    )

otherCasePolicy :: RecursiveCasePolicy -> RecursiveCasePolicy
otherCasePolicy OptionalRecursiveCases = EagerRecursiveCases
otherCasePolicy EagerRecursiveCases = OptionalRecursiveCases

caseQueue :: RecursiveCasePolicy -> FindExpressionsState -> RatedNodes
caseQueue OptionalRecursiveCases = findQueue
caseQueue EagerRecursiveCases = findEagerCaseQueue

setCaseQueue
  :: RecursiveCasePolicy -> RatedNodes
  -> FindExpressionsState -> FindExpressionsState
setCaseQueue OptionalRecursiveCases queued searchState =
  searchState { findQueue = queued }
setCaseQueue EagerRecursiveCases queued searchState =
  searchState { findEagerCaseQueue = queued }

frontierSize :: FindExpressionsState -> Natural
frontierSize searchState =
  queueSizeNatural (findQueue searchState)
    + queueSizeNatural (findEagerCaseQueue searchState)

-- Both lanes consume one shared capacity. While both are live each retains a
-- protected share; after one exhausts, its sibling may borrow the full bound.
-- Even an unlimited caller remains within the priority queue's native bound.
caseQueueLimit
  :: Maybe Int -> RecursiveCasePolicy -> FindExpressionsState -> Maybe Int
caseQueueLimit maximumSize policy searchState
  | Q.null $ caseQueue (otherCasePolicy policy) searchState = maximumSize
  | otherwise = Just $ fromIntegral $ case policy of
      OptionalRecursiveCases -> capacity - div capacity 2
      EagerRecursiveCases -> div capacity 2
 where
  capacity = min maximumPQueueSize $ maybe maximumPQueueSize
    (fromIntegral . max 0) maximumSize

-- Return the old step number: search budgets and statistics have always used
-- post-increment semantics here.
advanceStep :: StateT FindExpressionsState Maybe Int
advanceStep = state $ \searchState ->
  ( findSteps searchState
  , searchState { findSteps = findSteps searchState + 1 }
  )

recordBindingUsage :: SearchNode -> FindExpressionsState -> FindExpressionsState
recordBindingUsage node searchState = case nodeLastStepBinding node of
  Nothing -> searchState
  Just binding -> searchState
    { findBindingUsages = M.insertWith (+) binding 1
        $ findBindingUsages searchState
    }

-- Entry-point and main function of the algorithm.
-- Takes input, produces list of outputs. Output is basically a
-- [[Solution]], plus some statistics and stuff.
-- Nested list to allow executing n steps even when no solutions are found
-- (e.g. you take 1000, and get only []'s).
--
-- Basic implementation idea: We traverse a search tree. A step (`stateStep`
-- function) evaluates one node, and returns
-- a) new search nodes b) potential solutions.
-- findExpressions does the following stuff:
--   - determine what searchnode to use next (using a priority queue)
--   - call stateStep repeatedly
--   - convert stuff
--   - consider some special abort conditions
findEngineBatchesWith
  :: SearchAllocators
  -> CheckedExferenceQuery
  -> [EngineBatch]
findEngineBatchesWith = findEngineBatchesWithStateStepRoute
  OrderedStateStepActions

findEngineBatchesWithStateStepRoute
  :: StateStepRoute
  -> SearchAllocators
  -> CheckedExferenceQuery
  -> [EngineBatch]
findEngineBatchesWithStateStepRoute stepRoute allocators
    (CheckedExferenceQuery
      (ExferenceEnvironment EnvDictionary
      { environmentFunctions = allFunctions
      , environmentDeconstructors = deconss'
      , environmentClasses = sClassEnv
      } _ allFunctionSchemes)
      ExferenceQuery
      { queryGoalType = rawType
      , queryExcludedBindings = excludedBindings
      , querySearchOptions = ExferenceOptions
          { exferenceAllowUnused = allowUnused
          , exferenceAllowResidualConstraints = allowConstraints
          , exferenceConstraintDeferralSteps = allowConstraintsStopStep
          , exferenceMultiConstructorPatterns = multiPM
          , exferenceMaximumSteps = maxSteps
          , exferenceMaximumQueueSize = maxQueueSize
          , exferenceMaximumDepth = maxDepth
          , exferenceHeuristics = heuristics
          , exferenceCandidateRanking = ranking
          , exferenceProviderCosts = providerCostOverrides
          }
      }
      providerCandidates
      providerAssignments
      rigidPlan) =
  unfoldr helper rootFindExpressionState
 where
  -- Removing an already checked binding cannot invalidate the environment.
  -- Use the same exact projection for search and independent result checking,
  -- otherwise a generated definition could regain the binding it shadows.
  -- Signed source ratings retain their historical nodeDepth contribution.
  -- Structural cost has one shared interpretation at search and presentation.
  providerQualityCost name = M.findWithDefault
    (SharedQuality.defaultCandidateProviderCost name) name providerCostOverrides
  funcs = filter bindingAvailable allFunctions
  bindingAvailable binding = functionName binding
    `S.notMember` excludedBindings
  functionSchemes = M.filterWithKey
    (\name _ -> name `S.notMember` excludedBindings)
    allFunctionSchemes
  -- Boxed tuples are syntax, not declarations.  Introduction has therefore
  -- always been available from the type alone; retain the same invariant for
  -- elimination by deriving only the tuple shapes which this checked query
  -- and environment can actually expose. Explicit source deconstructors keep
  -- their established order, and an existing matching tuple head suppresses
  -- its derived duplicate.
  deconss = deconss' ++
    [ tupleDeconstructor arity
    | arity <- observedTupleArities
    , tupleNameForArity arity `S.notMember` declaredDeconstructorNames
    ]
  declaredDeconstructorNames = S.fromList
    [ deconstructorName
    | deconstructor <- deconss'
    , deconstructorName <- maybeToList
        $ typeConstructorHead $ deconstructorInput deconstructor
    ]
  observedTupleArities = SharedCollection.distinctOn id $ concatMap
    boxedTupleArities
    ( t
      : M.elems functionSchemes
      ++ concatMap functionBindingTypes funcs
      ++ concatMap deconstructorBindingTypes deconss'
      ++ concat (M.elems providerCandidates)
      ++ concatMap concat (M.elems providerAssignments)
      ++ concatMap (constraint_params . snd)
          (environmentConstraints $ EnvDictionary funcs deconss' sClassEnv)
    )
  tupleDeconstructor arity =
    let variables = map TypeVar [0 .. arity - 1]
        tupleName = tupleNameForArity arity
    in DeconstructorBinding
        (TypeTuple Boxed variables)
        [ConstructorBinding tupleName variables]
        False
  tupleNameForArity arity = case
      SynthesisName.tupleName SynthesisName.Boxed arity of
    Right tupleName -> tupleName
    Left failure -> error $
      "validated boxed tuple arity lost its generated name: " ++ show failure

  boxedTupleArities source = case source of
    SharedType.TypeVariable{} -> []
    SharedType.TypeConstructor{} -> []
    SharedType.TypeApplication function argument ->
      boxedTupleArities function ++ boxedTupleArities argument
    SharedType.FunctionType parameter result ->
      boxedTupleArities parameter ++ boxedTupleArities result
    SharedType.TupleType boxity elements ->
      [ length elements | boxity == SynthesisName.Boxed] ++
        concatMap boxedTupleArities elements
    SharedType.ForallType _ contexts body ->
      concatMap
          (concatMap boxedTupleArities . constraint_params)
          contexts
        ++ boxedTupleArities body

  -- Only roots which the checked query uses in a proper-type position become
  -- candidates for an otherwise unconstrained visible binder.  In an
  -- application the argument kind is not recoverable from this first-order
  -- core, so the traversal retains the complete application but deliberately
  -- does not descend into its function or argument.  Arrow and tuple children
  -- are independently known to have kind Type.
  properTypeCandidates = SharedCollection.distinctOn
    SharedTypeAtom.alphaTypeKey $ filter visibleTypeCandidate
      $ properSubtrees False t
  -- A query's leading forall chain is its synthesis boundary, not a type
  -- argument suggested by the query. Quantification reached through an arrow
  -- or tuple child, however, is itself in a proper-type position. Retain that
  -- complete scheme after visiting its body so the established monotype
  -- candidate order remains unchanged.
  properSubtrees retainQuantified source = case source of
    TypeArrow parameter result ->
      properSubtrees True parameter ++ properSubtrees True result ++ [source]
    TypeTuple _ elements ->
      concatMap (properSubtrees True) elements ++ [source]
    TypeForallNative _ _ body ->
      properSubtrees False body ++ [ source | retainQuantified]
    TypeApp{} -> [source]
    _ -> [source]
  visibleTypeCandidate source =
    groundMonotype source || closedContextFreeForall source
  -- The whole quantified value has a proven proper kind at this traversal
  -- point. Its binders may occur in the body, so closure must use lexical free
  -- variables rather than the representation's ordinary Foldable traversal.
  closedContextFreeForall source@TypeForallNative{} =
    S.null (SharedType.freeVariables source)
      && null (SharedType.typeConstraints source)
  closedContextFreeForall _ = False
  groundMonotype source =
    null source && not (SharedType.containsForall source)

  rootClassEnvironment = mkQueryClassEnv sClassEnv []
  preparedCheckContext = prepareExpressionCheckContextWithSchemes
    rigidPlan rootClassEnvironment funcs deconss' functionSchemes t

  rootFindExpressionState = FindExpressionsState
    { findSteps = 0
    , findQueuePruned = 0
    , findDepthPruned = 0
    , findIdentifierSpaceExhausted = False
    , findBindingUsages = M.empty
    , findQueue = rootQueue
    , findEagerCaseQueue = if protectRecursiveCases then rootQueue else Q.empty
    , findNextCasePolicy = OptionalRecursiveCases
    }
  rootQueue = Q.singleton (0, False)
    $ Unfinished $ ScheduledNode rootGoal rootSearchNode
  t = forallify rawType
  -- One recursive input does not cause the Cartesian starvation addressed
  -- here. Keep that established single-frontier schedule exactly, including
  -- callers whose queue cannot accommodate two roots. Only actual function
  -- domains (and their finite tuple fields) can introduce recursive inputs;
  -- an arbitrary type application argument is not a value in lexical scope.
  protectRecursiveCases =
    multiPM && maybe True (>= 2) maxQueueSize && hasJointRecursiveInputs t
  hasJointRecursiveInputs source = case source of
    TypeForallNative _ _ body -> hasJointRecursiveInputs body
    TypeArrow{} ->
      let (result, parameters) = splitArrowChain source
      in sum (map recursiveInputCount parameters) >= (2 :: Natural)
          || any hasJointRecursiveInputs (result : parameters)
    TypeTuple _ elements -> any hasJointRecursiveInputs elements
    _ -> False
  recursiveInputCount source = case source of
    TypeTuple _ elements -> sum $ map recursiveInputCount elements
    TypeArrow{} -> 0
    TypeForallNative{} -> 0
    _ -> if any (matchesRecursiveInput source) deconss' then 1 else 0
  matchesRecursiveInput source (DeconstructorBinding matchParam _ True) =
    case typeConstructorHead source of
      Just sourceHead ->
        Just sourceHead == typeConstructorHead matchParam
          && isJust (unifyRight source matchParam)
      Nothing -> False
  matchesRecursiveInput _ _ = False
  rootGoal = TGoal
    (VarBinding 0 t) initialScopeId OpenLeadingForalls AllowTupleTree []
  rootSearchNode = SearchNode
    { nodeGoals           = Seq.empty
    , nodeConstraintGoals = []
    , nodeProvidedScopes  = initialScopes
    , nodeVarUses         = IntMap.empty
    , nodeFunctions       = funcs
    , nodeFunctionSchemes = functionSchemes
    , nodeVisibleTypeCandidates = properTypeCandidates
    , nodeProviderInstantiationCandidates = providerCandidates
    , nodeProviderInstantiationAssignments = providerAssignments
    , nodeAggregateDonations = M.empty
    , nodeDeconstructors  = deconss
    , nodeQueryClassEnv   = rootClassEnvironment
    , nodeExpression      = case ranking of
        SharedQuality.LegacyCandidateRanking -> ExpHole 0
        _ -> enableExpressionQualityCache $ ExpHole 0
      -- The root goal and expression already own hole 0.
    , nodeNextVarId       = 1
    , nodeFlexibleIds     = supplyFromIdentifiers
        $ IntSet.toAscList $ flexibleIdentifiers t
    , nodeRigidInstantiations = rigidInstantiations rigidPlan
    , nodeRigidPlan       = rigidPlan
    , nodeRigidScope      = emptyRigidScope
    , nodeDepth           = 0.0
    , nodeLastStepBinding = Nothing
    }
  transformSolutions :: [ReadySolution] -> FindExpressionsState -> EngineBatch
  transformSolutions potentialSolutions searchState = SharedSearch.SearchBatch
      progress
      (ExferenceBatchMetadata
        { exferenceBindingUsages = newBindingUsages
        , exferenceQueuePruned = totalQueuePruned
        , exferenceDepthPruned = totalDepthPruned
        })
      (SharedQuality.rankCandidatesByQuality ranking providerQualityCost
        (\(ValidatedEngineCandidate expression _ _ _) ->
          toGeneratedExpression expression)
      [ ValidatedEngineCandidate
          e
          remainingConstraints
          (ExferenceStats n' d
            $ SharedCount.saturatingNaturalToInt
            $ frontierSize searchState)
          typedGraphAvailability
      | ReadySolution originStep solutionIndex solution <- potentialSolutions
      , let contxt = nodeQueryClassEnv solution
      , remainingScopedConstraints <- maybeToList
          $ resolveScopedConstraints filterUnresolved contxt
          $ nodeConstraintGoals solution
      , let remainingConstraints = scopedConstraintObligations
              remainingScopedConstraints
      , null $ escapingRigidConstraints
          (nodeRigidScope solution) remainingConstraints
        -- if allowConstraints, unresolved constraints are allowed;
        -- otherwise we discard this solution.
      , allowConstraints || null remainingConstraints
      , let unusedVarCount = getUnusedVarCount solution
        -- Apply the unused-variable policy to the search derivation before
        -- normalization. Certified dead-code removal can subsequently erase
        -- a use; it must not fabricate use evidence for a rejected derivation.
      , allowUnused || unusedVarCount==0
      , rawExpression <- [nodeExpression solution]
      , (e, checkedEvidence) <- maybeToList $ checkedSimplification
          (nodeRigidScope solution) remainingConstraints rawExpression
      , let typedGraphAvailability = checkedExpressionTermGraph
              (candidateIdentity originStep solutionIndex) checkedEvidence
      , let historicalScore = sumScores
              [ nodeDepth solution
              , multiplyScore (heuristics_unusedVar heuristics)
                  $ fromIntegral unusedVarCount
              , multiplyScore (heuristics_solutionLength heuristics)
                  $ fromIntegral (SharedGenerated.expressionSizeNatural
                      $ toGeneratedExpression e)
              ]
            d = normalizePenalty $ case ranking of
              SharedQuality.LegacyCandidateRanking -> historicalScore
              _ -> fromInteger $ toInteger $ expressionQualityCost
                ranking providerQualityCost e
      ])
    where
      n' = findSteps searchState
      totalQueuePruned = findQueuePruned searchState
      totalDepthPruned = findDepthPruned searchState
      identifierSpaceExhausted = findIdentifierSpaceExhausted searchState
      newBindingUsages = findBindingUsages searchState
      frontierEmpty = frontierSize searchState == 0
      progress
        | frontierEmpty
        , reason : remaining <- truncationReasons =
            SharedSearch.Completed $ SharedSearch.Truncated
              $ reason :| remaining
        | frontierEmpty =
            SharedSearch.Completed SharedSearch.Finished
        | n' >= maxSteps =
            SharedSearch.Completed $ SharedSearch.Truncated
              $ SharedSearch.StepLimitReached :| truncationReasons
        | otherwise = SharedSearch.Continuing
      truncationReasons =
        [ SharedSearch.IdentifierSpaceExhausted
        | identifierSpaceExhausted
        ] ++
        naturalPruningReasons totalQueuePruned totalDepthPruned
      -- Validate the exact tree returned to callers. The independent checker
      -- owns type reconstruction, local scope, and generated syntax together;
      -- repeating one of those tree traversals here would let the two result
      -- boundaries drift again. The raw term remains a safe fallback, but it
      -- too must pass that complete checker independently.
      checkedSimplification rigidScope constraints rawExpression = do
        normalized <- inlineVisibleTypeApplicationAliases rawExpression
        case preparedCheckContext of
          Left _ -> Nothing
          Right context -> firstChecked rigidScope context $ candidates normalized
       where
        candidates normalized = L.nub
          $ reduced ++ [simplifyExpression normalized, normalized]
         where
          reduced = case ranking of
            SharedQuality.LegacyCandidateRanking -> []
            _ -> let reducedExpression =
                       reduceKnownConstructorCases safeConstructorArity normalized
                 in [simplifyExpression reducedExpression, reducedExpression]
        -- Only explicit source evaluation metadata certifies non-strict
        -- fields. Nullary constructors require no such field authority;
        -- boxed tuples are also recognized intrinsically by the reducer.
        safeConstructorArity name = M.lookup name safeConstructorArities
        safeConstructorArities = M.fromList
          [ (constructorName constructor, length $ constructorFields constructor)
          | deconstructor <- deconss
          , constructor <- deconstructorConstructors deconstructor
          , null (constructorFields constructor)
              || constructorFieldsAreNonStrict constructor
          ]
        firstChecked _ _ [] = Nothing
        firstChecked candidateScope context
            (candidate : remainingCandidates) =
          case checkExpressionInContextWithNestedRigidProvenanceEvidence
              context (nestedRigidProvenance candidateScope)
              constraints candidate of
            Right evidence -> case checkedExpressionVisibleInstantiationRepair evidence of
              Nothing -> Just (candidate, evidence)
              Just repaired -> case inlineVisibleTypeApplicationAliases repaired of
                Nothing -> firstChecked candidateScope context remainingCandidates
                Just normalizedRepair -> case
                    checkExpressionInContextWithNestedRigidProvenanceEvidence
                      context (nestedRigidProvenance candidateScope)
                      constraints normalizedRepair of
                  Right repairedEvidence -> Just (normalizedRepair, repairedEvidence)
                  Left _ -> firstChecked candidateScope context remainingCandidates
            Left _ -> firstChecked candidateScope context remainingCandidates
  helper :: FindExpressionsState -> Maybe (EngineBatch, FindExpressionsState)
  helper searchState | findSteps searchState >= maxSteps = Nothing
  helper searchState = runStateT (do
    (casePolicy, entry) <- popBestNode
    n' <- advanceStep
    let
      -- actual work happens in stateStep
      -- Constraint checks are deliberately relaxed only during the configured
      -- warm-up window. Afterwards unresolved constraints are allowed solely
      -- when the caller explicitly requested constrained results.
      relaxConstraints = constraintsRelaxedAtStep
        allowConstraints allowConstraintsStopStep n'
      stepResults = case entry of
        Unfinished (ScheduledNode nextGoal s) -> runStateStep
          stepRoute allocators casePolicy multiPM relaxConstraints heuristics nextGoal s
        Ready _ -> []
      (rNodes, stepIdentifierSpaceExhausted) =
        foldr collectStepResult ([], False) stepResults
      (withinDepth, tooDeep) = partition depthAllowed rNodes
      (potentialSolutions, futures) = classifySearchNodes withinDepth
      discovered = case entry of
        Ready solution -> [solution]
        Unfinished _ ->
          [ReadySolution (n' + 1) index node | (index, node) <- zip [0 ..] potentialSolutions]
      frontierPriority node = normalizePriority $ addPriority
        (rateNode ranking providerQualityCost heuristics node)
        (Priority $ 4.5 * ageFactor (fromIntegral n'))
      ageFactor :: Double -> Double
      ageFactor x
        | x > 900 = 0.0
        | otherwise = let k = 1.111e-3*x in 1 + 2*k**3 - 3*k**2
      ratedFutures =
        [ ( (frontierPriority $ restoreScheduledNode newS, False)
          , Unfinished newS)
        | newS <- futures
        ]
      ratedReady =
        [ ((frontierPriority node, True), Ready solution)
        | solution@(ReadySolution _ _ node) <- discovered
        ]
      depthAllowed node = maybe True (nodeDepth node <=) maxDepth
      collectStepResult result (nodes, exhausted) = case result of
        Right node -> (node : nodes, exhausted)
        Left BranchIdentifierSpaceExhausted -> (nodes, True)
    -- Account for generated branches rather than only nodes eventually popped
    -- from the queue.  This includes applications that immediately solve the
    -- current goal and branches discarded by the configured bounds.
    traverse_ (modify . recordBindingUsage) rNodes
    let !depthDiscarded = SharedCount.naturalLength tooDeep
    modify $ \current -> current
      { findDepthPruned = findDepthPruned current + depthDiscarded
      , findIdentifierSpaceExhausted =
          findIdentifierSpaceExhausted current
            || stepIdentifierSpaceExhausted
      }
    currentState <- gets id
    let queued = caseQueue casePolicy currentState
        maximumLaneSize = caseQueueLimit maxQueueSize casePolicy currentState
    let (admitted, retained, queueDiscarded) = case ranking of
          SharedQuality.LegacyCandidateRanking ->
            let (remaining, discarded) = mergeQueueWithCapacity
                  maximumPQueueSize maximumLaneSize queued ratedFutures
            in (discovered, remaining, discarded)
          _ -> admitReadyFrontier (n' + 1 >= maxSteps) maximumLaneSize queued
            (ratedFutures ++ ratedReady)
    modify $ \current ->
      (setCaseQueue casePolicy retained current)
        { findQueuePruned = findQueuePruned current + queueDiscarded }
    -- The global final step belongs to both lanes. Ready results awaiting
    -- admission in the other lane already consumed their discovery work and
    -- must not disappear merely because its turn would follow the deadline.
    finalReady <- if n' + 1 >= maxSteps
      then do
        current <- gets id
        let otherPolicy = otherCasePolicy casePolicy
            (ready, remaining, discarded) = admitReadyFrontier True
              (caseQueueLimit maxQueueSize otherPolicy current)
              (caseQueue otherPolicy current) []
        modify $ \latest ->
          (setCaseQueue otherPolicy remaining latest)
            { findQueuePruned = findQueuePruned latest + discarded }
        pure ready
      else pure []
    gets $ transformSolutions (admitted ++ finalReady)) searchState

-- Completed branches participate in the same priority frontier as unfinished
-- work. Already-best completions are emitted during the producing step, so
-- no additional step is charged for admission. The retained head is always
-- unfinished. At the final step, known completions are emitted even if their
-- cheaper competitors remain unfinished; exhaustion cannot hide a witness
-- already found within the caller's allowance.
admitReadyFrontier
  :: Bool
  -> Maybe Int
  -> RatedNodes
  -> [((Priority, Bool), FrontierEntry)]
  -> ([ReadySolution], RatedNodes, Natural)
admitReadyFrontier finalStep maximumSize queued newEntries =
  let (combined, representationPruned) = mergeQueueWithCapacity
        maximumPQueueSize Nothing queued newEntries
      (immediate, pending) = if finalStep
        then extractAllReady combined
        else extractLeadingReady combined
      (retained, capacityPruned) = limitQueue maximumSize pending
  in if Q.null retained
      then
        -- A zero-capacity frontier may discard the cheaper unfinished work.
        -- Emit every remaining known completion instead of discarding those
        -- witnesses alongside work which can no longer be explored.
        let (readyAtCapacity, _) = extractAllReady pending
        in ( immediate ++ readyAtCapacity
           , retained
           , representationPruned + capacityPruned
               - SharedCount.naturalLength readyAtCapacity)
      else (immediate, retained, representationPruned + capacityPruned)
 where
  extractLeadingReady queue = case Q.maxView queue of
    Just (Ready solution, remaining) ->
      let (solutions, rest) = extractLeadingReady remaining
      in (solution : solutions, rest)
    _ -> ([], queue)
  extractAllReady queue =
    let (solutions, unfinished) = foldr collect ([], []) $ Q.toDescList queue
    in (solutions, Q.fromList unfinished)
  collect (_, Ready solution) (solutions, unfinished) =
    (solution : solutions, unfinished)
  collect entry@(_, Unfinished _) (solutions, unfinished) =
    (solutions, entry : unfinished)

-- Partition generated nodes while extracting the next goal from every future
-- before it can enter the priority queue. This preserves the historical node
-- order of 'partition' but makes the scheduler invariant structural.
classifySearchNodes :: [SearchNode] -> ([SearchNode], [ScheduledNode])
classifySearchNodes = foldr classify ([], [])
 where
  classify node (solutions, scheduled) = case Seq.viewl $ nodeGoals node of
    Seq.EmptyL -> (node : solutions, scheduled)
    nextGoal Seq.:< remainingGoals ->
      ( solutions
      , ScheduledNode nextGoal (node {nodeGoals = remainingGoals}) : scheduled
      )

-- Rating observes the complete pending goal sequence. Only execution consumes
-- the extracted head.
restoreScheduledNode :: ScheduledNode -> SearchNode
restoreScheduledNode (ScheduledNode nextGoal node) = node
  { nodeGoals = nextGoal Seq.<| nodeGoals node }

-- | Historical status-bearing view of an already checked engine trace.
findExpressions :: CheckedExferenceQuery -> [ExferenceChunkElement]
findExpressions = findExpressionsWithAllocators defaultSearchAllocators

-- | 'findExpressions' with explicit search allocators.  Every engine batch is
-- projected to one t'ExferenceChunkElement', so the batch and candidate order
-- are preserved and exact counts saturate to machine integers.
findExpressionsWithAllocators
  :: SearchAllocators
  -> CheckedExferenceQuery
  -> [ExferenceChunkElement]
findExpressionsWithAllocators allocators' =
  map projectCompatibilityChunk . findEngineBatchesWith allocators'

-- | Internal differential oracle retaining the historical monolithic
-- 'stateStep' dispatch.  It is intentionally absent from the public core
-- facade; production uses 'findExpressionsWithAllocators'.
findExpressionsWithAllocatorsUsingLegacyStateStepForTesting
  :: SearchAllocators
  -> CheckedExferenceQuery
  -> [ExferenceChunkElement]
findExpressionsWithAllocatorsUsingLegacyStateStepForTesting allocators' =
  map projectCompatibilityChunk
    . findEngineBatchesWithStateStepRoute LegacyStateStepAction allocators'

-- | Closed test observation of the exact association retained by the private
-- engine candidate. Unlike either public projector, this reads the typed graph
-- field produced inside 'transformSolutions'.
findEngineCandidatesWithAllocatorsForTesting
  :: SearchAllocators
  -> CheckedExferenceQuery
  -> [(Expression, ExferenceStats, ExferenceTermGraphAvailability)]
findEngineCandidatesWithAllocatorsForTesting allocators' =
  concatMap (map observe . SharedSearch.batchCandidates)
    . findEngineBatchesWith allocators'
 where
  observe (ValidatedEngineCandidate expression _ statistics availability) =
    (expression, statistics, availability)

-- | Typed-candidate counterpart of the legacy differential oracle.  Retaining
-- the private graph association lets engine tests compare candidate identities
-- as well as compatibility expressions and metadata.
findEngineCandidatesWithAllocatorsUsingLegacyStateStepForTesting
  :: SearchAllocators
  -> CheckedExferenceQuery
  -> [(Expression, ExferenceStats, ExferenceTermGraphAvailability)]
findEngineCandidatesWithAllocatorsUsingLegacyStateStepForTesting allocators' =
  concatMap (map observe . SharedSearch.batchCandidates)
    . findEngineBatchesWithStateStepRoute LegacyStateStepAction allocators'
 where
  observe (ValidatedEngineCandidate expression _ statistics availability) =
    (expression, statistics, availability)

projectCompatibilityChunk :: EngineBatch -> ExferenceChunkElement
projectCompatibilityChunk chunk = ExferenceChunkElement
  compatibilityStatus
  (projectCompatibilityBindingUsages
    $ exferenceBindingUsages metadata)
  (map projectCompatibilityCandidate $ SharedSearch.batchCandidates chunk)
 where
  metadata = SharedSearch.batchMetadata chunk
  compatibilityStatus = SearchStatus
    compatibilityCompletion
    (SharedCount.saturatingNaturalToInt $ exferenceQueuePruned metadata)
    (SharedCount.saturatingNaturalToInt $ exferenceDepthPruned metadata)
  compatibilityCompletion = case SharedSearch.batchProgress chunk of
    SharedSearch.Continuing -> SearchRunning
    SharedSearch.Completed SharedSearch.Finished -> SearchExhausted
    SharedSearch.Completed (SharedSearch.Truncated reasons)
      | SharedSearch.IdentifierSpaceExhausted `elem` reasons ->
          SearchIdentifierSpaceExhausted
      | SharedSearch.StepLimitReached `elem` reasons ->
          SearchStepLimitReached
      | otherwise -> SearchPruned

  projectCompatibilityCandidate
    (ValidatedEngineCandidate expression constraints statistics _) =
      (expression, constraints, statistics)

-- | Project exact engine totals into the historical chunk API without
-- allowing a large count to wrap into a misleading non-positive value.
projectCompatibilityBindingUsages
  :: BindingUsages
  -> M.Map QualifiedName Int
projectCompatibilityBindingUsages =
  M.map SharedCount.saturatingNaturalToInt

-- | Validate one query against a sealed environment, then expose its result
-- trace lazily in the common query envelope.  The exact target is excluded
-- before validation so search and the independent candidate checker see the
-- same environment.  The retained rigid-variable plan supplies rendering
-- hints without preparing the query a second time. The opaque hint value must
-- retain the same canonical goal; a value sealed for another local integer
-- namespace is rejected before the lazy trace is exposed.
findTypedQueryResultsInEnvironmentEither
  :: SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> Either ExferenceInputError [ExferenceTypedResult]
findTypedQueryResultsInEnvironmentEither =
  findTypedQueryResultsWithAllocators defaultSearchAllocators

-- | Historical query results are the one-way compatibility projection of the
-- typed result path.  Mapping candidates cannot change the retained evidence,
-- progress, metadata, batch order, or candidate order.
findQueryResultsInEnvironmentEither
  :: SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> Either ExferenceInputError [ExferenceResult]
findQueryResultsInEnvironmentEither target sourceHints environment query =
  projectTypedQueryResults
    $ findTypedQueryResultsInEnvironmentEither
        target sourceHints environment query

-- | Run a query whose options were checked before adapter-specific work.
-- The witness is authoritative: replacing the query field also means this
-- entrance cannot accidentally inspect or trust a second, unchecked copy.
-- This operation is exported only from the Cabal-private implementation
-- module and therefore does not weaken the public checked core boundary.
findTypedQueryResultsInEnvironmentWithCheckedOptions
  :: SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> CheckedExferenceOptions
  -> Either ExferenceInputError [ExferenceTypedResult]
findTypedQueryResultsInEnvironmentWithCheckedOptions =
  findTypedQueryResultsInEnvironmentWithCheckedOptionsAndEvidence
    M.empty M.empty

-- | Historical projection of
-- 'findTypedQueryResultsInEnvironmentWithCheckedOptions': the same lazy
-- trace with the typed graph result dropped from every candidate.
findQueryResultsInEnvironmentWithCheckedOptions
  :: SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> CheckedExferenceOptions
  -> Either ExferenceInputError [ExferenceResult]
findQueryResultsInEnvironmentWithCheckedOptions
    target sourceHints environment query checkedOptions =
  projectTypedQueryResults
    $ findTypedQueryResultsInEnvironmentWithCheckedOptions
        target sourceHints environment query checkedOptions

-- | Run a query with an adapter-checked, provider-local proper-type candidate
-- map.  This entrance is Cabal-private: stable adapters establish kind and
-- closure before any value can reach the raw search engine.
findTypedQueryResultsInEnvironmentWithCheckedOptionsAndCandidates
  :: M.Map QualifiedName [HsType]
  -> SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> CheckedExferenceOptions
  -> Either ExferenceInputError [ExferenceTypedResult]
findTypedQueryResultsInEnvironmentWithCheckedOptionsAndCandidates candidates =
  findTypedQueryResultsInEnvironmentWithCheckedOptionsAndEvidence
    candidates M.empty

-- | Run a query with adapter-checked exact provider assignments. This private
-- entrance preserves each ordered vector and keeps the historical flat
-- candidate API on its unchanged search path.
findTypedQueryResultsInEnvironmentWithCheckedOptionsAndAssignments
  :: M.Map QualifiedName [[HsType]]
  -> SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> CheckedExferenceOptions
  -> Either ExferenceInputError [ExferenceTypedResult]
findTypedQueryResultsInEnvironmentWithCheckedOptionsAndAssignments assignments =
  findTypedQueryResultsInEnvironmentWithCheckedOptionsAndEvidence
    M.empty assignments

findTypedQueryResultsInEnvironmentWithCheckedOptionsAndEvidence
  :: M.Map QualifiedName [HsType]
  -> M.Map QualifiedName [[HsType]]
  -> SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> CheckedExferenceOptions
  -> Either ExferenceInputError [ExferenceTypedResult]
findTypedQueryResultsInEnvironmentWithCheckedOptionsAndEvidence
    candidates assignments =
  findTypedQueryResultsWithCheckedOptionsAndAllocators
    defaultSearchAllocators candidates assignments

-- | 'findTypedQueryResultsInEnvironmentEither' with explicit search
-- allocators; the query's search options are checked here first.
-- The allocator-parametric form is an internal test seam for exercising
-- finite identifier exhaustion.  Keeping preparation here guarantees that
-- production and those tests share the exact one-validation result path.
findTypedQueryResultsWithAllocators
  :: SearchAllocators
  -> SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> Either ExferenceInputError [ExferenceTypedResult]
findTypedQueryResultsWithAllocators
    allocators' target sourceHints environment query = do
  checkedOptions <- checkExferenceOptions $ querySearchOptions query
  findTypedQueryResultsWithCheckedOptionsAndAllocators
    allocators' M.empty M.empty target sourceHints environment query checkedOptions

-- | Historical projection of 'findTypedQueryResultsWithAllocators': the same
-- lazy trace with the typed graph result dropped from every candidate.
findQueryResultsWithAllocators
  :: SearchAllocators
  -> SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> Either ExferenceInputError [ExferenceResult]
findQueryResultsWithAllocators
    allocators' target sourceHints environment query =
  projectTypedQueryResults
    $ findTypedQueryResultsWithAllocators
        allocators' target sourceHints environment query

findTypedQueryResultsWithCheckedOptionsAndAllocators
  :: SearchAllocators
  -> M.Map QualifiedName [HsType]
  -> M.Map QualifiedName [[HsType]]
  -> SharedGenerated.DefinitionName
  -> ExferenceSourceTypeVariableHints
  -> ExferenceEnvironment
  -> ExferenceQuery
  -> CheckedExferenceOptions
  -> Either ExferenceInputError [ExferenceTypedResult]
findTypedQueryResultsWithCheckedOptionsAndAllocators
    allocators' candidates assignments target sourceHints environment query
      checkedOptions = do
  checked@(CheckedExferenceQuery _ checkedQuery _ _ rigidPlan) <-
    prepareExferenceQueryWithCheckedOptionsAndEvidence
      environment checkedOptions candidates assignments queryWithTargetExcluded
  -- The opaque value is paired with the exact canonical goal for which its
  -- spelling scope was checked. Stable adapters retarget it only while
  -- performing origin-safe synonym elaboration; direct core callers cannot
  -- accidentally reuse a same-numbered hint with an unrelated query.
  typeHints <- either
    (Left . InvalidSourceTypeVariableHints)
    Right
    $ typeVariableHintsWithPlan
        (queryGoalType checkedQuery) rigidPlan sourceHints
  pure $ map (projectTypedQueryResult target typeHints)
    $ findEngineBatchesWith allocators' checked
 where
  queryWithTargetExcluded = query
    { queryExcludedBindings = S.insert
        (SharedGenerated.definitionName target)
        (queryExcludedBindings query)
    }

-- Keep this projection lazy in both the chunk and candidate dimensions.  The
-- shared smart constructor observes only whether the candidate list is empty,
-- so it neither invents logical evidence nor evaluates the candidate tail.
projectTypedQueryResult
  :: SharedGenerated.DefinitionName
  -> ExferenceTypeVariableHints
  -> EngineBatch
  -> ExferenceTypedResult
projectTypedQueryResult target typeHints =
  SharedQuery.queryResultFromCandidates
    . fmap projectCandidate
 where
  projectCandidate
      (ValidatedEngineCandidate candidateExpression constraints statistics
        availability) =
    SharedTypedCandidate.mkCertificateCapableTypedCandidate
      (projectValidatedCandidate
        target typeHints candidateExpression constraints statistics)
      (case availability of
        ExferenceTermGraphUnavailable absence -> Left absence
        ExferenceTermGraphAvailable graph -> Right $ Left graph
        ExferenceTermGraphAssociated checked -> Right $ Right checked)

-- | Project a typed query result without observing its graph result.  This is
-- the sole canonical-to-legacy candidate edge.
projectQueryResult
  :: SharedGenerated.DefinitionName
  -> ExferenceTypeVariableHints
  -> EngineBatch
  -> ExferenceResult
projectQueryResult target typeHints =
  SharedTypedCandidate.typedQueryResultCompatibility
    . projectTypedQueryResult target typeHints

projectTypedQueryResults
  :: Either ExferenceInputError [ExferenceTypedResult]
  -> Either ExferenceInputError [ExferenceResult]
projectTypedQueryResults = fmap
  $ map SharedTypedCandidate.typedQueryResultCompatibility

-- | Closed observations for the typed result boundary.  The three source
-- batches poison, respectively, the candidate head, graph result, and mapped
-- candidate tail so the test proves each public projection demands only its
-- own selected value.
typedQueryProjectionStrictnessForTesting
  :: SharedGenerated.DefinitionName
  -> ExferenceTypeVariableHints
  -> ( Bool
     , SharedSearch.Progress
     , ExferenceBatchMetadata
     , SharedGenerated.DefinitionName
     , Bool
     )
typedQueryProjectionStrictnessForTesting target typeHints =
  ( SharedQuery.resultEvidence poisonedResult
      == SharedQuery.ValidatedCandidates
  , SharedSearch.batchProgress $ SharedQuery.resultSearch poisonedResult
  , SharedSearch.batchMetadata $ SharedQuery.resultSearch poisonedResult
  , SharedGenerated.clauseName
      $ SharedCandidate.candidateOutput compatibilityCandidate
  , fallbackObserved
  )
 where
  metadata = ExferenceBatchMetadata M.empty 2 3
  poisonedResult = projectTypedQueryResult target typeHints
    $ SharedSearch.SearchBatch SharedSearch.Continuing metadata
      ( error "typed query projection forced a candidate head"
      : error "typed query projection forced a candidate tail"
      )
  expression = ExpLambda 1 (TypeVar 0) (ExpVar 1 $ TypeVar 0)
  compatibilityResult = projectTypedQueryResult target typeHints
    $ SharedSearch.SearchBatch SharedSearch.Continuing metadata
      ( ValidatedEngineCandidate expression [] (ExferenceStats 1 0 0)
          (error "typed compatibility forced graph availability")
      : error "typed compatibility forced the mapped candidate tail"
      )
  compatibilityCandidate = SharedTypedCandidate.typedCandidateCompatibility
    $ firstTypedCandidate compatibilityResult
  fallbackResult = projectTypedQueryResult target typeHints
    $ SharedSearch.SearchBatch SharedSearch.Continuing metadata
      ( ValidatedEngineCandidate
          (error "typed graph lookup forced compatibility expression")
          [] (ExferenceStats 1 0 0)
          (ExferenceTermGraphUnavailable TermGraphEvidenceMismatch)
      : error "typed graph lookup forced the mapped candidate tail"
      )
  fallbackObserved = case SharedTypedCandidate.typedCandidateTermGraph
      $ firstTypedCandidate fallbackResult of
    Left TermGraphEvidenceMismatch -> True
    _ -> False
  firstTypedCandidate result = case SharedSearch.batchCandidates
      $ SharedQuery.resultSearch result of
    candidate : _ -> candidate
    [] -> error "typed query projection lost a present candidate"

-- | Closed strictness probe compiled only by @exference-engine-tests@. It
-- returns observations rather than accepting raw candidates, so the test seam
-- cannot bypass the checked engine-candidate constructor.
queryProjectionStrictnessForTesting
  :: SharedGenerated.DefinitionName
  -> ExferenceTypeVariableHints
  -> ( Bool
     , SharedSearch.Progress
     , ExferenceBatchMetadata
     , SharedGenerated.DefinitionName
     )
queryProjectionStrictnessForTesting target typeHints =
  ( SharedQuery.resultEvidence poisonedResult
      == SharedQuery.ValidatedCandidates
  , SharedSearch.batchProgress $ SharedQuery.resultSearch poisonedResult
  , SharedSearch.batchMetadata $ SharedQuery.resultSearch poisonedResult
  , SharedGenerated.clauseName
      $ SharedCandidate.candidateOutput firstCandidate
  )
 where
  metadata = ExferenceBatchMetadata M.empty 2 3
  poisonedResult = projectQueryResult target typeHints
    $ SharedSearch.SearchBatch SharedSearch.Continuing metadata
      ( error "query projection forced a candidate head"
      : error "query projection forced a candidate tail"
      )
  expression = ExpLambda 1 (TypeVar 0) (ExpVar 1 $ TypeVar 0)
  validResult = projectQueryResult target typeHints
    $ SharedSearch.SearchBatch SharedSearch.Continuing metadata
      ( ValidatedEngineCandidate expression [] (ExferenceStats 1 0 0)
          (error "query projection forced typed graph availability")
      : error "query projection forced the mapped candidate tail"
      )
  firstCandidate = case SharedSearch.batchCandidates
      $ SharedQuery.resultSearch validResult of
    candidate : _ -> candidate
    [] -> error "query projection lost a present candidate"

-- | Compatibility counterpart to 'queryProjectionStrictnessForTesting'. The
-- observations force the projected candidate head while the retained typed
-- graph field and candidate tail remain poisoned.
compatibilityProjectionStrictnessForTesting
  :: (SearchStatus, Expression, [HsConstraint], ExferenceStats)
compatibilityProjectionStrictnessForTesting =
  ( chunkStatus poisonedChunk
  , observedExpression
  , observedConstraints
  , observedStatistics
  )
 where
  metadata = ExferenceBatchMetadata M.empty 2 3
  poisonedChunk = projectCompatibilityChunk
    $ SharedSearch.SearchBatch SharedSearch.Continuing metadata
      ( error "compatibility projection forced a candidate head"
      : error "compatibility projection forced a candidate tail"
      )
  expression = ExpLambda 1 (TypeVar 0) (ExpVar 1 $ TypeVar 0)
  validChunk = projectCompatibilityChunk
    $ SharedSearch.SearchBatch SharedSearch.Continuing metadata
      ( ValidatedEngineCandidate expression [] (ExferenceStats 1 0 0)
          (error "compatibility projection forced typed graph availability")
      : error "compatibility projection forced the mapped candidate tail"
      )
  (observedExpression, observedConstraints, observedStatistics) =
    case chunkElements validChunk of
      candidate : _ -> candidate
      [] -> error "compatibility projection lost a present candidate"

-- | Whether unresolved type-class constraints are tolerated at the given
-- step: always when constrained results were requested, and otherwise only
-- while the step number has not exceeded the configured warm-up stop step
-- (the stop step itself is still relaxed).
constraintsRelaxedAtStep :: Bool -> Int -> Int -> Bool
constraintsRelaxedAtStep allowConstraints stopStep currentStep =
  allowConstraints || currentStep <= stopStep

-- | Validate a compatibility input eagerly and retain every fallible value
-- needed by its lazy trace.  The validation order is the historical public
-- error precedence; constructing the checked artifact adds no later checks.
prepareExferenceInput
  :: ExferenceInput
  -> Either ExferenceInputError CheckedExferenceQuery
prepareExferenceInput input = do
  -- Keep this order identical to the historical guard chain.  Besides being
  -- more useful to callers, the first error is part of the compatibility API.
  validateQueryLimits query
  validateEnvironmentDuplicates environment
  validateQueryHeuristics query
  validateEnvironmentRatingsAndSyntax environment
  validateQueryInputWidths environment query
  validateEnvironmentMonotypeWidths environment
  validateEnvironmentConstraintWidths environment
  validateQueryClassConstraints environment query
  validateBindingClassConstraints environment
  validateInputTypes
    $ [queryGoalType query]
    ++ environmentBindingMonotypes environment
    ++ concatMap (constraint_params . snd) allConstraints
  validateEnvironmentDeconstructors environment
  let canonicalEnvironment = canonicalizeEnvironment environment
      canonicalQuery = canonicalizeQuery query
      rigidContext = mkRigidInstantiationContext canonicalEnvironment
  rigidPlan <- prepareRigidInstantiation rigidContext canonicalQuery
  pure $ CheckedExferenceQuery
    (ExferenceEnvironment canonicalEnvironment rigidContext M.empty)
    canonicalQuery
    M.empty
    M.empty
    rigidPlan
 where
  environment = inputEnvironment input
  query = inputQuery input
  allConstraints = queryConstraints query
    ++ environmentConstraints environment

-- | Compatibility projection retaining the established validation API.
validateExferenceInput :: ExferenceInput -> Either ExferenceInputError ()
validateExferenceInput input = void $ prepareExferenceInput input

-- | Seal a reusable environment after validating everything independent of a
-- particular query.  The abstract result can subsequently be paired with many
-- cheap query validations without repeating these checks.
mkExferenceEnvironment
  :: EnvDictionary
  -> Either ExferenceInputError ExferenceEnvironment
mkExferenceEnvironment environment = do
  validateExferenceEnvironment environment
  let canonicalEnvironment = canonicalizeEnvironment environment
  pure $ ExferenceEnvironment canonicalEnvironment
    (mkRigidInstantiationContext canonicalEnvironment) M.empty

-- | Seal a stable environment together with the exact specified schemes from
-- the same checked declaration inventory.  The ordinary compatibility
-- constructor cannot recover binder order from a flattened t'FunctionBinding'
-- and therefore leaves this map empty.  This Cabal-private entrance is used by
-- the parser-neutral Djex session, which owns that provenance already.
mkExferenceEnvironmentWithSchemes
  :: EnvDictionary
  -> M.Map QualifiedName HsType
  -> Either ExferenceInputError ExferenceEnvironment
mkExferenceEnvironmentWithSchemes environment schemes = do
  validateExferenceEnvironment environment
  validateInputTypes $ M.elems schemes
  case validatePreparedFunctionSchemes
      (environmentFunctions environment) schemes of
    Left name -> Left $ InvalidFunctionScheme name
    Right () -> Right ()
  let canonicalEnvironment = canonicalizeEnvironment environment
      canonicalSchemes = M.map canonicalize
        schemes
  pure $ ExferenceEnvironment canonicalEnvironment
    (mkRigidInstantiationContext canonicalEnvironment) canonicalSchemes

-- | Whether an exact value binding is available in this sealed search
-- projection.  Stable adapters use this before accepting provider-local
-- evidence, so an excluded or out-of-scope source name cannot donate a type.
exferenceEnvironmentContainsBinding
  :: QualifiedName
  -> ExferenceEnvironment
  -> Bool
exferenceEnvironmentContainsBinding name
    (ExferenceEnvironment environment _ _) = any
      ((== name) . functionName)
      $ environmentFunctions environment

-- | Recover the exact retained leading-forall scheme for one checked global.
-- Stable assignment adapters use this private projection to validate vector
-- arity before search. A present ordinary binding without a retained scheme is
-- deliberately ineligible for visible assignment evidence.
exferenceEnvironmentBindingScheme
  :: QualifiedName
  -> ExferenceEnvironment
  -> Maybe HsType
exferenceEnvironmentBindingScheme name
    (ExferenceEnvironment _ _ schemes) = M.lookup name schemes

-- | Validate the varying part of a search against an already sealed
-- environment and retain its exact rigid-instantiation plan. Excluding
-- bindings only removes capabilities and therefore cannot invalidate the
-- environment.
prepareExferenceQuery
  :: ExferenceEnvironment
  -> ExferenceQuery
  -> Either ExferenceInputError CheckedExferenceQuery
prepareExferenceQuery sealed query = do
  checkedOptions <- checkExferenceOptions $ querySearchOptions query
  prepareExferenceQueryWithCheckedOptions sealed checkedOptions query

-- The checked options replace rather than merely justify the public record
-- field. Thus even a future internal caller cannot validate one value and
-- make search consume another.
prepareExferenceQueryWithCheckedOptions
  :: ExferenceEnvironment
  -> CheckedExferenceOptions
  -> ExferenceQuery
  -> Either ExferenceInputError CheckedExferenceQuery
prepareExferenceQueryWithCheckedOptions
    sealed checkedOptions =
  prepareExferenceQueryWithCheckedOptionsAndEvidence
    sealed checkedOptions M.empty M.empty

prepareExferenceQueryWithCheckedOptionsAndEvidence
  :: ExferenceEnvironment
  -> CheckedExferenceOptions
  -> M.Map QualifiedName [HsType]
  -> M.Map QualifiedName [[HsType]]
  -> ExferenceQuery
  -> Either ExferenceInputError CheckedExferenceQuery
prepareExferenceQueryWithCheckedOptionsAndEvidence
    sealed@(ExferenceEnvironment environment rigidContext _)
    (CheckedExferenceOptions options) candidates assignments uncheckedQuery = do
  validateQueryInputWidths environment query
  validateQueryClassConstraints environment query
  validateInputTypes
    $ queryGoalType query
    : concatMap (constraint_params . snd) constraints
  let canonicalQuery = canonicalizeQuery query
  rigidPlan <- prepareRigidInstantiation rigidContext canonicalQuery
  pure $ CheckedExferenceQuery
    sealed canonicalQuery candidates assignments rigidPlan
 where
  query = uncheckedQuery {querySearchOptions = options}
  constraints = queryConstraints query

-- | Compatibility projection retaining the established validation API.
validateExferenceQuery
  :: ExferenceEnvironment
  -> ExferenceQuery
  -> Either ExferenceInputError ()
validateExferenceQuery environment query =
  void $ prepareExferenceQuery environment query

-- | Validate every search-control field once and retain the exact accepted
-- record for later preparation. This remains package-private; public core
-- callers continue through a checked search.
checkExferenceOptions
  :: ExferenceOptions
  -> Either ExferenceInputError CheckedExferenceOptions
checkExferenceOptions options = do
  validateOptionsLimits options
  validateOptionsHeuristics options
  pure $ CheckedExferenceOptions options

validateExferenceEnvironment
  :: EnvDictionary
  -> Either ExferenceInputError ()
validateExferenceEnvironment environment = do
  validateEnvironmentDuplicates environment
  validateEnvironmentRatingsAndSyntax environment
  validateEnvironmentMonotypeWidths environment
  validateEnvironmentConstraintWidths environment
  validateBindingClassConstraints environment
  validateInputTypes
    $ environmentBindingMonotypes environment
    ++ concatMap (constraint_params . snd) constraints
  validateEnvironmentDeconstructors environment
 where
  constraints = environmentConstraints environment

validateQueryLimits
  :: ExferenceQuery
  -> Either ExferenceInputError ()
validateQueryLimits = validateOptionsLimits . querySearchOptions

validateOptionsLimits
  :: ExferenceOptions
  -> Either ExferenceInputError ()
validateOptionsLimits options
  | exferenceMaximumSteps options <= 0 =
      Left $ InvalidMaxSteps $ exferenceMaximumSteps options
  | exferenceConstraintDeferralSteps options < 0 =
      Left $ InvalidConstraintDeferralSteps
        $ exferenceConstraintDeferralSteps options
  | Just limit <- exferenceMaximumQueueSize options, limit < 0 =
      Left $ InvalidMaxQueueSize limit
  | Just limit <- exferenceMaximumDepth options, not $ isFinitePenalty limit =
      Left $ InvalidMaxDepth limit
  | otherwise = Right ()

validateEnvironmentDuplicates
  :: EnvDictionary
  -> Either ExferenceInputError ()
validateEnvironmentDuplicates environment = case
    validateEnvironmentBindingIdentities environment of
  Right () -> Right ()
  Left failure -> Left $ case failure of
    DuplicateDeconstructorIdentities names ->
      DuplicateDeconstructorNames names
    DuplicateConstructorIdentities names ->
      DuplicateConstructorNames names
    DuplicateFunctionIdentities names ->
      DuplicateFunctionNames names

validateQueryHeuristics
  :: ExferenceQuery
  -> Either ExferenceInputError ()
validateQueryHeuristics = validateOptionsHeuristics . querySearchOptions

validateOptionsHeuristics
  :: ExferenceOptions
  -> Either ExferenceInputError ()
validateOptionsHeuristics options
  | Just (field, invalid) <- find (not . isFinitePenalty . snd)
      (heuristicFields $ exferenceHeuristics options) =
      Left $ InvalidHeuristic field invalid
  | otherwise = Right ()

validateEnvironmentRatingsAndSyntax
  :: EnvDictionary
  -> Either ExferenceInputError ()
validateEnvironmentRatingsAndSyntax environment =
  case validateEnvironmentBindingRatings environment of
    Left (NonFiniteFunctionRating name penalty) ->
      Left $ InvalidHeuristic (show name) penalty
    Right () -> case validateEnvironmentBindingSyntax environment of
      Left (InvalidFunctionBindingSyntax name syntaxError) ->
        Left $ InvalidGeneratedBinding name syntaxError
      Left (InvalidConstructorBindingSyntax name syntaxError) ->
        Left $ InvalidGeneratedConstructor name syntaxError
      Right () -> Right ()

-- Width preflights run before forall discovery because both tuple elements and
-- class arguments are public lazy lists. They own only the first impossible
-- cell; complete native-type and class validation remains in the established
-- later phases. A width error intentionally wins over an error hidden beyond
-- that impossible cell, since discovering whether such a tail is finite would
-- itself require the nontermination this boundary prevents.
validateQueryInputWidths
  :: EnvDictionary
  -> ExferenceQuery
  -> Either ExferenceInputError ()
validateQueryInputWidths environment query = validateTypeInputWidths
  environment QueryConstraint $ queryGoalType query

validateEnvironmentMonotypeWidths
  :: EnvDictionary
  -> Either ExferenceInputError ()
validateEnvironmentMonotypeWidths environment = do
  traverse_ validateFunctionWidth $ environmentFunctions environment
  traverse_ validateDeconstructorWidth $ environmentDeconstructors environment
 where
  validateFunctionWidth binding = validateTypeInputWidths environment
    (BindingConstraint $ functionName binding)
    $ functionBindingType binding

  validateDeconstructorWidth binding = do
    validateTypeInputWidths environment inputSite
      $ deconstructorInput binding
    traverse_ validateConstructor $ deconstructorConstructors binding
   where
    inputSite = maybe QueryConstraint BindingConstraint
      $ typeConstructorHead $ deconstructorInput binding
    validateConstructor constructor = traverse_
      (validateTypeInputWidths environment
        $ BindingConstraint $ constructorName constructor)
      $ constructorFields constructor

validateEnvironmentConstraintWidths
  :: EnvDictionary
  -> Either ExferenceInputError ()
validateEnvironmentConstraintWidths environment = traverse_
  (uncurry $ validateConstraintInputWidths environment)
  $ environmentConstraints environment

validateConstraintInputWidths
  :: EnvDictionary
  -> ConstraintSite
  -> HsConstraint
  -> Either ExferenceInputError ()
validateConstraintInputWidths environment site constraint = do
  validateKnownArity environment site constraint
  traverse_ validateArgument $ constraint_params constraint
 where
  validateArgument argument = SharedType.validateTypeWidthsWith
    (InvalidInputType argument . InvalidSynthesisType)
    (validateKnownArity environment site)
    argument

validateTypeInputWidths
  :: EnvDictionary
  -> ConstraintSite
  -> HsType
  -> Either ExferenceInputError ()
validateTypeInputWidths environment site original =
  SharedType.validateTypeWidthsWith
    (InvalidInputType original . InvalidSynthesisType)
    (validateKnownArity environment site)
    original

validateKnownArity
  :: EnvDictionary
  -> ConstraintSite
  -> HsConstraint
  -> Either ExferenceInputError ()
validateKnownArity environment site constraint = either
  (Left . InvalidClassConstraint)
  Right
  $ validateKnownConstraintArityInEnv
      (environmentClasses environment) site constraint

validateQueryClassConstraints
  :: EnvDictionary
  -> ExferenceQuery
  -> Either ExferenceInputError ()
validateQueryClassConstraints environment query =
  case listToMaybe
      [ classError
      | constraint <- typeConstraints $ queryGoalType query
      , Left classError <-
          [validateKnownConstraintInEnv classes QueryConstraint constraint]
      ] of
    Just classError -> Left $ InvalidClassConstraint classError
    Nothing -> Right ()
 where
  classes = environmentClasses environment

validateBindingClassConstraints
  :: EnvDictionary
  -> Either ExferenceInputError ()
validateBindingClassConstraints environment =
  case listToMaybe
      [ classError
      | (site, constraint) <- bindingConstraints
      , Left classError <-
          [validateKnownConstraintInEnv classes site constraint]
      ] of
    Just classError -> Left $ InvalidClassConstraint classError
    Nothing -> Right ()
 where
  classes = environmentClasses environment
  bindingConstraints =
    [ (BindingConstraint $ functionName binding, constraint)
    | binding <- environmentFunctions environment
    , constraint <- functionConstraints binding
        ++ typeConstraints (functionBindingType binding)
    ] ++
    [ (deconstructorSite deconstructor, constraint)
    | deconstructor <- environmentDeconstructors environment
    , constraint <- typeConstraints $ deconstructorInput deconstructor
    ] ++
    [ (BindingConstraint $ constructorName constructor, constraint)
    | deconstructor <- environmentDeconstructors environment
    , constructor <- deconstructorConstructors deconstructor
    , field <- constructorFields constructor
    , constraint <- typeConstraints field
    ]
  deconstructorSite deconstructor = maybe QueryConstraint BindingConstraint
    $ typeConstructorHead $ deconstructorInput deconstructor

validateInputTypes
  :: [HsType]
  -> Either ExferenceInputError ()
validateInputTypes types = case listToMaybe
    [ (typeExpression, typeError)
    | typeExpression <- types
    , Left typeError <- [toSynthesisType typeExpression]
    ] of
  Just (typeExpression, typeError) ->
    Left $ InvalidInputType typeExpression typeError
  Nothing -> Right ()

validateEnvironmentDeconstructors
  :: EnvDictionary
  -> Either ExferenceInputError ()
validateEnvironmentDeconstructors environment =
  traverse_ validateDeconstructor $ environmentDeconstructors environment
 where
  validateDeconstructor = either
    (Left . projectDeconstructorFailure)
    Right
    . validateDeconstructorBinding

  projectDeconstructorFailure failure = case failure of
    MissingDeconstructorNominalHead input ->
      DeconstructorInputWithoutNominalHead input
    FunctionDeconstructorHead name -> UnsupportedDeconstructorTypeHead name
    UnboundDeconstructorFields typeName constructor variables ->
      UnboundDeconstructorFieldVariables typeName constructor variables

prepareRigidInstantiation
  :: RigidInstantiationContext
  -> ExferenceQuery
  -> Either ExferenceInputError RigidInstantiationPlan
prepareRigidInstantiation context query = either
  (Left . RigidIdentifierExhaustion)
  Right
  $ planRigidInstantiation context [] $ queryGoalType query

inputEnvironment :: ExferenceInput -> EnvDictionary
inputEnvironment input = EnvDictionary
  { environmentFunctions = input_envFuncs input
  , environmentDeconstructors = input_envDeconsS input
  , environmentClasses = input_envClasses input
  }

inputQuery :: ExferenceInput -> ExferenceQuery
inputQuery input = ExferenceQuery
  { queryGoalType = input_goalType input
  , queryExcludedBindings = S.empty
  , querySearchOptions = inputSearchOptions input
  }

-- This is the sole projection from the historical flat compatibility record.
-- Every checked query after this boundary owns the canonical grouped value.
inputSearchOptions :: ExferenceInput -> ExferenceOptions
inputSearchOptions input = ExferenceOptions
  { exferenceAllowUnused = input_allowUnused input
  , exferenceAllowResidualConstraints = input_allowConstraints input
  , exferenceConstraintDeferralSteps = input_allowConstraintsStopStep input
  , exferenceMultiConstructorPatterns = input_multiPM input
  , exferenceMaximumSteps = input_maxSteps input
  , exferenceMaximumQueueSize = input_maxQueueSize input
  , exferenceMaximumDepth = input_maxDepth input
  , exferenceHeuristics = input_heuristicsConfig input
  -- The flat compatibility input predates configurable ranking.
  , exferenceCandidateRanking = SharedQuality.LegacyCandidateRanking
  , exferenceProviderCosts = M.empty
  }

-- Checked values retain the same canonical representation that validation
-- observes.  In particular, saturated function/tuple constructor applications
-- must not survive in a sealed session beside equal structural nodes.
canonicalizeQuery :: ExferenceQuery -> ExferenceQuery
canonicalizeQuery query = query
  { queryGoalType = SharedType.canonicalizeType $ queryGoalType query
  }

canonicalizeEnvironment :: EnvDictionary -> EnvDictionary
canonicalizeEnvironment environment = environment
  { environmentFunctions = map canonicalizeFunctionBinding
      $ environmentFunctions environment
  , environmentDeconstructors = map canonicalizeDeconstructorBinding
      $ environmentDeconstructors environment
  }

canonicalizeFunctionBinding :: FunctionBinding -> FunctionBinding
canonicalizeFunctionBinding = mapFunctionBindingTypes canonicalize

canonicalizeDeconstructorBinding
  :: DeconstructorBinding
  -> DeconstructorBinding
canonicalizeDeconstructorBinding = mapDeconstructorBindingTypes canonicalize

canonicalize :: HsType -> HsType
canonicalize = SharedType.canonicalizeType

-- Binding monotypes only: constraint argument types are validated beside
-- their sites through 'environmentConstraints', unlike the rigid planner's
-- complete environment scan.
environmentBindingMonotypes :: EnvDictionary -> [HsType]
environmentBindingMonotypes environment =
  map functionBindingType (environmentFunctions environment)
  ++ map deconstructorBindingType (environmentDeconstructors environment)

queryConstraints :: ExferenceQuery -> [(ConstraintSite, HsConstraint)]
queryConstraints query =
  [ (QueryConstraint, constraint)
  | constraint <- typeConstraints $ queryGoalType query
  ]

-- | Merge a generated frontier without ever overflowing pqueue's internal
-- Int size. The ordinary branch deliberately retains the historical
-- construction and tie behavior. The fallback is reachable in tests through
-- a small injected capacity; production reaches it only at Int-sized
-- representation exhaustion, where it keeps the best representable nodes and
-- reports every omitted node as queue pruning.
mergeQueueWithCapacity
  :: Ord priority
  => Natural
  -> Maybe Int
  -> Q.MaxPQueue priority value
  -> [(priority, value)]
  -> (Q.MaxPQueue priority value, Natural)
mergeQueueWithCapacity requestedCapacity maximumSize queued newEntries
  | combinedSize <= capacity =
      let combined = Q.union queued (Q.fromList newEntries)
      in limitQueue normalizedMaximumSize combined
  | otherwise =
      ( Q.fromList
          $ take (fromIntegral retainedSize)
          $ sortBy descendingPriority
          $ Q.toDescList queued ++ newEntries
      , combinedSize - retainedSize
      )
 where
  capacity = min requestedCapacity maximumPQueueSize
  combinedSize = queueSizeNatural queued + SharedCount.naturalLength newEntries
  normalizedMaximumSize = max 0 <$> maximumSize
  configuredCapacity = maybe capacity
    (min capacity . fromIntegral) normalizedMaximumSize
  retainedSize = min combinedSize configuredCapacity
  descendingPriority (left, _) (right, _) = compare right left

limitQueue
  :: Ord priority
  => Maybe Int
  -> Q.MaxPQueue priority value
  -> (Q.MaxPQueue priority value, Natural)
limitQueue Nothing queue = (queue, 0)
limitQueue (Just maximumSize) queue
  -- A queue already within its bound is returned untouched; rebuilding it
  -- from a sorted list on every step would make each search step cost
  -- O(n log n) whenever a maximum size is configured.
  | queueSize <= retentionLimit = (queue, 0)
  | otherwise =
      ( Q.fromList $ take retentionLimit $ Q.toDescList queue
      , fromIntegral $ queueSize - retentionLimit
      )
 where
  retentionLimit = max 0 maximumSize
  queueSize = Q.size queue

maximumPQueueSize :: Natural
maximumPQueueSize = fromIntegral (maxBound :: Int)

queueSizeNatural :: Q.MaxPQueue priority value -> Natural
queueSizeNatural = fromIntegral . Q.size

-- | Turn the exact queue-pruned and depth-pruned totals into truncation
-- reasons, omitting each reason whose count is zero.  The queue reason, when
-- present, precedes the depth reason.
naturalPruningReasons
  :: Natural
  -> Natural
  -> [SharedSearch.TruncationReason]
naturalPruningReasons queuePruned depthPruned =
  [ SharedSearch.QueueLimitPruned queuePruned
  | queuePruned > 0
  ] ++
  [ SharedSearch.DepthLimitPruned depthPruned
  | depthPruned > 0
  ]

rateNode :: SharedQuality.CandidateRankingPolicy
         -> (SynthesisName.Name -> Natural)
         -> ExferenceHeuristicsConfig -> SearchNode -> Priority
rateNode ranking providerCost h s = priorityFromPenalty $
    addScore historical $ negateScore structural
 where
  historical = addScore
    (negateScore $ addScore (rateGoals h (nodeProvidedScopes s) $ nodeGoals s) $ nodeDepth s)
    (rateUsage h s)
  -- Quality is a heuristic, never a reason to discard a proof or refund work.
  structural = fromInteger $ toInteger $ expressionQualityCost
    ranking providerCost $ nodeExpression s

rateGoals :: ExferenceHeuristicsConfig -> Scopes -> Seq.Seq TGoal -> Penalty
rateGoals h scopes = sumScores . fmap rateGoal
  where
    -- Opening a quantified function exposes the types of its supplied
    -- parameters before arrow introduction has installed them in the scope.
    -- Keep the quantifier's existing estimate through this administrative
    -- phase; after introduction, the actual body and local usage are rated.
    rateGoal (TGoal (VarBinding _ TypeArrow{}) _ ContinueForallIntroduction _ _) =
      heuristics_goalCons h
    -- Monomorphic arrow introduction binds its parameters; it does not
    -- synthesize values of their types. Charging those as constructions can
    -- discard a function-valued fold carrier before any argument is entered.
    -- Preserve the existing estimate when either the goal or its lexical
    -- context is polymorphic: using those parameters can require additional
    -- instantiation search, even when the current result is monomorphic.
    rateGoal (TGoal (VarBinding _ t@TypeArrow{}) scope _ _ givens)
      | not (SharedType.containsForall t)
      , all (all (not . SharedType.containsForall) . constraint_params) givens
      , all monomorphicBinding (scopeGetAllBindings scope scopes) = addScore
          (heuristics_functionGoalTransform h) (typeComplexity h $ fst $ splitArrowChain t)
    rateGoal (TGoal (VarBinding _ t) _ _ _ _) = typeComplexity h t
    monomorphicBinding binding = not $ any SharedType.containsForall $
      varPResult binding : varPParameters binding

-- | Heuristic penalty of a goal type: the configured per-node weights summed
-- over the type's structure, with nested @forall@ types counted as single
-- atoms.  These weights are historically chosen defaults; none has been
-- derived from measurement.
typeComplexity :: ExferenceHeuristicsConfig -> HsType -> Penalty
typeComplexity h = complexity
 where
  complexity TypeVar{} = heuristics_goalVar h
  -- Constants deliberately share the constructor weight.
  complexity TypeConstant{} = heuristics_goalCons h
  complexity TypeCons{} = heuristics_goalCons h
  complexity (TypeArrow parameter result) = sumScores
    [heuristics_goalArrow h, complexity parameter, complexity result]
  complexity (TypeApp function argument) = sumScores
    [heuristics_goalApp h, complexity function, complexity argument]
  -- Reproduce the former left-associated tuple-constructor application one
  -- node at a time. t'Penalty' addition saturates and Double addition is not
  -- associative, so multiplying/grouping equal weights can alter queue order.
  complexity (TypeTuple _ elements) = L.foldl' applyElement
    (heuristics_goalCons h) elements
   where
    applyElement functionCost element = sumScores
      [heuristics_goalApp h, functionCost, complexity element]
  -- Nested quantified values retain one unit of search-heuristic complexity;
  -- structural unification may nevertheless inspect their bodies. The root
  -- prenex wrapper is scheduled at
  -- priority zero and opened separately, so this cost applies to rank-N goals.
  complexity TypeForallNative{} = heuristics_goalCons h

rateUsage :: ExferenceHeuristicsConfig -> SearchNode -> Penalty
rateUsage h = sumScores . map f . IntMap.elems . nodeVarUses where
  f :: Natural -> Penalty
  f 0 = negateScore $ heuristics_tempUnusedVarPenalty h
  f 1 = 0
  f k = negateScore $ multiplyScore
    (fromIntegral (k - 1)) (heuristics_tempMultiVarUsePenalty h)

getUnusedVarCount :: SearchNode -> Natural
getUnusedVarCount = IntMap.foldl' countUnused 0 . nodeVarUses
 where
  countUnused count uses
    | uses == 0 = count + 1
    | otherwise = count

-- Finish an already determined local obligation before interleaving another
-- sibling's construction. Flexible variables in either the goal or its local
-- context can still receive information from siblings, so those groups keep
-- the established deferred order. Keep monomorphic work in that order too:
-- eagerly completing it can crowd out supplied structural instantiations.
-- Focus a group only when its goal or a visible local type contains a forall.
-- This changes only the worklist order: all
-- obligations and ordinary search-step charges remain present.
scheduleKnownGoals :: Scopes -> [TGoal] -> Seq.Seq TGoal -> Seq.Seq TGoal
scheduleKnownGoals scopes goals pending
  | all determined goals && any polymorphic goals = Seq.fromList goals <> pending
  | otherwise = pending <> Seq.fromList goals
 where
  determined goal = case goalBinding goal of
    VarBinding _ source -> closed source
      && all (all closed . constraint_params) (goalGivenConstraints goal)
      && all closedBinding (scopeGetAllBindings (goalScope goal) scopes)
  closed = S.null . freeVars
  closedBinding = all closed . bindingTypes
  bindingTypes binding = varPResult binding : varPParameters binding
  polymorphic goal = case goalBinding goal of
    VarBinding _ source -> any SharedType.containsForall $
      source : concatMap bindingTypes (scopeGetAllBindings (goalScope goal) scopes)

-- One suspended branch-local transformation of the popped search node.  Every
-- sibling action is interpreted against the same immutable input node.
type StepAction = StateT SearchNode SearchBranches ()

-- The independently spelled historical dispatch is retained as a differential
-- oracle.  Production consumes the finite ordered action list.
data StateStepPlan = StateStepPlan
  { plannedLegacyAction :: StepAction
  , plannedOrderedActions :: [StepAction]
  }

runStateStep
  :: StateStepRoute
  -> SearchAllocators
  -> RecursiveCasePolicy
  -> Bool
  -> Bool
  -> ExferenceHeuristicsConfig
  -> TGoal
  -> SearchNode
  -> [Either BranchTruncation SearchNode]
runStateStep route allocators casePolicy multiPM allowConstrs h goal initialNode =
  case route of
    OrderedStateStepActions -> concatMap runAction
      $ stateStepActions allocators casePolicy multiPM allowConstrs h goal initialNode
    LegacyStateStepAction -> runSearchBranches
      $ execStateT (stateStep allocators casePolicy multiPM allowConstrs h goal) initialNode
 where
  runAction action = runSearchBranches $ execStateT action initialNode

-- | Historical monolithic choice dispatch, kept private as the serial oracle
-- used by the engine-test facade.
stateStep
  :: SearchAllocators
  -> RecursiveCasePolicy
  -> Bool
  -> Bool
  -> ExferenceHeuristicsConfig
  -> TGoal
  -> StepAction
stateStep allocators casePolicy multiPM allowConstrs h goal = do
  initialNode <- gets id
  plannedLegacyAction
    $ stateStepPlan allocators casePolicy multiPM allowConstrs h goal initialNode

-- Take one SearchNode and expose its finite ordered sibling actions before any
-- branch-local unification, allocation, substitution, or expression work.
stateStepActions
  :: SearchAllocators
  -> RecursiveCasePolicy
  -> Bool
  -> Bool
  -> ExferenceHeuristicsConfig
  -> TGoal
  -> SearchNode
  -> [StepAction]
stateStepActions allocators casePolicy multiPM allowConstrs h goal initialNode =
  plannedOrderedActions
    $ stateStepPlan allocators casePolicy multiPM allowConstrs h goal initialNode

-- Take one SearchNode, return some amount of sub-SearchNodes. Some returned
-- nodes may in fact be potential solutions that need no further evaluation.
stateStepPlan
  :: SearchAllocators
  -> RecursiveCasePolicy
  -> Bool
  -> Bool
  -> ExferenceHeuristicsConfig
  -> TGoal
  -> SearchNode
  -> StateStepPlan
stateStepPlan allocators casePolicy multiPM allowConstrs h
    (TGoal (VarBinding var goalType) scopeId forallMode tupleMode
      givenConstraints) initialNode =
  let
    -- These shared inputs are snapshots of the exact node from which every
    -- sibling action starts.  Keep them lazy: structural lanes do not need to
    -- inspect constraint state merely because another lane does.
    contxt = nodeQueryClassEnv initialNode
    constraintGoals' = nodeConstraintGoals initialNode

    -- if type is TypeArrow, transform to lambda expression.
    arrowStep
      :: HsType
      -> [VarBinding]
      -> StateT SearchNode SearchBranches ()
    arrowStep g ts
      -- descend until no more TypeArrows, accumulating what is seen.
      | TypeArrow t1 t2 <- g = do
          nextId <- builderAllocVar allocators
          arrowStep t2 (VarBinding nextId t1 : ts)
      -- finally, do the goal/expression transformation.
      | otherwise = do
          nextId <- builderAllocHole allocators
          newScopeId <- builderAddScope allocators scopeId
          modify $ \node -> node
            { nodeExpression = fillExprHole var
                (foldl' (\e (VarBinding v ty) -> ExpLambda v ty e)
                  (ExpHole nextId) ts)
                (nodeExpression node)
            , nodeDepth = addScore (nodeDepth node)
                $ heuristics_functionGoalTransform h
            , nodeLastStepBinding = Nothing
            }
          -- for each parameter introduced in the lambda-expression above,
          -- it may be possible to pattern-match. and pattern-matching
          -- may cause duplication of the goals (e.g. for the different cases
          -- in the pattern match).
          additionalGoals <- addScopePatternMatch
            allocators casePolicy multiPM g nextId newScopeId tupleMode givenConstraints
            $ map splitBinding
            $ reverse ts
          modify $ \node -> node
            { nodeGoals = scheduleKnownGoals (nodeProvidedScopes node)
                additionalGoals (nodeGoals node) }

    -- if type is TypeForall, fix the forall-variables, i.e. invent a fresh
    -- set of constants that replace the relevant forall-variables.
    forallStep
      :: [TVarId]
      -> [HsConstraint]
      -> HsType
      -> StateT SearchNode SearchBranches ()
    forallStep vs cs t = do
      instantiations <- state $ \node ->
        let (current, remaining) = splitRigidInstantiationLayer vs
              $ nodeRigidInstantiations node
        in if map fst current == vs
          then (current, node {nodeRigidInstantiations = remaining})
          else error $ "rigid-instantiation plan disagrees with forall layer: "
            ++ show vs ++ " /= " ++ show (map fst current)
      modify $ \node -> node
        { nodeDepth = addScore (nodeDepth node)
            $ heuristics_functionGoalTransform h
          -- Forall opening reuses the function-goal-transform weight; no
          -- distinct forall-opening heuristic exists.
        , nodeLastStepBinding = Nothing
        }
      let substs = IntMap.fromList
            [ (binder, TypeConstant rigid) | (binder, rigid) <- instantiations]
      modify $ \node -> node
        { nodeGoals = TGoal
            (VarBinding var $ snd $ applySubsts substs t)
            scopeId OpenLeadingForalls tupleMode givenConstraints
            Seq.<| nodeGoals node
        , nodeQueryClassEnv = addQueryClassEnv
            (snd . constraintApplySubsts substs <$> cs)
            (nodeQueryClassEnv node)
        }

    -- Open one nested forall layer with branch-local fresh rigids. Its direct
    -- contexts become lexical givens for this quantified body, rather than
    -- node-wide assumptions which could leak into queued sibling goals.
    -- Unlike the query-root plan, this scope protects every flexible variable
    -- which was allocated before the layer opened. A continuation mode
    -- consumes the complete leading chain without exposing a partially opened
    -- scheme to the ordinary opaque-provider branches.
    introducedForallStep
      :: [TVarId]
      -> [HsConstraint]
      -> HsType
      -> StateT SearchNode SearchBranches ()
    introducedForallStep vs contexts t = do
      plan <- gets nodeRigidPlan
      case searchAllocateNestedRigidInstantiations allocators vs plan of
        Nothing -> lift $ truncateBranch BranchIdentifierSpaceExhausted
        Just (instantiations, nextPlan) -> do
          alive <- gets $ reservedIdentifierSet . nodeFlexibleIds
          let rigids = map snd instantiations
              substitutions = IntMap.fromList
                [ (binder, TypeConstant rigid)
                 | (binder, rigid) <- instantiations]
              openedContexts = map
                (snd . constraintApplySubsts substitutions) contexts
          modify $ \node -> node
            { nodeGoals = TGoal
                (VarBinding var $ snd $ applySubsts substitutions t)
                scopeId ContinueForallIntroduction tupleMode
                (givenConstraints ++ openedContexts)
                Seq.<| nodeGoals node
            , nodeRigidPlan = nextPlan
            , nodeRigidScope = registerRigidScope alive rigids
                $ nodeRigidScope node
            , nodeDepth = addScore (nodeDepth node)
                $ heuristics_functionGoalTransform h
            , nodeLastStepBinding = Nothing
            }

    -- A concrete boxed product is syntax-directed in the same way as an
    -- arrow: its constructor and arity are already fixed by the goal.  Build
    -- the structural tuple directly and schedule one field goal per element.
    -- Tuple constructor bindings remain useful for partial applications and
    -- flexible result goals, but a neutral session no longer needs to invent
    -- an ordinary @(,)@ declaration merely to introduce a known pair.
    tupleStep
      :: [HsType]
      -> StateT SearchNode SearchBranches ()
    tupleStep elements = do
      holes <- forM elements $ const $ builderAllocHole allocators
      let newGoals = zipWith shallowGoal holes elements
          shallowGoal hole element = TGoal
            (VarBinding hole element)
            scopeId
            TryForallIntroduction
            ContinueShallowTuple
            givenConstraints
      modify $ \node -> node
        { nodeExpression = fillExprHole var
            (ExpTuple $ map ExpHole holes)
            (nodeExpression node)
        , nodeGoals = nodeGoals node <> Seq.fromList newGoals
        , nodeDepth = addScore (nodeDepth node)
            $ heuristics_functionGoalTransform h
        , nodeLastStepBinding = Nothing
        }

    -- A nested concrete product tree is just as syntax-directed as one pair.
    -- Materialize every known nonempty boxed-tuple layer in a sibling branch,
    -- leaving holes only at non-tuple leaves. The shallow branch above remains
    -- available because it can still reuse an in-scope value or environment
    -- binding for an inner product instead of constructing that subtree.
    tupleTreeStep
      :: [HsType]
      -> StateT SearchNode SearchBranches ()
    tupleTreeStep elements
      | any isConcreteTuple elements = do
          fields <- mapM buildField elements
          modify $ \node -> node
            { nodeExpression = fillExprHole var
                (ExpTuple $ map fst fields)
                (nodeExpression node)
            , nodeGoals = nodeGoals node <> Seq.fromList
                (mkGoals scopeId givenConstraints $ concatMap snd fields)
            , nodeDepth = addScore (nodeDepth node)
                $ heuristics_functionGoalTransform h
            , nodeLastStepBinding = Nothing
            }
      | otherwise = mzero
     where
      isConcreteTuple (TypeTuple Boxed nested) = not $ null nested
      isConcreteTuple _ = False

      buildField
        :: HsType
        -> StateT SearchNode SearchBranches (Expression, [VarBinding])
      buildField (TypeTuple Boxed nested) | not $ null nested = do
        children <- mapM buildField nested
        pure (ExpTuple $ map fst children, concatMap snd children)
      buildField fieldType = do
        hole <- builderAllocHole allocators
        pure (ExpHole hole, [VarBinding hole fieldType])

    -- Look through later value/forall layers only to choose an instance of
    -- the provider's current leading binders. The ordinary partial-application
    -- rule still has to synthesize every argument and expose each residual
    -- scheme in its real lexical scope. No lookahead equation fills a goal.
    -- Future binders live in a temporary fresh namespace; a selected current
    -- image containing one of them is rejected rather than exported.
    resultDirectedProviderUse
      :: HsType
      -> StateT SearchNode SearchBranches
          ([SharedGenerated.VisibleTypeArgument], HsType, [HsConstraint])
    resultDirectedProviderUse source = do
      case source of
        TypeForallNative{} -> pure ()
        _ -> mzero
      when (null $ SharedType.leadingForallVariables source) mzero
      -- An inapplicable optional branch must not allocate identifiers or add
      -- an exhaustion event to the established ordinary-provider path.
      let (_, _, currentBody) = SharedType.splitLeadingForalls source
      case splitArrowChain currentBody of
        (TypeForallNative{}, _ : _) -> pure ()
        _ -> mzero
      supply <- gets nodeFlexibleIds
      (instantiated, constraints, currentSupply) <- maybe
        (lift $ truncateBranch BranchIdentifierSpaceExhausted) pure $
          instantiateLeadingForallsWith
            (searchAllocateFlexibleNamespace allocators) supply source
      case splitArrowChain instantiated of
        (TypeForallNative{}, _ : _) -> pure ()
        _ -> mzero
      (ultimateResult, futureSupply) <- maybe
        (lift $ truncateBranch BranchIdentifierSpaceExhausted) pure $
          lookAhead currentSupply instantiated
      substitutions <- maybe mzero pure $ unifyShared goalType ultimateResult
      let currentBinders = freeVars instantiated `S.difference` freeVars source
          futureBinders = S.fromList $ IntSet.toList $
            reservedIdentifierSet futureSupply `IntSet.difference`
              reservedIdentifierSet currentSupply
          choices =
            [ (binder, image)
            | binder <- S.toList currentBinders
            , let image = snd $ applySubsts substitutions $ TypeVar binder
            , image /= TypeVar binder
            ]
      unless (any (SharedType.containsForall . snd) choices) mzero
      unless (all (S.null . S.intersection futureBinders . freeVars . snd) choices) mzero
      let projected = IntMap.fromList choices
          selected = snd $ applySubsts projected instantiated
          selectedConstraints = map (snd . constraintApplySubsts projected) constraints
          arguments = selectedPolytypeVisibleArguments source selected
      when (null arguments) mzero
      modify $ \node -> node {nodeFlexibleIds = futureSupply}
      pure (arguments, selected, selectedConstraints)
     where
      lookAhead current sourceType = case fst $ splitArrowChain sourceType of
        residual@TypeForallNative{} -> do
          (opened, _, next) <- instantiateLeadingForallsWith
            (searchAllocateFlexibleNamespace allocators) current residual
          lookAhead next opened
        result -> Just (result, current)

    -- try to resolve the goal by looking at the parameters in scope, i.e.
    -- the parameters accumulated by building the expression so far.
    -- e.g. for (\x -> (_ :: Int)), the goal can be filled by `x` if
    -- `x :: Int`.

    byProvided :: StepAction
    byProvided = do
      provided <- lift . chooseBranches =<< gets
        (scopeGetAllBindings scopeId . nodeProvidedScopes)
      byProvidedFor provided

    byProvidedFor :: VarPBinding -> StepAction
    byProvidedFor provided = do
      let
        provId = varPVariable provided
        provType = varPResult provided
        dependencies = varPParameters provided
        scheme = SharedType.functionType dependencies provType
        exactUnification = unifyShared goalType provType
        useProviderWith = useProviderWithGoalOrder id
        useProviderWithGoalOrder goalOrder
            typeArguments annotation providedType constraints parameters
            unification =
          byGenericUnifyWithGoalOrder goalOrder
            (Right (provId, annotation, typeArguments))
            providedType
            constraints
            parameters
            (heuristics_stepProvidedGood h)
            (heuristics_stepProvidedBad h)
            -- Scoped bindings and the goal inhabit one flexible-variable
            -- namespace. A disjoint unifier would incorrectly accept a
            -- recursive equation such as @a ~ F a@.
            ((\substs -> (substs, substs)) <$> unification)
        useProvider = useProviderWith []
      case classifyProviderUse scheme goalType of
        -- Both semantic roots explicitly request an opaque polytype
        -- comparison. Merely unifying a flexible monotype goal with the
        -- provider atom is not forwarding and must not suppress per-use
        -- instantiation.
        OpaqueProviderForwarding ->
          useProvider scheme provType [] dependencies exactUnification
        -- A context-free provider scheme with no free flexible variables may
        -- be more general than the requested scheme. The shared classifier has
        -- already proved that relation with requested binders rigid, so no
        -- temporary matcher substitution may escape into the live search node.
        -- Record the requested scheme for the independent checker.
        SubsumedProviderForwarding ->
          useProvider goalType goalType [] [] $ Just IntMap.empty
        InstantiateProviderUse ->
          ordinaryInstantiation <|> wholePolytypeInstantiation
            <|> visibleGroundInstantiation <|> resultDirectedInstantiation
            <|> groundedOverappliedInstantiation
            <|> overappliedInstantiation
          where
          -- An argument metavariable may denote the entire polymorphic
          -- value. Keeping this branch beside ordinary per-use elimination
          -- lets a later argument correlate that choice with a rank-N
          -- consumer, as in @apply identity consumeIdentity@. The exact
          -- provider scheme supplies the impredicative type; no quantifier
          -- vocabulary, binder cap, or Cartesian instantiation guesses are
          -- needed. The occurrence retains that scheme so the independent
          -- checker verifies forwarding before considering elimination.
          wholePolytypeInstantiation = case goalType of
            TypeVar{} -> useProvider scheme scheme [] []
              $ unifyShared goalType scheme
            _ -> mzero

          ordinaryInstantiation = do
            supply <- gets nodeFlexibleIds
            case instantiateLeadingForallsWith
                (searchAllocateFlexibleNamespace allocators)
                supply
                scheme of
              Nothing -> lift $ truncateBranch BranchIdentifierSpaceExhausted
              Just (instantiated, constraints, nextSupply) -> do
                modify $ \node -> node {nodeFlexibleIds = nextSupply}
                let (instantiatedResult, instantiatedParameters) =
                      splitArrowChain instantiated
                    unification = unifyShared goalType instantiatedResult
                    typeArguments = case unification of
                      Nothing -> []
                      Just substitutions -> inferredProviderVisibleArguments
                        scheme $ snd $ applySubsts substitutions instantiated
                useProviderWith
                  typeArguments
                  (if null typeArguments then instantiated else scheme)
                  instantiatedResult
                  constraints
                  instantiatedParameters
                  unification

          resultDirectedInstantiation = do
            (arguments, selected, constraints) <- resultDirectedProviderUse scheme
            let (result, parameters) = splitArrowChain selected
            useProviderWith arguments scheme result constraints parameters Nothing

          -- A quantified result may itself be a function which must receive
          -- one more argument to reach this goal. Matching only the unsolved
          -- final result to the goal commits its carrier too early (for
          -- example, a fold can accumulate an endomorphism). This is one
          -- finite sibling, not an enumeration of guessed carrier types.
          -- Its fresh proper-type domain and additional argument goal remain
          -- subject to the ordinary allocators, queue, depth and step bounds.
          groundedOverappliedInstantiation = do
            unless (hasQuantifiedResult scheme) mzero
            domain <- lift $ chooseBranches knownOverapplicationDomains
            overappliedInstantiationAt $ Just domain

          overappliedInstantiation = overappliedInstantiationAt Nothing

          overappliedInstantiationAt knownDomain = do
            unless (hasQuantifiedResult scheme) mzero
            supply <- gets nodeFlexibleIds
            (instantiated, constraints, nextSupply) <- maybe
              (lift $ truncateBranch BranchIdentifierSpaceExhausted) pure $
                instantiateLeadingForallsWith
                  (searchAllocateFlexibleNamespace allocators) supply scheme
            let (result, parameters) = splitArrowChain instantiated
            case result of
              TypeVar identifier
                | identifier `S.notMember` freeVars scheme -> pure ()
              _ -> mzero
            modify $ \node -> node {nodeFlexibleIds = nextSupply}
            (domain, substitutions) <- overapplicationSubstitution result knownDomain
            let selected = snd $ applySubsts substitutions instantiated
                arguments = inferredProviderVisibleArguments scheme selected
            useProviderWithGoalOrder extraArgumentFirst arguments
              (if null arguments then selected else scheme)
              goalType constraints (parameters ++ [domain])
              (Just substitutions)

          -- A separate evidence-directed branch selects either closed
          -- monotypes named by explicit instance heads or checked proper-type
          -- candidates supplied by the query. This mirrors global-provider
          -- instantiation for scoped values while the ordinary branch remains
          -- available and never gains unnecessary visible syntax.
          visibleGroundInstantiation = do
            candidates <- gets nodeVisibleTypeCandidates
            instantiation <- lift . chooseBranches
              $ L.nub
              $ groundProviderInstantiations contxt scheme ++
                candidateProviderInstantiations candidates scheme
            typeArguments <- maybe mzero pure
              $ traverse
                  (either (const Nothing) Just
                    . SharedGenerated.specifiedVisibleTypeArgument)
                  (groundProviderArguments instantiation)
            let (instantiatedResult, instantiatedParameters) =
                  splitArrowChain $ groundProviderType instantiation
            useProviderWith
              typeArguments
              scheme
              instantiatedResult
              (groundProviderConstraints instantiation)
              instantiatedParameters
              (unifyShared goalType instantiatedResult)
        OrdinaryProviderUse ->
          useProvider scheme provType [] dependencies exactUnification

    -- Reuse an in-scope function as a whole before eta-expanding an arrow
    -- goal. Scoped bindings are stored as a final result plus their parameter
    -- spine, so the ordinary provider lane deliberately matches the result
    -- and schedules those parameters as application goals. For an arrow goal,
    -- however, that representation used to hide an exact function-valued
    -- forwarding step and force a factorial search over equivalent eta-long
    -- applications. Keep this lane exact: the shared same-namespace unifier
    -- may refine flexible variables, while the independent checker still
    -- validates the retained declaration annotation on every result.
    byProvidedWhole :: StepAction
    byProvidedWhole = do
      provided <- lift . chooseBranches =<< gets
        (scopeGetAllBindings scopeId . nodeProvidedScopes)
      byProvidedWholeFor provided

    byProvidedWholeFor :: VarPBinding -> StepAction
    byProvidedWholeFor provided = do
      let
        provId = varPVariable provided
        dependencies = varPParameters provided
        scheme = SharedType.functionType dependencies $ varPResult provided
      case dependencies of
        -- A scalar local with a flexible result was never split from an arrow;
        -- leave its established instantiation behavior to 'byProvided'.
        [] -> mzero
        _ -> byGenericUnify
          (Right (provId, scheme, []))
          scheme
          []
          []
          (heuristics_stepProvidedGood h)
          (heuristics_stepProvidedBad h)
          ((\substs -> (substs, substs)) <$> unifyShared goalType scheme)

    -- try to resolve the goal by looking at functions from the environment.
    byFunctionSimple :: StepAction
    byFunctionSimple = do
      binding <- lift . chooseBranches =<< gets nodeFunctions
      byFunctionSimpleFor binding

    byFunctionSimpleFor :: FunctionBinding -> StepAction
    byFunctionSimpleFor binding = do
      renaming <- builderFreshenTVarNamespace allocators
        $ IntSet.toAscList $ IntSet.unions
        $ map flexibleIdentifiers $ functionBindingTypes binding
      let
        rename = renameFlexibleType renaming
        provType = rename $ functionResult binding
        constraints = map (renameFlexibleConstraint renaming)
          $ functionConstraints binding
        parameters = map rename $ functionParameters binding
        good = addScore (heuristics_stepEnvGood h)
          $ functionPenalty binding
        bad = addScore (heuristics_stepEnvBad h)
          $ functionPenalty binding
        useGlobal typeArguments providedType providedConstraints
            providedParameters =
          byGenericUnify
            (Left (functionName binding, typeArguments))
            providedType
            providedConstraints
            providedParameters
            good
            bad
            (unifyDisjoint goalType providedType)
          <|> donateGlobalAggregate
            typeArguments
            providedType
            providedConstraints
            providedParameters
        -- An ordinary scalar global used to be considered only as a complete
        -- result.  If that result is an aggregate, failing to unify it with
        -- the current goal discarded fields which a local aggregate would
        -- expose immediately during lambda introduction.  Bind the exact
        -- checked global once in this lexical branch and feed the local value
        -- through the same pattern-elimination path.
        --
        -- Direct use and partial application retain priority.  The guard also
        -- runs before allocating the let: a scalar without an applicable
        -- deconstructor must leave no unused local or dead search branch.
        donateGlobalAggregate typeArguments providedType providedConstraints
            providedParameters = case providedParameters of
          _ : _ -> mzero
          [] -> do
            case unifyDisjoint goalType providedType of
              Just _ -> mzero
              Nothing -> pure ()
            deconstructors <- gets nodeDeconstructors
            let applicable deconstructor =
                  case unifyRight providedType
                      $ deconstructorInput deconstructor of
                    Nothing -> False
                    Just _ -> case deconstructorConstructors deconstructor of
                      [] -> True
                      [_] -> True
                      _ -> False
            unless (any applicable deconstructors) mzero
            priorDonations <- gets nodeAggregateDonations
            let globalName = functionName binding
                alreadyDonated = maybe False (S.member globalName)
                  $ M.lookup var priorDonations
            when alreadyDonated mzero
            scopedBindings <- gets
              (scopeGetAllBindings scopeId . nodeProvidedScopes)
            -- Avoid adding a byte-for-byte equivalent scalar which is already
            -- exposed in this scope. Fresh polymorphic instantiations have
            -- distinct flexible IDs and are governed by the goal/global marker
            -- above, so they remain available at a genuinely new hole.
            let aggregateKey = SharedTypeAtom.alphaTypeKey providedType
                sameAggregate scoped =
                  null (varPParameters scoped) &&
                    SharedTypeAtom.alphaTypeKey
                      (varPResult scoped) == aggregateKey
            when (any sameAggregate scopedBindings) mzero
            modify $ \node -> node
              { nodeAggregateDonations = M.insertWith S.union var
                  (S.singleton globalName) $ nodeAggregateDonations node }
            aggregate <- builderAllocVar allocators
            aggregateScope <- builderAddScope allocators scopeId
            let global = foldl' ExpTypeApply
                  (ExpName globalName) typeArguments
            modify $ \node -> node
              { nodeExpression = fillExprHole var
                  (ExpLet aggregate providedType global $ ExpHole var)
                  $ nodeExpression node
              , nodeConstraintGoals = nodeConstraintGoals node <>
                  scopedConstraints givenConstraints providedConstraints
              , nodeDepth = addScore (nodeDepth node) bad
              , nodeLastStepBinding = Just globalName
              }
            additionalGoals <- addScopePatternMatch
              allocators
              casePolicy
              multiPM
              goalType
              var
              aggregateScope
              tupleMode
              givenConstraints
              [splitBinding $ VarBinding aggregate providedType]
            modify $ \node -> node
              { nodeGoals = nodeGoals node <> Seq.fromList additionalGoals }
        ordinary = do
          retained <- gets $ M.lookup (functionName binding) . nodeFunctionSchemes
          let typeArguments = case (retained, unifyDisjoint goalType provType) of
                (Just source, Just (_, substitutions)) ->
                  inferredProviderVisibleArguments source $ snd $
                    applySubsts substitutions $ SharedType.functionType parameters provType
                _ -> []
          useGlobal typeArguments provType constraints parameters
        -- Every free variable in this global's complete binding namespace was
        -- freshly allocated above. The extra domain belongs to that same
        -- persistent namespace, so use the shared unifier and carry its full
        -- substitution through the normal rigid-escape and constraint checks.
        -- A disjoint unifier here would wrongly treat the added domain as a
        -- second provider variable with a coincident numeric identifier.
        groundedOverapplied = case provType of
          TypeVar{} -> do
            domain <- lift $ chooseBranches knownOverapplicationDomains
            overappliedAt $ Just domain
          _ -> mzero
        overapplied = overappliedAt Nothing
        overappliedAt knownDomain = case provType of
          TypeVar{} -> do
            (domain, substitutions) <- overapplicationSubstitution provType knownDomain
            retained <- gets $ M.lookup (functionName binding) . nodeFunctionSchemes
            let selected = snd $ applySubsts substitutions $
                  SharedType.functionType parameters provType
                arguments = maybe [] (`inferredProviderVisibleArguments` selected) retained
            byGenericUnifyWithGoalOrder extraArgumentFirst
              (Left (functionName binding, arguments))
              goalType constraints (parameters ++ [domain]) good bad
              (Just (substitutions, substitutions))
          _ -> mzero
        useVisible instantiations = do
          instantiation <- lift $ chooseBranches instantiations
          typeArguments <- maybe mzero pure
            $ traverse
                (either (const Nothing) Just
                  . SharedGenerated.specifiedVisibleTypeArgument)
                (groundProviderArguments instantiation)
          let (instantiatedResult, instantiatedParameters) =
                splitArrowChain $ groundProviderType instantiation
          useGlobal
            typeArguments
            instantiatedResult
            (groundProviderConstraints instantiation)
            instantiatedParameters
        remainingVisible = do
          source <- maybe mzero pure =<< gets
            (M.lookup (functionName binding) . nodeFunctionSchemes)
          candidates <- gets nodeVisibleTypeCandidates
          suppliedCandidates <- gets
            (M.findWithDefault [] (functionName binding)
              . nodeProviderInstantiationCandidates)
          let instantiations = L.nub $
                groundProviderInstantiations contxt source ++
                candidateProviderInstantiations candidates source ++
                candidateProviderInstantiations suppliedCandidates source
          useVisible instantiations <|> do
            (arguments, selected, selectedConstraints) <- resultDirectedProviderUse source
            let (result, selectedParameters) = splitArrowChain selected
            useGlobal arguments result selectedConstraints selectedParameters
      -- A caller-supplied complete assignment is exact retained-provider
      -- evidence.  Prefer its explicit visible application over the flattened
      -- compatibility binding when both render the same specialization; a
      -- downstream renderer may deduplicate those spellings, and retaining the
      -- ordinary candidate first would discard the checked association.  Keep
      -- inferred and candidate-derived visible applications after the ordinary
      -- lane exactly as before; an absent or unusable raw assignment therefore
      -- preserves the historical branch order.
      suppliedAssignments <- gets
        (M.findWithDefault [] (functionName binding)
          . nodeProviderInstantiationAssignments)
      case suppliedAssignments of
        [] -> ordinary <|> remainingVisible <|> groundedOverapplied <|> overapplied
        _ -> do
          assignedInstantiations <- gets $ \node -> case
              M.lookup (functionName binding) (nodeFunctionSchemes node) of
            Nothing -> []
            Just source -> L.nub $ assignmentProviderInstantiations
              suppliedAssignments source
          if null assignedInstantiations
            then ordinary <|> remainingVisible <|> groundedOverapplied <|> overapplied
            else useVisible assignedInstantiations
              <|> ordinary <|> remainingVisible <|> groundedOverapplied <|> overapplied

    -- Check the syntactic rule precondition before enumerating any domain or
    -- reserving an identifier. A nominal/arrow/quantified final result cannot
    -- become the function result of this particular elimination rule.
    hasQuantifiedResult scheme =
      let (_, _, body) = SharedType.splitLeadingForalls scheme
      in case fst $ splitArrowChain body of
        TypeVar identifier -> identifier `S.notMember` freeVars scheme
        _ -> False

    -- A scalar already present in this lexical scope can determine the
    -- domain of a polymorphic function result before its dependent argument
    -- goals enter the frontier. Otherwise a fresh domain is repeatedly priced
    -- as unknown inside those goals and its useful specialization may remain
    -- behind many ordinary folds. This finite acceleration uses only checked
    -- input bindings and exact monotypes; it neither guesses a type grammar
    -- nor manufactures the scalar's term. Every argument is still searched,
    -- and the fully flexible overapplication sibling remains available.
    knownOverapplicationDomains = SharedCollection.distinctOn
      SharedTypeAtom.alphaTypeKey $ filter knownMonotype $
        [varPResult binding | binding <- providedBindings,
          null $ varPParameters binding] ++
        [functionResult binding | binding <- functionBindings,
          null $ functionParameters binding,
          null $ functionConstraints binding]
     where
      knownMonotype ty = S.null (freeVars ty) && not (SharedType.containsForall ty)

    overapplicationSubstitution result knownDomain = do
      renaming <- builderFreshenTVarNamespace allocators [0]
      let freshDomain = renameFlexibleType renaming $ TypeVar 0
      domainSubstitution <- case knownDomain of
        Nothing -> pure IntMap.empty
        Just selected -> maybe mzero pure $ unifyShared freshDomain selected
      let domain = snd $ applySubsts domainSubstitution freshDomain
      resultSubstitution <- maybe mzero pure $
        unifyShared result $ TypeArrow domain goalType
      -- The domain is freshly allocated; selected monotypes have no flexible
      -- variables, so these maps have disjoint domains and no unresolved
      -- cross-reference. The normal builder validates all rigid references.
      pure (domain, IntMap.union resultSubstitution domainSubstitution)

    -- The last dependency is the value to which a freshly instantiated
    -- function result is applied. Solve it before constructing arguments
    -- whose types mention its still-flexible domain. This changes only goal
    -- order: holes and the actual provider application keep source order,
    -- and every goal still takes its ordinary charged search step.
    extraArgumentFirst goals = case reverse goals of
      [] -> []
      argument : earlier -> argument : reverse earlier

    -- Common code for byProvided and byFunctionSimple.
    byGenericUnify
                   :: Either
                        (QualifiedName,
                          [SharedGenerated.VisibleTypeArgument])
                        (TVarId, HsType,
                          [SharedGenerated.VisibleTypeArgument])
                   -> HsType
                   -> [HsConstraint]
                   -> [HsType]
                   -> Penalty
                   -> Penalty
                   -> Maybe (Substs, Substs)
                   -> StateT SearchNode SearchBranches ()
    byGenericUnify = byGenericUnifyWithGoalOrder id

    byGenericUnifyWithGoalOrder
                   :: ([TGoal] -> [TGoal])
                   -> Either
                        (QualifiedName,
                          [SharedGenerated.VisibleTypeArgument])
                        (TVarId, HsType,
                          [SharedGenerated.VisibleTypeArgument])
                   -> HsType
                   -> [HsConstraint]
                   -> [HsType]
                   -> Penalty
                   -> Penalty
                   -> Maybe (Substs, Substs)
                   -> StateT SearchNode SearchBranches ()
    byGenericUnifyWithGoalOrder goalOrder applier
                   provided
                   provConstrs
                   dependencies
                   depthModMatch
                   depthModNoMatch
      = maybe noUnify $ uncurry byUnified
     where
      (applierName, applierVariable, coreExp) = case applier of
        Left (name, typeArguments) ->
          ( Just name
          , Nothing
          , foldl' ExpTypeApply (ExpName name) typeArguments
          )
        Right (variable, annotation, typeArguments) ->
          ( Nothing
          , Just (variable, annotation)
          , foldl' ExpTypeApply (ExpVar variable annotation) typeArguments
          )

      noUnify :: StateT SearchNode SearchBranches ()
      noUnify = case dependencies of
        [] -> mzero -- we can't (randomly) partially apply a non-function
        (d:ds) -> do
          vResult <- builderAllocVar allocators
          vParam <- builderAllocHole allocators
          modify $ \node -> node
            { nodeExpression = fillExprHole var (ExpLet
                vResult
                -- The let binds a one-argument application, so its type keeps
                -- the remaining parameters. The scope entry below records the
                -- same arrow type; annotating with the bare result type would
                -- make the independent checker reject every candidate that
                -- retains this let.
                (SharedType.functionType ds provided)
                (ExpApply coreExp $ ExpHole vParam)
                (ExpHole var))
                (nodeExpression node)
            , nodeGoals = TGoal (VarBinding vParam d)
                scopeId TryForallIntroduction AllowTupleTree givenConstraints
                Seq.<| nodeGoals node
            }
          newScopeId <- builderAddScope allocators scopeId
          modify $ \node -> node
            { nodeConstraintGoals = nodeConstraintGoals node
                <> scopedConstraints givenConstraints provConstrs
            , nodeDepth = addScore (nodeDepth node) depthModNoMatch
            , nodeLastStepBinding = applierName
            }
          traverse_ (builderRecordVarUse . fst) applierVariable
          additionalGoals <- addScopePatternMatch
            allocators
            casePolicy
            multiPM
            goalType
            var
            newScopeId
            tupleMode
            givenConstraints
            [splitBindingWithParameters ds $ VarBinding vResult provided]
          modify $ \node -> node
            { nodeGoals = nodeGoals node <> Seq.fromList additionalGoals }

      byUnified :: Substs -> Substs -> StateT SearchNode SearchBranches ()
      byUnified originalGoalSS originalProvSS = do
        -- Constraint-only parameters cannot be inferred from the result or
        -- scheduled value arguments. The allocation snapshot identifies this
        -- provider use's fresh variables, excluding every persistent goal or
        -- local variable. Explore coherent lexical selections and preserve
        -- their direct class arguments for independent expression checking.
        let currentGivens = map (snd . constraintApplySubsts originalGoalSS) $
              S.toList (qClassEnv_constraints contxt) ++ givenConstraints
            required = map (snd . constraintApplySubsts originalProvSS) provConstrs
            fresh = IntSet.filter
              (not . (`identifierIsReserved` nodeFlexibleIds initialNode)) $
                IntSet.fromList $ S.toList $ foldMap
                  (foldMap freeVars . constraint_params) required
            selections = if IntSet.null fresh then [] else
              givenInstantiations 4096 fresh
                [(currentGivens, constraint) | constraint <- required]
        selected <- lift $ chooseBranches $ if null selections
          then [IntMap.empty] else selections
        let applySelected = snd . applySubsts selected
            goalSS = IntMap.map applySelected originalGoalSS
            provSS = IntMap.union selected $ IntMap.map applySelected originalProvSS
        byUnifiedWithSelections (not $ IntMap.null selected) goalSS provSS

      byUnifiedWithSelections :: Bool -> Substs -> Substs -> StateT SearchNode SearchBranches ()
      byUnifiedWithSelections retainSelection goalSS provSS = do
        let allSS = IntMap.union goalSS provSS
            substs = case applier of
              Left _  -> goalSS
              Right _ -> allSS
            (applied1, constrs1) = mapM
              (scopedConstraintApplySubsts substs) constraintGoals'
            constrs2 = map (snd . constraintApplySubsts provSS)
              provConstrs
            currentGivens = map
              (snd . constraintApplySubsts substs) givenConstraints
            scopedConstrs2 = scopedConstraints currentGivens constrs2
            selectedExpression = if retainSelection
              then ExpSelect coreExp constrs2 else coreExp
        newConstraints <- lift $ maybeBranch $ if allowConstrs
          then Just $ constrs1 ++ scopedConstrs2
          else if getAny applied1
            then resolveScopedConstraints isPossible contxt
              $ constrs1 ++ scopedConstrs2
            else (constrs1 ++) <$> resolveScopedConstraints
              isPossible contxt scopedConstrs2
        vars <- forM dependencies $ \_ -> builderAllocHole allocators
        let newGoals = mkGoals scopeId givenConstraints
              $ zipWith VarBinding vars dependencies
            applyProviderSubstitution = case applier of
              -- Provider variables live in a disjoint temporary namespace,
              -- while goal givens live in the persistent query namespace.
              -- Apply this map only to the dependency type; applying it to the
              -- whole TGoal could rewrite a numerically colliding local given.
              Left _ -> \goal -> case goalBinding goal of
                VarBinding dependencyVariable dependencyType -> goal
                  { goalBinding = VarBinding dependencyVariable
                      $ snd $ applySubsts provSS dependencyType
                  }
              Right _ -> id
        builderApplySubst allSS substs
        modify $ \node -> node
          { nodeGoals = scheduleKnownGoals (nodeProvidedScopes node)
              (goalOrder $ map (goalApplySubst substs . applyProviderSubstitution) newGoals)
              (nodeGoals node) }
        modify $ \node -> node
          { nodeExpression = fillExprHole var
              (foldl' ExpApply selectedExpression (map ExpHole vars))
              (nodeExpression node)
          , nodeConstraintGoals = newConstraints
          , nodeDepth = addScore (nodeDepth node) depthModMatch
          , nodeLastStepBinding = applierName
          }
        traverse_ (builderRecordVarUse . fst) applierVariable

    providedBindings = scopeGetAllBindings scopeId
      $ nodeProvidedScopes initialNode
    functionBindings = nodeFunctions initialNode

    -- Independently retain the historical nondeterministic dispatch so tests
    -- can compare it with the extracted action interpreter.
    legacyAction :: StepAction
    legacyAction = case goalType of
      TypeArrow _ _ -> byProvidedWhole <|> arrowStep goalType []
      TypeForall is cs t | forallMode == OpenLeadingForalls ->
        forallStep is cs t
      TypeForall is cs t | forallMode == ContinueForallIntroduction ->
        introducedForallStep is cs t
      TypeForall is cs t | forallMode == TryForallIntroduction ->
        byProvided <|> byFunctionSimple <|> introducedForallStep is cs t
      TypeTuple Boxed elements | not $ null elements ->
        byProvided
          <|> (case tupleMode of
            AllowTupleTree -> tupleTreeStep elements <|> tupleStep elements
            ContinueShallowTuple -> tupleStep elements)
          <|> byFunctionSimple
      _ -> byProvided <|> byFunctionSimple

    -- Each outer list element is one finite sibling lane.  Inner alternatives
    -- remain within the captured provider/function action, preserving their
    -- allocation snapshot, truncation cardinality, and contiguous result order.
    orderedActions :: [StepAction]
    orderedActions = case goalType of
      TypeArrow _ _ ->
        map byProvidedWholeFor providedBindings ++ [arrowStep goalType []]
      TypeForall is cs t | forallMode == OpenLeadingForalls ->
        [forallStep is cs t]
      TypeForall is cs t | forallMode == ContinueForallIntroduction ->
        [introducedForallStep is cs t]
      TypeForall is cs t | forallMode == TryForallIntroduction ->
        map byProvidedFor providedBindings
          ++ map byFunctionSimpleFor functionBindings
          ++ [introducedForallStep is cs t]
      TypeTuple Boxed elements | not $ null elements ->
        map byProvidedFor providedBindings
          ++ (case tupleMode of
            AllowTupleTree -> [tupleTreeStep elements, tupleStep elements]
            ContinueShallowTuple -> [tupleStep elements])
          ++ map byFunctionSimpleFor functionBindings
      _ -> map byProvidedFor providedBindings
        ++ map byFunctionSimpleFor functionBindings
  in StateStepPlan legacyAction orderedActions


{-# INLINE addScopePatternMatch #-}
-- Insert pattern-matching on newly introduced VarPBindings where
-- possible/necessary. Note that this also effectively transforms a goal
-- (into potentially multiple goals), as goal id + HsType + ScopeId = TGoal.
-- So the input describes one single TGoal.
-- TGoals are duplicated when the pattern-matching involves more than one case,
-- as the goals for different cases are distinct because their scopes are
-- modified when new bindings are added by the pattern-matching.
addScopePatternMatch :: SearchAllocators
                     -> RecursiveCasePolicy
                     -> Bool -- should p-m on anything but newtypes?
                     -> HsType -- the current goal (should be returned in one
                               --  form or another)
                     -> Int    -- goal id (hole id)
                     -> ScopeId -- scope for this goal
                     -> TupleGoalMode -- structural product provenance
                     -> [HsConstraint] -- lexical class givens for this goal
                     -> [VarPBinding]
                     -> StateT SearchNode SearchBranches [TGoal]
addScopePatternMatch allocators casePolicy multiPM goalType vid sid tupleMode givens
    bindings = addScopePatternQueue allocators casePolicy multiPM goalType vid sid tupleMode givens
      [(True, binding) | binding <- bindings]

-- Recursive constructor fields may expose finite nonrecursive structure
-- (notably tuple payloads), but never another recursive constructor layer.
-- Each queued binding carries that permission independently, so suppressing
-- recursion in one field does not suppress a later function argument's case.
addScopePatternQueue :: SearchAllocators -> RecursiveCasePolicy -> Bool -> HsType -> Int -> ScopeId
                     -> TupleGoalMode -> [HsConstraint] -> [(Bool, VarPBinding)]
                     -> StateT SearchNode SearchBranches [TGoal]
addScopePatternQueue allocators casePolicy multiPM goalType vid sid tupleMode givens bindings =
  case bindings of
  [] -> return
    [TGoal (VarBinding vid goalType) sid TryForallIntroduction
      tupleMode givens]
  ((allowRecursive, b) : bindingRest) -> do
    let v = varPVariable b
        vtResult = varPResult b
        vtParams = varPParameters b
    let expVar = ExpVar v $ SharedType.functionType vtParams vtResult
    modify $ \node -> node
      { nodeProvidedScopes = scopesAddPBinding sid b
          $ nodeProvidedScopes node }
    let defaultHandleRest = addScopePatternQueue
          allocators casePolicy multiPM goalType vid sid tupleMode givens bindingRest
    case vtResult of
      TypeVar {}    -> defaultHandleRest -- dont pattern-match on variables, even if it unifies
      TypeArrow {}  ->
        error $ "addScopePatternMatch: TypeArrow: " ++ show vtResult  -- should never happen, given a pbinding..
      -- A quantified result has no nominal head visible to pattern matching.
      -- It remains usable as one opaque scoped value.
      TypeForallNative {} -> defaultHandleRest
      _ | not $ null vtParams -> defaultHandleRest
        | otherwise -> do
            selectDeconstructor =<< gets nodeDeconstructors
         where
          -- Preserve the historical first-applicable deconstructor policy.
          selectDeconstructor [] = defaultHandleRest
          selectDeconstructor (deconstructor : remaining) =
            fromMaybe (selectDeconstructor remaining) $ mapFunc deconstructor

          -- Sealing guarantees that every field variable occurs in the
          -- datatype head. 'unifyRight' gives that head a temporary tagged
          -- namespace and returns substitutions keyed by its original IDs,
          -- so applying those substitutions directly to the validated fields
          -- is both capture-safe and allocation-free.
          mapFunc
            :: DeconstructorBinding
            -> Maybe (StateT SearchNode SearchBranches [TGoal])
          mapFunc (DeconstructorBinding _ _ True)
            | not allowRecursive = Nothing
          mapFunc (DeconstructorBinding matchParam [] _) =
            let eliminateEmpty = do
                  -- An empty case evaluates its scrutinee once and has no
                  -- branch goals. Recording that use is also what lets a
                  -- strict no-unused-variable search retain the proof.
                  builderRecordVarUse v
                  modify $ \node -> node
                    { nodeExpression = fillExprHole vid
                        (ExpCaseMatch expVar [])
                        (nodeExpression node) }
                  pure []
            -- No deconstructor variable escapes an empty match. 'unifyRight'
            -- already gives its right operand a disjoint tagged namespace, so
            -- reserving persistent flexible IDs here could only introduce a
            -- spurious identifier-space truncation.
            --
            -- Empty elimination is one valid use of the value, but it is not
            -- the only one. In particular, the shipped declaration corpus
            -- represents abstract primitive types such as Int with no visible
            -- constructors. Committing to @case x of {}@ here used to discard
            -- the sibling in which @x@ is passed to another scoped provider.
            -- Retain both proof branches just as the search does for other
            -- alternative term constructions.
            in (eliminateEmpty <|> defaultHandleRest)
              <$ unifyRight vtResult matchParam
          mapFunc (DeconstructorBinding matchParam
                    [ConstructorBinding matchId matchRs] recursive) =
            (recursiveChoice recursive . mapFunc1) <$> unifyRight vtResult matchParam
           where
            mapFunc1 substs = do
              vars <- forM matchRs $ \_ ->
                builderAllocVar allocators
              builderRecordVarUse v
              let newProvTypes = map (snd . applySubsts substs) matchRs
                  newBinds = zipWith
                    (\x y -> splitBinding $ VarBinding x y)
                    vars
                    newProvTypes
                  expr = ExpLetMatch matchId
                    (zip vars newProvTypes)
                    expVar
                    (ExpHole vid)
              modify $ \node -> node
                { nodeExpression = fillExprHole vid expr
                    $ nodeExpression node }
              addScopePatternQueue
                  allocators
                  casePolicy
                  multiPM
                  goalType
                  vid
                  sid
                  tupleMode
                  givens
                  ([(allowRecursive && not recursive, binding) | binding <- reverse newBinds]
                    ++ bindingRest)
          mapFunc (DeconstructorBinding matchParam
              matchers@(_ : _) recursive)
            | multiPM = (recursiveChoice recursive . mapFunc2) <$> unifyRight vtResult matchParam
           where
            mapFunc2 substs = do
              -- The case expression evaluates its scrutinee once. Its
              -- alternatives do not constitute additional uses of that
              -- variable; charging one use per constructor biases the queue
              -- against datatypes merely for having more constructors.
              builderRecordVarUse v
              matchData <- matchers `forM` \matcher -> do
                let matchId = constructorName matcher
                    matchRs = constructorFields matcher
                newSid <- builderAddScope allocators sid
                vars <- forM matchRs $ \_ ->
                  builderAllocVar allocators
                newVid <- builderAllocHole allocators
                let newProvTypes = map (snd . applySubsts substs) matchRs
                    newBinds = zipWith
                      (\x y -> splitBinding $ VarBinding x y)
                      vars
                      newProvTypes
                return
                  ( (matchId, zip vars newProvTypes, ExpHole newVid)
                  , (newVid, reverse newBinds, newSid)
                  )
              modify $ \node -> node
                { nodeExpression = fillExprHole vid
                    (ExpCaseMatch expVar $ map fst matchData)
                    (nodeExpression node) }
              fmap concat $ map snd matchData `forM`
                \(newVid, newBinds, newSid) -> addScopePatternQueue
                    allocators
                    casePolicy
                    multiPM
                    goalType
                    newVid
                    newSid
                    tupleMode
                    givens
                    ([(allowRecursive && not recursive, binding) | binding <- newBinds]
                      ++ bindingRest)
          mapFunc _ = Nothing

          -- Retaining an input whole lets a default value coexist with a
          -- case on another argument of the same recursive type. Mandatory
          -- splitting of both inputs creates needless Cartesian branch goals.
          -- The ordinary lane retains both choices. The protected lane only
          -- changes scheduling by exploring eager cases separately; it shares
          -- the same finite field-inspection rule and all checking authority.
          recursiveChoice True inspect = case casePolicy of
            OptionalRecursiveCases -> defaultHandleRest <|> inspect
            EagerRecursiveCases -> inspect
          recursiveChoice False inspect = inspect
  -- where
  --  (<&>) = flip (<$>)
