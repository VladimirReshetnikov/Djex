from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys

ROOT = Path.cwd()
OUT = ROOT/'dist-newstyle/exference-selections-validation-v2'
sys.path.insert(0, str(ROOT/'test-church'))
import behavior_runtime as runtime

OUT.mkdir(exist_ok=False)
base = ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17'
specs = [
    ('cyclic', 'exference-tests', ['-p', 'preflights cyclic checker class and pattern arities'], 30),
    ('focused', 'exference-engine-tests', ['-p', 'constraint-only lexical instantiation'], 120),
    ('public', 'djex-tests', ['-p', 'Proof-selected dictionaries survive public synthesis'], 180),
    ('engine', 'exference-engine-tests', [], 900),
    ('exference', 'exference-tests', [], 1800),
    ('integration', 'djex-tests', [], 900),
    ('church', 'djex-church-tests', ['--report-dir', str(OUT/'church')], 1200),
    ('scopes', 'djex-rank-n-scope-tests', [], 900),
]
bins = {name:base/'t'/name/'build'/name/(name+'.exe') for _,name,_,_ in specs}
paths = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT).decode().split('\0')
sources = {p:runtime.sha256(ROOT/p) for p in paths if p and (ROOT/p).is_file()}
changed = subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).decode().splitlines()
for p in changed:
    dest = OUT/'source'/p
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes((ROOT/p).read_bytes())
(OUT/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report = {'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'source_sha256':sources,'binary_sha256':{name:runtime.sha256(path) for name,path in bins.items()},'gates':[]}
runner = runtime.Processes(OUT,1800)
env = dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
def save():
    report['processes'] = runner.rows
    runtime.write_json(OUT/'results.json',report)
save()
try:
    for label,name,args,guard in specs:
        report['active_gate'] = label
        save()
        runner.timeout = guard
        result = runner.run(label,[str(bins[name]),'-j1']+args,cwd=ROOT,env=env)
        report['gates'].append({'gate':label,'exit_code':result.returncode})
        save()
        if result.returncode:
            break
    report['status'] = 'passed' if len(report['gates'])==len(specs) and all(g['exit_code']==0 for g in report['gates']) else 'failed'
except BaseException as error:
    report.update(status='failed',error=repr(error))
finally:
    report['sources_unchanged'] = all(runtime.sha256(ROOT/p)==h for p,h in sources.items())
    report['binaries_unchanged'] = all(runtime.sha256(bins[name])==h for name,h in report['binary_sha256'].items())
    report['controller_unchanged'] = (OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    if not all(report[k] for k in ['sources_unchanged','binaries_unchanged','controller_unchanged']):
        report['status'] = 'failed'
    report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
print(report['status'],report.get('error',''),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
