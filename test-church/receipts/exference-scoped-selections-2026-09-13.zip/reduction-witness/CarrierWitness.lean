set_option autoImplicit false
def CList (A : Type) : Type 1 := ∀ R : Type, (A → R → R) → R → R
def foldl1C {A : Type} (d : A) (f : A → A → A) (xs : CList A) : A :=
  xs ((A → A) → A → A) (fun x rest g _ => rest (f (g x)) (g x))
    (fun _ z => z) (fun x => x) d
def foldr1C {A : Type} (d : A) (f : A → A → A) (xs : CList A) : A :=
  xs ((A → A) → A → A) (fun x rest g _ => rest (fun y => g (f x y)) (g x))
    (fun _ z => z) (fun x => x) d
def encode {A : Type} (xs : List A) : CList A := fun _ step zero => xs.foldr step zero
example : foldl1C 99 Nat.sub (encode [8,3,1]) = 4 := by decide
example : foldr1C 99 Nat.sub (encode [8,3,1]) = 6 := by decide
example : foldl1C 99 Nat.sub (encode []) = 99 := by decide
example : foldr1C 99 Nat.sub (encode []) = 99 := by decide
#print axioms foldl1C
#print axioms foldr1C
