{-# LANGUAGE PatternSynonyms #-}
module Main (main) where

import Control.Monad (unless)
import Data.Char (ord)
import Data.List (intercalate)
import qualified Data.Map.Strict as Map
import Numeric (showHex)
import System.Environment (getArgs)
import System.FilePath ((</>))
import System.IO (Handle, IOMode (WriteMode), hPutStrLn, withFile)
import Language.Haskell.Djex
import Language.Haskell.Djex.Exference.HaskellSrc
  (parseExferenceRequest, exferenceCommandSessionPolicy,
   loadExferenceSessionFromSourcesWithTypeVisibilityWithPolicy,
   exferenceSessionLoadResult, exferenceSessionLoadDiagnostics)
import qualified Language.Haskell.Synthesis.TypedGenerated.Haskell as H

-- This observes the original public raw observation slots, after the
-- independent checker and per-batch production ranking. It is not a trace of
-- unchecked branches, and it never asks for an unobserved candidate's graph.
main :: IO ()
main = do
  args <- getArgs
  case args of
    [targetSource, typePath, output] -> run targetSource typePath output
    _ -> fail "usage: PrefixProbe TARGET TYPE-FILE NEW-OUTPUT-DIRECTORY"

run :: String -> FilePath -> FilePath -> IO ()
run targetSource typePath output = do
  source <- readFile typePath
  target <- expectRight $ parseName targetSource
  policy <- expectRight $ exferenceCommandSessionPolicy False
  loaded <- loadExferenceSessionFromSourcesWithTypeVisibilityWithPolicy policy [] [] []
  session <- expectRight $ exferenceSessionLoadResult loaded
  writeFile (output </> "loader-diagnostics.show") $ show (exferenceSessionLoadDiagnostics loaded) ++ "\n"
  request <- expectRight $ parseExferenceRequest session options target
    "<interactive>" source
  writeFile (output </> "request.show") $ show request ++ "\n"
  writeFile (output </> "inventory.show") $
    show (environmentDeclarations $ exferenceSessionEnvironment session) ++ "\n"
  writeFile (output </> "options.show") $ show options ++ "\n"
  results <- expectRight $ runExferenceTypedQuery session request
  withFile (output </> "batches.jsonl") WriteMode $ \batches ->
    withFile (output </> "candidates.jsonl") WriteMode $ \candidates -> do
      (count, batchesSeen, progress, exhausted) <- consume batches candidates
        output 0 0 Nothing results
      writeFile (output </> "summary.json") $ object
        [ ("schema", string "exference-public-prefix-v1")
        , ("window", "256"), ("observed", number count)
        , ("batches_observed", number batchesSeen)
        , ("last_observed_progress", maybe "null" (string . show) progress)
        , ("stream_exhausted_by_observation", boolean exhausted)
        , ("candidate_tail_inspected_at_cap", "false")
        , ("maximum_steps", "100000"), ("maximum_queue", "8192")
        , ("acceptance_claim", "false")
        ] ++ "\n"

options :: ExferenceOptions
options = defaultExferenceOptions
  { exferenceAllowUnused = True
  , exferenceAllowResidualConstraints = False
  , exferenceConstraintDeferralSteps = 8192
  , exferenceMultiConstructorPatterns = False
  , exferenceMaximumSteps = 100000
  , exferenceMaximumQueueSize = Just 8192
  , exferenceMaximumDepth = Nothing
  , exferenceCandidateRanking = defaultCandidateRankingPolicy
  , exferenceProviderCosts = Map.empty
  }

-- The cap guard precedes matching either list. This matches Behavioral.hs's
-- first/all-False demand boundary: no length, terminal scan, or refill.
consume :: Handle -> Handle -> FilePath -> Int -> Int -> Maybe Progress
  -> [ExferenceTypedResult] -> IO (Int, Int, Maybe Progress, Bool)
consume _ _ _ count batchCount previous _ | count >= 256 =
  pure (count, batchCount, previous, False)
consume _ _ _ count batchCount previous [] =
  pure (count, batchCount, previous, True)
consume batches candidates output count batchCount _ (result : rest) = do
  let batch = resultSearch result
      metadata = batchMetadata batch
      progress = batchProgress batch
      currentBatch = batchCount + 1
  unless (currentBatch <= 100000) $ fail "public batches exceed global step cap"
  hPutStrLn batches $ object
    [ ("batch", number currentBatch)
    , ("progress", string $ show progress)
    , ("evidence", string $ show $ resultEvidence result)
    , ("queue_pruned", number $ exferenceBatchQueuePruned metadata)
    , ("depth_pruned", number $ exferenceBatchDepthPruned metadata)
    , ("binding_usages", string $ show $ exferenceBatchBindingUsages metadata)
    , ("consumed_before", number count)
    ]
  next <- consumeCandidates candidates output currentBatch count $ batchCandidates batch
  consume batches candidates output next currentBatch (Just progress) rest

consumeCandidates :: Handle -> FilePath -> Int -> Int -> [ExferenceTypedCandidate] -> IO Int
consumeCandidates _ _ _ count _ | count >= 256 = pure count
consumeCandidates _ _ _ count [] = pure count
consumeCandidates handle output batch count (candidate : rest) = do
  recordCandidate handle output batch (count + 1) candidate
  consumeCandidates handle output batch (count + 1) rest

recordCandidate :: Handle -> FilePath -> Int -> Int -> ExferenceTypedCandidate -> IO ()
recordCandidate handle output batch ordinal candidate = do
  let compatibility = typedCandidateCompatibility candidate
      clause = candidateOutput compatibility
      metrics = exferenceCandidateMetrics compatibility
      base = "candidate-" ++ pad 3 (show ordinal)
      globals = expressionGlobals $ functionClauseExpression clause
  unless (all (maybe False (const True) . nameSpecial) globals) $
    fail "a candidate acquired a non-intrinsic global in the empty user environment"
  unless (exferenceCandidateSteps metrics == batch
      && exferenceCandidateSteps metrics <= 100000
      && exferenceCandidateFinalQueueSize metrics <= 8192) $
    fail "candidate admission metrics differ from the observed public batch/bounds"
  expression <- expectRight $ renderExferenceCandidateExpression FullyQualified compatibility
  definition <- expectRight $ renderExferenceCandidateDefinition FullyQualified compatibility
  writeFile (output </> base ++ ".expression.hs") $ expression ++ "\n"
  writeFile (output </> base ++ ".definition.hs") $ definition ++ "\n"
  writeFile (output </> base ++ ".compatibility.show") $ show compatibility ++ "\n"
  graphFields <- case typedCandidateTermGraph candidate of
    Left absence -> pure [("graph_available", "false"), ("graph_absence", string $ show absence)]
    Right graph -> do
      unless (eraseTermGraphToFunctionClause (clauseName clause) graph == clause) $
        fail "the retained graph does not erase to its own exact compatibility clause"
      writeFile (output </> base ++ ".graph.show") $ show graph ++ "\n"
      renderedFields <- case H.renderHaskellTermGraph (defaultRenderOptions $ const "x") graph of
        Left failure -> pure [("typed_render_error", string $ show failure)]
        Right rendered -> do
          writeFile (output </> base ++ ".typed.hs") $ rendered ++ "\n"
          pure [("typed_expression", string rendered)]
      pure $ renderedFields ++
        [ ("graph_available", "true"), ("exact_graph_erasure", "true")
        , ("graph_root", nodeId $ termGraphRoot graph)
        , ("graph_metrics", string $ show $ termGraphMetrics graph)
        , ("root_term_binders", array $ rootBinders graph $ termGraphRoot graph)
        , ("nodes", array [nodeJSON identity node | (identity, node) <- termGraphNodes graph])
        , ("application_spines", array $ applicationSpines graph)
        ]
  hPutStrLn handle $ object $
    [ ("ordinal", number ordinal), ("batch", number batch)
    , ("admission_step", number $ exferenceCandidateSteps metrics)
    , ("final_queue_size", number $ exferenceCandidateFinalQueueSize metrics)
    , ("final_complexity", string $ show $ exferenceCandidateComplexity metrics)
    , ("original_expression", string expression), ("original_definition", string definition)
    , ("candidate_details", string $ show $ candidateDetails compatibility)
    ] ++ graphFields

type Graph = TermGraph ExferenceType ExferenceLocal

rootBinders :: Graph -> TermNodeId -> [String]
rootBinders graph identity = case lookupTermNode identity graph of
  Just (TermNode _ (TypedForallIntroduction _ child _)) -> rootBinders graph child
  Just (TermNode _ (TypedLambda patterns child)) -> map patternJSON patterns ++ rootBinders graph child
  _ -> []

nodeJSON :: TermNodeId -> TermNode ExferenceType ExferenceLocal -> String
nodeJSON identity node = object $ [("id", nodeId identity), ("type", typeJSON $ termNodeType node)]
  ++ case termNodeForm node of
    TypedLocal occurrence local -> [("tag", string "local"), ("local", number local), ("occurrence", string $ show occurrence)]
    TypedLambda patterns body -> [("tag", string "lambda"), ("patterns", array $ map patternJSON patterns), ("body", nodeId body)]
    TypedApply function argument witness -> [("tag", string "apply"), ("function", nodeId function), ("argument", nodeId argument), ("domain", typeJSON $ applicationDomain witness), ("result", typeJSON $ applicationResult witness)]
    TypedForallIntroduction occurrence body witness -> [("tag", string "forall_introduction"), ("occurrence", string $ show occurrence), ("body", nodeId body), ("source", typeJSON $ forallIntroductionSource witness), ("opened_variable", typeJSON $ forallIntroductionVariable witness), ("opened_body", typeJSON $ forallIntroductionBody witness)]
    TypedImplicitTypeApplication occurrence child witness -> [("tag", string "implicit_instantiation"), ("occurrence", string $ show occurrence), ("child", nodeId child), ("source", typeJSON $ implicitTypeApplicationSource witness), ("selected", typeJSON $ implicitTypeApplicationSelected witness), ("result", typeJSON $ implicitTypeApplicationResult witness)]
    TypedVisibleTypeApplication occurrence child argument witness -> [("tag", string "visible_instantiation"), ("occurrence", string $ show occurrence), ("child", nodeId child), ("argument", string $ show argument), ("source", typeJSON $ typeApplicationSource witness), ("selected", typeJSON $ typeApplicationSelected witness), ("result", typeJSON $ typeApplicationResult witness), ("certificate", string $ show $ typeApplicationCertificate witness)]
    form -> [("tag", string "other"), ("form", string $ show form)]

patternJSON :: TypedPattern ExferenceType ExferenceLocal -> String
patternJSON patternValue = object
  [ ("occurrence", string $ show $ typedPatternOccurrence patternValue)
  , ("type", typeJSON $ typedPatternType patternValue)
  , ("pattern", string $ show $ typedPatternNode patternValue)
  , ("local", case typedPatternNode patternValue of TypedBind local -> number local; _ -> "null")
  ]

-- Type/application evidence can prove that a local's instantiated result
-- supplies additional ordinary arguments. It cannot reveal which search-rule
-- sibling originally constructed that term; no rule tag is fabricated here.
applicationSpines :: Graph -> [String]
applicationSpines graph =
  [ object [("root", nodeId identity), ("head", nodeId headId)
           , ("head_local", number local), ("arguments", array $ map nodeId arguments)
           , ("source_type", typeJSON source), ("declared_domains", number $ declaredDomains source)
           , ("extra_result_arguments", number $ max 0 $ length arguments - declaredDomains source)]
  | (identity, TermNode _ TypedApply{}) <- termGraphNodes graph
  , identity `notElem` functionChildren
  , let (headId, arguments) = walk identity []
  , Just (TermNode source (TypedLocal _ local)) <- [lookupTermNode headId graph]
  ]
 where
  functionChildren = concat
    [functionPath child | (_, TermNode _ (TypedApply child _ _)) <- termGraphNodes graph]
  functionPath identity = identity : case lookupTermNode identity graph of
    Just (TermNode _ (TypedImplicitTypeApplication _ child _)) -> functionPath child
    Just (TermNode _ (TypedVisibleTypeApplication _ child _ _)) -> functionPath child
    _ -> []
  walk identity arguments = case lookupTermNode identity graph of
    Just (TermNode _ (TypedApply function argument _)) -> walk function (argument : arguments)
    Just (TermNode _ (TypedImplicitTypeApplication _ child _)) -> walk child arguments
    Just (TermNode _ (TypedVisibleTypeApplication _ child _ _)) -> walk child arguments
    _ -> (identity, arguments)

declaredDomains :: ExferenceType -> Int
declaredDomains = arrows . leadingBody
 where
  leadingBody (ForallType _ _ body) = leadingBody body
  leadingBody source = source
  arrows (FunctionType _ result) = 1 + arrows result
  arrows _ = 0

typeJSON :: ExferenceType -> String
typeJSON ty = object $ case ty of
  TypeVariable variable -> [("tag", string "variable"), ("variable", string $ show variable)]
  TypeConstructor name -> [("tag", string "constructor"), ("name", string $ renderCanonical name)]
  TypeApplication function argument -> [("tag", string "application"), ("function", typeJSON function), ("argument", typeJSON argument)]
  FunctionType domain result -> [("tag", string "arrow"), ("domain", typeJSON domain), ("result", typeJSON result)]
  TupleType boxity fields -> [("tag", string "tuple"), ("boxity", string $ show boxity), ("fields", array $ map typeJSON fields)]
  ForallType binders constraints body -> [("tag", string "forall"), ("binders", array $ map (string . show) binders), ("constraints", string $ show constraints), ("body", typeJSON body)]

expectRight :: Show failure => Either failure value -> IO value
expectRight = either (fail . show) pure

object :: [(String, String)] -> String
object fields = "{" ++ intercalate "," [string key ++ ":" ++ value | (key, value) <- fields] ++ "}"

array :: [String] -> String
array values = "[" ++ intercalate "," values ++ "]"

string :: String -> String
string text = '"' : concatMap escape text ++ "\""
 where
  escape '"' = "\\\""
  escape '\\' = "\\\\"
  escape character | ord character < 32 = "\\u" ++ pad 4 (showHex (ord character) "")
  escape character = [character]

number :: Show value => value -> String
number = show

boolean :: Bool -> String
boolean True = "true"
boolean False = "false"

nodeId :: TermNodeId -> String
nodeId = number . termNodeIdValue

pad :: Int -> String -> String
pad width value = replicate (max 0 $ width - length value) '0' ++ value
