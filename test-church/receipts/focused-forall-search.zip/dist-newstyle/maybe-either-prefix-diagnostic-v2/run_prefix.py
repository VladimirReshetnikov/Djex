#!/usr/bin/env python3
"""Owned, unchanged-window public-prefix diagnostic; never an acceptance claim."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "test-church"))
from behavior_runtime import Processes, prepare_output_directory, sha256, write_json

BASELINE = ROOT / "dist-newstyle/priority4-live/extended-exference-maybe-either-graph-v1"
SOURCE_DIRS = ("src", "exference/src-core", "exference/src-frontend", "djinn/src-core",
               "djinn/src-internal", "djinn/src-frontend", "synthesis/src", "synthesis/internal")


def source_paths():
    paths = {p.resolve() for root in SOURCE_DIRS for p in (ROOT / root).rglob("*.hs")}
    paths.update((ROOT / "djex.cabal", HERE / "PrefixProbe.hs",
                  HERE / "run_prefix.py", ROOT / "test-church/behavior_runtime.py",
                  ROOT / "test-church/behavior_spec.py"))
    paths.update(path for path in ROOT.glob("cabal.project*") if path.is_file())
    paths.add(ROOT / "dist-newstyle/cache/plan.json")
    return sorted(paths)


def frozen_baseline():
    expected = json.loads((HERE / "baseline-pins.json").read_text(encoding="utf-8"))
    for relative, digest in expected["files"].items():
        if sha256(BASELINE / relative) != digest:
            raise ValueError("completed reference input/capture changed: " + relative)
    commands = (BASELINE / "exference-maybeEither.commands.txt").read_text(encoding="utf-8")
    matches = re.findall(r"(?m)^:synth (\w+) :: (.*?) where (.*)$", commands)
    if len(matches) != 1:
        raise ValueError("expected exactly one original named behavioral query")
    name, target, predicate = matches[0]
    setup = commands[:commands.index(":synth ")].splitlines()
    if setup != expected["setup_lines"]:
        raise ValueError("baseline settings differ from reviewed exact setup")
    return expected, name, target, predicate


def load_json_lines(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def verify_output(capture, samples):
    summary = json.loads((capture / "summary.json").read_text(encoding="utf-8"))
    rows = load_json_lines(capture / "candidates.jsonl")
    batches = load_json_lines(capture / "batches.jsonl")
    if summary["schema"] != "exference-public-prefix-v1" or summary["window"] != 256:
        raise ValueError("unexpected diagnostic format/bound")
    if summary["observed"] != 256 or len(rows) != 256:
        raise ValueError("the unchanged query did not deliver the original 256-slot prefix")
    if summary["batches_observed"] != len(batches) or not 1 <= len(batches) <= 100000:
        raise ValueError("batch inventory does not match the recorded global bound")
    if summary["candidate_tail_inspected_at_cap"] or summary["acceptance_claim"]:
        raise ValueError("unexpected demand or acceptance claim")
    if [r["batch"] for r in batches] != list(range(1, len(batches) + 1)):
        raise ValueError("public progress batches were omitted/reordered")
    if [r["ordinal"] for r in rows] != list(range(1, 257)):
        raise ValueError("candidate prefix has gaps or refilled slots")
    for row in rows:
        if not 1 <= row["admission_step"] == row["batch"] <= len(batches):
            raise ValueError("candidate lost its own public admission batch")
        if not 0 <= row["final_queue_size"] <= 8192:
            raise ValueError("candidate queue size exceeds unchanged global queue")
        if row["graph_available"] and not row.get("exact_graph_erasure"):
            raise ValueError("observed graph lost exact compatibility association")
    for previous, current in zip(batches, batches[1:]):
        if any(current[key] < previous[key] for key in ("queue_pruned", "depth_pruned", "consumed_before")):
            raise ValueError("cumulative actual batch measurements decreased")
    if batches[-1]["progress"] != summary["last_observed_progress"]:
        raise ValueError("summary substituted a later unobserved progress value")
    sample_matches = []
    for sample in samples:
        row = rows[sample["ordinal"] - 1]
        matched = row["original_expression"] == sample["original_expression"]
        sample_matches.append({**sample, "new_prefix_exact_match": matched})
        if not matched:
            raise ValueError("new prefix differs from an actually retained original CLI sample: " + str(sample["ordinal"]))
    # These are observations about retained source-owned graph structure.
    # Neither number identifies the original rule sibling or a behavioral pass.
    extra = [row["ordinal"] for row in rows if any(
        spine["extra_result_arguments"] > 0 for spine in row.get("application_spines", []))]
    root_usage = []
    for row in rows:
        uses = Counter(node["local"] for node in row.get("nodes", []) if node["tag"] == "local")
        root_usage.append({"ordinal": row["ordinal"], "root_binders": [
            {"position": i, "local": binder["local"], "occurrence": binder["occurrence"],
             "retained_occurrences": uses.get(binder["local"], 0), "type": binder["type"]}
            for i, binder in enumerate(row.get("root_term_binders", []))]})
    return {"summary": summary, "last_consumed_batch": batches[-1],
            "original_cli_sample_matches": sample_matches,
            "graph_available_count": sum(row["graph_available"] for row in rows),
            "typed_rendered_count": sum("typed_expression" in row for row in rows),
            "source_result_extra_argument_ordinals": extra,
            "forall_introduction_histogram": dict(Counter(str(sum(
                node["tag"] == "forall_introduction" for node in row.get("nodes", []))) for row in rows)),
            "root_binder_usage": root_usage,
            "interpretation": "post-check public observation slots; no rule tags or pending goals exist in this API; no predicate was executed"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cabal", default="cabal")
    parser.add_argument("--ghc", default="ghc")
    args = parser.parse_args()
    output = prepare_output_directory(args.output.resolve())
    baseline, name, target, predicate = frozen_baseline()
    sources = {str(path): sha256(path) for path in source_paths()}
    archives = {str(path.resolve()): sha256(path)
                for path in (ROOT / "dist-newstyle/build").rglob("libHSdjex-*.a")}
    if not archives:
        raise ValueError("a previously built djex library archive is required; this driver never builds the library")
    cabal = shutil.which(args.cabal)
    ghc = shutil.which(args.ghc)
    if not cabal or not ghc:
        raise ValueError("exact cabal/GHC executable must resolve before any process")
    tools = {str(Path(p).resolve()): sha256(p) for p in (cabal, ghc)}
    capture = output / "prefix"
    capture.mkdir()
    type_path = output / "original-type.hs.txt"
    type_path.write_text(target, encoding="utf-8")
    (output / "original-predicate.hs.txt").write_text(predicate, encoding="utf-8")
    request_inputs = {str(type_path): sha256(type_path)}
    compiler_output = output / "compiler"
    compiler_output.mkdir()
    executable = output / ("PrefixProbe.exe" if sys.platform == "win32" else "PrefixProbe")
    owned = Processes(output, 300)
    result = {"schema": "exference-public-prefix-run-v1", "status": "pending",
              "search_acceptance": False, "baseline": baseline,
              "sources_before": sources, "tools_before": tools,
              "library_archives_before": archives,
              "inputs_before": request_inputs,
              "runtime_guard_seconds_per_process": 300,
              "phases": ["compile diagnostic against current built djex", "capture one unchanged public query"]}
    write_json(output / "results.json", result)
    try:
        compiled = owned.run("compile", [cabal, "exec", "--", ghc,
            "-O1", "-Wall", "-Werror", "-package", "djex", "-package", "containers",
            "-outputdir", str(compiler_output), str(HERE / "PrefixProbe.hs"), "-o", str(executable)], cwd=ROOT)
        if compiled.returncode != 0:
            raise ValueError("diagnostic compilation failed; no search ran")
        result["probe_executable_before"] = sha256(executable)
        queried = owned.run("public-prefix", [str(executable), name, str(type_path), str(capture)], cwd=ROOT)
        if queried.returncode != 0:
            raise ValueError("public-prefix diagnostic failed")
        result["observations"] = verify_output(capture, baseline["original_cli_samples"])
        result["probe_executable_after"] = sha256(executable)
        result["status"] = "captured"
    except BaseException as failure:
        result["status"] = "failed"
        result["failure"] = str(failure)
        raise
    finally:
        result["sources_after"] = {path: sha256(path) for path in sources}
        result["library_archives_after"] = {path: sha256(path) for path in archives}
        result["tools_after"] = {path: sha256(path) for path in tools}
        result["inputs_after"] = {path: sha256(path) for path in request_inputs}
        result["source_integrity"] = result["sources_after"] == sources
        result["library_archive_integrity"] = result["library_archives_after"] == archives
        result["tool_integrity"] = result["tools_after"] == tools
        result["input_integrity"] = result["inputs_after"] == request_inputs
        result["probe_executable_integrity"] = result.get("probe_executable_before") == result.get("probe_executable_after") if "probe_executable_before" in result else None
        result["artifacts"] = {str(path.relative_to(output)): sha256(path) for path in output.rglob("*")
                               if path.is_file() and path.name != "results.json" and "compiler" not in path.relative_to(output).parts}
        write_json(output / "results.json", result)
    if not all(result[key] for key in ("source_integrity", "library_archive_integrity", "tool_integrity", "input_integrity", "probe_executable_integrity")):
        raise ValueError("source/input/executable integrity failed")


if __name__ == "__main__":
    main()
