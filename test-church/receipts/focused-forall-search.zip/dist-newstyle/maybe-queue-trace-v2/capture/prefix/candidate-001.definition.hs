extended_exference_maybeEither _ c _ = c
