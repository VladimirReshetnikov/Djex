extended_exference_maybeEither f1 c _ = f1 (\_ -> c) (\_ -> c)
