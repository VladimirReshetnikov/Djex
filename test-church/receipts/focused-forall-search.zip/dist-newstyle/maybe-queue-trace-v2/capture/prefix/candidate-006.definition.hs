extended_exference_maybeEither f1 c _ =
  f1 (\_ -> \j -> j) (\_ -> \_ -> c) c
