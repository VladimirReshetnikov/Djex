extended_exference_maybeEither f1 c _ =
  f1 (\_ -> \j -> j) (\f12 -> \m -> f12 c (\_ -> m)) c
