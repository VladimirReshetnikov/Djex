extended_exference_maybeEither f1 c _ =
  f1 (\f8 -> f8 c (\_ -> c)) (\f10 -> f10 c (\_ -> c))
