extended_exference_maybeEither f1 c _ =
  f1 (\f9 -> \j -> f9 c (\_ -> j)) (\_ -> \m -> m) c
