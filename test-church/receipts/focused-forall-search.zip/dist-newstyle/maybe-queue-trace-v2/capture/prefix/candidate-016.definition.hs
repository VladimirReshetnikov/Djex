extended_exference_maybeEither f1 c _ =
  f1 (\_ -> \j -> j) (\f12 -> \_ -> f12 c (\_ -> c)) c
