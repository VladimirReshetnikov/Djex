extended_exference_maybeEither f1 c _ =
  f1 (\f9 -> \_ -> f9 c (\_ -> c)) (\_ -> \m -> m) c
