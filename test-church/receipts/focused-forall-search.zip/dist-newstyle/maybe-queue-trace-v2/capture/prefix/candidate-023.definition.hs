extended_exference_maybeEither f1 c _ =
  f1 (\_ -> c) (\f10 -> f10 (\o -> o) (\_ -> \_ -> c) c)
