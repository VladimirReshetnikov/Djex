\_ c _ -> let () = () in c
