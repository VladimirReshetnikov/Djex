extended_exference_maybeEither f1 c _ =
  f1 (\f8 -> f8 (\o -> o) (\_ -> \_ -> c) c) (\_ -> c)
