extended_exference_maybeEither f1 c _ =
  f1 (\f9 -> \j -> f9 j (\_ -> j)) (\f12 -> \m -> f12 m (\_ -> c)) c
