extended_exference_maybeEither f1 c _ =
  f1 (\f8 -> f8 (\_ -> c) (\_ -> \r -> r) c) (\_ -> c)
