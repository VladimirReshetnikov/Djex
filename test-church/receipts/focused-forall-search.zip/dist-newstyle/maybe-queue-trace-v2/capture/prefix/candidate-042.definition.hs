extended_exference_maybeEither f1 c f4 =
  f1 (\_ -> c) (\f10 -> f10 c (\n -> f4 (\_ -> \f18 -> f18 n)))
