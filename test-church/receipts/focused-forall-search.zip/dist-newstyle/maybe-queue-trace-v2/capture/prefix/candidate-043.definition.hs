extended_exference_maybeEither f1 c f4 =
  f1 (\f8 -> f8 c (\n -> f4 (\f17 -> \_ -> f17 n))) (\_ -> c)
