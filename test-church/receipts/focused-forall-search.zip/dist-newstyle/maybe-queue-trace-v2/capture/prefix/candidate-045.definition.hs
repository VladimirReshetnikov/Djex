extended_exference_maybeEither f1 c _ =
  f1 (\_ -> \j -> j) (\f12 -> f12 (\r -> r) (\_ -> \_ -> c)) c
