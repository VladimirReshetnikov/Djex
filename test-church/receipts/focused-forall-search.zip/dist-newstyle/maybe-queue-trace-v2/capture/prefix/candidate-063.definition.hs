extended_exference_maybeEither f1 c _ =
  f1 (\_ -> \_ -> c) (\_ -> \_ -> c) f1
