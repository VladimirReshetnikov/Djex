extended_exference_maybeEither f1 c f4 =
  f1
  (\_ -> \j -> j)
  (\f12 -> \m -> f12 m (\q -> f4 (\_ -> \f21 -> f21 q)))
  c
