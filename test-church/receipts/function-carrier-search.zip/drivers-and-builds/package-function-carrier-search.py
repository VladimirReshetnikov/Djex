from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT=Path('C:/Djex')
LEANT=Path('C:/Leant')
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
full=read(ROOT/'dist-newstyle/tree-arrow-context-complete-v1/regression/results.json')
length=read(ROOT/'dist-newstyle/tree-arrow-context-length-v1/results.json')
signatures=read(ROOT/'dist-newstyle/tree-arrow-context-signatures-v1/results.json')
extended=read(ROOT/'dist-newstyle/tree-arrow-context-extended-v1/results.json')
tree=read(LEANT/'dist-newstyle/tree-arrow-context-haskell-v1/results.json')
focused=read(ROOT/'dist-newstyle/tree-arrow-context-gates-v1/results.json')
engine=ROOT/'exference/src-core/Language/Haskell/Exference/Core/Internal/Exference.hs'
length_source=ROOT/'synthesis/test-length/Spec.hs'
assert full['sources_unchanged'] and full['helpers_unchanged']
assert [r['suite'] for r in full['rows'] if r['status']!='passed']==['synthesis-length-tests']
assert length['status']=='passed' and length['sources_unchanged'] and length['helpers_unchanged']
assert len(full['rows'])==15 and sum(r['inventory_count'] for r in full['rows'])==2309
assert length['rows'][0]['passed_count']==436
assert full['helper_hashes_after']==length['helper_hashes_before']
assert [p for p,h in full['source_hashes_after'].items() if length['source_hashes_before'].get(p)!=h]==[str(length_source)]
assert sha(engine.read_bytes())==full['source_hashes_after'][str(engine)]==length['source_hashes_after'][str(engine)]
assert signatures['status']=='passed' and signatures['unchanged']
assert signatures['after'][str(engine)]==sha(engine.read_bytes())
assert extended['status']=='passed' and extended['sources_unchanged'] and extended['executables_unchanged']
assert [extended[k] for k in ['passed_synthesis_cells','passed_false_controls','passed_oracle_controls']]==[13,1,28]
assert all(full['helper_hashes_after'].get(p,h)==h for p,h in extended['executable_hashes'].items())
assert tree['status']=='passed' and all(tree[k] for k in ['source_integrity','executable_integrity','input_integrity','library_integrity','process_capture_integrity'])
assert tree['source_hashes'][str(engine)]==sha(engine.read_bytes())
assert focused['status']=='passed' and focused['unchanged']
verdict=tree['results'][0]['ghc_verdict']
assert verdict['accepted'] and verdict['false_observation_count']==1024 and not verdict['false_passed_indices']
for report in [full,length,signatures,extended,tree,focused]:
    for process in report['processes']:
        for stream in ['stdout','stderr']:
            assert sha(Path(process[stream+'_path']).read_bytes())==process[stream+'_sha256']

files={}
directories=[
 ('final-focused',ROOT/'dist-newstyle/tree-arrow-context-gates-v1'),
 ('final-complete-run',ROOT/'dist-newstyle/tree-arrow-context-complete-v1'),
 ('final-length',ROOT/'dist-newstyle/tree-arrow-context-length-v1'),
 ('final-signatures',ROOT/'dist-newstyle/tree-arrow-context-signatures-v1'),
 ('final-extended',ROOT/'dist-newstyle/tree-arrow-context-extended-v1'),
 ('final-tree',LEANT/'dist-newstyle/tree-arrow-context-haskell-v1'),
 ('broad-focused',ROOT/'dist-newstyle/tree-arrow-focused-v2'),
 ('broad-complete-run',ROOT/'dist-newstyle/tree-arrow-complete-validation-v1'),
 ('broad-source',ROOT/'dist-newstyle/tree-arrow-broad-source-v1'),
 ('goal-only-gates',ROOT/'dist-newstyle/tree-arrow-monomorphic-gates-v1'),
 ('goal-only-source',ROOT/'dist-newstyle/tree-arrow-monomorphic-source-v1'),
]
for label,directory in directories:
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.suffix in {'.json','.txt','.log','.hs','.py','.tsv','.inc','.md'}:
            files[label+'/'+path.relative_to(directory).as_posix()]=path.read_bytes()
sources=[engine,ROOT/'test-integration/RecursorSpec.hs',ROOT/'test-cli/Spec.hs',length_source]
for path in sources:
    files['final-source/'+path.relative_to(ROOT).as_posix()]=path.read_bytes()
files['final-source/change.patch']=subprocess.check_output(['git','diff','--',*[str(p) for p in sources]],cwd=ROOT)
for name in ['tree-arrow-regression-build-v2.log','tree-arrow-regression-build-v3.log',
 'tree-arrow-monomorphic-build-v1.log','tree-arrow-context-build-v1.log',
 'tree-arrow-elaboration-regression-build-v1.log','tree-arrow-elaboration-regression-build-v2.log',
 'tree-arrow-length-fixture-build-v1.log','tree-arrow-context-length-original.hs',
 'run-tree-arrow-recursors.py','run-tree-arrow-guarded-gates.py','run-tree-arrow-context-gates.py',
 'run-loaded-provider-regression.py','run-tree-arrow-length-regression.py',
 'validate-tree-arrow-context-complete.py','validate-tree-arrow-context-signatures.py']:
    files['drivers-and-builds/'+name]=(ROOT/'dist-newstyle'/name).read_bytes()
files['drivers-and-builds/package-function-carrier-search.py']=Path(__file__).read_bytes()
out=ROOT/'test-church/receipts'
archive=out/'function-carrier-search.zip'
receipt=out/'function-carrier-search.json'
assert not archive.exists() and not receipt.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,data in files.items():assert sha(z.read(name))==sha(data)
data={
 'status':'accepted_canonical_haskell_milestone',
 'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'source_hashes':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sources},
 'validation':{
   'regressions':{'suite_count':15,'test_count':2309,
      'qualification':'14 complete suites passed together; the complete 436-test Length suite passed after its test-only timing repair. Engine and helper identities are unchanged between these runs; earlier failures are retained.',
      'original_complete_run_status':full['status'],
      'changed_source_before_length_rerun':str(length_source.relative_to(ROOT))},
   'signatures':{'djinn':350,'exference':350},
   'extended_exference':{'accepted':13,'false_controls':1,'oracle_controls':28,'settings':extended['settings']},
   'tree_exference':{'observations':16,'candidate_count':1024,'verdict':verdict,'limits':tree['limits']},
   'native_lean':'not_run_for_this_change',
 },
 'rejected_experiments':{
   'broad_arrow_estimate':'tree accepted; Church CLI test timed out at 180 seconds',
   'monomorphic_goal_only':'tree accepted; Church completed with 256 false candidates and no match',
 },
 'archive':{'path':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'artifact_count':len(files),'binaries_included':False},
 'artifacts':[{'path':name,'sha256':sha(data),'bytes':len(data)} for name,data in sorted(files.items())],
}
receipt.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:data[k] for k in ['status','validation','archive']},indent=2))
