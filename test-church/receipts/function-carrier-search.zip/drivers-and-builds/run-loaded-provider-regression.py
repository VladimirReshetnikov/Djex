"""Serial complete-suite validation with exact inventories and pinned artifacts."""
from pathlib import Path
import hashlib, json, os, re, shutil, sys
ROOT = Path('C:/Djex')
BASE = ROOT / 'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17'
sys.path.insert(0, str(ROOT / 'test-church'))
import behavior_runtime as runtime

SUITES = ['exference-engine-tests', 'exference-tests', 'synthesis-length-tests',
    'djex-tests', 'djex-api-tests', 'djex-cli-tests', 'exference-frontend-api-tests',
    'exference-cli-tests', 'synthesis-tests', 'synthesis-certificate-tests',
    'synthesis-term-graph-fingerprint-tests', 'djinn-source-graph-tests',
    'djinn-source-graph-private-tests', 'djinn-tests', 'djinn-cli-tests']
REQUIRED = {'exference-tests': [
    'loaded value schemes preserve specified binder order and reseal',
    'loaded source scheme cannot replace its flat binding'],
    'djex-cli-tests': ['REPL synthesizes loaded constraint-only providers with exact replay',
    'REPL contextual Djinn instance gaps weaken only negative evidence']}

def hashes(paths):
    return {str(p.resolve()): runtime.sha256(p) for p in sorted(set(paths), key=str)}

def main():
    output = runtime.prepare_output_directory(Path(sys.argv[1]).resolve())
    processes = runtime.Processes(output, 1800)
    source_files = [Path(__file__), ROOT / 'djex.cabal', ROOT / 'test-church/behavior_runtime.py',
        ROOT / 'dist-newstyle/cache/plan.json']
    for directory in ['src', 'exference', 'djinn', 'synthesis', 'test-cli', 'test-api',
            'test-integration', 'test-support']:
        source_files += [p for p in (ROOT / directory).rglob('*') if p.is_file()
            and p.suffix in {'.hs', '.lhs', '.hsc', '.py', '.golden', '.txt', '.inc'}
            and not {'dist-newstyle', '__pycache__', 'results'}.intersection(p.parts)]
    helpers = [BASE / f'x/{name}/build/{name}/{name}.exe'
        for name in ['djex', 'djinn', 'exference', 'djex-fake-cabal', 'djex-fake-z3']]
    helpers += [Path(shutil.which(name)) for name in ['ghc', 'runghc', 'cabal']]
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith('TASTY_')}
    env['djex_datadir'] = str(ROOT)
    env['PATH'] = os.pathsep.join(str(p.parent) for p in helpers) + os.pathsep + env.get('PATH', '')
    report = {'status': 'running', 'selected_suites': SUITES, 'source_hashes_before': hashes(source_files),
        'helper_hashes_before': hashes(helpers), 'rows': []}
    runtime.write_json(output / 'results.json', report)
    try:
        for suite in SUITES:
            binary = BASE / f't/{suite}/build/{suite}/{suite}.exe'
            row = {'suite': suite, 'status': 'running', 'executable_sha256': runtime.sha256(binary)}
            report['rows'].append(row)
            listed = processes.run(suite + '-inventory', [binary, '--list-tests'], cwd=ROOT, env=env)
            names = [line for line in listed.stdout.splitlines() if line.strip()]
            assert listed.returncode == 0 and names and len(set(names)) == len(names)
            for required in REQUIRED.get(suite, []):
                assert sum(item.endswith('.' + required) or item == required for item in names) == 1, required
            row.update(inventory=names, inventory_count=len(names))
            runtime.write_json(output / 'results.json', report)
            result = processes.run(suite, [binary, '-j1', '--color=never', '--timeout=180s'], cwd=ROOT, env=env)
            summaries = re.findall(r'^All (\d+) tests passed \(([0-9.]+)s\)\s*$',
                result.stdout + '\n' + result.stderr, re.M)
            row['executable_unchanged'] = runtime.sha256(binary) == row['executable_sha256']
            row['exit_code'] = result.returncode
            if result.returncode == 0 and len(summaries) == 1 and int(summaries[0][0]) == len(names) and row['executable_unchanged']:
                row.update(status='passed', passed_count=len(names), seconds=float(summaries[0][1]))
            else:
                row.update(status='failed')
            runtime.write_json(output / 'results.json', report)
            print(suite + ': ' + row['status'], flush=True)
        report['status'] = 'passed' if all(row['status'] == 'passed' for row in report['rows']) else 'failed'
    finally:
        report.update(source_hashes_after=hashes(source_files), helper_hashes_after=hashes(helpers), processes=processes.rows)
        report['sources_unchanged'] = report['source_hashes_before'] == report['source_hashes_after']
        report['helpers_unchanged'] = report['helper_hashes_before'] == report['helper_hashes_after']
        if not report['sources_unchanged'] or not report['helpers_unchanged'] or len(report['rows']) != len(SUITES):
            report['status'] = 'failed'
        runtime.write_json(output / 'results.json', report)
    return 0 if report['status'] == 'passed' else 1

if __name__ == '__main__':
    raise SystemExit(main())
