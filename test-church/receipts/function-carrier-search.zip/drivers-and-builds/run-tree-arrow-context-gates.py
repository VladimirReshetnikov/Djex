from pathlib import Path
import os, re, sys
ROOT=Path('C:/Djex')
BASE=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17'
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
out=runtime.prepare_output_directory(Path(sys.argv[1]).resolve())
cases=[('private-engine','exference-engine-tests',None,92),
       ('tree-and-lists','djex-tests','Supplied generic recursors',9),
       ('church-branches','djex-cli-tests','Exference composes both Church branches within the original window',1),
       ('elaboration','djex-cli-tests','live graph elaboration repairs and displays the exact checked candidate',1)]
cases=[cases[i] for i in [0,3,2,1]]
helpers=[BASE/f'x/{name}/build/{name}/{name}.exe' for name in ['djex','djinn','exference','djex-fake-cabal','djex-fake-z3']]
paths=[ROOT/'exference/src-core/Language/Haskell/Exference/Core/Internal/Exference.hs',ROOT/'test-integration/RecursorSpec.hs',ROOT/'test-cli/Spec.hs',Path(__file__).resolve(),*helpers]
paths.extend(BASE/f't/{suite}/build/{suite}/{suite}.exe' for _,suite,_,_ in cases)
snapshot=lambda:{str(p):runtime.sha256(p) for p in sorted(set(paths))}
env={k:v for k,v in os.environ.items() if not k.upper().startswith('TASTY_')}
env['djex_datadir']=str(ROOT)
env['PATH']=os.pathsep.join(str(p.parent) for p in helpers)+os.pathsep+env.get('PATH','')
report={'status':'running','before':snapshot(),'rows':[]}
processes=runtime.Processes(out,900)
runtime.write_json(out/'results.json',report)
try:
    for name,suite,pattern,count in cases:
        exe=BASE/f't/{suite}/build/{suite}/{suite}.exe'
        command=[exe,'-j1','--timeout=180s','--color=never']
        if pattern:command+=['-p',pattern]
        result=processes.run(name,command,cwd=ROOT,env=env)
        passed=result.returncode==0 and re.search(r'^All '+str(count)+r' tests passed ',result.stdout,re.M)
        row={'name':name,'status':'passed' if passed else 'failed','exit_code':result.returncode}
        report['rows'].append(row)
        runtime.write_json(out/'results.json',report)
        print(name,row['status'],flush=True)
        if not passed:break
    report['status']='passed' if len(report['rows'])==len(cases) and all(r['status']=='passed' for r in report['rows']) else 'failed'
finally:
    report.update(after=snapshot(),processes=processes.rows)
    report['unchanged']=report['before']==report['after']
    if not report['unchanged'] or len(report['rows'])!=len(cases):report['status']='failed'
    runtime.write_json(out/'results.json',report)
sys.exit(0 if report['status']=='passed' else 1)
