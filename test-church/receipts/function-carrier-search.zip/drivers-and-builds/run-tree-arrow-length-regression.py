from pathlib import Path
import importlib.util

source = Path('C:/Djex/dist-newstyle/run-loaded-provider-regression.py')
spec = importlib.util.spec_from_file_location('regression', source)
regression = importlib.util.module_from_spec(spec)
spec.loader.exec_module(regression)
regression.SUITES = ['synthesis-length-tests']
raise SystemExit(regression.main())
