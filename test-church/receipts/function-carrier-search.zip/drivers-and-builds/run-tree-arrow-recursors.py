from pathlib import Path
import json, os, re, sys
ROOT=Path('C:/Djex')
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
out=runtime.prepare_output_directory(Path(sys.argv[1]).resolve())
exe=ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17/t/djex-tests/build/djex-tests/djex-tests.exe'
paths=[ROOT/'exference/src-core/Language/Haskell/Exference/Core/Internal/Exference.hs',ROOT/'test-integration/RecursorSpec.hs',exe]
snapshot=lambda:{str(p):runtime.sha256(p) for p in paths}
report=dict(status='running',before=snapshot())
processes=runtime.Processes(out,900)
runtime.write_json(out/'results.json',report)
try:
    env={k:v for k,v in os.environ.items() if not k.upper().startswith('TASTY_')}
    env['djex_datadir']=str(ROOT)
    result=processes.run('supplied-recursors',[exe,'-p','Supplied generic recursors','-j1','--timeout=180s','--color=never'],cwd=ROOT,env=env)
    report['exit_code']=result.returncode
    report['status']='passed' if result.returncode==0 and re.search(r'^All 9 tests passed ',result.stdout,re.M) else 'failed'
finally:
    report.update(after=snapshot(),processes=processes.rows)
    report['unchanged']=report['before']==report['after']
    if not report['unchanged']:report['status']='failed'
    runtime.write_json(out/'results.json',report)
    print(json.dumps({'status':report['status'],'unchanged':report['unchanged']}),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
