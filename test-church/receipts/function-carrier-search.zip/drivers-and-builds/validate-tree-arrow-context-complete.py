from pathlib import Path
import importlib.util, subprocess, sys
root=Path('C:/Djex')
spec=importlib.util.spec_from_file_location('regression',root/'dist-newstyle/run-loaded-provider-regression.py')
regression=importlib.util.module_from_spec(spec)
spec.loader.exec_module(regression)
out=root/'dist-newstyle/tree-arrow-context-complete-v1'
out.mkdir(exist_ok=False)
targets=['test:'+name for name in regression.SUITES]
targets+=['test:djex-church-tests']
targets+=['exe:'+name for name in ['djex','djinn','exference','djex-fake-cabal','djex-fake-z3']]
command=['cabal','build',*targets,'-j1','--ghc-options=-Werror']
with (out/'strict-build.log').open('w',encoding='utf-8') as log:
    result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
if result.returncode: sys.exit(result.returncode)
print('Strict serial build passed; starting complete regression.',flush=True)
sys.exit(subprocess.call([sys.executable,str(root/'dist-newstyle/run-loaded-provider-regression.py'),str(out/'regression')],cwd=root))
