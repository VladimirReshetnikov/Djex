{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_catMaybes) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_catMaybes :: (forall church0. ((forall church2. (((forall church1. (church1 -> ((church0 -> church1) -> church1))) -> (church2 -> church2)) -> (church2 -> church2))) -> (forall church3. ((church0 -> (church3 -> church3)) -> (church3 -> church3)))))
extended_exference_catMaybes f1 f3 =
  f1 (\f8 -> \i -> f8 i (\m -> f3 m i))
