{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_either) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_either :: (forall church0 church1 church2. ((church0 -> church1) -> ((church2 -> church1) -> ((forall church3. ((church0 -> church3) -> ((church2 -> church3) -> church3))) -> church1))))
extended_exference_either f1 f2 f3 = f3 f1 f2
