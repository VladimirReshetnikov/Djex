{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_foldl) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_foldl :: (forall church0 church1. ((church0 -> (church1 -> church0)) -> (church0 -> ((forall church2. ((church1 -> (church2 -> church2)) -> (church2 -> church2))) -> church0))))
extended_exference_foldl f1 b f3 =
  f3 (\h -> \f9 -> \j -> f9 (f1 j h)) (\o -> o) b
