{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_foldr) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_foldr :: (forall church0 church1. ((church0 -> (church1 -> church1)) -> (church1 -> ((forall church2. ((church0 -> (church2 -> church2)) -> (church2 -> church2))) -> church1))))
extended_exference_foldr f1 b f3 = f3 f1 b
