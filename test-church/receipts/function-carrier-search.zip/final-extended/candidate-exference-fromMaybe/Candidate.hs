{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_fromMaybe) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_fromMaybe :: (forall church0. (church0 -> ((forall church1. (church1 -> ((church0 -> church1) -> church1))) -> church0)))
extended_exference_fromMaybe a f2 = f2 a (\f -> f)
