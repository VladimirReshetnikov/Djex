{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_isLeft) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_isLeft :: (forall church0 church1. ((forall church2. ((church0 -> church2) -> ((church1 -> church2) -> church2))) -> (forall church3. (church3 -> (church3 -> church3)))))
extended_exference_isLeft f1 c d = f1 (\_ -> c) (\_ -> d)
