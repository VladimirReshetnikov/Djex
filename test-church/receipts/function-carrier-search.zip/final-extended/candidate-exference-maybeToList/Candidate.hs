{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_maybeToList) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_maybeToList :: (forall church0. ((forall church1. (church1 -> ((church0 -> church1) -> church1))) -> (forall church2. ((church0 -> (church2 -> church2)) -> (church2 -> church2)))))
extended_exference_maybeToList f1 f3 d = f1 d (\h -> f3 h d)
