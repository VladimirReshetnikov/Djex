{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_numeralAdd) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_numeralAdd :: (forall r. (r -> r) -> r -> r) -> (forall r. (r -> r) -> r -> r) -> (forall r. (r -> r) -> r -> r)
extended_exference_numeralAdd f1 f2 f4 e = f1 f4 (f2 f4 e)
