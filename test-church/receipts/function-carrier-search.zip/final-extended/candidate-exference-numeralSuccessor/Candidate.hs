{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (extended_exference_numeralSuccessor) where
import Prelude (Int)
import qualified Prelude (Int)
extended_exference_numeralSuccessor :: (forall r. (r -> r) -> r -> r) -> (forall r. (r -> r) -> r -> r)
extended_exference_numeralSuccessor f1 f3 d = f3 (f1 f3 d)
