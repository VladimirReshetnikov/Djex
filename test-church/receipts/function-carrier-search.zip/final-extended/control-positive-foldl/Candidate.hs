{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (generated) where
import Prelude (Int)
import qualified Prelude (Int)
generated :: (forall church0 church1. ((church0 -> (church1 -> church0)) -> (church0 -> ((forall church2. ((church1 -> (church2 -> church2)) -> (church2 -> church2))) -> church0))))
generated = \step zero xs -> xs (\x k acc -> k (step acc x)) (\x -> x) zero
