{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (generated) where
import Prelude (Int)
import qualified Prelude (Int)
import ExtendedNumeric (numericZero, numericSuccessor)
generated :: (forall church0. ((forall church1. ((church0 -> (church1 -> church1)) -> (church1 -> church1))) -> Int))
generated = \xs -> xs (\_ n -> numericSuccessor n) numericZero
