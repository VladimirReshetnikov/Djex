{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (generated) where
import Prelude (Int)
import qualified Prelude (Int)
generated :: (forall r. (r -> r) -> r -> r) -> (forall r. (r -> r) -> r -> r)
generated = \n step zero -> step (n step zero)
