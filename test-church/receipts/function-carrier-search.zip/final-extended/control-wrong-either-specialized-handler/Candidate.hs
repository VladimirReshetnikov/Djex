{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (generated) where
import Prelude (Int)
import qualified Prelude (Int)
generated :: (Prelude.Int -> Prelude.Int) -> (Prelude.Int -> Prelude.Int) -> (forall r. (Prelude.Int -> r) -> (Prelude.Int -> r) -> r) -> Prelude.Int
generated onLeft _ e = e onLeft onLeft
