{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Main (main) where
import Prelude
import qualified Prelude
import qualified Candidate
import qualified Control.Exception as E
import qualified System.Timeout as T
import qualified System.Exit as Exit
main :: IO ()
main = do
  outcome <- T.timeout 2000000 (E.try (E.evaluate (Prelude.not (Candidate.generated (\x -> x+7) (\x -> 3*x) (\_ onRight -> onRight 2) == (6 :: Prelude.Int)))) :: IO (Either E.SomeException Bool))
  case outcome of
    Just (Right True) -> putStrLn "PASS wrong-either-specialized-handler"
    _ -> putStrLn ("FAIL wrong-either-specialized-handler: " ++ show outcome) >> Exit.exitFailure
