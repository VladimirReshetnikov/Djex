{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Main (main) where

import Data.Maybe (fromMaybe)
import Control.Monad (forM_, void, when)
import Control.Concurrent (forkIO, myThreadId, threadDelay, throwTo)
import Control.Concurrent.MVar
  ( newEmptyMVar
  , putMVar
  , takeMVar
  )
import Control.Exception
  ( Exception
  , SomeException
  , displayException
  , evaluate
  , finally
  , throwIO
  , try
  )
import Control.DeepSeq (force)
import qualified Crypto.Hash.SHA256 as SHA256
import qualified Data.ByteString as BS
import qualified Data.ByteString.Char8 as BSC
import Data.List (intercalate, isInfixOf, nub, sort)
import Data.IORef (newIORef, readIORef, writeIORef)
import Data.Word (Word64, Word8)
import GHC.Clock (getMonotonicTimeNSec)
import Numeric.Natural (Natural)
import System.Directory (doesPathExist)
import qualified System.Info as SystemInfo
import System.Timeout (timeout)
import Unsafe.Coerce (unsafeCoerce)

import qualified SMTLibLiveSpec
import qualified SMTLibQFLIASpec
import qualified LengthWhereSpec
import qualified DjinnSourceGraphSpec
import qualified Language.Haskell.Djex as Djex
import Language.Haskell.Synthesis.Constraint (Constraint (..))
import Language.Haskell.Synthesis.Declaration
  ( DataConstructor (DataConstructor)
  , Declaration
      ( AbstractTypeDeclaration
      , ClassDeclaration
      , DataTypeDeclaration
      , InstanceDeclaration
      , ValueDeclaration
      )
  , TypeParameter (TypeParameter)
  , ValueSignature (ValueSignature)
  )
import qualified Language.Haskell.Synthesis.Fingerprint as Fingerprint
import Language.Haskell.Synthesis.Inventory
  ( Inventory
  , mkInventory
  )
import qualified Language.Haskell.Synthesis.Internal.Fingerprint
  as InternalFingerprint
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Execution
  as InternalSMTLibExecution
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Protocol
  as SMTLibProtocol
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Protocol.SpinePair
  as SMTLibSpinePairProtocol
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Session
  as SMTLibSession
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Session.Capability
  as SMTLibCapability
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Session.Process
  as SMTLibProcess
import qualified Language.Haskell.Synthesis.Internal.SMTLib.Causal
  as SMTLibCausal
import qualified Language.Haskell.Synthesis.Internal.SMTLib.Stream
  as SMTLibStream
import qualified Language.Haskell.Synthesis.Internal.SMTLib.Z3.Execution
  as Z3Execution
import qualified Language.Haskell.Synthesis.Internal.TypedCandidate
  as InternalTypedCandidate
import qualified Language.Haskell.Synthesis.Internal.TypedGenerated.Certificate
  as InternalCertificate
import qualified Language.Haskell.Synthesis.Internal.TypedGenerated.Certificate.Association
  as InternalCertificateAssociation
import Language.Haskell.Synthesis.Kind (Kind (ProperTypeKind))
import Language.Haskell.Synthesis.KindInference
  ( KindInferenceError (UnknownTypeConstructor)
  , KindInventoryPolicy (ClosedKindInventory)
  )
import Language.Haskell.Synthesis.Name
  ( Boxity (Boxed, Unboxed)
  , Name
  , consName
  , listName
  , parseName
  )
import qualified Language.Haskell.Synthesis.Semantic.Length as Length
import qualified Language.Haskell.Synthesis.Semantic.Length.CounterexampleBank
  as LengthBank
import qualified Language.Haskell.Synthesis.Semantic.Length.Evaluate as Evaluate
import qualified Language.Haskell.Synthesis.Semantic.Length.Problem as LengthProblem
import qualified Language.Haskell.Synthesis.Semantic.Length.SMTLib as SMTLib
import qualified Language.Haskell.Synthesis.Semantic.Length.SMTLib.Execution
  as SMTLibExecution
import qualified Language.Haskell.Synthesis.Semantic.Length.SMTLib.Live
  as SMTLibLive
import qualified Language.Haskell.Synthesis.Semantic.Length.SMTLib.Observation
  as SMTLibObservation
import qualified Language.Haskell.Synthesis.Semantic.Length.SMTLib.Response
  as SMTLibResponse
import qualified Language.Haskell.Synthesis.Semantic.Observation as Observation
import qualified Language.Haskell.Synthesis.Semantic.Problem as SemanticProblem
import Language.Haskell.Synthesis.Type (Type (..), Variable (..))
import Test.Tasty (TestTree, defaultMain, testGroup)
import Test.Tasty.HUnit
  ( assertBool
  , assertFailure
  , testCase
  , (@?=)
  )

main :: IO ()
main = defaultMain lengthTests

lengthTests :: TestTree
lengthTests = testGroup "finite-list-spine-length/v1"
  [ LengthWhereSpec.lengthWhereTests
  , DjinnSourceGraphSpec.tests
  , limitTests
  , contextTests
  , contractTests
  , spinePairContractTests
  , providerTests
  , sessionTests
  , interpretationPolicyCharacterizationTests
  , unifiedInterpretationPolicyTests
  , candidateProblemTests
  , spinePairProblemTests
  , spinePairSMTLibTests
  , associatedCertificateCandidateTests
  , problemReplayTests
  , counterexampleBankTests
  , counterexampleBankBridgeTests
  , counterexampleSimplificationTests
  , inputBoxValidationTests
  , applicableDomainValidationTests
  , SMTLibQFLIASpec.smtLibQFLIATests
  , smtLibTests
  , smtLibProtocolTests
  , SMTLibLiveSpec.smtLibLiveTests
  , usableWorkBudgetTests
  , smtLibLiveQueryTests
  , smtLibLiveFacadeTests
  , smtLibSpinePairLiveFacadeTests
  , evaluationTests
  , normalizationTests
  , productiveBoundTests
  , fingerprintTests
  ]

usableWorkBudgetTests :: TestTree
usableWorkBudgetTests = testGroup "shared live usable-work budget"
  [ testCase "validate positive, host-wait, and monotonic-clock durations"
      assertLiveUsableWorkBudgetValidation
  , testCase
      "reject a normally returning all-pure callback only after it returns"
      assertLiveUsableWorkOwnerReturnExpiry
  , testCase "map absolute-deadline overflow to a sanitized resource failure"
      assertLiveUsableWorkDeadlineResourceOverflow
  , testCase "reject an expired token before workspace launch"
      assertLiveUsableWorkWorkspaceExpiry
  , testCase "bound a hung opener by the shared deadline"
      assertLiveUsableWorkOpenerExpiry
  , testCase
      "preserve legacy identity bytes and distinguish budgeted query schemas"
      assertLiveUsableWorkIdentitySchemas
  , testCase
      "share one tie-winning deadline across scalar and pair ordinals"
      assertLiveUsableWorkMixedDomainDeadline
  , testCase "retain the shorter fresh per-query deadline"
      assertLiveUsableWorkLocalQueryDeadline
  , testCase
      "sanitize query expiry, poison atomically, and remove the workspace"
      assertLiveUsableWorkPublicQueryExpiry
  , testCase "check public session callback return before fresh cleanup"
      assertLiveUsableWorkSessionCallbackReturnExpiry
  , testCase "exclude final cleanup from the convenience entrance"
      assertLiveUsableWorkConvenienceCleanupExclusion
  , testCase "rethrow an expired callback exception after durable cleanup"
      assertLiveUsableWorkCallbackException
  , testCase
      "reject an expired escaped v2 closure before resources or solver events"
      assertLiveScopedUsableWorkEscapedClosure
  , testCase
      "reject a forked v2 use without spending the owner's live authority"
      assertLiveScopedUsableWorkWrongThread
  , testCase "close v2 authority after synchronous callback exceptions"
      assertLiveScopedUsableWorkSynchronousException
  , testCase "close v2 authority after throwTo callback exceptions"
      assertLiveScopedUsableWorkAsynchronousException
  , testCase "observe one absolute v2 deadline across repeated checkpoints"
      assertLiveScopedUsableWorkCheckpointExpiry
  , testCase
      "separate v2 ready, scalar, and pair identity from byte-exact v1 tags"
      assertLiveScopedUsableWorkIdentitySchemas
  , testCase
      "bind sealed-launch scalar and pair identities under scoped authority"
      assertDescriptorBoundScopedIdentitySchemas
  , testCase
      "bind effective-ID scalar and pair identities under scoped authority"
      assertEffectiveIDDescriptorBoundScopedIdentitySchemas
  , testCase
      "bind exec-check scalar and pair identities under shared and scoped authority"
      assertExecveCheckDescriptorBoundBudgetIdentitySchemas
  , testCase "exclude fresh finalization from the scoped convenience entrance"
      assertLiveScopedUsableWorkConvenienceCleanupExclusion
  ]

assertLiveUsableWorkBudgetValidation :: IO ()
assertLiveUsableWorkBudgetValidation = do
  let source milliseconds = SMTLibLive.LengthSMTLibLiveUsableWorkBudgetSource
        { SMTLibLive.lengthSMTLibLiveUsableWorkBudgetSourceMilliseconds =
            milliseconds }
      microsecondsOverflow = maxBound `div` 1000 + 1
      nanosecondsOverflowInteger =
        toInteger (maxBound :: Word64) `div` 1000000 + 1
  assertBudgetValidationFailure
    (SMTLibLive.LengthSMTLibLiveUsableWorkBudgetNonPositive 0)
    $ SMTLibLive.mkLengthSMTLibLiveUsableWorkBudget (source 0)
  assertBudgetValidationFailure
    (SMTLibLive.LengthSMTLibLiveUsableWorkBudgetNonPositive (-1))
    $ SMTLibLive.mkLengthSMTLibLiveUsableWorkBudget (source (-1))
  assertBudgetValidationFailure
    (SMTLibLive.LengthSMTLibLiveUsableWorkBudgetMicrosecondsOverflow
      microsecondsOverflow)
    $ SMTLibLive.mkLengthSMTLibLiveUsableWorkBudget
        (source microsecondsOverflow)
  when (nanosecondsOverflowInteger <= toInteger (maxBound :: Int)) $ do
      let nanosecondsOverflow = fromInteger nanosecondsOverflowInteger
      assertBudgetValidationFailure
        (SMTLibLive.LengthSMTLibLiveUsableWorkBudgetMicrosecondsOverflow
          nanosecondsOverflow)
        $ SMTLibLive.mkLengthSMTLibLiveUsableWorkBudget
            (source nanosecondsOverflow)
  one <- mkLiveUsableWorkBudget 1
  two <- mkLiveUsableWorkBudget 2
  assertBool "validated usable-work budgets lost their exact ordering"
    $ one < two
  void (evaluate (force sourceOne))
  void (evaluate (force one))
 where
 sourceOne = SMTLibLive.LengthSMTLibLiveUsableWorkBudgetSource 1

assertBudgetValidationFailure
  :: SMTLibLive.LengthSMTLibLiveUsableWorkBudgetError
  -> Either
      SMTLibLive.LengthSMTLibLiveUsableWorkBudgetError
      SMTLibLive.LengthSMTLibLiveUsableWorkBudget
  -> IO ()
assertBudgetValidationFailure expected result = case result of
  Left actual -> actual @?= expected
  Right _ -> assertFailure $ "expected usable-work budget rejection: " ++
    show expected

assertLiveUsableWorkOwnerReturnExpiry :: IO ()
assertLiveUsableWorkOwnerReturnExpiry = do
  budget <- mkLiveUsableWorkBudget 20
  callbackReturned <- newIORef False
  scoped <- SMTLibLive.withLengthSMTLibLiveUsableWorkDeadline budget $ \_ -> do
    threadDelay 80000
    writeIORef callbackReturned True
  readIORef callbackReturned >>= (@?= True)
  assertPublicLiveSessionFailure
    SMTLibLive.LengthSMTLibLiveSessionDeadlineExceeded scoped
  let rendered = either show (const "unexpected-success") scoped
  assertBool "public deadline failure exposed raw monotonic deadline material"
    $ not ("nanosecond" `isInfixOf` rendered) &&
        not ("ProcessDeadline" `isInfixOf` rendered)

assertLiveUsableWorkDeadlineResourceOverflow :: IO ()
assertLiveUsableWorkDeadlineResourceOverflow = do
  let maximumDeltaMilliseconds =
        toInteger (maxBound :: Word64) `div` 1000000
  if maximumDeltaMilliseconds > toInteger (maxBound :: Int)
    then pure ()
    else do
      budget <- mkLiveUsableWorkBudget
        $ fromInteger maximumDeltaMilliseconds
      reached <- newIORef False
      scoped <- SMTLibLive.withLengthSMTLibLiveUsableWorkDeadline budget
        $ \_ -> writeIORef reached True
      readIORef reached >>= (@?= False)
      assertPublicLiveSessionFailure
        SMTLibLive.LengthSMTLibLiveSessionResourceLimitExceeded scoped

assertLiveUsableWorkWorkspaceExpiry :: IO ()
assertLiveUsableWorkWorkspaceExpiry =
  SMTLibLiveSpec.withFakeZ3Mode "healthy" $ \executable _ -> do
    execution <- mkBudgetLiveExecution executable 1000
    budget <- mkLiveUsableWorkBudget 25
    callbackReached <- newIORef False
    scoped <- SMTLibLive.withLengthSMTLibLiveUsableWorkDeadline budget
      $ \deadline -> do
          threadDelay 80000
          SMTLibLive.withLengthSMTLibLiveSessionUnderDeadline
            deadline execution $ \_ -> writeIORef callbackReached True
    readIORef callbackReached >>= (@?= False)
    assertPublicLiveSessionFailure
      SMTLibLive.LengthSMTLibLiveSessionDeadlineExceeded scoped
    spawned <- doesPathExist $ executable ++ ".events"
    assertBool "an already-expired workspace token spawned the fake solver"
      $ not spawned

assertLiveUsableWorkOpenerExpiry :: IO ()
assertLiveUsableWorkOpenerExpiry =
  SMTLibLiveSpec.withFakeZ3Mode "hang" $ \executable _ -> do
    execution <- mkBudgetLiveExecution executable 1000
    budget <- mkLiveUsableWorkBudget 150
    callbackReached <- newIORef False
    scoped <- SMTLibLive.withLengthSMTLibLiveSessionWithUsableWorkBudget
      budget execution $ \_ -> writeIORef callbackReached True
    readIORef callbackReached >>= (@?= False)
    assertPublicLiveSessionFailure
      SMTLibLive.LengthSMTLibLiveSessionDeadlineExceeded scoped
    assertFakeWorkerWorkspaceRemoved "shared opener deadline" executable

assertLiveUsableWorkIdentitySchemas :: IO ()
assertLiveUsableWorkIdentitySchemas = do
  SMTLibSession.lengthSMTLibReadyWorkerSchemaTag @?=
    asciiBytes "djex-length-z3-capability-probed-ready-worker/v4"
  SMTLibSession.lengthSMTLibQueryRunSchemaTag @?= asciiBytes (concat
    [ "djex-length-z3-capability-probed-pre-spawn-pathname-snapshot-"
    , "worker-query-run/v1"
    ])
  SMTLibSession.lengthSMTLibBudgetedQueryRunSchemaTag @?= asciiBytes (concat
    [ "djex-length-z3-capability-probed-pre-spawn-pathname-snapshot-worker-"
    , "query-run/shared-usable-work-deadline/v1"
    ])
  SMTLibSession.lengthSpinePairSMTLibQueryRunSchemaTag @?= asciiBytes (concat
    [ "djex-length-spine-pair-z3-capability-probed-pre-spawn-pathname-"
    , "snapshot-worker-query-run/v1"
    ])
  SMTLibSession.lengthSpinePairSMTLibBudgetedQueryRunSchemaTag @?=
    asciiBytes (concat
      [ "djex-length-spine-pair-z3-capability-probed-pre-spawn-pathname-"
      , "snapshot-worker-query-run/shared-usable-work-deadline/v1"
      ])
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  legacy <- SMTLibLiveSpec.withLiveQueryWorker "healthy"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
    $ \_ worker -> do
        run <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        let identity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint run
        assertBool "legacy run identity lost its exact schema"
          $ SMTLibSession.lengthSMTLibQueryRunSchemaTag `isInfixOf` identity
        assertBool "legacy run identity acquired the budgeted schema"
          $ not
          $ SMTLibSession.lengthSMTLibBudgetedQueryRunSchemaTag
              `isInfixOf` identity
        assertBool "legacy run identity acquired the scoped-v2 schema"
          $ not
          $ SMTLibSession.lengthSMTLibScopedBudgetedQueryRunSchemaTag
              `isInfixOf` identity
  _ <- expectRight legacy

  budgeted <- withInternalBudgetedWorker "healthy" 1000 1000
    $ \_ worker -> do
        run <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        let workerIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSMTLibReadyWorkerIdentityFingerprint worker
            runIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint run
        assertBool "budgeted worker identity omitted its shared deadline schema"
          $ asciiBytes "djex-length-z3-shared-usable-work-deadline/v1"
              `isInfixOf` workerIdentity
        assertBool "v1 worker identity acquired the scoped-v2 schema"
          $ not
          $ asciiBytes
              "djex-length-z3-scoped-shared-usable-work-deadline/v2"
                `isInfixOf` workerIdentity
        assertBool "budgeted run identity omitted its distinct schema"
          $ SMTLibSession.lengthSMTLibBudgetedQueryRunSchemaTag
              `isInfixOf` runIdentity
        assertBool "v1 run identity acquired the scoped-v2 schema"
          $ not
          $ SMTLibSession.lengthSMTLibScopedBudgetedQueryRunSchemaTag
              `isInfixOf` runIdentity
        assertBool "budgeted run identity retained the legacy top-level schema"
          $ not
          $ SMTLibSession.lengthSMTLibQueryRunSchemaTag `isInfixOf` runIdentity
        assertEffectiveDeadlineCause
          "shared-usable-work-deadline" runIdentity
  _ <- expectRight =<< expectRight budgeted
  pure ()

assertLiveUsableWorkMixedDomainDeadline :: IO ()
assertLiveUsableWorkMixedDomainDeadline = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  scoped <- withInternalBudgetedWorker
    "query-hang-after-two-status" 2000 2000
    $ \executable worker -> do
        scalar <- expectRight
          =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker scalarQuery
        pair <- expectRight
          =<< SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker pairQuery
        SMTLibSession.lengthSMTLibQueryRunOrdinal scalar @?= 0
        SMTLibSession.lengthSpinePairSMTLibQueryRunOrdinal pair @?= 1
        assertLiveValueQueryRun scalarQuery [3] scalar
        assertLiveSpinePairValueQueryRun
          pairQuery [3] (Length.LengthSpinePair 3 0) pair
        let scalarIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint scalar
            pairIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSpinePairSMTLibQueryRunIdentityFingerprint
                  pair
        assertBool "budgeted scalar run omitted its nominal schema"
          $ SMTLibSession.lengthSMTLibBudgetedQueryRunSchemaTag
              `isInfixOf` scalarIdentity
        assertBool "budgeted pair run omitted its nominal schema"
          $ SMTLibSession.lengthSpinePairSMTLibBudgetedQueryRunSchemaTag
              `isInfixOf` pairIdentity
        assertBool "v1 scalar run acquired the scoped-v2 schema"
          $ not
          $ SMTLibSession.lengthSMTLibScopedBudgetedQueryRunSchemaTag
              `isInfixOf` scalarIdentity
        assertBool "v1 pair run acquired the scoped-v2 schema"
          $ not
          $ SMTLibSession.lengthSpinePairSMTLibScopedBudgetedQueryRunSchemaTag
              `isInfixOf` pairIdentity
        assertBool "budgeted scalar and pair runs shared one nominal identity"
          $ scalarIdentity /= pairIdentity

        expired <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker scalarQuery
        assertInternalQueryDeadlineFailure True expired
        spent <- SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker pairQuery
        assertInternalPairQueryFailure
          SMTLibSession.LengthSpinePairSMTLibQueryWorkerSpent False spent
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0, 1, 2] events
        assertFakeZ3EventOrdinals "query-hang" [2] events
        case fakeZ3Events "query-hang" events of
          [event] -> SMTLibLiveSpec.fakeZ3FieldValues
              (liveTestBytes "phase") event @?= [liveTestBytes "status"]
          _ -> assertFailure
            "third-query status hang emitted an unexpected event set"
  scope <- expectRight scoped
  assertInternalSessionDeadlineScope scope

assertLiveUsableWorkLocalQueryDeadline :: IO ()
assertLiveUsableWorkLocalQueryDeadline = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  healthy <- withInternalBudgetedWorker "healthy" 2000 200
    $ \_ worker -> do
        scalar <- expectRight
          =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker scalarQuery
        pair <- expectRight
          =<< SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker pairQuery
        let scalarIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint scalar
            pairIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSpinePairSMTLibQueryRunIdentityFingerprint
                  pair
        assertEffectiveDeadlineCause "fresh-per-query-deadline" scalarIdentity
        assertEffectiveDeadlineCause "fresh-per-query-deadline" pairIdentity
  _ <- expectRight =<< expectRight healthy

  -- Keep the worker quiescent after the query-check record. A delayed reply
  -- can wake during deadline cleanup and be killed halfway through writing
  -- its trace; that tests an incidental logging race instead of which
  -- deadline owns the query. The unchanged outer-scope assertions distinguish
  -- this fresh 200 ms deadline from the shared 2000 ms allowance.
  scalarScoped <- withInternalBudgetedWorker
    "query-hang-status" 2000 200
    $ \executable worker -> do
        rejected <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker scalarQuery
        assertInternalQueryDeadlineFailure True rejected
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventOrdinals "query-hang" [0] events
  _ <- expectRight =<< expectRight scalarScoped

  pairScoped <- withInternalBudgetedWorker
    "query-hang-status" 2000 200
    $ \executable worker -> do
        rejected <- SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker pairQuery
        assertInternalPairQueryDeadlineFailure True rejected
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventOrdinals "query-hang" [0] events
  _ <- expectRight =<< expectRight pairScoped
  pure ()

assertLiveUsableWorkPublicQueryExpiry :: IO ()
assertLiveUsableWorkPublicQueryExpiry = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  -- Keep the short-budget safety case even when worker startup consumes its
  -- allowance. A separate case must actually reach the blocked query before
  -- the shared deadline, so startup variance cannot masquerade as query expiry.
  forM_ [(400, 1000, False), (3000, 5000, True)] $
   \(sharedMilliseconds, queryMilliseconds, requireQuery) ->
    SMTLibLiveSpec.withFakeZ3Mode "query-hang-status" $ \executable _ -> do
    execution <- mkBudgetLiveExecution executable queryMilliseconds
    budget <- mkLiveUsableWorkBudget sharedMilliseconds
    scoped <- SMTLibLive.withLengthSMTLibLiveSessionWithUsableWorkBudget
      budget execution $ \session -> do
        rejected <- SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session query
        assertPublicLiveQueryFailure
          SMTLibLive.LengthSMTLibLiveQueryDeadlineExceeded False rejected
        spent <- SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session query
        assertPublicLiveQueryFailure
          SMTLibLive.LengthSMTLibLiveQuerySessionUnavailable False spent
    assertPublicLiveSessionFailure
      SMTLibLive.LengthSMTLibLiveSessionDeadlineExceeded scoped
    events <- SMTLibLiveSpec.readFakeZ3Events executable
    let reachedQuery = not $ null $ fakeZ3Events "query-check" events
    when (requireQuery || reachedQuery) $
      assertFakeZ3EventOrdinals "query-check" [0] events
    when requireQuery $ assertFakeZ3EventOrdinals "query-hang" [0] events
    when (not reachedQuery) $ assertFakeZ3EventCount "query-hang" 0 events
    assertFakeWorkerWorkspaceRemoved "shared query deadline" executable

assertLiveUsableWorkSessionCallbackReturnExpiry :: IO ()
assertLiveUsableWorkSessionCallbackReturnExpiry =
  -- The callback-return contract applies after the callback has started.
  -- Retain the original short-budget case and require entry separately with
  -- startup allowance; either entered callback must finish before cleanup.
  forM_ [(500, 1000, 700000, False), (3000, 5000, 3200000, True)] $
   \(sharedMilliseconds, queryMilliseconds, delayMicroseconds, requireCallback) ->
    SMTLibLiveSpec.withFakeZ3Mode "healthy" $ \executable _ -> do
    execution <- mkBudgetLiveExecution executable queryMilliseconds
    budget <- mkLiveUsableWorkBudget sharedMilliseconds
    callbackEntered <- newIORef False
    callbackReturned <- newIORef False
    scoped <- SMTLibLive.withLengthSMTLibLiveSessionWithUsableWorkBudget
      budget execution $ \_ -> do
        writeIORef callbackEntered True
        threadDelay delayMicroseconds
        writeIORef callbackReturned True
    entered <- readIORef callbackEntered
    when requireCallback $ entered @?= True
    readIORef callbackReturned >>= (@?= entered)
    assertPublicLiveSessionFailure
      SMTLibLive.LengthSMTLibLiveSessionDeadlineExceeded scoped
    assertFakeWorkerWorkspaceRemoved "session callback return" executable

assertLiveUsableWorkConvenienceCleanupExclusion :: IO ()
assertLiveUsableWorkConvenienceCleanupExclusion =
  SMTLibLiveSpec.withFakeZ3Mode "stubborn-eof" $ \executable _ -> do
    let budgetMilliseconds = 1500
        cleanupMarginMilliseconds = 100
    execution <- mkBudgetLiveExecution executable 1000
    budget <- mkLiveUsableWorkBudget budgetMilliseconds
    started <- getMonotonicTimeNSec
    scoped <- SMTLibLive.withLengthSMTLibLiveSessionWithUsableWorkBudget
      budget execution $ \_ -> delayUntilMonotonic
        $ started + fromIntegral
            ((budgetMilliseconds - cleanupMarginMilliseconds) * 1000000)
    _ <- expectRight scoped
    finished <- getMonotonicTimeNSec
    assertBool "fresh cleanup did not cross the shared usable-work deadline"
      $ finished >= started + fromIntegral (budgetMilliseconds * 1000000)
    assertFakeWorkerWorkspaceRemoved "excluded final cleanup" executable

data LiveUsableWorkCallbackException = LiveUsableWorkCallbackException
  deriving (Eq, Show)

instance Exception LiveUsableWorkCallbackException

assertLiveUsableWorkCallbackException :: IO ()
assertLiveUsableWorkCallbackException =
  SMTLibLiveSpec.withFakeZ3Mode "healthy" $ \executable _ -> do
    let budgetMilliseconds = 5000
    execution <- mkBudgetLiveExecution executable 4000
    budget <- mkLiveUsableWorkBudget budgetMilliseconds
    callbackEntered <- newIORef False
    callbackCrossedDeadline <- newIORef False
    attempted <- try
      $ SMTLibLive.withLengthSMTLibLiveSessionWithUsableWorkBudget
          budget execution $ \_ -> do
            writeIORef callbackEntered True
            entered <- getMonotonicTimeNSec
            -- The convenience entrance captures its shared deadline before
            -- opening the worker. Waiting one full budget from callback entry
            -- therefore crosses that same deadline even after slow setup;
            -- the extra millisecond avoids relying on its exact boundary.
            delayUntilMonotonic $ entered
              + fromIntegral ((budgetMilliseconds + 1) * 1000000)
            writeIORef callbackCrossedDeadline True
            throwIO LiveUsableWorkCallbackException
    entered <- readIORef callbackEntered
    assertBool ("worker setup did not enter the exception callback: "
      ++ show attempted) entered
    readIORef callbackCrossedDeadline >>= assertBool
      "the exception callback did not wait past the shared deadline"
    case attempted of
      Left failure -> failure @?= LiveUsableWorkCallbackException
      Right (_ :: Either SMTLibLive.LengthSMTLibLiveSessionError ()) ->
        assertFailure "expired callback exception was replaced by a deadline"
    assertFakeWorkerWorkspaceRemoved "budgeted callback exception" executable

assertLiveScopedUsableWorkEscapedClosure :: IO ()
assertLiveScopedUsableWorkEscapedClosure =
  SMTLibLiveSpec.withFakeZ3Mode "healthy" $ \executable _ -> do
    execution <- mkBudgetLiveExecution executable 1000
    budget <- mkLiveUsableWorkBudget 100
    callbackReached <- newIORef False
    escapedResult <-
      SMTLibLive.withLengthSMTLibLiveScopedUsableWorkDeadline budget
        $ \deadline -> pure
        $ SMTLibLive.withLengthSMTLibLiveSessionUnderScopedDeadline
            deadline execution $ \_ -> writeIORef callbackReached True
    escaped <- expectRight escapedResult
    threadDelay 250000
    rejected <- escaped
    assertPublicLiveSessionFailure
      SMTLibLive.LengthSMTLibLiveSessionUsableWorkScopeUnavailable rejected
    readIORef callbackReached >>= (@?= False)
    spawned <- doesPathExist $ executable ++ ".events"
    assertBool
      "a closed and expired scoped authority acquired a workspace or solver"
      $ not spawned

assertLiveScopedUsableWorkWrongThread :: IO ()
assertLiveScopedUsableWorkWrongThread =
  SMTLibLiveSpec.withFakeZ3Mode "healthy" $ \executable _ -> do
    execution <- mkBudgetLiveExecution executable 1000
    budget <- mkLiveUsableWorkBudget 4000
    scoped <- SMTLibLive.withLengthSMTLibLiveScopedUsableWorkDeadline budget
      $ \deadline -> do
          forkedResult <- newEmptyMVar
          _ <- forkIO $ do
            rejected <-
              SMTLibLive.withLengthSMTLibLiveSessionUnderScopedDeadline
                deadline execution $ \_ -> pure ()
            putMVar forkedResult rejected
          received <- timeout 2000000 $ takeMVar forkedResult
          rejected <- case received of
            Nothing -> assertFailure
              "forked scoped-deadline admission did not terminate"
            Just result -> pure result
          assertPublicLiveSessionFailure
            SMTLibLive.LengthSMTLibLiveSessionUsableWorkScopeUnavailable
            rejected
          spawned <- doesPathExist $ executable ++ ".events"
          assertBool "wrong-thread admission reached the fake solver" $ not spawned
          ownerSession <-
            SMTLibLive.withLengthSMTLibLiveSessionUnderScopedDeadline
              deadline execution $ \_ -> pure ()
          _ <- expectRight ownerSession
          _ <- expectRight
            =<< SMTLibLive.checkLengthSMTLibLiveScopedUsableWorkDeadline
                  deadline
          pure ()
    _ <- expectRight scoped
    assertFakeWorkerWorkspaceRemoved "owner reuse after fork rejection" executable

data LiveScopedUsableWorkSynchronousException =
  LiveScopedUsableWorkSynchronousException
  deriving (Eq, Show)

instance Exception LiveScopedUsableWorkSynchronousException

assertLiveScopedUsableWorkSynchronousException :: IO ()
assertLiveScopedUsableWorkSynchronousException = do
  budget <- mkLiveUsableWorkBudget 1000
  escapedRef <- newIORef Nothing
  attempted <- try
    (SMTLibLive.withLengthSMTLibLiveScopedUsableWorkDeadline budget
      (\deadline -> do
        writeIORef escapedRef $ Just
          $ SMTLibLive.checkLengthSMTLibLiveScopedUsableWorkDeadline deadline
        throwIO LiveScopedUsableWorkSynchronousException)
      :: IO (Either SMTLibLive.LengthSMTLibLiveSessionError ()))
  case attempted of
    Left failure -> failure @?= LiveScopedUsableWorkSynchronousException
    Right _ -> assertFailure
      "scoped deadline owner swallowed a synchronous exception"
  escaped <- readIORef escapedRef >>= maybe
    (assertFailure "synchronous exception callback did not publish its closure")
    pure
  rejected <- escaped
  assertPublicLiveSessionFailure
    SMTLibLive.LengthSMTLibLiveSessionUsableWorkScopeUnavailable rejected

data LiveScopedUsableWorkAsynchronousException =
  LiveScopedUsableWorkAsynchronousException
  deriving (Eq, Show)

instance Exception LiveScopedUsableWorkAsynchronousException

assertLiveScopedUsableWorkAsynchronousException :: IO ()
assertLiveScopedUsableWorkAsynchronousException = do
  budget <- mkLiveUsableWorkBudget 2000
  target <- myThreadId
  throwerFinished <- newEmptyMVar
  callbackBlock <- newEmptyMVar
  escapedRef <- newIORef Nothing
  attempted <- try
    (SMTLibLive.withLengthSMTLibLiveScopedUsableWorkDeadline budget
      (\deadline -> do
        writeIORef escapedRef $ Just
          $ SMTLibLive.checkLengthSMTLibLiveScopedUsableWorkDeadline deadline
        _ <- forkIO $ throwTo target
          LiveScopedUsableWorkAsynchronousException
            `finally` putMVar throwerFinished ()
        takeMVar callbackBlock)
      :: IO (Either SMTLibLive.LengthSMTLibLiveSessionError ()))
  case attempted of
    Left failure -> failure @?= LiveScopedUsableWorkAsynchronousException
    Right _ -> assertFailure "scoped deadline owner swallowed a throwTo exception"
  finished <- timeout 1000000 $ takeMVar throwerFinished
  case finished of
    Nothing -> assertFailure "scoped deadline throwTo helper did not terminate"
    Just () -> pure ()
  escaped <- readIORef escapedRef >>= maybe
    (assertFailure "throwTo callback did not publish its closure") pure
  rejected <- escaped
  assertPublicLiveSessionFailure
    SMTLibLive.LengthSMTLibLiveSessionUsableWorkScopeUnavailable rejected

assertLiveScopedUsableWorkCheckpointExpiry :: IO ()
assertLiveScopedUsableWorkCheckpointExpiry = do
  let budgetMilliseconds = 500
      millisecondNanoseconds :: Int -> Word64
      millisecondNanoseconds milliseconds =
        fromIntegral milliseconds * 1000000
  budget <- mkLiveUsableWorkBudget budgetMilliseconds
  finalObservation <- newIORef Nothing
  scoped <- SMTLibLive.withLengthSMTLibLiveScopedUsableWorkDeadline budget
    $ \deadline -> do
        started <- getMonotonicTimeNSec
        mapM_ (\milliseconds -> do
          delayUntilMonotonic
            $ started + millisecondNanoseconds milliseconds
          _ <- expectRight
            =<< SMTLibLive.checkLengthSMTLibLiveScopedUsableWorkDeadline
                  deadline
          pure ()) [100, 200, 300]
        delayUntilMonotonic $ started + millisecondNanoseconds 650
        observed <-
          SMTLibLive.checkLengthSMTLibLiveScopedUsableWorkDeadline deadline
        writeIORef finalObservation $ Just observed
  assertPublicLiveSessionFailure
    SMTLibLive.LengthSMTLibLiveSessionDeadlineExceeded scoped
  observed <- readIORef finalObservation >>= maybe
    (assertFailure "final scoped checkpoint was not observed") pure
  assertPublicLiveSessionFailure
    SMTLibLive.LengthSMTLibLiveSessionDeadlineExceeded observed

assertLiveScopedUsableWorkIdentitySchemas :: IO ()
assertLiveScopedUsableWorkIdentitySchemas = do
  SMTLibSession.lengthSMTLibScopedBudgetedQueryRunSchemaTag @?=
    asciiBytes (concat
      [ "djex-length-z3-capability-probed-pre-spawn-pathname-snapshot-worker-"
      , "query-run/scoped-shared-usable-work-deadline/v2"
      ])
  SMTLibSession.lengthSpinePairSMTLibScopedBudgetedQueryRunSchemaTag @?=
    asciiBytes (concat
      [ "djex-length-spine-pair-z3-capability-probed-pre-spawn-pathname-"
      , "snapshot-worker-query-run/scoped-shared-usable-work-deadline/v2"
      ])
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  scoped <- withInternalScopedBudgetedWorker "healthy" 2000 3000
    $ \_ worker -> do
        scalar <- expectRight
          =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker scalarQuery
        pair <- expectRight
          =<< SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker pairQuery
        let readyIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSMTLibReadyWorkerIdentityFingerprint worker
            scalarIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint scalar
            pairIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSpinePairSMTLibQueryRunIdentityFingerprint
                  pair
            v1Ready = asciiBytes
              "djex-length-z3-shared-usable-work-deadline/v1"
            v2Ready = asciiBytes
              "djex-length-z3-scoped-shared-usable-work-deadline/v2"
        assertBool "v2 ready identity omitted its scoped schema"
          $ v2Ready `isInfixOf` readyIdentity
        assertBool "v2 ready identity reused its v1 budget schema"
          $ not $ v1Ready `isInfixOf` readyIdentity
        assertBool "v2 scalar identity omitted its nominal run schema"
          $ SMTLibSession.lengthSMTLibScopedBudgetedQueryRunSchemaTag
              `isInfixOf` scalarIdentity
        assertBool "v2 scalar identity reused its v1 run schema"
          $ not
          $ SMTLibSession.lengthSMTLibBudgetedQueryRunSchemaTag
              `isInfixOf` scalarIdentity
        assertBool "v2 pair identity omitted its nominal run schema"
          $ SMTLibSession.lengthSpinePairSMTLibScopedBudgetedQueryRunSchemaTag
              `isInfixOf` pairIdentity
        assertBool "v2 pair identity reused its v1 run schema"
          $ not
          $ SMTLibSession.lengthSpinePairSMTLibBudgetedQueryRunSchemaTag
              `isInfixOf` pairIdentity
        assertBool "v2 scalar and pair runs shared one nominal identity"
          $ scalarIdentity /= pairIdentity
        assertBool "v2 ready and scalar identities shared one byte envelope"
          $ readyIdentity /= scalarIdentity
        assertBool "v2 ready and pair identities shared one byte envelope"
          $ readyIdentity /= pairIdentity
        assertBool "v2 scalar identity admitted the product run schema"
          $ not
          $ SMTLibSession.lengthSpinePairSMTLibScopedBudgetedQueryRunSchemaTag
              `isInfixOf` scalarIdentity
        assertBool "v2 pair identity admitted the scalar run schema"
          $ not
          $ SMTLibSession.lengthSMTLibScopedBudgetedQueryRunSchemaTag
              `isInfixOf` pairIdentity
        assertEffectiveDeadlineCause
          "scoped-shared-usable-work-deadline" scalarIdentity
        assertEffectiveDeadlineCause
          "scoped-shared-usable-work-deadline" pairIdentity
  _ <- expectRight =<< expectRight scoped
  pure ()

assertDescriptorBoundScopedIdentitySchemas :: IO ()
assertDescriptorBoundScopedIdentitySchemas = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  scoped <- withInternalDescriptorBoundScopedBudgetedWorker
    "healthy" 2000 3000 $ \_ worker -> do
      scalar <- expectRight
        =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
              Evaluate.defaultLengthEvaluationLimits worker scalarQuery
      pair <- expectRight
        =<< SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
              Evaluate.defaultLengthEvaluationLimits worker pairQuery
      let readyIdentity = BS.pack $ InternalFingerprint.fingerprintCanonicalBytes
            $ SMTLibSession.lengthSMTLibReadyWorkerIdentityFingerprint worker
          scalarIdentity = BS.pack
            $ InternalFingerprint.fingerprintCanonicalBytes
            $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint scalar
          pairIdentity = BS.pack
            $ InternalFingerprint.fingerprintCanonicalBytes
            $ SMTLibSession.lengthSpinePairSMTLibQueryRunIdentityFingerprint pair
          descriptorReady = BSC.pack
            "djex-length-z3-capability-probed-sealed-main-image-ready-worker/v1"
          descriptorScalar = BSC.pack $ concat
            [ "djex-length-z3-capability-probed-sealed-main-image-worker-"
            , "query-run/scoped-shared-usable-work-deadline/v1"
            ]
          descriptorPair = BSC.pack $ concat
            [ "djex-length-spine-pair-z3-capability-probed-sealed-main-image-"
            , "worker-query-run/scoped-shared-usable-work-deadline/v1"
            ]
          legacyScalar = BS.pack
            SMTLibSession.lengthSMTLibScopedBudgetedQueryRunSchemaTag
          legacyPair = BS.pack
            SMTLibSession.lengthSpinePairSMTLibScopedBudgetedQueryRunSchemaTag
          strength =
            SMTLibProcess.lengthSMTLibDescriptorBoundExecutableLaunchStrengthTag
      assertBool "scoped descriptor ready identity omitted its launch schema"
        $ descriptorReady `BS.isInfixOf` readyIdentity
      assertBool "scoped descriptor scalar identity omitted its run schema"
        $ descriptorScalar `BS.isInfixOf` scalarIdentity
      assertBool "scoped descriptor pair identity omitted its run schema"
        $ descriptorPair `BS.isInfixOf` pairIdentity
      assertBool "scoped descriptor scalar identity reused the legacy schema"
        $ not $ legacyScalar `BS.isInfixOf` scalarIdentity
      assertBool "scoped descriptor pair identity reused the legacy schema"
        $ not $ legacyPair `BS.isInfixOf` pairIdentity
      assertBool "scoped descriptor scalar and pair identities were equal"
        $ scalarIdentity /= pairIdentity
      mapM_ (\identity -> assertBool
          "scoped descriptor identity omitted its exact launch strength"
          $ strength `BS.isInfixOf` identity)
        [readyIdentity, scalarIdentity, pairIdentity]
      assertEffectiveDeadlineCause
        "scoped-shared-usable-work-deadline" $ BS.unpack scalarIdentity
      assertEffectiveDeadlineCause
        "scoped-shared-usable-work-deadline" $ BS.unpack pairIdentity
  assertDescriptorScopedOutcome
    SMTLibProcess.lengthSMTLibDescriptorBoundExecutableLaunchSupported
    SMTLibProcess.LengthSMTLibProcessSpawnPhase
    SMTLibProcess.LengthSMTLibProcessDescriptorBoundLaunchUnavailable scoped

assertEffectiveIDDescriptorBoundScopedIdentitySchemas :: IO ()
assertEffectiveIDDescriptorBoundScopedIdentitySchemas = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  scoped <- withInternalEffectiveIDDescriptorBoundScopedBudgetedWorker
    "healthy" 2000 3000 $ \_ worker -> do
      scalar <- expectRight
        =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
              Evaluate.defaultLengthEvaluationLimits worker scalarQuery
      pair <- expectRight
        =<< SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
              Evaluate.defaultLengthEvaluationLimits worker pairQuery
      let readyIdentity = BS.pack $ InternalFingerprint.fingerprintCanonicalBytes
            $ SMTLibSession.lengthSMTLibReadyWorkerIdentityFingerprint worker
          scalarIdentity = BS.pack
            $ InternalFingerprint.fingerprintCanonicalBytes
            $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint scalar
          pairIdentity = BS.pack
            $ InternalFingerprint.fingerprintCanonicalBytes
            $ SMTLibSession.lengthSpinePairSMTLibQueryRunIdentityFingerprint pair
          effectiveReady = BSC.pack $ concat
            [ "djex-length-z3-capability-probed-effective-id-executable-"
            , "access-sealed-main-image-ready-worker/v1"
            ]
          effectiveScalar = BSC.pack $ concat
            [ "djex-length-z3-capability-probed-effective-id-executable-"
            , "access-sealed-main-image-worker-query-run/"
            , "scoped-shared-usable-work-deadline/v1"
            ]
          effectivePair = BSC.pack $ concat
            [ "djex-length-spine-pair-z3-capability-probed-effective-id-"
            , "executable-access-sealed-main-image-worker-query-run/"
            , "scoped-shared-usable-work-deadline/v1"
            ]
          oldDescriptorReady = BSC.pack
            "djex-length-z3-capability-probed-sealed-main-image-ready-worker/v1"
          oldDescriptorScalar = BSC.pack $ concat
            [ "djex-length-z3-capability-probed-sealed-main-image-worker-"
            , "query-run/scoped-shared-usable-work-deadline/v1"
            ]
          oldDescriptorPair = BSC.pack $ concat
            [ "djex-length-spine-pair-z3-capability-probed-sealed-main-image-"
            , "worker-query-run/scoped-shared-usable-work-deadline/v1"
            ]
          strength =
            SMTLibProcess.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchStrengthTag
      assertBool "scoped effective-ID ready identity omitted its launch schema"
        $ effectiveReady `BS.isInfixOf` readyIdentity
      assertBool "scoped effective-ID scalar identity omitted its run schema"
        $ effectiveScalar `BS.isInfixOf` scalarIdentity
      assertBool "scoped effective-ID pair identity omitted its run schema"
        $ effectivePair `BS.isInfixOf` pairIdentity
      assertBool "scoped effective-ID ready identity reused old descriptor schema"
        $ not $ oldDescriptorReady `BS.isInfixOf` readyIdentity
      assertBool "scoped effective-ID scalar identity reused old descriptor schema"
        $ not $ oldDescriptorScalar `BS.isInfixOf` scalarIdentity
      assertBool "scoped effective-ID pair identity reused old descriptor schema"
        $ not $ oldDescriptorPair `BS.isInfixOf` pairIdentity
      assertBool "scoped effective-ID scalar and pair identities were equal"
        $ scalarIdentity /= pairIdentity
      mapM_ (\identity -> assertBool
          "scoped effective-ID identity omitted its exact launch strength"
          $ strength `BS.isInfixOf` identity)
        [readyIdentity, scalarIdentity, pairIdentity]
      assertEffectiveDeadlineCause
        "scoped-shared-usable-work-deadline" $ BS.unpack scalarIdentity
      assertEffectiveDeadlineCause
        "scoped-shared-usable-work-deadline" $ BS.unpack pairIdentity
  assertDescriptorScopedOutcome
    SMTLibProcess.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchSupported
    SMTLibProcess.LengthSMTLibProcessSnapshotPhase
    SMTLibProcess.LengthSMTLibProcessEffectiveIDExecutableAccessCheckUnavailable scoped

-- Unsupported launch policies must retain their exact refusal instead of
-- silently falling back to pathname execution. Supported builds must still
-- execute every identity assertion in the callback above.
assertDescriptorScopedOutcome
  :: Show failure
  => Bool
  -> SMTLibProcess.LengthSMTLibProcessPhase
  -> SMTLibProcess.LengthSMTLibProcessFailureClass
  -> Either failure (Either SMTLibSession.LengthSMTLibSessionScopeError ())
  -> IO ()
assertDescriptorScopedOutcome supported phase failureClass outcome = case outcome of
  Left failure -> assertFailure $ "unexpected descriptor Session failure: " ++ show failure
  Right (Left scope) -> do
    assertBool "supported descriptor launch failed" $ not supported
    assertDescriptorLaunchUnavailableScope phase failureClass scope
  Right (Right ()) ->
    assertBool "unsupported descriptor launch executed its callback" supported

assertExecveCheckDescriptorBoundBudgetIdentitySchemas :: IO ()
assertExecveCheckDescriptorBoundBudgetIdentitySchemas = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  shared <- withInternalExecveCheckDescriptorBoundBudgetedWorker
    "healthy" 2000 3000 $ \_ worker ->
      assertWorker "shared-usable-work-deadline" scalarQuery pairQuery worker
  assertOutcome shared
  scoped <- withInternalExecveCheckDescriptorBoundScopedBudgetedWorker
    "healthy" 2000 3000 $ \_ worker ->
      assertWorker
        "scoped-shared-usable-work-deadline" scalarQuery pairQuery worker
  assertOutcome scoped
 where
  assertOutcome result = case result of
    Left failure -> assertFailure $ "unexpected exec-check Session failure: " ++
      show failure
    Right (Left scope) -> assertExecveCheckUnavailableScope scope
    Right (Right ()) -> pure ()

  assertWorker deadlineTag scalarQuery pairQuery worker = do
    scalar <- expectRight
      =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
            Evaluate.defaultLengthEvaluationLimits worker scalarQuery
    pair <- expectRight
      =<< SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
            Evaluate.defaultLengthEvaluationLimits worker pairQuery
    let readyIdentity = BS.pack $ InternalFingerprint.fingerprintCanonicalBytes
          $ SMTLibSession.lengthSMTLibReadyWorkerIdentityFingerprint worker
        scalarIdentity = BS.pack
          $ InternalFingerprint.fingerprintCanonicalBytes
          $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint scalar
        pairIdentity = BS.pack
          $ InternalFingerprint.fingerprintCanonicalBytes
          $ SMTLibSession.lengthSpinePairSMTLibQueryRunIdentityFingerprint pair
        readySchema = BSC.pack $ concat
          [ "djex-length-z3-capability-probed-execve-check-executable-"
          , "access-sealed-main-image-ready-worker/v1"
          ]
        scalarSchema = BSC.pack $ concat
          [ "djex-length-z3-capability-probed-execve-check-executable-"
          , "access-sealed-main-image-worker-query-run/"
          , deadlineTag, "/v1"
          ]
        pairSchema = BSC.pack $ concat
          [ "djex-length-spine-pair-z3-capability-probed-execve-check-"
          , "executable-access-sealed-main-image-worker-query-run/"
          , deadlineTag, "/v1"
          ]
        strength =
          SMTLibProcess.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunchStrengthTag
        authority = BSC.pack execveCheckQueryAuthorityTag
        wrapper = BSC.pack
          "descriptor-bound-execve-check-executable-access-ready-worker-identity"
    assertBool "exec-check budget ready identity omitted nominal schema"
      $ readySchema `BS.isInfixOf` readyIdentity
    assertBool "exec-check budget scalar identity omitted nominal schema"
      $ scalarSchema `BS.isInfixOf` scalarIdentity
    assertBool "exec-check budget pair identity omitted nominal schema"
      $ pairSchema `BS.isInfixOf` pairIdentity
    assertBool "exec-check budget scalar and pair identities were equal"
      $ scalarIdentity /= pairIdentity
    mapM_ (\identity -> assertBool
        "exec-check budget identity omitted launch strength"
        $ strength `BS.isInfixOf` identity)
      [readyIdentity, scalarIdentity, pairIdentity]
    mapM_ (\identity -> assertBool
        "exec-check budget query identity omitted exact authority"
        $ authority `BS.isInfixOf` identity)
      [scalarIdentity, pairIdentity]
    countByteStringOccurrences wrapper readyIdentity @?= 1
    assertEffectiveDeadlineCause deadlineTag $ BS.unpack scalarIdentity
    assertEffectiveDeadlineCause deadlineTag $ BS.unpack pairIdentity

assertLiveScopedUsableWorkConvenienceCleanupExclusion :: IO ()
assertLiveScopedUsableWorkConvenienceCleanupExclusion =
  SMTLibLiveSpec.withFakeZ3Mode "stubborn-eof" $ \executable _ -> do
    let budgetMilliseconds = 1500
        cleanupMarginMilliseconds = 100
    execution <- mkBudgetLiveExecution executable 1000
    budget <- mkLiveUsableWorkBudget budgetMilliseconds
    started <- getMonotonicTimeNSec
    scoped <-
      SMTLibLive.withLengthSMTLibLiveSessionWithScopedUsableWorkBudget
        budget execution $ \_ -> delayUntilMonotonic
          $ started + fromIntegral
              ((budgetMilliseconds - cleanupMarginMilliseconds) * 1000000)
    _ <- expectRight scoped
    finished <- getMonotonicTimeNSec
    assertBool "fresh scoped cleanup did not cross the usable-work deadline"
      $ finished >= started + fromIntegral (budgetMilliseconds * 1000000)
    assertFakeWorkerWorkspaceRemoved "excluded scoped final cleanup" executable

mkLiveUsableWorkBudget
  :: Int
  -> IO SMTLibLive.LengthSMTLibLiveUsableWorkBudget
mkLiveUsableWorkBudget milliseconds = expectRight
  $ SMTLibLive.mkLengthSMTLibLiveUsableWorkBudget
  $ SMTLibLive.LengthSMTLibLiveUsableWorkBudgetSource milliseconds

mkBudgetLiveExecution
  :: FilePath
  -> Int
  -> IO SMTLibExecution.LengthSMTLibExecutionConfig
mkBudgetLiveExecution executable hostDeadline = expectRight
  $ SMTLibExecution.mkLengthSMTLibExecutionConfig
      SMTLibExecution.defaultLengthSMTLibExecutionLimits
  $ (SMTLibExecution.defaultLengthSMTLibExecutionConfigSource
      executable Nothing)
    { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
        100
    , SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
        4242
    , SMTLibExecution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
        SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    , SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
        hostDeadline
    }

-- | Shared plain-deadline core of the internal budgeted-worker fixtures:
-- the launch flavor contributes only its session-config maker.
withInternalBudgetedWorkerVia
  :: (FilePath -> Int -> IO SMTLibSession.LengthSMTLibSessionConfig)
  -> String
  -> Int
  -> Int
  -> (forall epoch.
      FilePath
      -> SMTLibSession.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO
      (Either
        SMTLibSession.LengthSMTLibSessionError
        (Either SMTLibSession.LengthSMTLibSessionScopeError result))
withInternalBudgetedWorkerVia mkConfig mode budgetMilliseconds hostDeadline
    use =
  SMTLibLiveSpec.withFakeZ3Mode mode $ \executable _ -> do
    config <- mkConfig executable hostDeadline
    SMTLibSession.withLengthSMTLibSessionUsableWorkDeadlineForBudgetedSession
      budgetMilliseconds $ \deadline ->
        SMTLibSession.withLengthSMTLibReadyWorkerUnderDeadline deadline config
          $ use executable

-- | Scoped-deadline sibling of 'withInternalBudgetedWorkerVia'.
withInternalScopedBudgetedWorkerVia
  :: (FilePath -> Int -> IO SMTLibSession.LengthSMTLibSessionConfig)
  -> String
  -> Int
  -> Int
  -> (forall epoch.
      FilePath
      -> SMTLibSession.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO
      (Either
        SMTLibSession.LengthSMTLibSessionError
        (Either SMTLibSession.LengthSMTLibSessionScopeError result))
withInternalScopedBudgetedWorkerVia mkConfig mode budgetMilliseconds
    hostDeadline use =
  SMTLibLiveSpec.withFakeZ3Mode mode $ \executable _ -> do
    config <- mkConfig executable hostDeadline
    SMTLibSession.withLengthSMTLibSessionScopedUsableWorkDeadlineForBudgetedSession
      budgetMilliseconds $ \deadline ->
        SMTLibSession.withLengthSMTLibReadyWorkerUnderScopedDeadline
          deadline config $ use executable

withInternalBudgetedWorker
  :: String
  -> Int
  -> Int
  -> (forall epoch.
      FilePath
      -> SMTLibSession.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO
      (Either
        SMTLibSession.LengthSMTLibSessionError
        (Either SMTLibSession.LengthSMTLibSessionScopeError result))
withInternalBudgetedWorker =
  withInternalBudgetedWorkerVia mkInternalBudgetSessionConfig

withInternalScopedBudgetedWorker
  :: String
  -> Int
  -> Int
  -> (forall epoch.
      FilePath
      -> SMTLibSession.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO
      (Either
        SMTLibSession.LengthSMTLibSessionError
        (Either SMTLibSession.LengthSMTLibSessionScopeError result))
withInternalScopedBudgetedWorker =
  withInternalScopedBudgetedWorkerVia mkInternalBudgetSessionConfig

withInternalDescriptorBoundScopedBudgetedWorker
  :: String
  -> Int
  -> Int
  -> (forall epoch.
      FilePath
      -> SMTLibSession.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO
      (Either
        SMTLibSession.LengthSMTLibSessionError
        (Either SMTLibSession.LengthSMTLibSessionScopeError result))
withInternalDescriptorBoundScopedBudgetedWorker =
  withInternalScopedBudgetedWorkerVia
    mkInternalDescriptorBoundBudgetSessionConfig

withInternalEffectiveIDDescriptorBoundScopedBudgetedWorker
  :: String
  -> Int
  -> Int
  -> (forall epoch.
      FilePath
      -> SMTLibSession.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO
      (Either
        SMTLibSession.LengthSMTLibSessionError
        (Either SMTLibSession.LengthSMTLibSessionScopeError result))
withInternalEffectiveIDDescriptorBoundScopedBudgetedWorker =
  withInternalScopedBudgetedWorkerVia
    mkInternalEffectiveIDDescriptorBoundBudgetSessionConfig

withInternalExecveCheckDescriptorBoundBudgetedWorker
  :: String
  -> Int
  -> Int
  -> (forall epoch.
      FilePath
      -> SMTLibSession.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO
      (Either
        SMTLibSession.LengthSMTLibSessionError
        (Either SMTLibSession.LengthSMTLibSessionScopeError result))
withInternalExecveCheckDescriptorBoundBudgetedWorker =
  withInternalBudgetedWorkerVia
    mkInternalExecveCheckDescriptorBoundBudgetSessionConfig

withInternalExecveCheckDescriptorBoundScopedBudgetedWorker
  :: String
  -> Int
  -> Int
  -> (forall epoch.
      FilePath
      -> SMTLibSession.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO
      (Either
        SMTLibSession.LengthSMTLibSessionError
        (Either SMTLibSession.LengthSMTLibSessionScopeError result))
withInternalExecveCheckDescriptorBoundScopedBudgetedWorker =
  withInternalScopedBudgetedWorkerVia
    mkInternalExecveCheckDescriptorBoundBudgetSessionConfig

mkInternalBudgetSessionConfig
  :: FilePath
  -> Int
  -> IO SMTLibSession.LengthSMTLibSessionConfig
mkInternalBudgetSessionConfig executable hostDeadline = do
  mkInternalBudgetSessionConfigWith
    InternalSMTLibExecution.mkLengthSMTLibExecutionConfig
    executable hostDeadline

mkInternalDescriptorBoundBudgetSessionConfig
  :: FilePath
  -> Int
  -> IO SMTLibSession.LengthSMTLibSessionConfig
mkInternalDescriptorBoundBudgetSessionConfig executable hostDeadline =
  mkInternalBudgetSessionConfigWith
    InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundExecutionConfig
    executable hostDeadline

mkInternalEffectiveIDDescriptorBoundBudgetSessionConfig
  :: FilePath
  -> Int
  -> IO SMTLibSession.LengthSMTLibSessionConfig
mkInternalEffectiveIDDescriptorBoundBudgetSessionConfig executable hostDeadline =
  mkInternalBudgetSessionConfigWith
    InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessExecutionConfig
    executable hostDeadline

mkInternalExecveCheckDescriptorBoundBudgetSessionConfig
  :: FilePath
  -> Int
  -> IO SMTLibSession.LengthSMTLibSessionConfig
mkInternalExecveCheckDescriptorBoundBudgetSessionConfig executable hostDeadline =
  mkInternalBudgetSessionConfigWith
    InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundExecveCheckExecutableAccessExecutionConfig
    executable hostDeadline

mkInternalBudgetSessionConfigWith
  :: (InternalSMTLibExecution.LengthSMTLibExecutionLimits
      -> InternalSMTLibExecution.LengthSMTLibExecutionConfigSource
      -> Either
          InternalSMTLibExecution.LengthSMTLibExecutionConfigError
          InternalSMTLibExecution.LengthSMTLibExecutionConfig)
  -> FilePath
  -> Int
  -> IO SMTLibSession.LengthSMTLibSessionConfig
mkInternalBudgetSessionConfigWith seal executable hostDeadline = do
  execution <- expectRight
    $ seal
        InternalSMTLibExecution.defaultLengthSMTLibExecutionLimits
    $ (InternalSMTLibExecution.defaultLengthSMTLibExecutionConfigSource
        executable Nothing)
      { InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
          100
      , InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
          4242
      , InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
          InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      , InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
          hostDeadline
      }
  process <- expectRight $ SMTLibProcess.mkLengthSMTLibProcessLimits
    SMTLibProcess.defaultLengthSMTLibProcessLimitSource
  session <- expectRight $ SMTLibSession.mkLengthSMTLibSessionLimits
    SMTLibSession.defaultLengthSMTLibSessionLimitSource
      { SMTLibSession.lengthSMTLibSessionLimitSourceOpenerDeadlineMilliseconds =
          3000 }
  expectRight $ SMTLibSession.sealLengthSMTLibSessionConfig
    session process SMTLibCapability.defaultLengthSMTLibCapabilityLimits
    SMTLibProtocol.defaultLengthSMTLibProtocolLimits execution

assertPublicLiveSessionFailure
  :: SMTLibLive.LengthSMTLibLiveSessionFailure
  -> Either SMTLibLive.LengthSMTLibLiveSessionError value
  -> IO ()
assertPublicLiveSessionFailure expected result = case result of
  Left failure -> do
    SMTLibLive.lengthSMTLibLiveSessionPrimaryFailure failure @?= expected
    SMTLibLive.lengthSMTLibLiveSessionCleanupIncomplete failure @?= False
  Right _ -> assertFailure $ "expected public live session failure: " ++
    show expected

assertPublicLiveQueryFailure
  :: SMTLibLive.LengthSMTLibLiveQueryFailure
  -> Bool
  -> Either SMTLibLive.LengthSMTLibLiveQueryError value
  -> IO ()
assertPublicLiveQueryFailure expected cleanupIncomplete result = case result of
  Left failure -> do
    SMTLibLive.lengthSMTLibLiveQueryPrimaryFailure failure @?= expected
    SMTLibLive.lengthSMTLibLiveQueryCleanupIncomplete failure @?=
      cleanupIncomplete
    let rendered = show failure
    assertBool "public query failure exposed raw deadline or child material"
      $ not ("ProcessDeadline" `isInfixOf` rendered) &&
          not ("nanosecond" `isInfixOf` rendered)
  Right _ -> assertFailure $ "expected public live query failure: " ++
    show expected

assertInternalQueryDeadlineFailure
  :: Bool
  -> Either SMTLibSession.LengthSMTLibQueryRunError value
  -> IO ()
assertInternalQueryDeadlineFailure expectedCleanup result = case result of
  Left failure -> do
    case SMTLibSession.lengthSMTLibQueryRunPrimaryFailure failure of
      SMTLibSession.LengthSMTLibQueryDeadlineFailure process ->
        SMTLibProcess.lengthSMTLibProcessErrorClass process @?=
          SMTLibProcess.LengthSMTLibProcessDeadlineExceeded
      unexpected -> assertFailure $ "wrong internal query failure: " ++
        show unexpected
    case ( expectedCleanup
         , SMTLibSession.lengthSMTLibQueryRunProcessCleanupStatus failure) of
      (True, Just cleanup) -> do
        SMTLibProcess.lengthSMTLibProcessCleanupReadersStopped cleanup @?= True
        assertBool "deadline cleanup remained incomplete"
          $ SMTLibProcess.lengthSMTLibProcessCleanupEscalation cleanup /=
              SMTLibProcess.LengthSMTLibProcessCleanupIncomplete
      (False, Nothing) -> pure ()
      _ -> assertFailure "internal deadline carried the wrong cleanup owner"
  Right _ -> assertFailure "expected internal query deadline failure"

assertInternalPairQueryFailure
  :: SMTLibSession.LengthSpinePairSMTLibQueryRunFailure
  -> Bool
  -> Either SMTLibSession.LengthSpinePairSMTLibQueryRunError value
  -> IO ()
assertInternalPairQueryFailure expected expectedCleanup result = case result of
  Left failure -> do
    SMTLibSession.lengthSpinePairSMTLibQueryRunPrimaryFailure failure @?=
      expected
    case ( expectedCleanup
         , SMTLibSession.lengthSpinePairSMTLibQueryRunProcessCleanupStatus
             failure) of
      (True, Just _) -> pure ()
      (False, Nothing) -> pure ()
      _ -> assertFailure "pair query failure carried the wrong cleanup owner"
  Right _ -> assertFailure $ "expected internal pair query failure: " ++
    show expected

assertInternalPairQueryDeadlineFailure
  :: Bool
  -> Either SMTLibSession.LengthSpinePairSMTLibQueryRunError value
  -> IO ()
assertInternalPairQueryDeadlineFailure expectedCleanup result = case result of
  Left failure -> do
    case SMTLibSession.lengthSpinePairSMTLibQueryRunPrimaryFailure failure of
      SMTLibSession.LengthSpinePairSMTLibQueryDeadlineFailure process ->
        SMTLibProcess.lengthSMTLibProcessErrorClass process @?=
          SMTLibProcess.LengthSMTLibProcessDeadlineExceeded
      unexpected -> assertFailure $ "wrong internal pair query failure: " ++
        show unexpected
    case ( expectedCleanup
         , SMTLibSession.lengthSpinePairSMTLibQueryRunProcessCleanupStatus
             failure) of
      (True, Just cleanup) -> do
        SMTLibProcess.lengthSMTLibProcessCleanupReadersStopped cleanup @?= True
        assertBool "pair deadline cleanup remained incomplete"
          $ SMTLibProcess.lengthSMTLibProcessCleanupEscalation cleanup /=
              SMTLibProcess.LengthSMTLibProcessCleanupIncomplete
      (False, Nothing) -> pure ()
      _ -> assertFailure "pair deadline carried the wrong cleanup owner"
  Right _ -> assertFailure "expected internal pair query deadline failure"

assertInternalSessionDeadlineScope
  :: Either SMTLibSession.LengthSMTLibSessionScopeError value
  -> IO ()
assertInternalSessionDeadlineScope result = case result of
  Left scope -> case SMTLibSession.lengthSMTLibSessionScopePrimaryError scope of
    SMTLibSession.LengthSMTLibSessionDeadlineFailure process ->
      SMTLibProcess.lengthSMTLibProcessErrorClass process @?=
        SMTLibProcess.LengthSMTLibProcessDeadlineExceeded
    unexpected -> assertFailure $ "wrong shared session failure: " ++
      show unexpected
  Right _ -> assertFailure "expired shared session unexpectedly succeeded"

assertEffectiveDeadlineCause :: String -> [Word8] -> IO ()
assertEffectiveDeadlineCause expected identity =
  countByteStringOccurrences
      (BS.pack $ encodeFingerprintFieldForIdentityTest field)
      (BS.pack identity) @?= 1
 where
  field = InternalFingerprint.FingerprintTag
    (asciiBytes "effective-cause")
    [InternalFingerprint.FingerprintBytes $ asciiBytes expected]

assertFakeWorkerWorkspaceRemoved :: String -> FilePath -> IO ()
assertFakeWorkerWorkspaceRemoved label executable = do
  events <- SMTLibLiveSpec.readFakeZ3Events executable
  case fakeZ3Events "start" events of
    [event] -> case SMTLibLiveSpec.fakeZ3FieldValues
        (liveTestBytes "cwd") event of
      [raw] -> do
        retained <- doesPathExist $ BSC.unpack raw
        assertBool (label ++ " retained its workspace") $ not retained
      _ -> assertFailure $ label ++ " trace omitted its cwd"
    _ -> assertFailure $ label ++ " emitted an unexpected start trace"

delayUntilMonotonic :: Word64 -> IO ()
delayUntilMonotonic target = do
  now <- getMonotonicTimeNSec
  if now >= target
    then pure ()
    else do
      let remainingMicroseconds =
            fromIntegral ((target - now + 999) `div` 1000)
      threadDelay remainingMicroseconds
      delayUntilMonotonic target

smtLibLiveQueryTests :: TestTree
smtLibLiveQueryTests = testGroup "Length SMT-LIB live queries"
  [ testCase "admit the exact Word64 ordinal boundary"
      assertLiveQueryOrdinalBoundary
  , testCase
      "preserve scalar/pair wire bytes and statuses across sealed launches"
      assertDescriptorBoundLiveQueryParity
  , testCase "run sequential unary values with ordinals, identity, and replay"
      assertLiveSequentialUnaryQueries
  , testGroup "status and artifact branches"
      [ testCase "status-only satisfiable omits values"
          assertLiveStatusOnlySatisfiable
      , testCase "values policy unsatisfiable omits values"
          $ assertLiveTerminalStatus "query-unsat"
              Observation.SolverUnsatisfiable
      , testCase "values policy unknown omits values"
          $ assertLiveTerminalStatus "query-unknown"
              Observation.SolverUnknown
      , testCase "values policy admits a vacuous zero-input counterexample"
          assertLiveZeroInputQuery
      , testCase "values policy decodes and replays a binary assignment"
          assertLiveBinaryQuery
      ]
  , testCase "complete unary values under split and drip stdout"
      assertLiveQueryChunkModes
  , testCase "reject stale pre-write values, omit get-value, and spend worker"
      assertLiveQueryStalePreWrite
  , testCase "bound a hung status and spend worker"
      assertLiveQueryHangStatus
  , testCase "admit exactly maximum queries and reject maximum plus one"
      assertLiveQueryMaximum
  , testCase
      "share all 64 default ordinals across scalar and product domains"
      assertLiveMixedDomainQueryMaximum
  , testCase "retain the query-run identity cap after readiness"
      assertLiveQueryRunIdentityMaximum
  , testCase "source remaining stdout capacity from the retained process"
      assertLiveQueryProcessCapacity
  ]

data LiveLaunchParityObservation = LiveLaunchParityObservation
  { liveLaunchParityStableInputBytes :: [BS.ByteString]
  , liveLaunchParityReportedStatuses :: [BS.ByteString]
  , liveLaunchParityDecodedStatuses :: [Observation.SolverStatus]
  , liveLaunchParityReadyIdentity :: BS.ByteString
  , liveLaunchParityScalarIdentity :: BS.ByteString
  , liveLaunchParityPairIdentity :: BS.ByteString
  }
  deriving (Eq, Show)

assertDescriptorBoundLiveQueryParity :: IO ()
assertDescriptorBoundLiveQueryParity
  | SMTLibProcess.lengthSMTLibDescriptorBoundExecutableLaunchSupported =
      assertSupportedDescriptorBoundLiveQueryParity
  | otherwise = do
      SMTLibProcess.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchSupported
        @?= False
      SMTLibProcess.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunchSupported
        @?= False
      let unexpected _ _ = assertFailure "unsupported launch executed a query callback"
          policy = InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      descriptor <- SMTLibLiveSpec.withDescriptorBoundLiveQueryWorker
        "healthy" policy id unexpected
      effective <- SMTLibLiveSpec.withEffectiveIDDescriptorBoundLiveQueryWorker
        "healthy" policy id unexpected
      execCheck <- SMTLibLiveSpec.withExecveCheckDescriptorBoundLiveQueryWorker
        "healthy" policy id unexpected
      assertUnavailable SMTLibProcess.LengthSMTLibProcessSpawnPhase
        SMTLibProcess.LengthSMTLibProcessDescriptorBoundLaunchUnavailable descriptor
      assertUnavailable SMTLibProcess.LengthSMTLibProcessSnapshotPhase
        SMTLibProcess.LengthSMTLibProcessEffectiveIDExecutableAccessCheckUnavailable effective
      assertUnavailable SMTLibProcess.LengthSMTLibProcessSnapshotPhase
        SMTLibProcess.LengthSMTLibProcessSourceExecveCheckUnavailable execCheck
  where
    assertUnavailable phase failureClass result = case result of
      Left scope -> assertDescriptorLaunchUnavailableScope phase failureClass scope
      Right _ -> assertFailure "unsupported launch fell back to another policy"

assertSupportedDescriptorBoundLiveQueryParity :: IO ()
assertSupportedDescriptorBoundLiveQueryParity = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  legacy <- expectRight =<< SMTLibLiveSpec.withLiveQueryWorker "healthy"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
    (captureLiveLaunchParity scalarQuery pairQuery)
  descriptorBound <- expectRight =<<
    SMTLibLiveSpec.withDescriptorBoundLiveQueryWorker "healthy"
      InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
      (captureLiveLaunchParity scalarQuery pairQuery)
  effectiveID <- expectRight =<<
    SMTLibLiveSpec.withEffectiveIDDescriptorBoundLiveQueryWorker "healthy"
      InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
      (captureLiveLaunchParity scalarQuery pairQuery)
  execveCheck <-
    SMTLibLiveSpec.withExecveCheckDescriptorBoundLiveQueryWorker "healthy"
      InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
      (captureLiveLaunchParity scalarQuery pairQuery)
  liveLaunchParityStableInputBytes descriptorBound @?=
    liveLaunchParityStableInputBytes legacy
  liveLaunchParityStableInputBytes effectiveID @?=
    liveLaunchParityStableInputBytes legacy
  liveLaunchParityReportedStatuses descriptorBound @?=
    liveLaunchParityReportedStatuses legacy
  liveLaunchParityReportedStatuses effectiveID @?=
    liveLaunchParityReportedStatuses legacy
  liveLaunchParityDecodedStatuses descriptorBound @?=
    liveLaunchParityDecodedStatuses legacy
  liveLaunchParityDecodedStatuses effectiveID @?=
    liveLaunchParityDecodedStatuses legacy
  liveLaunchParityDecodedStatuses descriptorBound @?=
    [Observation.SolverSatisfiable, Observation.SolverSatisfiable]
  assertBool "launch strategies shared a ready-worker identity"
    $ liveLaunchParityReadyIdentity descriptorBound /=
        liveLaunchParityReadyIdentity legacy
  assertBool "launch strategies shared a scalar run identity"
    $ liveLaunchParityScalarIdentity descriptorBound /=
        liveLaunchParityScalarIdentity legacy
  assertBool "launch strategies shared a pair run identity"
    $ liveLaunchParityPairIdentity descriptorBound /=
        liveLaunchParityPairIdentity legacy
  assertBool "effective-ID and legacy launches shared a ready identity"
    $ liveLaunchParityReadyIdentity effectiveID /=
        liveLaunchParityReadyIdentity legacy
  assertBool "effective-ID and old descriptor launches shared a ready identity"
    $ liveLaunchParityReadyIdentity effectiveID /=
        liveLaunchParityReadyIdentity descriptorBound
  assertBool "effective-ID and legacy launches shared a scalar identity"
    $ liveLaunchParityScalarIdentity effectiveID /=
        liveLaunchParityScalarIdentity legacy
  assertBool "effective-ID and old descriptor launches shared a scalar identity"
    $ liveLaunchParityScalarIdentity effectiveID /=
        liveLaunchParityScalarIdentity descriptorBound
  assertBool "effective-ID and legacy launches shared a pair identity"
    $ liveLaunchParityPairIdentity effectiveID /=
        liveLaunchParityPairIdentity legacy
  assertBool "effective-ID and old descriptor launches shared a pair identity"
    $ liveLaunchParityPairIdentity effectiveID /=
        liveLaunchParityPairIdentity descriptorBound
  assertBool "descriptor scalar and pair runs shared nominal identity"
    $ liveLaunchParityScalarIdentity descriptorBound /=
        liveLaunchParityPairIdentity descriptorBound
  assertIdentityContains
    "descriptor ready identity omitted its launch schema"
    (BSC.pack
      "djex-length-z3-capability-probed-sealed-main-image-ready-worker/v1")
    $ liveLaunchParityReadyIdentity descriptorBound
  assertIdentityContains
    "descriptor scalar identity omitted its launch schema"
    (BSC.pack
      "djex-length-z3-capability-probed-sealed-main-image-worker-query-run/v1")
    $ liveLaunchParityScalarIdentity descriptorBound
  assertIdentityContains
    "descriptor pair identity omitted its launch schema"
    (BSC.pack $ concat
      [ "djex-length-spine-pair-z3-capability-probed-sealed-main-image-"
      , "worker-query-run/v1"
      ])
    $ liveLaunchParityPairIdentity descriptorBound
  assertBool "effective-ID scalar and pair runs shared nominal identity"
    $ liveLaunchParityScalarIdentity effectiveID /=
        liveLaunchParityPairIdentity effectiveID
  mapM_ (assertIdentityContains
      "descriptor live identity omitted its exact sealed-image strength"
      SMTLibProcess.lengthSMTLibDescriptorBoundExecutableLaunchStrengthTag)
    [ liveLaunchParityReadyIdentity descriptorBound
    , liveLaunchParityScalarIdentity descriptorBound
    , liveLaunchParityPairIdentity descriptorBound
    ]

  assertIdentityContains
    "effective-ID ready identity omitted its launch schema"
    (BSC.pack $ concat
      [ "djex-length-z3-capability-probed-effective-id-executable-access-"
      , "sealed-main-image-ready-worker/v1"
      ])
    $ liveLaunchParityReadyIdentity effectiveID
  assertIdentityContains
    "effective-ID scalar identity omitted its launch schema"
    (BSC.pack $ concat
      [ "djex-length-z3-capability-probed-effective-id-executable-access-"
      , "sealed-main-image-worker-query-run/v1"
      ])
    $ liveLaunchParityScalarIdentity effectiveID
  assertIdentityContains
    "effective-ID pair identity omitted its launch schema"
    (BSC.pack $ concat
      [ "djex-length-spine-pair-z3-capability-probed-effective-id-"
      , "executable-access-sealed-main-image-worker-query-run/v1"
      ])
    $ liveLaunchParityPairIdentity effectiveID
  mapM_ (assertIdentityContains
      "effective-ID live identity omitted its exact launch strength"
      SMTLibProcess.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchStrengthTag)
    [ liveLaunchParityReadyIdentity effectiveID
    , liveLaunchParityScalarIdentity effectiveID
    , liveLaunchParityPairIdentity effectiveID
    ]
  case execveCheck of
    Left scope -> assertExecveCheckUnavailableScope scope
    Right observation -> do
      liveLaunchParityStableInputBytes observation @?=
        liveLaunchParityStableInputBytes legacy
      liveLaunchParityReportedStatuses observation @?=
        liveLaunchParityReportedStatuses legacy
      liveLaunchParityDecodedStatuses observation @?=
        liveLaunchParityDecodedStatuses legacy
      let ready = liveLaunchParityReadyIdentity observation
          scalar = liveLaunchParityScalarIdentity observation
          pair = liveLaunchParityPairIdentity observation
          oldIdentities =
            [ liveLaunchParityReadyIdentity legacy
            , liveLaunchParityReadyIdentity descriptorBound
            , liveLaunchParityReadyIdentity effectiveID
            , liveLaunchParityScalarIdentity legacy
            , liveLaunchParityScalarIdentity descriptorBound
            , liveLaunchParityScalarIdentity effectiveID
            , liveLaunchParityPairIdentity legacy
            , liveLaunchParityPairIdentity descriptorBound
            , liveLaunchParityPairIdentity effectiveID
            ]
          authority = BSC.pack execveCheckQueryAuthorityTag
      assertBool "exec-check fresh scalar and pair identities were equal"
        $ scalar /= pair
      assertBool "exec-check fresh identity reused a predecessor identity"
        $ all (`notElem` [ready, scalar, pair]) oldIdentities
      assertIdentityContains
        "exec-check ready identity omitted its nominal schema"
        (BSC.pack $ concat
          [ "djex-length-z3-capability-probed-execve-check-executable-"
          , "access-sealed-main-image-ready-worker/v1"
          ]) ready
      assertIdentityContains
        "exec-check scalar identity omitted its nominal schema"
        (BSC.pack $ concat
          [ "djex-length-z3-capability-probed-execve-check-executable-"
          , "access-sealed-main-image-worker-query-run/v1"
          ]) scalar
      assertIdentityContains
        "exec-check pair identity omitted its nominal schema"
        (BSC.pack $ concat
          [ "djex-length-spine-pair-z3-capability-probed-execve-check-"
          , "executable-access-sealed-main-image-worker-query-run/v1"
          ]) pair
      mapM_ (assertIdentityContains
          "exec-check fresh identity omitted its exact launch strength"
          SMTLibProcess.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunchStrengthTag)
        [ready, scalar, pair]
      mapM_ (assertIdentityContains
          "exec-check fresh query identity omitted exact authority"
          authority) [scalar, pair]
 where
  assertIdentityContains label bytes identity =
    assertBool label $ bytes `BS.isInfixOf` identity

assertExecveCheckUnavailableScope
  :: SMTLibSession.LengthSMTLibSessionScopeError
  -> IO ()
assertExecveCheckUnavailableScope = assertDescriptorLaunchUnavailableScope
  SMTLibProcess.LengthSMTLibProcessSnapshotPhase
  SMTLibProcess.LengthSMTLibProcessSourceExecveCheckUnavailable

assertDescriptorLaunchUnavailableScope
  :: SMTLibProcess.LengthSMTLibProcessPhase
  -> SMTLibProcess.LengthSMTLibProcessFailureClass
  -> SMTLibSession.LengthSMTLibSessionScopeError
  -> IO ()
assertDescriptorLaunchUnavailableScope phase failureClass scope = case
    SMTLibSession.lengthSMTLibSessionScopePrimaryError scope of
  SMTLibSession.LengthSMTLibSessionProcessFailure failure -> do
    SMTLibProcess.lengthSMTLibProcessErrorPhase failure @?= phase
    SMTLibProcess.lengthSMTLibProcessErrorClass failure @?= failureClass
    SMTLibProcess.lengthSMTLibProcessErrorCleanupStatus failure @?= Nothing
    SMTLibSession.lengthSMTLibSessionProcessCleanupStatus
        (SMTLibSession.lengthSMTLibSessionScopeCleanupStatus scope) @?= Nothing
  other -> assertFailure $ "unexpected descriptor scope failure: " ++ show other

execveCheckQueryAuthorityTag :: String
execveCheckQueryAuthorityTag = concat
  [ "live-syntactic-process-observation/"
  , "independent-counterexample-replay/"
  , "two-point-source-effective-id-vfs-and-execve-check-executable-"
  , "access-admitted/"
  , "sealed-mfd-exec-fixed-0500-f-seal-exec-staged-execve-check-main-"
  , "image-bytes-bound/"
  , "point-in-time-format-and-interpreter-dependencies-ignored/"
  , "no-source-authorization-transfer-binfmt-bprm-check-credential-"
  , "transition-interpreter-loader-library-or-solver-soundness-authority/v1"
  ]

captureLiveLaunchParity
  :: SMTLib.LengthSMTLibQuery AdversarialIdentity AdversarialLocal
  -> SMTLib.LengthSpinePairSMTLibQuery
      AdversarialIdentity AdversarialLocal
  -> FilePath
  -> SMTLibSession.LengthSMTLibReadyWorker epoch
  -> IO LiveLaunchParityObservation
captureLiveLaunchParity scalarQuery pairQuery executable worker = do
  scalar <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
    Evaluate.defaultLengthEvaluationLimits worker scalarQuery
  pair <- expectRight =<< SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
    Evaluate.defaultLengthEvaluationLimits worker pairQuery
  assertLiveValueQueryRun scalarQuery [3] scalar
  assertLiveSpinePairValueQueryRun
    pairQuery [3] (Length.LengthSpinePair 3 0) pair
  events <- SMTLibLiveSpec.readFakeZ3Events executable
  let inputBytes = concatMap
        (SMTLibLiveSpec.fakeZ3FieldValues $ liveTestBytes "bytes")
        $ fakeZ3Events "stdin" events
      stableInput = filter
        (not . BSC.isPrefixOf (liveTestBytes "(echo \"")) inputBytes
      reportedStatuses = concatMap
        (SMTLibLiveSpec.fakeZ3FieldValues $ liveTestBytes "status")
        $ fakeZ3Events "query-check" events
      scalarStatus = Observation.solverObservationStatus
        $ SMTLibSession.lengthSMTLibQueryRunObservation scalar
      pairStatus = Observation.solverObservationStatus
        $ SMTLibSession.lengthSpinePairSMTLibQueryRunObservation pair
  pure LiveLaunchParityObservation
    { liveLaunchParityStableInputBytes = stableInput
    , liveLaunchParityReportedStatuses = reportedStatuses
    , liveLaunchParityDecodedStatuses = [scalarStatus, pairStatus]
    , liveLaunchParityReadyIdentity = BS.pack
        $ InternalFingerprint.fingerprintCanonicalBytes
        $ SMTLibSession.lengthSMTLibReadyWorkerIdentityFingerprint worker
    , liveLaunchParityScalarIdentity = BS.pack
        $ InternalFingerprint.fingerprintCanonicalBytes
        $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint scalar
    , liveLaunchParityPairIdentity = BS.pack
        $ InternalFingerprint.fingerprintCanonicalBytes
        $ SMTLibSession.lengthSpinePairSMTLibQueryRunIdentityFingerprint pair
    }

assertLiveQueryOrdinalBoundary :: IO ()
assertLiveQueryOrdinalBoundary = do
  let maximumOrdinal = fromIntegral (maxBound :: Word64)
      source = SMTLibSession.defaultLengthSMTLibSessionLimitSource
        { SMTLibSession.lengthSMTLibSessionLimitSourceMaximumQueries =
            maximumOrdinal
        }
  _ <- expectRight $ SMTLibSession.mkLengthSMTLibSessionLimits source
  case SMTLibSession.mkLengthSMTLibSessionLimits
      (source
        { SMTLibSession.lengthSMTLibSessionLimitSourceMaximumQueries =
            maximumOrdinal + 1
        }) of
    Left (SMTLibSession.LengthSMTLibSessionLimitConversionOverflow
      SMTLibSession.LengthSMTLibSessionMaximumQueries observed) ->
      observed @?= maximumOrdinal + 1
    Left failure -> assertFailure $
      "unexpected ordinal-bound rejection: " ++ show failure
    Right _ -> assertFailure "maximum plus one entered the Word64 ordinal"

smtLibLiveFacadeTests :: TestTree
smtLibLiveFacadeTests = testGroup "public Length SMT-LIB live facade"
  [ testCase
      "replay sequential evidence and reject a stale exact query first"
      assertLiveFacadeSequentialEvidence
  , testCase "project the expected query before forcing the observation"
      assertLiveFacadeReplayDemandPrecedence
  , testCase "report satisfiable status-only without evidence"
      assertLiveFacadeStatusOnlySatisfiable
  , testGroup "terminal heuristic observations"
      [ testCase "report unsatisfiable without evidence"
          $ assertLiveFacadeTerminalStatus "query-unsat"
              Observation.SolverUnsatisfiable
              SemanticProblem.RawSolverUnsatRelativeToEncoding
      , testCase "report unknown without evidence"
          $ assertLiveFacadeTerminalStatus "query-unknown"
              Observation.SolverUnknown
              SemanticProblem.RawSolverUnknown
      ]
  , testCase
      "sanitize stale output, spend the session, and hide dynamic payloads"
      assertLiveFacadeStaleFailure
  , testCase "sanitize a deadline and reject reuse of the spent session"
      assertLiveFacadeDeadlineFailure
  ]

smtLibSpinePairLiveFacadeTests :: TestTree
smtLibSpinePairLiveFacadeTests = testGroup
  "public binary product-of-spines SMT-LIB live facade"
  [ testCase
      "replay one model and reject pair-stale and cross-domain observations"
      assertSpinePairLiveFacadeEvidence
  , testCase "report satisfiable status-only without pair evidence"
      assertSpinePairLiveFacadeStatusOnlySatisfiable
  , testGroup "terminal pair heuristic observations"
      [ testCase "report pair unsatisfiable without evidence"
          $ assertSpinePairLiveFacadeTerminalStatus "query-unsat"
              Observation.SolverUnsatisfiable
              SemanticProblem.RawSolverUnsatRelativeToEncoding
      , testCase "report pair unknown without evidence"
          $ assertSpinePairLiveFacadeTerminalStatus "query-unknown"
              Observation.SolverUnknown
              SemanticProblem.RawSolverUnknown
      ]
  , testCase "replay pair models under split and drip stdout"
      assertSpinePairLiveFacadeChunkModes
  , testCase
      "associate a vacuous pair model with origin and input-box replay"
      assertSpinePairLiveFacadeZeroInputParity
  , testCase
      "sanitize stale pair output and spend the shared scalar session"
      assertSpinePairLiveFacadeStaleFailure
  , testCase "sanitize a pair deadline and reject shared-session reuse"
      assertSpinePairLiveFacadeDeadlineFailure
  ]

assertSpinePairLiveFacadeEvidence :: IO ()
assertSpinePairLiveFacadeEvidence = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  staleProblem <- adversarialInputAndZeroSpinePairProblem
    trivialSpinePairContract
  staleQuery <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits staleProblem
  assertBool "distinct pair fixtures shared a query fingerprint"
    $ SMTLib.lengthSpinePairSMTLibQueryFingerprint pairQuery /=
        SMTLib.lengthSpinePairSMTLibQueryFingerprint staleQuery
  scoped <- SMTLibLiveSpec.withLiveFacadeSession "healthy"
    SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    $ \executable session -> do
        scalarObservation <- expectRight
          =<< SMTLibLive.runLengthSMTLibLiveQuery
                Evaluate.defaultLengthEvaluationLimits session scalarQuery
        pairObservation <- expectRight
          =<< SMTLibLive.runLengthSpinePairSMTLibLiveQuery
                Evaluate.defaultLengthEvaluationLimits session pairQuery
        scalarReceipt <- case
            SMTLibLive.replayLengthSMTLibLiveQueryObservation
              scalarQuery scalarObservation of
          Left failure -> assertFailure
            ("wire-twin scalar replay failed: " ++ show failure)
              >> error "unreachable"
          Right Nothing -> assertFailure
            "wire-twin scalar replay omitted its evidence"
              >> error "unreachable"
          Right (Just receipt) -> pure receipt
        Evaluate.validatedLengthCounterexampleInputs scalarReceipt @?= [3]
        pairReceipt <- assertSpinePairLiveFacadeObservation
          pairQuery [3] (Length.LengthSpinePair 3 0) pairObservation
        direct <- expectCounterexample
          $ SMTLib.replayLengthSpinePairSMTLibCounterexampleInputs
              Evaluate.defaultLengthEvaluationLimits pairQuery [3]
        pairReceipt @?= direct

        assertSpinePairLiveReplayMismatch staleQuery pairObservation
          SMTLibLive.LengthSpinePairSMTLibLiveObservationQueryFingerprintMismatch
        let scalarAsPair = unsafeCoerce scalarObservation
              :: SMTLibLive.LengthSpinePairSMTLibLiveQueryObservation
                  epoch AdversarialIdentity AdversarialLocal
            pairAsScalar = unsafeCoerce pairObservation
              :: SMTLibLive.LengthSMTLibLiveQueryObservation
                  epoch AdversarialIdentity AdversarialLocal
        assertSpinePairLiveReplayMismatch pairQuery scalarAsPair
          SMTLibLive.LengthSpinePairSMTLibLiveObservationQueryFingerprintMismatch
        assertLiveFacadeQueryMismatch scalarQuery pairAsScalar

        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0, 1] events
        assertFakeZ3EventOrdinals "query-get-value" [0, 1] events
  _ <- expectRight scoped
  pure ()

assertSpinePairLiveFacadeObservation
  :: SMTLib.LengthSpinePairSMTLibQuery identity local
  -> [Natural]
  -> Length.LengthSpinePair Natural
  -> SMTLibLive.LengthSpinePairSMTLibLiveQueryObservation
      epoch identity local
  -> IO Evaluate.ValidatedLengthSpinePairCounterexample
assertSpinePairLiveFacadeObservation query expectedInputs expectedResult
    observation = do
  SMTLibLive.lengthSpinePairSMTLibLiveQueryObservationSolverStatus observation
    @?= Observation.SolverSatisfiable
  SMTLibLive.lengthSpinePairSMTLibLiveQueryObservationResultStrength observation
    @?= SemanticProblem.RawSolverModelHint
  SMTLibLive.lengthSpinePairSMTLibLiveQueryObservationUse observation @?=
    SemanticProblem.HeuristicRankingOnly
  receipt <- case
      SMTLibLive.replayLengthSpinePairSMTLibLiveQueryObservation
        query observation of
    Left failure -> assertFailure
      ("matching pair live observation replay failed: " ++ show failure)
        >> error "unreachable"
    Right Nothing -> assertFailure
      "matching pair live observation omitted its evidence"
        >> error "unreachable"
    Right (Just value) -> pure value
  Evaluate.validatedLengthSpinePairCounterexampleInputs receipt @?=
    expectedInputs
  Evaluate.validatedLengthSpinePairCounterexampleResult receipt @?=
    expectedResult
  pure receipt

assertSpinePairLiveReplayMismatch
  :: SMTLib.LengthSpinePairSMTLibQuery identity local
  -> SMTLibLive.LengthSpinePairSMTLibLiveQueryObservation
      epoch identity local
  -> SMTLibLive.LengthSpinePairSMTLibLiveObservationReplayError
  -> IO ()
assertSpinePairLiveReplayMismatch query observation expected = case
    SMTLibLive.replayLengthSpinePairSMTLibLiveQueryObservation
      query observation of
  Left failure -> failure @?= expected
  Right _ -> assertFailure
    "stale or cross-domain pair live observation replay unexpectedly succeeded"

assertSpinePairLiveFacadeStatusOnlySatisfiable :: IO ()
assertSpinePairLiveFacadeStatusOnlySatisfiable = do
  (_, query) <- liveWireTwinQueries
  scoped <- SMTLibLiveSpec.withLiveFacadeSession "healthy"
    SMTLibExecution.LengthSMTLibStatusOnly
    $ \executable session -> do
        observation <- expectRight
          =<< SMTLibLive.runLengthSpinePairSMTLibLiveQuery
                Evaluate.defaultLengthEvaluationLimits session query
        assertSpinePairLiveFacadeStatusObservation query
          Observation.SolverSatisfiable
          SemanticProblem.RawSolverModelHint observation
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

assertSpinePairLiveFacadeTerminalStatus
  :: String
  -> Observation.SolverStatus
  -> SemanticProblem.RawResultStrength
  -> IO ()
assertSpinePairLiveFacadeTerminalStatus mode expectedStatus expectedStrength =
  do
    (_, query) <- liveWireTwinQueries
    scoped <- SMTLibLiveSpec.withLiveFacadeSession mode
      SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      $ \executable session -> do
          observation <- expectRight
            =<< SMTLibLive.runLengthSpinePairSMTLibLiveQuery
                  Evaluate.defaultLengthEvaluationLimits session query
          assertSpinePairLiveFacadeStatusObservation query expectedStatus
            expectedStrength observation
          events <- SMTLibLiveSpec.readFakeZ3Events executable
          assertFakeZ3EventOrdinals "query-check" [0] events
          assertFakeZ3EventCount "query-get-value" 0 events
    _ <- expectRight scoped
    pure ()

assertSpinePairLiveFacadeStatusObservation
  :: SMTLib.LengthSpinePairSMTLibQuery identity local
  -> Observation.SolverStatus
  -> SemanticProblem.RawResultStrength
  -> SMTLibLive.LengthSpinePairSMTLibLiveQueryObservation
      epoch identity local
  -> IO ()
assertSpinePairLiveFacadeStatusObservation query expectedStatus
    expectedStrength observation = do
  SMTLibLive.lengthSpinePairSMTLibLiveQueryObservationSolverStatus observation
    @?= expectedStatus
  SMTLibLive.lengthSpinePairSMTLibLiveQueryObservationResultStrength observation
    @?= expectedStrength
  SMTLibLive.lengthSpinePairSMTLibLiveQueryObservationUse observation @?=
    SemanticProblem.HeuristicRankingOnly
  case SMTLibLive.replayLengthSpinePairSMTLibLiveQueryObservation
      query observation of
    Left failure -> assertFailure
      $ "matching pair status-only replay failed: " ++ show failure
    Right Nothing -> pure ()
    Right (Just _) -> assertFailure
      "pair status-only observation replay invented evidence"

assertSpinePairLiveFacadeChunkModes :: IO ()
assertSpinePairLiveFacadeChunkModes = mapM_ runMode
  ["split-output", "drip-output"]
 where
  runMode mode = do
    (_, query) <- liveWireTwinQueries
    scoped <- SMTLibLiveSpec.withLiveFacadeSession mode
      SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      $ \executable session -> do
          observation <- expectRight
            =<< SMTLibLive.runLengthSpinePairSMTLibLiveQuery
                  Evaluate.defaultLengthEvaluationLimits session query
          _ <- assertSpinePairLiveFacadeObservation
            query [3] (Length.LengthSpinePair 3 0) observation
          events <- SMTLibLiveSpec.readFakeZ3Events executable
          assertFakeZ3EventOrdinals "query-check" [0] events
          assertFakeZ3EventOrdinals "query-get-value" [0] events
    _ <- expectRight scoped
    pure ()

assertSpinePairLiveFacadeZeroInputParity :: IO ()
assertSpinePairLiveFacadeZeroInputParity = do
  let firstResult = pairResultVariable Length.LengthSpinePairFirst
      secondResult = pairResultVariable Length.LengthSpinePairSecond
      source = spinePairContractWith (Length.LengthTruth True)
        $ Length.LengthAll
            [ Length.LengthEqual firstResult $ Length.LengthLiteral 1
            , Length.LengthEqual secondResult $ Length.LengthLiteral 0
            ]
  problem <- adversarialNullaryZeroSpinePairProblem source
  query <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  SMTLib.lengthSpinePairSMTLibQueryInputSymbols query @?= []
  SMTLib.lengthSpinePairSMTLibQueryInputValueRequestBytes query @?= Nothing
  origin <- expectCounterexample
    $ SMTLib.probeLengthSpinePairSMTLibCounterexampleAtOrigin
        Evaluate.defaultLengthEvaluationLimits query
  boxed <- expectRight
    $ SMTLib.validateLengthSpinePairSMTLibQueryInputBox
        Evaluate.defaultLengthEvaluationLimits
        Evaluate.defaultLengthInputBoxLimits query []
  boxCounterexample <- case boxed of
    Evaluate.LengthInputBoxCounterexample receipt -> pure receipt
    Evaluate.LengthInputBoxValidated{} -> assertFailure
      "the violating nullary pair query produced positive box evidence"
        >> error "unreachable"
  origin @?= boxCounterexample

  scoped <- SMTLibLiveSpec.withLiveFacadeSession "healthy"
    SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    $ \executable session -> do
        observation <- expectRight
          =<< SMTLibLive.runLengthSpinePairSMTLibLiveQuery
                Evaluate.defaultLengthEvaluationLimits session query
        receipt <- assertSpinePairLiveFacadeObservation
          query [] (Length.LengthSpinePair 0 0) observation
        receipt @?= origin
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

assertSpinePairLiveFacadeStaleFailure :: IO ()
assertSpinePairLiveFacadeStaleFailure = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  scoped <- SMTLibLiveSpec.withLiveFacadeSession "query-stale-prewrite"
    SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    $ \executable session -> do
        rejected <- SMTLibLive.runLengthSpinePairSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session pairQuery
        _ <- expectSpinePairLiveFacadeQueryFailure
          SMTLibLive.LengthSpinePairSMTLibLiveQueryProtocolRejected rejected
        spent <- SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session scalarQuery
        _ <- expectLiveFacadeQueryFailure
          SMTLibLive.LengthSMTLibLiveQuerySessionUnavailable spent
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

assertSpinePairLiveFacadeDeadlineFailure :: IO ()
assertSpinePairLiveFacadeDeadlineFailure = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  scoped <- SMTLibLiveSpec.withLiveFacadeSession "query-hang-status"
    SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    $ \executable session -> do
        rejected <- SMTLibLive.runLengthSpinePairSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session pairQuery
        _ <- expectSpinePairLiveFacadeQueryFailure
          SMTLibLive.LengthSpinePairSMTLibLiveQueryDeadlineExceeded rejected
        spent <- SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session scalarQuery
        _ <- expectLiveFacadeQueryFailure
          SMTLibLive.LengthSMTLibLiveQuerySessionUnavailable spent
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

expectSpinePairLiveFacadeQueryFailure
  :: SMTLibLive.LengthSpinePairSMTLibLiveQueryFailure
  -> Either SMTLibLive.LengthSpinePairSMTLibLiveQueryError value
  -> IO SMTLibLive.LengthSpinePairSMTLibLiveQueryError
expectSpinePairLiveFacadeQueryFailure expected result = case result of
  Left failure -> do
    SMTLibLive.lengthSpinePairSMTLibLiveQueryPrimaryFailure failure @?=
      expected
    SMTLibLive.lengthSpinePairSMTLibLiveQueryCleanupIncomplete failure @?=
      False
    pure failure
  Right _ -> assertFailure $ "expected public pair query failure: " ++
    show expected

liveWireTwinQueries
  :: IO
      ( SMTLib.LengthSMTLibQuery AdversarialIdentity AdversarialLocal
      , SMTLib.LengthSpinePairSMTLibQuery
          AdversarialIdentity AdversarialLocal
      )
liveWireTwinQueries = do
  scalarProblem <- adversarialConstantZeroProblem identityLengthContract
  scalarQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits scalarProblem
  let input = Length.LengthVariable $ Length.LengthSpinePairInput 0
      source = spinePairContractWith (Length.LengthTruth True)
        $ Length.LengthEqual
            (pairResultVariable Length.LengthSpinePairSecond) input
  pairProblem <- adversarialInputAndZeroSpinePairProblem source
  pairQuery <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits pairProblem
  SMTLib.lengthSpinePairSMTLibQueryCheckBytes pairQuery @?=
    SMTLib.lengthSMTLibQueryCheckBytes scalarQuery
  SMTLib.lengthSpinePairSMTLibQueryInputValueRequestBytes pairQuery @?=
    SMTLib.lengthSMTLibQueryInputValueRequestBytes scalarQuery
  pure (scalarQuery, pairQuery)

assertLiveFacadeSequentialEvidence :: IO ()
assertLiveFacadeSequentialEvidence = do
  unaryProblem <- adversarialConstantZeroProblem identityLengthContract
  binaryProblem <- adversarialBinaryConstantZeroProblem identityLengthContract
  unaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits unaryProblem
  binaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits binaryProblem
  assertBool "distinct facade fixtures shared a query fingerprint"
    $ SMTLib.lengthSMTLibQueryFingerprint unaryQuery /=
        SMTLib.lengthSMTLibQueryFingerprint binaryQuery
  scoped <- SMTLibLiveSpec.withLiveFacadeSession "healthy"
    SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    $ \executable session -> do
        unary <- expectRight =<< SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session unaryQuery
        binary <- expectRight =<< SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session binaryQuery
        assertLiveFacadeEvidence unaryQuery [3] unary
        assertLiveFacadeEvidence binaryQuery [3, 5] binary
        assertLiveFacadeQueryMismatch binaryQuery unary
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0, 1] events
        assertFakeZ3EventOrdinals "query-get-value" [0, 1] events
  _ <- expectRight scoped
  pure ()

assertLiveFacadeEvidence
  :: SMTLib.LengthSMTLibQuery identity local
  -> [Natural]
  -> SMTLibLive.LengthSMTLibLiveQueryObservation epoch identity local
  -> IO ()
assertLiveFacadeEvidence query expectedInputs observation = do
  SMTLibLive.lengthSMTLibLiveQueryObservationSolverStatus observation @?=
    Observation.SolverSatisfiable
  SMTLibLive.lengthSMTLibLiveQueryObservationResultStrength observation @?=
    SemanticProblem.RawSolverModelHint
  SMTLibLive.lengthSMTLibLiveQueryObservationUse observation @?=
    SemanticProblem.HeuristicRankingOnly
  receipt <- case SMTLibLive.replayLengthSMTLibLiveQueryObservation
      query observation of
    Left failure -> assertFailure
      $ "matching live observation replay failed: " ++ show failure
    Right Nothing -> assertFailure
      "matching live observation replay omitted its evidence"
    Right (Just value) -> pure value
  Evaluate.validatedLengthCounterexampleInputs receipt @?= expectedInputs
  Evaluate.validatedLengthCounterexampleResult receipt @?= 0

-- The unary observation carries unary evidence as well as its unary query
-- key.  Replaying it against the binary query therefore pins the public
-- query-before-evidence failure precedence.
assertLiveFacadeQueryMismatch
  :: SMTLib.LengthSMTLibQuery identity local
  -> SMTLibLive.LengthSMTLibLiveQueryObservation epoch identity local
  -> IO ()
assertLiveFacadeQueryMismatch query observation = case
    SMTLibLive.replayLengthSMTLibLiveQueryObservation query observation of
  Left failure -> failure @?=
    SMTLibLive.LengthSMTLibLiveObservationQueryFingerprintMismatch
  Right _ -> assertFailure
    "stale live observation replay unexpectedly succeeded"

assertLiveFacadeReplayDemandPrecedence :: IO ()
assertLiveFacadeReplayDemandPrecedence = do
  let query :: SMTLib.LengthSMTLibQuery () ()
      query = error "expected-query-demand"
      observation :: SMTLibLive.LengthSMTLibLiveQueryObservation () () ()
      observation = error "observation-demand"
  attempted <- try $ evaluate
    $ SMTLibLive.replayLengthSMTLibLiveQueryObservation query observation
  case attempted :: Either SomeException
      (Either SMTLibLive.LengthSMTLibLiveObservationReplayError
        (Maybe Evaluate.ValidatedLengthCounterexample)) of
    Left failure -> do
      let message = displayException failure
      assertBool "live replay forced the observation before the query"
        $ "expected-query-demand" `isInfixOf` message
      assertBool "live replay also forced the opaque observation"
        $ not $ "observation-demand" `isInfixOf` message
    Right _ -> assertFailure
      "poisoned live replay unexpectedly produced a result"

assertLiveFacadeStatusOnlySatisfiable :: IO ()
assertLiveFacadeStatusOnlySatisfiable = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveFacadeSession "healthy"
    SMTLibExecution.LengthSMTLibStatusOnly
    $ \executable session -> do
        observation <- expectRight =<< SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session query
        assertLiveFacadeStatusObservation query
          Observation.SolverSatisfiable
          SemanticProblem.RawSolverModelHint observation
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

assertLiveFacadeTerminalStatus
  :: String
  -> Observation.SolverStatus
  -> SemanticProblem.RawResultStrength
  -> IO ()
assertLiveFacadeTerminalStatus mode expectedStatus expectedStrength = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveFacadeSession mode
    SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    $ \executable session -> do
        observation <- expectRight =<< SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session query
        assertLiveFacadeStatusObservation query expectedStatus expectedStrength
          observation
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

assertLiveFacadeStatusObservation
  :: SMTLib.LengthSMTLibQuery identity local
  -> Observation.SolverStatus
  -> SemanticProblem.RawResultStrength
  -> SMTLibLive.LengthSMTLibLiveQueryObservation epoch identity local
  -> IO ()
assertLiveFacadeStatusObservation query expectedStatus expectedStrength
    observation = do
  SMTLibLive.lengthSMTLibLiveQueryObservationSolverStatus observation @?=
    expectedStatus
  SMTLibLive.lengthSMTLibLiveQueryObservationResultStrength observation @?=
    expectedStrength
  SMTLibLive.lengthSMTLibLiveQueryObservationUse observation @?=
    SemanticProblem.HeuristicRankingOnly
  case SMTLibLive.replayLengthSMTLibLiveQueryObservation query observation of
    Left failure -> assertFailure
      $ "matching status-only observation replay failed: " ++ show failure
    Right Nothing -> pure ()
    Right (Just _) -> assertFailure
      "status-only live observation replay invented evidence"

assertLiveFacadeStaleFailure :: IO ()
assertLiveFacadeStaleFailure = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveFacadeSession "query-stale-prewrite"
    SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    $ \executable session -> do
        rejected <- SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session query
        stale <- expectLiveFacadeQueryFailure
          SMTLibLive.LengthSMTLibLiveQueryProtocolRejected rejected
        spentResult <- SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session query
        spent <- expectLiveFacadeQueryFailure
          SMTLibLive.LengthSMTLibLiveQuerySessionUnavailable spentResult
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
        assertLiveFacadeErrorShowSanitized True executable events [stale, spent]
  _ <- expectRight scoped
  pure ()

assertLiveFacadeDeadlineFailure :: IO ()
assertLiveFacadeDeadlineFailure = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveFacadeSession "query-hang-status"
    SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    $ \executable session -> do
        rejected <- SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session query
        deadline <- expectLiveFacadeQueryFailure
          SMTLibLive.LengthSMTLibLiveQueryDeadlineExceeded rejected
        spentResult <- SMTLibLive.runLengthSMTLibLiveQuery
          Evaluate.defaultLengthEvaluationLimits session query
        spent <- expectLiveFacadeQueryFailure
          SMTLibLive.LengthSMTLibLiveQuerySessionUnavailable spentResult
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
        assertLiveFacadeErrorShowSanitized False executable events
          [deadline, spent]
  _ <- expectRight scoped
  pure ()

expectLiveFacadeQueryFailure
  :: SMTLibLive.LengthSMTLibLiveQueryFailure
  -> Either SMTLibLive.LengthSMTLibLiveQueryError value
  -> IO SMTLibLive.LengthSMTLibLiveQueryError
expectLiveFacadeQueryFailure expected result = case result of
  Left failure -> do
    SMTLibLive.lengthSMTLibLiveQueryPrimaryFailure failure @?= expected
    SMTLibLive.lengthSMTLibLiveQueryCleanupIncomplete failure @?= False
    pure failure
  Right _ -> assertFailure $ "expected public facade query failure: " ++
    show expected

assertLiveFacadeErrorShowSanitized
  :: Bool
  -> FilePath
  -> [SMTLibLiveSpec.FakeZ3Event]
  -> [SMTLibLive.LengthSMTLibLiveQueryError]
  -> IO ()
assertLiveFacadeErrorShowSanitized requireValue executable events failures = do
  let bytePayloads = concatMap
        (SMTLibLiveSpec.fakeZ3FieldValues $ liveTestBytes "bytes") events
      stdoutPayloads = concatMap
        (SMTLibLiveSpec.fakeZ3FieldValues $ liveTestBytes "bytes")
        $ fakeZ3Events "stdout" events
      markers = concatMap quotedResponseBodies stdoutPayloads
      symbol = liveTestBytes "djex_length_input_0"
      valuation = liveTestBytes "((djex_length_input_0 3))"
  assertBool "fake trace omitted the generated query symbol"
    $ any (BS.isInfixOf symbol) bytePayloads
  assertBool "fake trace omitted dynamic quoted marker responses"
    $ not $ null markers
  when requireValue $ assertBool "stale fake trace omitted its raw valuation"
      $ any (BS.isInfixOf valuation) bytePayloads
  let fixedForbidden =
        [ ("executable path", executable)
        , ("generated SMT symbol", BSC.unpack symbol)
        ] ++ if requireValue
          then
            [ ("raw valuation", BSC.unpack valuation)
            , ("decoded integer value", "3")
            ]
          else []
      dynamicForbidden =
        [("dynamic protocol marker", BSC.unpack marker) | marker <- markers]
  mapM_ (assertRenderingSanitized $ fixedForbidden ++ dynamicForbidden)
    $ map show failures

assertRenderingSanitized :: [(String, String)] -> String -> IO ()
assertRenderingSanitized forbidden rendered = mapM_ reject forbidden
 where
  reject (label, bytes) = assertBool
    ("public query error Show leaked " ++ label ++ ": " ++ rendered)
    $ not $ bytes `isInfixOf` rendered

quotedResponseBodies :: BS.ByteString -> [BS.ByteString]
quotedResponseBodies payload = case BS.uncons payload of
  Just (34, afterOpen) ->
    let (body, afterBody) = BS.break (== 34) afterOpen
    in [body | not (BS.null body), not (BS.null afterBody)]
  _ -> []

assertLiveSequentialUnaryQueries :: IO ()
assertLiveSequentialUnaryQueries = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveQueryWorker "healthy"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
    $ \executable worker -> do
        first <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        second <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        SMTLibSession.lengthSMTLibQueryRunOrdinal first @?= 0
        SMTLibSession.lengthSMTLibQueryRunOrdinal second @?= 1
        assertLiveValueQueryRun query [3] first
        assertLiveValueQueryRun query [3] second
        assertBool "sequential query runs shared an identity"
          $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint first /=
              SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint second
        SMTLibSession.lengthSMTLibQueryRunStdoutStart second @?=
          SMTLibSession.lengthSMTLibQueryRunStdoutEnd first
        SMTLibSession.lengthSMTLibQueryRunStderrStart second @?=
          SMTLibSession.lengthSMTLibQueryRunStderrEnd first
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0, 1] events
        assertFakeZ3EventOrdinals "query-get-value" [0, 1] events
  _ <- expectRight scoped
  pure ()

assertLiveStatusOnlySatisfiable :: IO ()
assertLiveStatusOnlySatisfiable = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveQueryWorker "healthy"
    InternalSMTLibExecution.LengthSMTLibStatusOnly id
    $ \executable worker -> do
        run <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        SMTLibSession.lengthSMTLibQueryRunOrdinal run @?= 0
        assertLiveStatusQueryRun Observation.SolverSatisfiable run
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

assertLiveTerminalStatus
  :: String
  -> Observation.SolverStatus
  -> IO ()
assertLiveTerminalStatus mode status = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveQueryWorker mode
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
    $ \executable worker -> do
        run <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        SMTLibSession.lengthSMTLibQueryRunOrdinal run @?= 0
        assertLiveStatusQueryRun status run
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

assertLiveZeroInputQuery :: IO ()
assertLiveZeroInputQuery = do
  let result = Length.LengthVariable Length.LengthResult
      source = contractWith (Length.LengthTruth True)
        $ Length.LengthEqual result $ Length.LengthLiteral 1
  problem <- adversarialZeroInputProblem source
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveQueryWorker "healthy"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
    $ \executable worker -> do
        run <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        assertLiveValueQueryRun query [] run
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

assertLiveBinaryQuery :: IO ()
assertLiveBinaryQuery = do
  problem <- adversarialBinaryConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveQueryWorker "healthy"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
    $ \executable worker -> do
        run <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        assertLiveValueQueryRun query [3, 5] run
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-get-value" [0] events
        case fakeZ3Events "query-get-value" events of
          [event] -> SMTLibLiveSpec.fakeZ3FieldValues
              (liveTestBytes "symbol") event @?=
                map liveTestBytes
                  ["djex_length_input_0", "djex_length_input_1"]
          _ -> assertFailure "binary query emitted an unexpected value event set"
  _ <- expectRight scoped
  pure ()

assertLiveQueryChunkModes :: IO ()
assertLiveQueryChunkModes = mapM_ runMode ["split-output", "drip-output"]
 where
  runMode mode = do
    problem <- adversarialConstantZeroProblem identityLengthContract
    query <- expectRight $ SMTLib.sealLengthSMTLibQuery
      SMTLib.defaultLengthSMTLibLimits problem
    scoped <- SMTLibLiveSpec.withLiveQueryWorker mode
      InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
      $ \executable worker -> do
          run <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
            Evaluate.defaultLengthEvaluationLimits worker query
          assertLiveValueQueryRun query [3] run
          events <- SMTLibLiveSpec.readFakeZ3Events executable
          assertFakeZ3EventOrdinals "query-check" [0] events
          assertFakeZ3EventOrdinals "query-get-value" [0] events
    _ <- expectRight scoped
    pure ()

assertLiveQueryStalePreWrite :: IO ()
assertLiveQueryStalePreWrite = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveQueryWorker "query-stale-prewrite"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
    $ \executable worker -> do
        rejected <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        case rejected of
          Left failure -> do
            case SMTLibSession.lengthSMTLibQueryRunPrimaryFailure failure of
              SMTLibSession.LengthSMTLibQueryProtocolFailure
                  (SMTLibProtocol.LengthSMTLibProtocolUnexpectedPostBarrierByte
                    _ byte) -> byte @?= 40
              unexpected -> assertFailure $ "wrong stale-output failure: " ++
                show unexpected
            case SMTLibSession.lengthSMTLibQueryRunProcessCleanupStatus failure of
              Nothing -> assertFailure "stale-output failure did not close worker"
              Just cleanup ->
                SMTLibProcess.lengthSMTLibProcessCleanupReadersStopped cleanup
                  @?= True
          Right _ -> assertFailure "stale pre-write model was accepted"
        spent <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        assertLiveQueryFailure SMTLibSession.LengthSMTLibQueryWorkerSpent
          False spent
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
  _ <- expectRight scoped
  pure ()

assertLiveQueryHangStatus :: IO ()
assertLiveQueryHangStatus = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  scoped <- SMTLibLiveSpec.withLiveQueryWorker "query-hang-status"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
    $ \executable worker -> do
        rejected <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        case rejected of
          Left failure -> do
            case SMTLibSession.lengthSMTLibQueryRunPrimaryFailure failure of
              SMTLibSession.LengthSMTLibQueryDeadlineFailure processFailure ->
                SMTLibProcess.lengthSMTLibProcessErrorClass processFailure @?=
                  SMTLibProcess.LengthSMTLibProcessDeadlineExceeded
              unexpected -> assertFailure $ "wrong query-hang failure: " ++
                show unexpected
            case SMTLibSession.lengthSMTLibQueryRunProcessCleanupStatus failure of
              Nothing -> assertFailure "query deadline did not close worker"
              Just cleanup ->
                SMTLibProcess.lengthSMTLibProcessCleanupReadersStopped cleanup
                  @?= True
          Right _ -> assertFailure "hung query status completed"
        spent <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker query
        assertLiveQueryFailure SMTLibSession.LengthSMTLibQueryWorkerSpent
          False spent
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0] events
        assertFakeZ3EventCount "query-get-value" 0 events
        case fakeZ3Events "query-hang" events of
          [event] -> SMTLibLiveSpec.fakeZ3FieldValues
              (liveTestBytes "phase") event @?= [liveTestBytes "status"]
          _ -> assertFailure "query status hang emitted an unexpected event set"
  _ <- expectRight scoped
  pure ()

assertLiveQueryMaximum :: IO ()
assertLiveQueryMaximum = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  let maximumQueries source = source
        { SMTLibSession.lengthSMTLibSessionLimitSourceMaximumQueries = 2 }
  scoped <- SMTLibLiveSpec.withLiveQueryWorker "healthy"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    maximumQueries $ \executable worker -> do
      first <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
        Evaluate.defaultLengthEvaluationLimits worker query
      second <- expectRight =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
        Evaluate.defaultLengthEvaluationLimits worker query
      SMTLibSession.lengthSMTLibQueryRunOrdinal first @?= 0
      SMTLibSession.lengthSMTLibQueryRunOrdinal second @?= 1
      rejected <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
        Evaluate.defaultLengthEvaluationLimits worker query
      assertLiveQueryFailure
        (SMTLibSession.LengthSMTLibQueryLimitExceeded 2 3) False rejected
      events <- SMTLibLiveSpec.readFakeZ3Events executable
      assertFakeZ3EventOrdinals "query-check" [0, 1] events
      assertFakeZ3EventOrdinals "query-get-value" [0, 1] events
  _ <- expectRight scoped
  pure ()

assertLiveMixedDomainQueryMaximum :: IO ()
assertLiveMixedDomainQueryMaximum = do
  (scalarQuery, pairQuery) <- liveWireTwinQueries
  let maximumQueries =
        SMTLibSession.lengthSMTLibSessionLimitSourceMaximumQueries
          SMTLibSession.defaultLengthSMTLibSessionLimitSource
  maximumQueries @?= 64
  SMTLibLive.defaultLengthSMTLibLiveSessionMaximumQueries @?= maximumQueries
  scoped <- SMTLibLiveSpec.withLiveQueryWorker "healthy"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable id
    $ \executable worker -> do
        scalarRun <- expectRight
          =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker scalarQuery
        pairRun <- expectRight
          =<< SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker pairQuery
        SMTLibSession.lengthSMTLibQueryRunOrdinal scalarRun @?= 0
        SMTLibSession.lengthSpinePairSMTLibQueryRunOrdinal pairRun @?= 1
        assertLiveValueQueryRun scalarQuery [3] scalarRun
        assertLiveSpinePairValueQueryRun
          pairQuery [3] (Length.LengthSpinePair 3 0) pairRun
        let scalarIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint scalarRun
            pairIdentity = InternalFingerprint.fingerprintCanonicalBytes
              $ SMTLibSession.lengthSpinePairSMTLibQueryRunIdentityFingerprint
                  pairRun
        assertBool
          "wire-identical scalar and product runs shared nominal identity"
          $ scalarIdentity /= pairIdentity
        SMTLibSession.lengthSpinePairSMTLibQueryRunStdoutStart pairRun @?=
          SMTLibSession.lengthSMTLibQueryRunStdoutEnd scalarRun
        SMTLibSession.lengthSpinePairSMTLibQueryRunStderrStart pairRun @?=
          SMTLibSession.lengthSMTLibQueryRunStderrEnd scalarRun

        mapM_ (runRemaining worker scalarQuery pairQuery)
          [2 .. maximumQueries - 1]
        rejected <- SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
          Evaluate.defaultLengthEvaluationLimits worker pairQuery
        case rejected of
          Left failure -> do
            SMTLibSession.lengthSpinePairSMTLibQueryRunPrimaryFailure failure
              @?= SMTLibSession.LengthSpinePairSMTLibQueryLimitExceeded
                    maximumQueries (maximumQueries + 1)
            SMTLibSession.lengthSpinePairSMTLibQueryRunProcessCleanupStatus
                failure @?= Nothing
          Right _ -> assertFailure
            "the sixty-fifth mixed-domain query unexpectedly ran"
        events <- SMTLibLiveSpec.readFakeZ3Events executable
        assertFakeZ3EventOrdinals "query-check" [0 .. maximumQueries - 1]
          events
        assertFakeZ3EventOrdinals "query-get-value"
          [0 .. maximumQueries - 1] events
  _ <- expectRight scoped
  pure ()
 where
  runRemaining worker scalarQuery pairQuery ordinal
    | even ordinal = do
        run <- expectRight
          =<< SMTLibSession.runLengthSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker scalarQuery
        SMTLibSession.lengthSMTLibQueryRunOrdinal run @?= ordinal
    | otherwise = do
        run <- expectRight
          =<< SMTLibSession.runLengthSpinePairSMTLibReadyWorkerQuery
                Evaluate.defaultLengthEvaluationLimits worker pairQuery
        SMTLibSession.lengthSpinePairSMTLibQueryRunOrdinal run @?= ordinal

assertLiveQueryRunIdentityMaximum :: IO ()
assertLiveQueryRunIdentityMaximum = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  let withMaximum source = source
        { SMTLibSession.lengthSMTLibSessionLimitSourceQueryRunIdentityFingerprintBytes =
            1
        }
  scoped <- SMTLibLiveSpec.withLiveQueryWorker "healthy"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    withMaximum $ \executable worker -> do
      first <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
        Evaluate.defaultLengthEvaluationLimits worker query
      assertIdentityAdmission first
      second <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
        Evaluate.defaultLengthEvaluationLimits worker query
      assertIdentityAdmission second
      events <- SMTLibLiveSpec.readFakeZ3Events executable
      assertFakeZ3EventCount "query-check" 0 events
  _ <- expectRight scoped
  pure ()
 where
  assertIdentityAdmission result = case result of
    Left failure -> do
      case SMTLibSession.lengthSMTLibQueryRunPrimaryFailure failure of
        SMTLibSession.LengthSMTLibQueryRunIdentityAdmissionTooSmall
            maximumBytes observed -> do
          maximumBytes @?= 1
          assertBool "query-run identity admission did not report an excess"
            $ observed > maximumBytes
        unexpected -> assertFailure $ "wrong query-run identity failure: " ++
          show unexpected
      SMTLibSession.lengthSMTLibQueryRunProcessCleanupStatus failure @?= Nothing
    Right _ -> assertFailure "one-byte query-run identity cap admitted a run"

assertLiveQueryProcessCapacity :: IO ()
assertLiveQueryProcessCapacity = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  let liveCapabilityBytes =
        SMTLibCapability.lengthSMTLibCapabilityMinimumOutputByteCount + 1
      withMaximum source = source
        { SMTLibProcess.lengthSMTLibProcessLimitSourceStdoutBytes =
            liveCapabilityBytes
        }
  scoped <- SMTLibLiveSpec.withLiveQueryWorkerLimits "healthy"
    InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
    withMaximum id $ \executable worker -> do
      SMTLibSession.lengthSMTLibReadyWorkerObservedStdoutBytes worker @?=
        liveCapabilityBytes
      rejected <- SMTLibSession.runLengthSMTLibReadyWorkerQuery
        Evaluate.defaultLengthEvaluationLimits worker query
      case rejected of
        Left failure -> do
          case SMTLibSession.lengthSMTLibQueryRunPrimaryFailure failure of
            SMTLibSession.LengthSMTLibQueryProcessStdoutCapacityTooSmall
                remaining required -> do
              remaining @?= 0
              assertBool "query protocol reported an empty minimum"
                $ required > 0
            unexpected -> assertFailure $ "wrong query-capacity failure: " ++
              show unexpected
          SMTLibSession.lengthSMTLibQueryRunProcessCleanupStatus failure @?=
            Nothing
        Right _ -> assertFailure "exhausted process stdout cap admitted a query"
      events <- SMTLibLiveSpec.readFakeZ3Events executable
      assertFakeZ3EventCount "query-check" 0 events
  _ <- expectRight scoped
  pure ()

assertLiveStatusQueryRun
  :: Observation.SolverStatus
  -> SMTLibSession.LengthSMTLibQueryRun epoch identity local
  -> IO ()
assertLiveStatusQueryRun expectedStatus run = do
  case (expectedStatus, SMTLibSession.lengthSMTLibQueryRunObservation run) of
    ( Observation.SolverSatisfiable
      , Observation.SatisfiableObservation Nothing
      ) -> pure ()
    ( Observation.SolverUnsatisfiable
      , Observation.UnsatisfiableObservation ()
      ) -> pure ()
    ( Observation.SolverUnknown
      , Observation.UnknownObservation ()
      ) -> pure ()
    _ -> assertFailure
      "status-only run lost its status-indexed evidence absence"
  assertLiveQueryRunIdentityBranch
    expectedStatus "absent" replayTag run
  assertLiveQueryRunAccounting run
 where
  replayTag = case expectedStatus of
    Observation.SolverSatisfiable -> "not-requested-policy"
    Observation.SolverUnsatisfiable -> "not-applicable-status"
    Observation.SolverUnknown -> "not-applicable-status"

assertLiveValueQueryRun
  :: SMTLib.LengthSMTLibQuery identity local
  -> [Natural]
  -> SMTLibSession.LengthSMTLibQueryRun epoch identity local
  -> IO ()
assertLiveValueQueryRun query expectedInputs run = do
  evidence <- case SMTLibSession.lengthSMTLibQueryRunObservation run of
    Observation.SatisfiableObservation (Just value) -> pure value
    _ -> assertFailure
      "satisfiable values run lost its status-indexed replay evidence"
  receipt <- expectRight $ Djex.replayBehavioralEvidence
    (SMTLib.lengthSMTLibQueryBehavioralProblem query) evidence
  Evaluate.validatedLengthCounterexampleInputs receipt @?= expectedInputs
  Evaluate.validatedLengthCounterexampleResult receipt @?= 0
  assertLiveQueryRunIdentityBranch
    Observation.SolverSatisfiable
    (if null expectedInputs
      then "vacuous-zero-input"
      else "framed-input-values")
    "validated-counterexample"
    run
  assertLiveQueryRunAccounting run

assertLiveSpinePairValueQueryRun
  :: SMTLib.LengthSpinePairSMTLibQuery identity local
  -> [Natural]
  -> Length.LengthSpinePair Natural
  -> SMTLibSession.LengthSpinePairSMTLibQueryRun epoch identity local
  -> IO ()
assertLiveSpinePairValueQueryRun query expectedInputs expectedResult run = do
  evidence <- case
      SMTLibSession.lengthSpinePairSMTLibQueryRunObservation run of
    Observation.SatisfiableObservation (Just value) -> pure value
    _ -> assertFailure
      "satisfiable pair values run lost its status-indexed replay evidence"
        >> error "unreachable"
  receipt <- expectRight $ Djex.replayBehavioralEvidence
    (SMTLib.lengthSpinePairSMTLibQueryBehavioralProblem query) evidence
  Evaluate.validatedLengthSpinePairCounterexampleInputs receipt @?=
    expectedInputs
  Evaluate.validatedLengthSpinePairCounterexampleResult receipt @?=
    expectedResult
  let identityBytes = InternalFingerprint.fingerprintCanonicalBytes
        $ SMTLibSession.lengthSpinePairSMTLibQueryRunIdentityFingerprint run
      replayTag = asciiBytes
        "finite-binary-product-spine-lengths/counterexample-replay/v1"
  let presentSchemas = filter (`isInfixOf` identityBytes)
        [ SMTLibSession.lengthSpinePairSMTLibQueryRunSchemaTag
        , SMTLibSession.lengthSpinePairSMTLibBudgetedQueryRunSchemaTag
        , SMTLibSession.lengthSpinePairSMTLibScopedBudgetedQueryRunSchemaTag
        , asciiBytes $ concat
            [ "djex-length-spine-pair-z3-capability-probed-sealed-main-image-"
            , "worker-query-run/v1"
            ]
        , asciiBytes $ concat
            [ "djex-length-spine-pair-z3-capability-probed-sealed-main-image-"
            , "worker-query-run/shared-usable-work-deadline/v1"
            ]
        , asciiBytes $ concat
            [ "djex-length-spine-pair-z3-capability-probed-sealed-main-image-"
            , "worker-query-run/scoped-shared-usable-work-deadline/v1"
            ]
        , asciiBytes $ concat
            [ "djex-length-spine-pair-z3-capability-probed-effective-id-"
            , "executable-access-sealed-main-image-worker-query-run/v1"
            ]
        , asciiBytes $ concat
            [ "djex-length-spine-pair-z3-capability-probed-effective-id-"
            , "executable-access-sealed-main-image-worker-query-run/"
            , "shared-usable-work-deadline/v1"
            ]
        , asciiBytes $ concat
            [ "djex-length-spine-pair-z3-capability-probed-effective-id-"
            , "executable-access-sealed-main-image-worker-query-run/"
            , "scoped-shared-usable-work-deadline/v1"
            ]
        , asciiBytes $ concat
            [ "djex-length-spine-pair-z3-capability-probed-execve-check-"
            , "executable-access-sealed-main-image-worker-query-run/v1"
            ]
        , asciiBytes $ concat
            [ "djex-length-spine-pair-z3-capability-probed-execve-check-"
            , "executable-access-sealed-main-image-worker-query-run/"
            , "shared-usable-work-deadline/v1"
            ]
        , asciiBytes $ concat
            [ "djex-length-spine-pair-z3-capability-probed-execve-check-"
            , "executable-access-sealed-main-image-worker-query-run/"
            , "scoped-shared-usable-work-deadline/v1"
            ]
        ]
  assertBool "the product run lacked one exact live-policy schema"
    $ length presentSchemas == 1
  countByteStringOccurrences (BS.pack replayTag) (BS.pack identityBytes) @?= 1
  assertLiveSpinePairQueryRunAccounting run

assertLiveQueryRunIdentityBranch
  :: Observation.SolverStatus
  -> String
  -> String
  -> SMTLibSession.LengthSMTLibQueryRun epoch identity local
  -> IO ()
assertLiveQueryRunIdentityBranch status valuesTag replayTag run = do
  assertIdentityFieldOccursOnce decodedField
  assertIdentityFieldOccursOnce replayField
 where
  identityBytes = BS.pack $ InternalFingerprint.fingerprintCanonicalBytes
    $ SMTLibSession.lengthSMTLibQueryRunIdentityFingerprint run
  defaults = Evaluate.defaultLengthEvaluationLimits
  decodedField = InternalFingerprint.FingerprintTag
    (asciiBytes "decoded-branch")
    [ InternalFingerprint.FingerprintBytes $ asciiBytes statusTag
    , InternalFingerprint.FingerprintBytes $ asciiBytes valuesTag
    ]
  replayField = InternalFingerprint.FingerprintTag
    (asciiBytes "independent-replay")
    [ InternalFingerprint.FingerprintBytes
        $ asciiBytes "finite-list-spine-length/counterexample-replay/v1"
    , InternalFingerprint.FingerprintNatural $ fromIntegral
        $ Evaluate.lengthAssignmentValueBitLimit defaults
    , InternalFingerprint.FingerprintNatural $ fromIntegral
        $ Evaluate.lengthIntermediateValueBitLimit defaults
    , InternalFingerprint.FingerprintBytes $ asciiBytes replayTag
    ]
  statusTag = case status of
    Observation.SolverSatisfiable -> "satisfiable"
    Observation.SolverUnsatisfiable -> "unsatisfiable"
    Observation.SolverUnknown -> "unknown"
  assertIdentityFieldOccursOnce field =
    countByteStringOccurrences
        (BS.pack $ encodeFingerprintFieldForIdentityTest field)
        identityBytes @?= 1

-- Mirror the stable v1 field envelope only in this identity-schema
-- regression.  The production encoder remains the sole fingerprint
-- constructor; this independent spelling proves that the two outcome fields
-- remain byte-for-byte present inside each completed run key.
encodeFingerprintFieldForIdentityTest
  :: InternalFingerprint.FingerprintField
  -> [Word8]
encodeFingerprintFieldForIdentityTest field = case field of
  InternalFingerprint.FingerprintNatural value ->
    sized 0x01 $ encodeNatural value
  InternalFingerprint.FingerprintBytes bytes -> sized 0x02 bytes
  InternalFingerprint.FingerprintSequence fields ->
    sized 0x03 $ concatMap encodeFingerprintFieldForIdentityTest fields
  InternalFingerprint.FingerprintTag tag fields -> sized 0x04 $
    encodeFingerprintFieldForIdentityTest
      (InternalFingerprint.FingerprintBytes tag) ++
    encodeFingerprintFieldForIdentityTest
      (InternalFingerprint.FingerprintSequence fields)
  InternalFingerprint.FingerprintName _ ->
    error "query-run branch fields never contain structural names"
 where
  sized :: Word8 -> [Word8] -> [Word8]
  sized tag payload =
    tag : encodeLength (fromIntegral $ length payload) ++ payload
  encodeNatural :: Natural -> [Word8]
  encodeNatural 0 = [0]
  encodeNatural value = reverse $ go value
   where
    go :: Natural -> [Word8]
    go 0 = []
    go remaining =
      let (quotient, remainder) = remaining `quotRem` 256
      in fromIntegral remainder : go quotient
  encodeLength :: Natural -> [Word8]
  encodeLength remaining =
    let (quotient, remainder) = remaining `quotRem` 128
        byte = fromIntegral remainder
    in if quotient == 0
        then [byte]
        else (byte + 0x80) : encodeLength quotient

countByteStringOccurrences :: BS.ByteString -> BS.ByteString -> Int
countByteStringOccurrences needle haystack
  | BS.null needle = 0
  | BS.null suffix = 0
  | otherwise = 1 + countByteStringOccurrences needle (BS.tail suffix)
 where
  (_, suffix) = BS.breakSubstring needle haystack

assertLiveQueryRunAccounting
  :: SMTLibSession.LengthSMTLibQueryRun epoch identity local
  -> IO ()
assertLiveQueryRunAccounting run = do
  let stdoutStart = SMTLibSession.lengthSMTLibQueryRunStdoutStart run
      stdoutEnd = SMTLibSession.lengthSMTLibQueryRunStdoutEnd run
      stderrStart = SMTLibSession.lengthSMTLibQueryRunStderrStart run
      stderrEnd = SMTLibSession.lengthSMTLibQueryRunStderrEnd run
      transcriptBytes =
        SMTLibSession.lengthSMTLibQueryRunTranscriptByteCount run
  assertBool "live query observed a decreasing stdout boundary"
    $ stdoutEnd >= stdoutStart
  transcriptBytes @?= stdoutEnd - stdoutStart
  assertBool "live query produced an empty transcript" $ transcriptBytes > 0
  stderrEnd @?= stderrStart
  BS.length (SMTLibSession.lengthSMTLibQueryRunTranscriptSHA256 run) @?= 32

assertLiveSpinePairQueryRunAccounting
  :: SMTLibSession.LengthSpinePairSMTLibQueryRun epoch identity local
  -> IO ()
assertLiveSpinePairQueryRunAccounting run = do
  let stdoutStart =
        SMTLibSession.lengthSpinePairSMTLibQueryRunStdoutStart run
      stdoutEnd = SMTLibSession.lengthSpinePairSMTLibQueryRunStdoutEnd run
      stderrStart =
        SMTLibSession.lengthSpinePairSMTLibQueryRunStderrStart run
      stderrEnd = SMTLibSession.lengthSpinePairSMTLibQueryRunStderrEnd run
      transcriptBytes =
        SMTLibSession.lengthSpinePairSMTLibQueryRunTranscriptByteCount run
  assertBool "live pair query observed a decreasing stdout boundary"
    $ stdoutEnd >= stdoutStart
  transcriptBytes @?= stdoutEnd - stdoutStart
  assertBool "live pair query produced an empty transcript"
    $ transcriptBytes > 0
  stderrEnd @?= stderrStart
  BS.length
      (SMTLibSession.lengthSpinePairSMTLibQueryRunTranscriptSHA256 run) @?= 32

assertLiveQueryFailure
  :: SMTLibSession.LengthSMTLibQueryRunFailure
  -> Bool
  -> Either SMTLibSession.LengthSMTLibQueryRunError value
  -> IO ()
assertLiveQueryFailure expectedFailure expectedCleanup result = case result of
  Left failure -> do
    SMTLibSession.lengthSMTLibQueryRunPrimaryFailure failure @?=
      expectedFailure
    case ( expectedCleanup
         , SMTLibSession.lengthSMTLibQueryRunProcessCleanupStatus failure) of
      (False, Nothing) -> pure ()
      (True, Just _) -> pure ()
      _ -> assertFailure "query failure carried the wrong cleanup ownership"
  Right _ -> assertFailure $ "expected live query failure: " ++
    show expectedFailure

assertFakeZ3EventOrdinals
  :: String
  -> [Natural]
  -> [SMTLibLiveSpec.FakeZ3Event]
  -> IO ()
assertFakeZ3EventOrdinals tag expected events =
  map (SMTLibLiveSpec.fakeZ3FieldValues $ liveTestBytes "ordinal")
      (fakeZ3Events tag events) @?=
    map (\ordinal -> [liveTestBytes $ show ordinal]) expected

assertFakeZ3EventCount
  :: String
  -> Int
  -> [SMTLibLiveSpec.FakeZ3Event]
  -> IO ()
assertFakeZ3EventCount tag expected events =
  length (fakeZ3Events tag events) @?= expected

fakeZ3Events
  :: String
  -> [SMTLibLiveSpec.FakeZ3Event]
  -> [SMTLibLiveSpec.FakeZ3Event]
fakeZ3Events tag = filter
  ((== liveTestBytes tag) . SMTLibLiveSpec.fakeZ3EventTag)

liveTestBytes :: String -> BS.ByteString
liveTestBytes = BS.pack . asciiBytes

sessionTests :: TestTree
sessionTests = testGroup "checked length sessions"
  [ testCase "bind context and provider laws to one exact inventory" $ do
      providerName <- expectName "Fixture.sessionProvider"
      let provider = sessionUnaryProvider providerName "element"
          inventory = sessionInventory ()
            [sessionProviderDeclaration () provider]
      session <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits inventory Length.BuiltinListSpine [provider]
      Length.lengthContextInventory
          (LengthProblem.checkedLengthSessionContext session) @?= inventory
      assertBool "checked provider disappeared from the atomic session" $
        case Length.lookupCheckedLengthProviderSummary providerName
            $ LengthProblem.checkedLengthSessionProviderInventory session of
          Nothing -> False
          Just _ -> True
  , testCase
      "version only the mixed opaque-target interpreter policy" $ do
      let inventory = sessionInventory () []
          observed = [Length.LengthObservedSpine]
          mixed =
            [ Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
      legacy <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits inventory Length.BuiltinListSpine []
      explicitObserved <- expectRight
        $ LengthProblem.sealRoleAwareLengthSession
            Length.defaultLengthLimits observed inventory
            Length.BuiltinListSpine []
      mixedSession <- expectRight
        $ LengthProblem.sealRoleAwareLengthSession
            Length.defaultLengthLimits mixed inventory
            Length.BuiltinListSpine []
      exactCaseSession <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthSession
            Length.defaultLengthLimits observed inventory
            Length.BuiltinListSpine []
      LengthProblem.lengthSessionInventoryFingerprint explicitObserved @?=
        LengthProblem.lengthSessionInventoryFingerprint legacy
      LengthProblem.lengthSessionEncodingPolicyFingerprint explicitObserved @?=
        LengthProblem.lengthSessionEncodingPolicyFingerprint legacy
      Fingerprint.fingerprintCanonicalBytes
          (LengthProblem.lengthSessionEncodingPolicyFingerprint
            explicitObserved) @?=
        Fingerprint.fingerprintCanonicalBytes
          (LengthProblem.lengthSessionEncodingPolicyFingerprint legacy)
      assertBool "mixed target semantics reused the legacy policy identity" $
        LengthProblem.lengthSessionEncodingPolicyFingerprint mixedSession /=
          LengthProblem.lengthSessionEncodingPolicyFingerprint legacy
      LengthProblem.lengthSessionInventoryFingerprint exactCaseSession @?=
        LengthProblem.lengthSessionInventoryFingerprint legacy
      assertBool "exact case semantics reused an ordinary policy identity" $
        LengthProblem.lengthSessionEncodingPolicyFingerprint exactCaseSession /=
          LengthProblem.lengthSessionEncodingPolicyFingerprint legacy
  , testCase
      "separate conditional provider authority from the encoding policy" $ do
      className <- expectName "Fixture.SessionConditionalConstraint"
      legacyProviderName <- expectName "Fixture.sessionLegacyProvider"
      conditionalProviderName <- expectName
        "Fixture.sessionConditionalProvider"
      let binder = FlexibleVariable "session-conditional-element"
          classBinder = FlexibleVariable "session-conditional-class-element"
          body = FunctionType
            (sessionListOf $ TypeVariable binder)
            (sessionListOf $ TypeVariable binder)
          legacyScheme = ForallType [binder] [] body
          conditionalScheme = ForallType [binder]
            [Constraint className [TypeVariable binder]] body
          roles = [Length.LengthSpineArgument]
          transfer = Length.LengthVariable $ Length.LengthProviderArgument 0
          legacy = Length.AssumedProviderSummary
            { Length.lengthProviderName = legacyProviderName
            , Length.lengthProviderScheme = legacyScheme
            , Length.lengthProviderArgumentRoles = roles
            , Length.lengthProviderTransfer = transfer
            }
          conditional = Length.AssumedConstraintConditionalProviderSummary
            { Length.lengthProviderName = conditionalProviderName
            , Length.lengthProviderScheme = conditionalScheme
            , Length.lengthProviderArgumentRoles = roles
            , Length.lengthProviderTransfer = transfer
            }
          classDeclaration = ClassDeclaration () className
            [TypeParameter classBinder (Just ProperTypeKind)] [] []
          inventory = sessionInventory ()
            [ classDeclaration
            , ValueDeclaration
                $ ValueSignature () legacyProviderName legacyScheme
            , ValueDeclaration
                $ ValueSignature () conditionalProviderName conditionalScheme
            ]
      legacySession <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits inventory
        Length.BuiltinListSpine [legacy]
      conditionalSession <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits inventory
        Length.BuiltinListSpine [conditional]
      mixedSession <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits inventory
        Length.BuiltinListSpine [legacy, conditional]
      legacyMixedRoleSession <- expectRight
        $ LengthProblem.sealRoleAwareLengthSession
            Length.defaultLengthLimits
            [ Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
            inventory Length.BuiltinListSpine [legacy]
      conditionalMixedRoleSession <- expectRight
        $ LengthProblem.sealRoleAwareLengthSession
            Length.defaultLengthLimits
            [ Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
            inventory Length.BuiltinListSpine [legacy, conditional]
      legacyExactCaseSession <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthSession
            Length.defaultLengthLimits [Length.LengthObservedSpine]
            inventory Length.BuiltinListSpine [legacy]
      conditionalExactCaseSession <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthSession
            Length.defaultLengthLimits [Length.LengthObservedSpine]
            inventory Length.BuiltinListSpine [legacy, conditional]
      let providerFingerprint = Length.lengthProviderInventoryFingerprint
            . LengthProblem.checkedLengthSessionProviderInventory
          canonical = Fingerprint.fingerprintCanonicalBytes
          providerBytes = canonical . providerFingerprint
          inventoryBytes = canonical
            . LengthProblem.lengthSessionInventoryFingerprint
          policyBytes = canonical
            . LengthProblem.lengthSessionEncodingPolicyFingerprint
          conditionalTrustTag = asciiBytes
            "conditional-on-independent-ground-constraint-discharge/v1"
          retentionPolicyTag = asciiBytes
            "retain-constraint-conditional-provider-laws/v1"
          resolverPolicyTag = asciiBytes
            "exact-inventory-owned-class-resolution/v1"
          receiptPolicyTag = asciiBytes
            "final-certificate-receipt-node-authority/v1"
          uniformEvidenceTag = asciiBytes
            "provider-law-uniform-over-dictionary-evidence/v1"
          resolverLimitTags = map asciiBytes
            [ "class-resolution-limits"
            , "declarations"
            , "classes"
            , "instances"
            , "type-constructor-kinds"
            , "collection-width"
            , "type-nodes"
            , "kind-nodes"
            , "overlap-comparisons"
            , "proof-depth"
            , "proof-nodes"
            ]
      take 10 (providerBytes legacySession) @?= fingerprintVersionPrefix 2
      take 10 (providerBytes conditionalSession) @?= fingerprintVersionPrefix 3
      take 10 (providerBytes mixedSession) @?= fingerprintVersionPrefix 3
      take 10 (inventoryBytes legacySession) @?= fingerprintVersionPrefix 1
      take 10 (inventoryBytes conditionalSession) @?= fingerprintVersionPrefix 2
      take 10 (inventoryBytes mixedSession) @?= fingerprintVersionPrefix 2
      assertBool "conditional trust was omitted from provider identity" $
        conditionalTrustTag `isInfixOf` providerBytes conditionalSession
      assertBool "mixed provider identity omitted conditional trust" $
        conditionalTrustTag `isInfixOf` providerBytes mixedSession
      assertBool "legacy provider identity gained conditional trust" $
        not $ conditionalTrustTag `isInfixOf` providerBytes legacySession
      assertBool "conditional semantic inventory omitted retention policy" $
        retentionPolicyTag `isInfixOf` inventoryBytes conditionalSession
      assertBool "mixed semantic inventory omitted retention policy" $
        retentionPolicyTag `isInfixOf` inventoryBytes mixedSession
      assertBool "legacy semantic inventory gained retention policy" $
        not $ retentionPolicyTag `isInfixOf` inventoryBytes legacySession
      take 10 (policyBytes legacySession) @?= fingerprintVersionPrefix 5
      take 10 (policyBytes legacyMixedRoleSession) @?= fingerprintVersionPrefix 6
      take 10 (policyBytes legacyExactCaseSession) @?= fingerprintVersionPrefix 7
      take 10 (policyBytes conditionalSession) @?= fingerprintVersionPrefix 8
      take 10 (policyBytes conditionalMixedRoleSession) @?=
        fingerprintVersionPrefix 9
      take 10 (policyBytes conditionalExactCaseSession) @?=
        fingerprintVersionPrefix 10
      assertBool "conditional resolver authority reused legacy policy identity" $
        LengthProblem.lengthSessionEncodingPolicyFingerprint
            conditionalSession /=
          LengthProblem.lengthSessionEncodingPolicyFingerprint legacySession
      assertBool "mixed conditional authority reused legacy policy identity" $
        LengthProblem.lengthSessionEncodingPolicyFingerprint
            conditionalMixedRoleSession /=
          LengthProblem.lengthSessionEncodingPolicyFingerprint
            legacyMixedRoleSession
      assertBool "exact conditional authority reused legacy policy identity" $
        LengthProblem.lengthSessionEncodingPolicyFingerprint
            conditionalExactCaseSession /=
          LengthProblem.lengthSessionEncodingPolicyFingerprint
            legacyExactCaseSession
      assertBool "conditional policy omitted its exact resolver" $
        resolverPolicyTag `isInfixOf` policyBytes conditionalSession
      assertBool "conditional policy omitted final receipt-node authority" $
        receiptPolicyTag `isInfixOf` policyBytes conditionalSession
      assertBool "conditional policy omitted evidence uniformity" $
        uniformEvidenceTag `isInfixOf` policyBytes conditionalSession
      assertBool "legacy policy gained conditional resolver authority" $
        not $ resolverPolicyTag `isInfixOf` policyBytes legacySession
      assertBool "legacy policy gained evidence uniformity" $
        not $ uniformEvidenceTag `isInfixOf` policyBytes legacySession
      mapM_ (\tag -> assertBool
          "conditional policy omitted one resolver-limit field" $
          tag `isInfixOf` policyBytes conditionalSession)
        resolverLimitTags
      mapM_ (\tag -> assertBool
          "legacy policy gained a resolver-limit field" $
          not $ tag `isInfixOf` policyBytes legacySession)
        resolverLimitTags
      ( canonicalFingerprintSHA256 $ providerFingerprint legacySession
        , canonicalFingerprintSHA256
            $ LengthProblem.lengthSessionInventoryFingerprint legacySession
        ) @?=
        ( "7c2ccf1a7cbd05cf2ce3fb7f66626495c199491fafc35651582b17243aaf0119"
        , "a73933cfe915ff842b928532aa3b6d10f1e78d6d8a1b9da327a54abf1439b9b1"
        )
  , testCase "bound target roles after existing session authority" $ do
      let inventory = sessionInventory () []
          limits = limitsWith $ \source -> source
            { Length.lengthLimitSourceContractInputs = 1 }
      assertLeft
        (LengthProblem.LengthSessionTargetArgumentRoleLimitExceeded 1 2)
        $ LengthProblem.sealRoleAwareLengthSession limits
            [Length.LengthObservedSpine, Length.LengthUnobservedTarget]
            inventory Length.BuiltinListSpine []
      assertLeft
        (LengthProblem.LengthSessionTargetArgumentRoleLimitExceeded 1 2)
        $ LengthProblem.sealExactSpineCaseLengthSession limits
            [Length.LengthObservedSpine, Length.LengthUnobservedTarget]
            inventory Length.BuiltinListSpine []
  , testCase
      "reject spine and provider authority before demanding target roles" $ do
      typeName <- expectName "Fixture.MissingRoleSpine"
      zeroName <- expectName "Fixture.missingRoleZero"
      stepName <- expectName "Fixture.missingRoleStep"
      providerName <- expectName "Fixture.missingRoleProvider"
      let poisonRoles = error "session authority demanded target roles"
          inventory = sessionInventory () []
          provider = sessionUnaryProvider providerName "role-provider"
      spineResult <- evaluateWithin
        $ LengthProblem.sealRoleAwareLengthSession
            Length.defaultLengthLimits poisonRoles inventory
            (Length.DeclaredListSpine typeName zeroName stepName) []
      assertLeft
        (LengthProblem.LengthSessionSpineModelRejected
          $ Length.LengthSpineTypeDeclarationMissing typeName)
        spineResult
      exactSpineResult <- evaluateWithin
        $ LengthProblem.sealExactSpineCaseLengthSession
            Length.defaultLengthLimits poisonRoles inventory
            (Length.DeclaredListSpine typeName zeroName stepName) []
      assertLeft
        (LengthProblem.LengthSessionSpineModelRejected
          $ Length.LengthSpineTypeDeclarationMissing typeName)
        exactSpineResult
      providerResult <- evaluateWithin
        $ LengthProblem.sealRoleAwareLengthSession
            Length.defaultLengthLimits poisonRoles inventory
            Length.BuiltinListSpine [provider]
      assertLeft
        (LengthProblem.LengthSessionProviderInventoryRejected
          $ Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderNotInSourceInventory providerName)
        providerResult
      exactProviderResult <- evaluateWithin
        $ LengthProblem.sealExactSpineCaseLengthSession
            Length.defaultLengthLimits poisonRoles inventory
            Length.BuiltinListSpine [provider]
      assertLeft
        (LengthProblem.LengthSessionProviderInventoryRejected
          $ Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderNotInSourceInventory providerName)
        exactProviderResult
  , testCase "reject oversized target roles before identity construction" $ do
      let inventory = sessionInventory () []
      context <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits inventory Length.BuiltinListSpine
      providers <- expectRight $ Length.sealLengthProviderInventoryInContext
        Length.defaultLengthLimits context []
      let providerBytes = length $ Fingerprint.fingerprintCanonicalBytes
            $ Length.lengthProviderInventoryFingerprint providers
          limits = limitsWith $ \source -> source
            { Length.lengthLimitSourceContractInputs = 1
            , Length.lengthLimitSourceFingerprintBytes = providerBytes
            }
      assertLeft
        (LengthProblem.LengthSessionTargetArgumentRoleLimitExceeded 1 2)
        $ LengthProblem.sealRoleAwareLengthSession limits
            [Length.LengthObservedSpine, Length.LengthUnobservedTarget]
            inventory Length.BuiltinListSpine []
  , testCase "erase annotations but retain every neutral declaration" $ do
      providerName <- expectName "Fixture.annotationProvider"
      unusedName <- expectName "Fixture.unusedSessionValue"
      let provider = sessionUnaryProvider providerName "element"
          providerDeclaration annotation =
            sessionProviderDeclaration annotation provider
          base annotation = sessionInventory annotation
            [providerDeclaration annotation]
          widened = sessionInventory (3 :: Int)
            [ providerDeclaration 3
            , ValueDeclaration $ ValueSignature 3 unusedName sessionPayloadType
            ]
      first <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits (base (1 :: Int))
        Length.BuiltinListSpine [provider]
      annotated <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits (base (2 :: Int))
        Length.BuiltinListSpine [provider]
      withUnused <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits widened Length.BuiltinListSpine [provider]
      LengthProblem.lengthSessionInventoryFingerprint first @?=
        LengthProblem.lengthSessionInventoryFingerprint annotated
      assertBool "an unused neutral declaration was absent from exact identity" $
        LengthProblem.lengthSessionInventoryFingerprint first /=
          LengthProblem.lengthSessionInventoryFingerprint withUnused
      LengthProblem.lengthSessionEncodingPolicyFingerprint first @?=
        LengthProblem.lengthSessionEncodingPolicyFingerprint withUnused
  , testCase "canonicalize declaration and provider type binders together" $ do
      providerName <- expectName "Fixture.alphaSessionProvider"
      let firstProvider = sessionUnaryProvider providerName "first"
          secondProvider = sessionUnaryProvider providerName "renamed"
          firstInventory = sessionInventory ()
            [sessionProviderDeclaration () firstProvider]
          secondInventory = sessionInventory ()
            [sessionProviderDeclaration () secondProvider]
      first <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits firstInventory
        Length.BuiltinListSpine [firstProvider]
      second <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits secondInventory
        Length.BuiltinListSpine [secondProvider]
      LengthProblem.lengthSessionInventoryFingerprint first @?=
        LengthProblem.lengthSessionInventoryFingerprint second
      LengthProblem.lengthSessionEncodingPolicyFingerprint first @?=
        LengthProblem.lengthSessionEncodingPolicyFingerprint second
  , testCase "ignore instance binder spelling and declaration order" $ do
      className <- expectName "Fixture.SessionRelation"
      let classParameter identity = TypeParameter
            (FlexibleVariable identity) (Just ProperTypeKind)
          classDeclaration = ClassDeclaration () className
            [classParameter "class-left", classParameter "class-right"] [] []
          firstLeft = FlexibleVariable "first-left"
          firstRight = FlexibleVariable "first-right"
          renamedLeft = FlexibleVariable "renamed-left"
          renamedRight = FlexibleVariable "renamed-right"
          instanceDeclaration binders left right = InstanceDeclaration
            () binders [] $ Constraint className
              [TypeVariable left, TypeVariable right]
          firstInventory = sessionInventory ()
            [ classDeclaration
            , instanceDeclaration
                [firstLeft, firstRight] firstLeft firstRight
            ]
          reorderedInventory = sessionInventory ()
            [ classDeclaration
            , instanceDeclaration
                [renamedRight, renamedLeft] renamedLeft renamedRight
            ]
      first <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits firstInventory Length.BuiltinListSpine []
      reordered <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits reorderedInventory Length.BuiltinListSpine []
      LengthProblem.lengthSessionInventoryFingerprint first @?=
        LengthProblem.lengthSessionInventoryFingerprint reordered
  , testCase "reject a provider projection not owned by the source inventory" $ do
      providerName <- expectName "Fixture.foreignSessionProvider"
      let provider = sessionUnaryProvider providerName "element"
          inventory = sessionInventory () []
      case LengthProblem.sealLengthSession Length.defaultLengthLimits
          inventory Length.BuiltinListSpine [provider] of
        Left (LengthProblem.LengthSessionProviderInventoryRejected
            (Length.LengthProviderSummaryRejected 0 rejectedName
              (Length.LengthProviderNotInSourceInventory missingName))) -> do
          rejectedName @?= providerName
          missingName @?= providerName
        Left other -> assertFailure $ "unexpected rejection: " ++ show other
        Right _ -> assertFailure "a foreign provider was admitted"
  , testCase "surface the first bounded session identity failure" $ do
      let inventory = sessionInventory () []
      context <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits inventory Length.BuiltinListSpine
      providers <- expectRight $ Length.sealLengthProviderInventoryInContext
        Length.defaultLengthLimits context []
      let providerBytes = length $ Fingerprint.fingerprintCanonicalBytes
            $ Length.lengthProviderInventoryFingerprint providers
          limits = limitsWith $ \source -> source
            { Length.lengthLimitSourceFingerprintBytes = providerBytes }
      assertLeft
        (LengthProblem.LengthSessionFingerprintLimitExceeded
          LengthProblem.LengthSemanticInventoryFingerprint
          (fromIntegral providerBytes) (fromIntegral providerBytes + 1))
        $ LengthProblem.sealLengthSession limits inventory
            Length.BuiltinListSpine []
  , testCase "reserve modeled constructor names from provider laws" $ do
      typeName <- expectName "Fixture.SessionSpine"
      zeroName <- expectName "Fixture.SessionEmpty"
      stepName <- expectName "Fixture.SessionStep"
      let element = FlexibleVariable "element"
          spine = TypeApplication (TypeConstructor typeName)
            $ TypeVariable element
          declaration = DataTypeDeclaration () typeName
            [TypeParameter element Nothing]
            [ DataConstructor () zeroName []
            , DataConstructor () stepName [TypeVariable element, spine]
            ]
          inventory = sessionInventory () [declaration]
          zeroScheme = ForallType [element] [] spine
          conflicting = Length.AssumedProviderSummary
            { Length.lengthProviderName = zeroName
            , Length.lengthProviderScheme = zeroScheme
            , Length.lengthProviderArgumentRoles = []
            , Length.lengthProviderTransfer = Length.LengthLiteral 0
            }
      assertLeft
        (LengthProblem.LengthSessionProviderConflictsWithSpineConstructor
          zeroName)
        $ LengthProblem.sealLengthSession Length.defaultLengthLimits inventory
            (Length.DeclaredListSpine typeName zeroName stepName) [conflicting]
  ]

interpretationPolicyCharacterizationTests :: TestTree
interpretationPolicyCharacterizationTests = testGroup
  "Length interpretation policy characterization"
  [ testCase "freeze five configurations and their four policy identities" $ do
      let observed = Length.LengthObservedSpine
          unobserved = Length.LengthUnobservedTarget
          allObservedRoles = [observed, observed]
          mixedRoles = [unobserved, observed]
          target = adversarialBinaryConstantZeroTarget
      graph <- adversarialBinaryConstantZeroGraph
      let candidate = adversarialTypedCandidate $ Right graph

      legacySession <- adversarialLengthSession [] []
      legacyContract <- adversarialLengthContract
        legacySession target trivialLengthContract
      legacyProblem <- expectRight
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            legacySession legacyContract candidate

      explicitSession <- adversarialRoleAwareLengthSession
        allObservedRoles [] []
      explicitContract <- adversarialRoleAwareLengthContract
        explicitSession allObservedRoles target trivialLengthContract
      explicitProblem <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            explicitSession explicitContract candidate

      mixedSession <- adversarialRoleAwareLengthSession mixedRoles [] []
      mixedContract <- adversarialRoleAwareLengthContract
        mixedSession mixedRoles target trivialLengthContract
      mixedProblem <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            mixedSession mixedContract candidate

      exactObservedSession <- adversarialExactCaseLengthSession
        allObservedRoles [] []
      exactObservedContract <- adversarialRoleAwareLengthContract
        exactObservedSession allObservedRoles target trivialLengthContract
      exactObservedProblem <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactObservedSession exactObservedContract candidate

      exactMixedSession <- adversarialExactCaseLengthSession mixedRoles [] []
      exactMixedContract <- adversarialRoleAwareLengthContract
        exactMixedSession mixedRoles target trivialLengthContract
      exactMixedProblem <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactMixedSession exactMixedContract candidate

      let snapshot name session contract problem =
            ( name
            , canonicalFingerprintSHA256
                $ LengthProblem.lengthSessionEncodingPolicyFingerprint session
            , canonicalFingerprintSHA256
                $ Length.lengthContractFingerprint contract
            , canonicalFingerprintSHA256
                $ LengthProblem.checkedLengthProblemEncodingFingerprint problem
            , canonicalFingerprintSHA256
                $ Djex.behavioralProblemFingerprint
                $ LengthProblem.checkedLengthProblemBehavioralProblem problem
            )
          snapshots =
            [ snapshot "legacy"
                legacySession legacyContract legacyProblem
            , snapshot "explicit-all-observed"
                explicitSession explicitContract explicitProblem
            , snapshot "mixed-role-aware"
                mixedSession mixedContract mixedProblem
            , snapshot "exact-all-observed"
                exactObservedSession exactObservedContract exactObservedProblem
            , snapshot "exact-mixed"
                exactMixedSession exactMixedContract exactMixedProblem
            ]
          legacySessionHash =
            "351b683d063208ddfb6e071614b535ab58e7f4f7f7bc152c23cbf081ac8c55d6"
          legacyContractHash =
            "7793c68d7a203e6e24a80bd45fcf0b3d81f9363fcf1c207e0ef55f4eceabfdd8"
          legacyConcreteHash =
            "ce6497b14e3c3d7a2bd742bef3b5e62d59879bf8b4b9bf9bf27f72bf021b0b7a"
          legacyProblemHash =
            "6c1669c7465bed5d24f3b7da0d64011e0a175fe1364f7ed8f34b172bf02e97de"
          mixedSessionHash =
            "5592fd19e27f4da75832114c6a38d574e108a68b6e4601f2b6ab35dd034d0d9b"
          mixedContractHash =
            "32e0d2b30421486c6d6fe04b42acd9075010ef79b9224c6ab309e28ea924dd4e"
          mixedConcreteHash =
            "bd40910c9c7a38d24fd3746d97f244f4768fc5768665fc75ed779119218d5fad"
          mixedProblemHash =
            "90d82462d7a2285eaf2872c64b07a413e008bfb534e68f5b7b81a3f599681b97"
          exactObservedSessionHash =
            "a528c8e74deacb243af2e11dbca9a45974675f86cea44f6f195af4fa9ba4c02f"
          exactObservedConcreteHash =
            "2c8369e278eca6c92139f381bb4b68fbb0e84cf9676ba0297a6d7750ac692bee"
          exactObservedProblemHash =
            "0e98488ff5e0cdc5f62d993310e5fbadbe87b1a561247776edcf74097c4ee913"
          exactMixedSessionHash =
            "7c6b77fd2b92fd0b29eaa6e55beab7a6a0e43f8d2f1a7594b1b2c0812605c989"
          exactMixedConcreteHash =
            "c793301a76f7827523115f642f45749a33ed81954e1d485d03267ab53ea737a2"
          exactMixedProblemHash =
            "eb65ebc24dafbdb7cdf74695d2696f43d9cfccd37a5c4210dadc27825406f9bb"
          expectedSnapshots =
            [ ( "legacy"
              , legacySessionHash
              , legacyContractHash
              , legacyConcreteHash
              , legacyProblemHash
              )
            , ( "explicit-all-observed"
              , legacySessionHash
              , legacyContractHash
              , legacyConcreteHash
              , legacyProblemHash
              )
            , ( "mixed-role-aware"
              , mixedSessionHash
              , mixedContractHash
              , mixedConcreteHash
              , mixedProblemHash
              )
            , ( "exact-all-observed"
              , exactObservedSessionHash
              , legacyContractHash
              , exactObservedConcreteHash
              , exactObservedProblemHash
              )
            , ( "exact-mixed"
              , exactMixedSessionHash
              , mixedContractHash
              , exactMixedConcreteHash
              , exactMixedProblemHash
              )
            ]
      -- These digests only snapshot the collision-free canonical bytes. They
      -- are not production identity, semantic authority, or a hash-based
      -- replacement for the reversible fingerprints themselves.
      snapshots @?= expectedSnapshots

      LengthProblem.lengthSessionInventoryFingerprint explicitSession @?=
        LengthProblem.lengthSessionInventoryFingerprint legacySession
      LengthProblem.lengthSessionEncodingPolicyFingerprint explicitSession @?=
        LengthProblem.lengthSessionEncodingPolicyFingerprint legacySession
      Length.lengthContractFingerprint explicitContract @?=
        Length.lengthContractFingerprint legacyContract
      LengthProblem.checkedLengthCandidateFingerprint
          (LengthProblem.checkedLengthProblemCandidate explicitProblem) @?=
        LengthProblem.checkedLengthCandidateFingerprint
          (LengthProblem.checkedLengthProblemCandidate legacyProblem)
      LengthProblem.checkedLengthProblemEncodingFingerprint explicitProblem @?=
        LengthProblem.checkedLengthProblemEncodingFingerprint legacyProblem
      Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem explicitProblem)
        @?= Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem legacyProblem)
  , testCase
      "preserve wrapper policy failure precedence before graph demand" $ do
      let mixedRoles =
            [ Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
          poisonCandidate = adversarialTypedCandidate
            $ error "policy precedence demanded the candidate graph"
      typeName <- expectName "Fixture.PolicyPrecedenceSpine"
      zeroName <- expectName "Fixture.PolicyPrecedenceZero"
      stepName <- expectName "Fixture.PolicyPrecedenceStep"
      let element = FlexibleVariable "policy-precedence-element"
          spine = TypeApplication (TypeConstructor typeName)
            $ TypeVariable element
          declaration = DataTypeDeclaration () typeName
            [TypeParameter element Nothing]
            [ DataConstructor () zeroName []
            , DataConstructor () stepName [TypeVariable element, spine]
            ]
          foreignInventory = sessionInventory () [declaration]
          foreignTarget = FunctionType spine $ FunctionType spine spine
      foreignContext <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits foreignInventory
        $ Length.DeclaredListSpine typeName zeroName stepName
      mixedContract <- expectRight $ Length.sealRoleAwareLengthContractInContext
        Length.defaultLengthLimits foreignContext mixedRoles foreignTarget
        trivialLengthContract
      exactMixedSession <- adversarialExactCaseLengthSession mixedRoles [] []
      ordinarySession <- adversarialLengthSession [] []

      legacyResult <- evaluateWithin
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactMixedSession mixedContract poisonCandidate
      assertLeft
        LengthProblem.LengthProblemMixedTargetArgumentsRequireRoleAwareSealer
        legacyResult

      caseResult <- evaluateWithin
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            ordinarySession mixedContract poisonCandidate
      assertLeft LengthProblem.LengthProblemCasePolicyMismatch caseResult

      targetResult <- evaluateWithin
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            ordinarySession mixedContract poisonCandidate
      assertLeft
        LengthProblem.LengthProblemTargetArgumentPolicyMismatch targetResult

      matchingPolicySession <- adversarialRoleAwareLengthSession
        mixedRoles [] []
      contextResult <- evaluateWithin
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            matchingPolicySession mixedContract poisonCandidate
      assertLeft
        (LengthProblem.LengthProblemContractResealRejected
          $ Length.LengthContractTargetKindError
          $ UnknownTypeConstructor typeName)
        contextResult
  , testCase
      "accept role-vector order and arity drift when mixedness agrees" $ do
      let firstRoles =
            [ Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
          reversedRoles = reverse firstRoles
          target = adversarialBinaryConstantZeroTarget
      graph <- adversarialBinaryConstantZeroGraph
      let candidate = adversarialTypedCandidate $ Right graph

      ordinarySession <- adversarialRoleAwareLengthSession firstRoles [] []
      reversedSession <- adversarialRoleAwareLengthSession reversedRoles [] []
      ordinaryContract <- adversarialRoleAwareLengthContract
        ordinarySession reversedRoles target trivialLengthContract
      ordinaryProblem <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            ordinarySession ordinaryContract candidate

      exactSession <- adversarialExactCaseLengthSession firstRoles [] []
      exactReversedSession <- adversarialExactCaseLengthSession
        reversedRoles [] []
      exactContract <- adversarialRoleAwareLengthContract
        exactSession reversedRoles target trivialLengthContract
      exactProblem <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactSession exactContract candidate

      Length.checkedLengthContractTargetArgumentRoles ordinaryContract @?=
        reversedRoles
      Length.checkedLengthContractTargetArgumentRoles exactContract @?=
        reversedRoles
      LengthProblem.lengthSessionEncodingPolicyFingerprint ordinarySession @?=
        LengthProblem.lengthSessionEncodingPolicyFingerprint reversedSession
      LengthProblem.lengthSessionEncodingPolicyFingerprint exactSession @?=
        LengthProblem.lengthSessionEncodingPolicyFingerprint
          exactReversedSession
      firstContract <- adversarialRoleAwareLengthContract
        ordinarySession firstRoles target trivialLengthContract
      assertBool "distinct mixed role vectors shared a contract identity" $
        Length.lengthContractFingerprint firstContract /=
          Length.lengthContractFingerprint ordinaryContract
      LengthProblem.checkedLengthProblemInputCount ordinaryProblem @?= 1
      LengthProblem.checkedLengthProblemInputCount exactProblem @?= 1

      allObservedSession <- adversarialRoleAwareLengthSession [] [] []
      allObservedContract <- adversarialRoleAwareLengthContract
        allObservedSession
        [Length.LengthObservedSpine, Length.LengthObservedSpine]
        target trivialLengthContract
      _ <- expectRight $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits
        allObservedSession allObservedContract candidate

      exactAllObservedSession <- adversarialExactCaseLengthSession [] [] []
      exactAllObservedContract <- adversarialRoleAwareLengthContract
        exactAllObservedSession
        [Length.LengthObservedSpine, Length.LengthObservedSpine]
        target trivialLengthContract
      _ <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactAllObservedSession exactAllObservedContract candidate

      shortMixedSession <- adversarialRoleAwareLengthSession
        [Length.LengthUnobservedTarget] [] []
      longMixedContract <- adversarialRoleAwareLengthContract
        shortMixedSession
        [ Length.LengthObservedSpine
        , Length.LengthUnobservedTarget
        ]
        target trivialLengthContract
      _ <- expectRight $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits
        shortMixedSession longMixedContract candidate

      exactShortMixedSession <- adversarialExactCaseLengthSession
        [Length.LengthUnobservedTarget] [] []
      exactLongMixedContract <- adversarialRoleAwareLengthContract
        exactShortMixedSession
        [ Length.LengthObservedSpine
        , Length.LengthUnobservedTarget
        ]
        target trivialLengthContract
      _ <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactShortMixedSession exactLongMixedContract candidate
      pure ()
  ]

unifiedInterpretationPolicyTests :: TestTree
unifiedInterpretationPolicyTests = testGroup
  "unified checked Length interpretation policy"
  [ testCase "seal all five public policy configurations" $ do
      let observed = Length.LengthObservedSpine
          unobserved = Length.LengthUnobservedTarget
          sources =
            [ LengthProblem.LengthLegacyCasesRejected
            , LengthProblem.LengthExplicitTargetRolesCasesRejected
                [observed, observed]
            , LengthProblem.LengthExplicitTargetRolesCasesRejected
                [unobserved, observed]
            , LengthProblem.LengthExplicitTargetRolesExactZeroStepCases
                [observed, observed]
            , LengthProblem.LengthExplicitTargetRolesExactZeroStepCases
                [unobserved, observed]
            ]
          inventory = sessionInventory () []
      sessions <- mapM (expectRight . (\source ->
        LengthProblem.sealLengthSessionWithInterpretationPolicy
          Length.defaultLengthLimits source inventory
          Length.BuiltinListSpine [])) sources
      mapM_ (\session ->
        LengthProblem.checkedLengthSessionInterpretationPolicy session
          `seq` pure ()) sessions
  , testCase "match every compatibility wrapper output and fingerprint" $ do
      let observed = Length.LengthObservedSpine
          unobserved = Length.LengthUnobservedTarget
          allObserved = [observed, observed]
          mixed = [unobserved, observed]
          target = adversarialBinaryConstantZeroTarget
          inventory = sessionInventory () []
      graph <- adversarialBinaryConstantZeroGraph
      let candidate = adversarialTypedCandidate $ Right graph
          check source wrapperSession wrapperContract wrapperProblem = do
            unifiedSession <- expectRight
              $ LengthProblem.sealLengthSessionWithInterpretationPolicy
                  Length.defaultLengthLimits source inventory
                  Length.BuiltinListSpine []
            unifiedContract <- expectRight
              $ LengthProblem.sealLengthContractInSession
                  unifiedSession target trivialLengthContract
            unifiedProblem <- expectRight
              $ LengthProblem.sealLengthTypedCandidateProblemInSession
                  LengthProblem.defaultLengthProblemLimits
                  unifiedSession unifiedContract candidate
            LengthProblem.lengthSessionInventoryFingerprint unifiedSession @?=
              LengthProblem.lengthSessionInventoryFingerprint wrapperSession
            LengthProblem.lengthSessionEncodingPolicyFingerprint
                unifiedSession @?=
              LengthProblem.lengthSessionEncodingPolicyFingerprint
                wrapperSession
            Length.lengthContractFingerprint unifiedContract @?=
              Length.lengthContractFingerprint wrapperContract
            let unifiedCandidate =
                  LengthProblem.checkedLengthProblemCandidate unifiedProblem
                wrapperCandidate =
                  LengthProblem.checkedLengthProblemCandidate wrapperProblem
            LengthProblem.checkedLengthCandidateResult unifiedCandidate @?=
              LengthProblem.checkedLengthCandidateResult wrapperCandidate
            LengthProblem.checkedLengthCandidateUsedProviders
                unifiedCandidate @?=
              LengthProblem.checkedLengthCandidateUsedProviders
                wrapperCandidate
            LengthProblem.checkedLengthCandidateFingerprint unifiedCandidate @?=
              LengthProblem.checkedLengthCandidateFingerprint wrapperCandidate
            LengthProblem.checkedLengthProblemEncodingFingerprint
                unifiedProblem @?=
              LengthProblem.checkedLengthProblemEncodingFingerprint
                wrapperProblem
            Djex.behavioralProblemFingerprint
                (LengthProblem.checkedLengthProblemBehavioralProblem
                  unifiedProblem) @?=
              Djex.behavioralProblemFingerprint
                (LengthProblem.checkedLengthProblemBehavioralProblem
                  wrapperProblem)

      legacySession <- adversarialLengthSession [] []
      legacyContract <- adversarialLengthContract
        legacySession target trivialLengthContract
      legacyProblem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits
        legacySession legacyContract candidate
      check LengthProblem.LengthLegacyCasesRejected
        legacySession legacyContract legacyProblem

      explicitSession <- adversarialRoleAwareLengthSession allObserved [] []
      explicitContract <- adversarialRoleAwareLengthContract
        explicitSession allObserved target trivialLengthContract
      explicitProblem <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            explicitSession explicitContract candidate
      check (LengthProblem.LengthExplicitTargetRolesCasesRejected allObserved)
        explicitSession explicitContract explicitProblem

      mixedSession <- adversarialRoleAwareLengthSession mixed [] []
      mixedContract <- adversarialRoleAwareLengthContract
        mixedSession mixed target trivialLengthContract
      mixedProblem <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            mixedSession mixedContract candidate
      check (LengthProblem.LengthExplicitTargetRolesCasesRejected mixed)
        mixedSession mixedContract mixedProblem

      exactObservedSession <- adversarialExactCaseLengthSession allObserved [] []
      exactObservedContract <- adversarialRoleAwareLengthContract
        exactObservedSession allObserved target trivialLengthContract
      exactObservedProblem <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactObservedSession exactObservedContract candidate
      check
        (LengthProblem.LengthExplicitTargetRolesExactZeroStepCases allObserved)
        exactObservedSession exactObservedContract exactObservedProblem

      exactMixedSession <- adversarialExactCaseLengthSession mixed [] []
      exactMixedContract <- adversarialRoleAwareLengthContract
        exactMixedSession mixed target trivialLengthContract
      exactMixedProblem <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactMixedSession exactMixedContract candidate
      check (LengthProblem.LengthExplicitTargetRolesExactZeroStepCases mixed)
        exactMixedSession exactMixedContract exactMixedProblem
  , testCase "keep unified session failures and productive roles ordered" $ do
      typeName <- expectName "Fixture.MissingUnifiedPolicySpine"
      zeroName <- expectName "Fixture.MissingUnifiedPolicyZero"
      stepName <- expectName "Fixture.MissingUnifiedPolicyStep"
      let poisonSource =
            LengthProblem.LengthExplicitTargetRolesCasesRejected
              $ error "spine failure demanded unified policy roles"
          inventory = sessionInventory () []
      result <- evaluateWithin
        $ LengthProblem.sealLengthSessionWithInterpretationPolicy
            Length.defaultLengthLimits poisonSource inventory
            (Length.DeclaredListSpine typeName zeroName stepName) []
      assertLeft
        (LengthProblem.LengthSessionSpineModelRejected
          $ Length.LengthSpineTypeDeclarationMissing typeName)
        result

      let limit = limitsWith $ \source -> source
            { Length.lengthLimitSourceContractInputs = 1 }
          oversized = LengthProblem.LengthExplicitTargetRolesCasesRejected
            [ Length.LengthObservedSpine
            , error "role limit demanded the excess role"
            ]
      oversizedResult <- evaluateWithin
        $ LengthProblem.sealLengthSessionWithInterpretationPolicy
            limit oversized inventory Length.BuiltinListSpine []
      assertLeft
        (LengthProblem.LengthSessionTargetArgumentRoleLimitExceeded 1 2)
        oversizedResult

      let retained = LengthProblem.LengthExplicitTargetRolesCasesRejected
            [ Length.LengthUnobservedTarget
            , error "retained-later-role"
            ]
      lazySession <- expectRight
        $ LengthProblem.sealLengthSessionWithInterpretationPolicy
            Length.defaultLengthLimits retained inventory
            Length.BuiltinListSpine []
      forced <- try $ evaluate $ force lazySession
      case forced of
        Left failure -> assertBool "deep session force missed the retained role"
          $ "retained-later-role" `isInfixOf` displayException
              (failure :: SomeException)
        Right _ -> assertFailure "deep session force left a retained role lazy"
  , testCase "route contract checks through the retained policy" $ do
      let observed = Length.LengthObservedSpine
          roles = [observed, observed]
          inventory = sessionInventory () []
          poisonContract = Length.LengthContractSource
            (error "role arity failure demanded the precondition")
            (error "role arity failure demanded the postcondition")
      session <- expectRight
        $ LengthProblem.sealLengthSessionWithInterpretationPolicy
            Length.defaultLengthLimits
            (LengthProblem.LengthExplicitTargetRolesCasesRejected roles)
            inventory Length.BuiltinListSpine []
      arityResult <- evaluateWithin
        $ LengthProblem.sealLengthContractInSession session
            (FunctionType adversarialClosedList adversarialClosedList)
            poisonContract
      assertLeft
        (Length.LengthContractTargetArgumentRoleArityMismatch 1 2)
        arityResult

      let illKindedTarget = adversarialListOf $ TypeConstructor listName
      kindResult <- evaluateWithin
        $ LengthProblem.sealLengthContractInSession session
            illKindedTarget poisonContract
      case kindResult of
        Left Length.LengthContractTargetKindError{} -> pure ()
        Left other -> assertFailure
          $ "unexpected in-session contract rejection: " ++ show other
        Right _ -> assertFailure
          "in-session contract sealing admitted an ill-kinded target"
  , testCase "reject exact role drift before contract reseal and graph demand" $ do
      let observed = Length.LengthObservedSpine
          unobserved = Length.LengthUnobservedTarget
          expected = [unobserved, observed]
          poisonCandidate = adversarialTypedCandidate
            $ error "strict policy mismatch demanded the candidate graph"
          inventory = sessionInventory () []
      typeName <- expectName "Fixture.StrictPolicyForeignSpine"
      zeroName <- expectName "Fixture.StrictPolicyForeignZero"
      stepName <- expectName "Fixture.StrictPolicyForeignStep"
      let element = FlexibleVariable "strict-policy-element"
          spine = TypeApplication (TypeConstructor typeName)
            $ TypeVariable element
          declaration = DataTypeDeclaration () typeName
            [TypeParameter element Nothing]
            [ DataConstructor () zeroName []
            , DataConstructor () stepName [TypeVariable element, spine]
            ]
          foreignInventory = sessionInventory () [declaration]
          foreignTarget = FunctionType spine $ FunctionType spine spine
      foreignContext <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits foreignInventory
        $ Length.DeclaredListSpine typeName zeroName stepName
      let reject source actualRoles = do
            session <- expectRight
              $ LengthProblem.sealLengthSessionWithInterpretationPolicy
                  Length.defaultLengthLimits source inventory
                  Length.BuiltinListSpine []
            contract <- expectRight
              $ Length.sealRoleAwareLengthContractInContext
                  Length.defaultLengthLimits foreignContext actualRoles
                  foreignTarget trivialLengthContract
            result <- evaluateWithin
              $ LengthProblem.sealLengthTypedCandidateProblemInSession
                  LengthProblem.defaultLengthProblemLimits
                  session contract poisonCandidate
            assertLeft LengthProblem.LengthProblemTargetArgumentPolicyMismatch
              result
      reject (LengthProblem.LengthExplicitTargetRolesCasesRejected expected)
        (reverse expected)
      reject
        (LengthProblem.LengthExplicitTargetRolesExactZeroStepCases expected)
        (reverse expected)
      reject
        (LengthProblem.LengthExplicitTargetRolesCasesRejected [unobserved])
        [observed, unobserved]
      reject
        (LengthProblem.LengthExplicitTargetRolesExactZeroStepCases [unobserved])
        [observed, unobserved]

      matchingSession <- expectRight
        $ LengthProblem.sealLengthSessionWithInterpretationPolicy
            Length.defaultLengthLimits
            (LengthProblem.LengthExplicitTargetRolesCasesRejected expected)
            inventory Length.BuiltinListSpine []
      matchingContract <- expectRight
        $ Length.sealRoleAwareLengthContractInContext
            Length.defaultLengthLimits foreignContext expected foreignTarget
            trivialLengthContract
      matchingResult <- evaluateWithin
        $ LengthProblem.sealLengthTypedCandidateProblemInSession
            LengthProblem.defaultLengthProblemLimits
            matchingSession matchingContract poisonCandidate
      assertLeft
        (LengthProblem.LengthProblemContractResealRejected
          $ Length.LengthContractTargetKindError
          $ UnknownTypeConstructor typeName)
        matchingResult

      legacySession <- expectRight
        $ LengthProblem.sealLengthSessionWithInterpretationPolicy
            Length.defaultLengthLimits LengthProblem.LengthLegacyCasesRejected
            inventory Length.BuiltinListSpine []
      mixedContract <- expectRight
        $ Length.sealRoleAwareLengthContractInContext
            Length.defaultLengthLimits foreignContext expected foreignTarget
            trivialLengthContract
      legacyResult <- evaluateWithin
        $ LengthProblem.sealLengthTypedCandidateProblemInSession
            LengthProblem.defaultLengthProblemLimits
            legacySession mixedContract poisonCandidate
      assertLeft
        LengthProblem.LengthProblemMixedTargetArgumentsRequireRoleAwareSealer
        legacyResult
  , testCase "keep compatibility role drift beside strict association" $ do
      let observed = Length.LengthObservedSpine
          unobserved = Length.LengthUnobservedTarget
          retainedRoles = [unobserved, observed]
          detachedRoles = reverse retainedRoles
          target = adversarialBinaryConstantZeroTarget
      graph <- adversarialBinaryConstantZeroGraph
      let candidate = adversarialTypedCandidate $ Right graph

      ordinarySession <- adversarialRoleAwareLengthSession retainedRoles [] []
      ordinaryContract <- adversarialRoleAwareLengthContract
        ordinarySession detachedRoles target trivialLengthContract
      _ <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            ordinarySession ordinaryContract candidate
      assertLeft LengthProblem.LengthProblemTargetArgumentPolicyMismatch
        $ LengthProblem.sealLengthTypedCandidateProblemInSession
            LengthProblem.defaultLengthProblemLimits
            ordinarySession ordinaryContract candidate

      exactSession <- adversarialExactCaseLengthSession retainedRoles [] []
      exactContract <- adversarialRoleAwareLengthContract
        exactSession detachedRoles target trivialLengthContract
      _ <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactSession exactContract candidate
      assertLeft LengthProblem.LengthProblemTargetArgumentPolicyMismatch
        $ LengthProblem.sealLengthTypedCandidateProblemInSession
            LengthProblem.defaultLengthProblemLimits
            exactSession exactContract candidate
  ]

candidateProblemTests :: TestTree
candidateProblemTests = testGroup "typed candidate behavioral problems"
  [ testCase "interpret one real Exference list identity atomically" $ do
      (lengthSession, contract, candidate) <- realListIdentityFixture
        $ TypeVariable $ FlexibleVariable 0
      problem <- case LengthProblem.sealLengthTypedCandidateProblem
          LengthProblem.defaultLengthProblemLimits
          lengthSession contract candidate of
        Right value -> pure value
        Left failure -> do
          graph <- expectRight $ Djex.typedCandidateTermGraph candidate
          let root = Djex.termGraphRoot graph
              rootType = Djex.termNodeType <$> Djex.lookupTermNode root graph
          assertFailure $ "unexpected candidate rejection: " ++ show failure
            ++ "; contract target: "
            ++ show (Length.checkedLengthContractTarget contract)
            ++ "; graph root type: " ++ show rootType
      let checkedCandidate = LengthProblem.checkedLengthProblemCandidate problem
      LengthProblem.checkedLengthCandidateResult checkedCandidate @?=
        Length.LengthVariable (Length.LengthInput 0)
      LengthProblem.checkedLengthCandidateUsedProviders checkedCandidate @?= []
      LengthProblem.checkedLengthProblemCounterexampleCondition problem @?=
        Length.LengthTruth False
      Djex.behavioralProblemDomain
          (LengthProblem.checkedLengthProblemBehavioralProblem problem) @?=
        Length.finiteListSpineLengthDomainTag
      Djex.behavioralProblemCandidateFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem problem) @?=
        LengthProblem.checkedLengthCandidateFingerprint checkedCandidate
      Djex.behavioralProblemEncodingFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem problem) @?=
        LengthProblem.checkedLengthProblemEncodingFingerprint problem
  , testCase
      "admit only an explicitly sealed exact zero/step spine case" $ do
      (exactSession, exactContract, graph) <- adversarialExactSpineCaseFixture
        listName consName False
      let candidate = adversarialTypedCandidate $ Right graph
      problem <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactSession exactContract candidate
      let input = Length.LengthVariable $ Length.LengthInput 0
          expected = Length.LengthIf
            (Length.LengthEqual input $ Length.LengthLiteral 0)
            (Length.LengthLiteral 0)
            (Length.LengthMonus input $ Length.LengthLiteral 1)
          checked = LengthProblem.checkedLengthProblemCandidate problem
      LengthProblem.checkedLengthProblemInputCount problem @?= 1
      LengthProblem.checkedLengthCandidateResult checked @?= expected
      LengthProblem.checkedLengthCandidateUsedProviders checked @?= []
      evidence <- expectCounterexample
        $ Evaluate.validateLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits problem
            $ Evaluate.LengthProblemAssignment [3]
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence
      Evaluate.validatedLengthCounterexampleInputs receipt @?= [3]
      Evaluate.validatedLengthCounterexampleResult receipt @?= 2
  , testCase
      "reject every detached case-policy pairing before graph demand" $ do
      let roles = [Length.LengthObservedSpine]
          target = FunctionType adversarialClosedList adversarialClosedList
          poisonCandidate = adversarialTypedCandidate
            $ error "case-policy mismatch demanded the graph"
      ordinarySession <- adversarialRoleAwareLengthSession roles [] []
      ordinaryContract <- adversarialRoleAwareLengthContract
        ordinarySession roles target identityLengthContract
      exactSession <- adversarialExactCaseLengthSession roles [] []
      exactContract <- adversarialRoleAwareLengthContract
        exactSession roles target identityLengthContract
      ordinaryResult <- evaluateWithin
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            ordinarySession ordinaryContract poisonCandidate
      assertLeft LengthProblem.LengthProblemCasePolicyMismatch ordinaryResult
      exactResult <- evaluateWithin
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactSession exactContract poisonCandidate
      assertLeft LengthProblem.LengthProblemCasePolicyMismatch exactResult
      legacyResult <- evaluateWithin
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactSession exactContract poisonCandidate
      assertLeft LengthProblem.LengthProblemCasePolicyMismatch legacyResult
  , testCase
      "freshly bind constructor-pattern schemas to the exact session" $ do
      (session, contract, exactGraph) <- adversarialExactSpineCaseFixture
        listName consName False
      case Djex.fingerprintSharedTermGraph
          Djex.defaultTermGraphLimits
          Djex.defaultTermGraphFingerprintByteLimit exactGraph of
        Left (Djex.TermGraphFingerprintSharedResealError
            (Djex.UnknownConstructorPatternSchema occurrence name _)) -> do
          occurrence @?= Djex.occurrenceId 2
          name @?= listName
        Left other -> assertFailure $ "unexpected public rejection: "
          ++ show other
        Right _ -> assertFailure
          "the public shared fingerprint admitted constructor patterns"
      (_, _, foreignGraph) <- adversarialExactSpineCaseFixtureWithSchema
        listName consName False True
      case LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
          LengthProblem.defaultLengthProblemLimits session contract
          (adversarialTypedCandidate $ Right foreignGraph) of
        Left (LengthProblem.LengthProblemTermGraphFingerprintRejected
            (Djex.TermGraphFingerprintSharedResealError
              (Djex.ConstructorPatternFieldTypeMismatch
                occurrence index expected actual))) -> do
          occurrence @?= Djex.occurrenceId 4
          index @?= 0
          expected @?= TupleType Boxed []
          actual @?= adversarialClosedList
        Left other -> assertFailure $ "unexpected fresh-reseal rejection: "
          ++ show other
        Right _ -> assertFailure
          "a graph sealed under detached constructor schemas was admitted"
  , testCase
      "canonicalize case analysis while retaining structural branch order" $ do
      (session, contract, forwardGraph) <- adversarialExactSpineCaseFixture
        listName consName False
      (_, _, reversedGraph) <- adversarialExactSpineCaseFixture
        listName consName True
      forward <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right forwardGraph
      reversed <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right reversedGraph
      let first = LengthProblem.checkedLengthProblemCandidate forward
          second = LengthProblem.checkedLengthProblemCandidate reversed
      LengthProblem.checkedLengthCandidateResult first @?=
        LengthProblem.checkedLengthCandidateResult second
      LengthProblem.checkedLengthCandidateUsedProviders first @?=
        LengthProblem.checkedLengthCandidateUsedProviders second
      assertBool "source branch order disappeared from graph identity" $
        LengthProblem.checkedLengthCandidateFingerprint first /=
          LengthProblem.checkedLengthCandidateFingerprint second
      LengthProblem.checkedLengthProblemEncodingFingerprint forward @?=
        LengthProblem.checkedLengthProblemEncodingFingerprint reversed
  , testCase
      "reject inspection of the exact step payload" $ do
      (session, contract, graph, payloadOccurrence, caseNode) <-
        adversarialExactCasePayloadDemandFixture
      assertLeft
        (LengthProblem.LengthProblemStepPayloadDemanded payloadOccurrence
          $ LengthProblem.LengthStepPayloadSpineDemand caseNode)
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right graph
  , testCase
      "retain provider-law authority reached by both exact case branches" $ do
      (expectedProviders, session, contract, graph) <-
        adversarialExactCaseProviderUnionFixture
      problem <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right graph
      let checked = LengthProblem.checkedLengthProblemCandidate problem
      LengthProblem.checkedLengthCandidateResult checked @?=
        Length.LengthLiteral 7
      LengthProblem.checkedLengthCandidateUsedProviders checked @?=
        expectedProviders
      LengthProblem.checkedLengthProblemCounterexampleCondition problem @?=
        Length.LengthTruth False
  , testCase
      "preserve ordinary case rejection at the public graph identity" $ do
      let roles = [Length.LengthObservedSpine]
          target = FunctionType adversarialClosedList adversarialClosedList
      ordinarySession <- adversarialRoleAwareLengthSession roles [] []
      ordinaryContract <- adversarialRoleAwareLengthContract
        ordinarySession roles target identityLengthContract
      (_, _, graph) <- adversarialExactSpineCaseFixture
        listName consName False
      case LengthProblem.sealRoleAwareLengthTypedCandidateProblem
          LengthProblem.defaultLengthProblemLimits
          ordinarySession ordinaryContract
          (adversarialTypedCandidate $ Right graph) of
        Left (LengthProblem.LengthProblemTermGraphFingerprintRejected
            (Djex.TermGraphFingerprintSharedResealError
              (Djex.UnknownConstructorPatternSchema occurrence name _))) -> do
          occurrence @?= Djex.occurrenceId 2
          name @?= listName
        Left other -> assertFailure $ "unexpected ordinary rejection: "
          ++ show other
        Right _ -> assertFailure "an ordinary session admitted a case graph"
  , testCase
      "forward an opaque higher-order target into a checked map law" $ do
      (providerName, session, contract, candidate) <- roleAwareMapFixture
      assertLeft
        LengthProblem.LengthProblemMixedTargetArgumentsRequireRoleAwareSealer
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            session contract candidate
      problem <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            session contract candidate
      Length.checkedLengthContractTargetArgumentRoles contract @?=
        [ Length.LengthUnobservedTarget
        , Length.LengthObservedSpine
        ]
      LengthProblem.checkedLengthProblemInputCount problem @?= 1
      let checked = LengthProblem.checkedLengthProblemCandidate problem
      LengthProblem.checkedLengthCandidateResult checked @?=
        Length.LengthVariable (Length.LengthInput 0)
      LengthProblem.checkedLengthCandidateUsedProviders checked @?=
        [providerName]
      LengthProblem.checkedLengthProblemCounterexampleCondition problem @?=
        Length.LengthTruth False
      mapM_ (\input -> expectNoCounterexample
        $ Evaluate.validateLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits problem
            $ Evaluate.LengthProblemAssignment [input]) [0, 1, 8]
  , testCase
      "canonicalize all-observed candidate identities to the legacy path" $ do
      let roles = [Length.LengthObservedSpine]
          target = FunctionType adversarialClosedList adversarialClosedList
      legacySession <- adversarialLengthSession [] []
      explicitSession <- adversarialRoleAwareLengthSession roles [] []
      legacyContract <- adversarialLengthContract
        legacySession target identityLengthContract
      explicitContract <- adversarialRoleAwareLengthContract
        explicitSession roles target identityLengthContract
      graph <- sealAdversarialGraph
        $ adversarialIdentityGraphSource adversarialClosedList
      let candidate = adversarialTypedCandidate $ Right graph
      legacy <- expectRight
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            legacySession legacyContract candidate
      explicit <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            explicitSession explicitContract candidate
      LengthProblem.lengthSessionEncodingPolicyFingerprint explicitSession @?=
        LengthProblem.lengthSessionEncodingPolicyFingerprint legacySession
      Length.lengthContractFingerprint explicitContract @?=
        Length.lengthContractFingerprint legacyContract
      LengthProblem.checkedLengthProblemEncodingFingerprint explicit @?=
        LengthProblem.checkedLengthProblemEncodingFingerprint legacy
      Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem explicit) @?=
        Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem legacy)
  , testCase
      "reject a mixed contract paired with a legacy session" $ do
      legacySession <- adversarialLengthSession [] []
      let roles = [Length.LengthUnobservedTarget]
          target = FunctionType adversarialClosedList adversarialClosedList
      contract <- adversarialRoleAwareLengthContract
        legacySession roles target trivialLengthContract
      graph <- sealAdversarialGraph
        $ adversarialIdentityGraphSource adversarialClosedList
      assertLeft LengthProblem.LengthProblemTargetArgumentPolicyMismatch
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits legacySession contract
            $ adversarialTypedCandidate $ Right graph
  , testCase
      "reject callable, spine, and tuple demands on opaque targets" $ do
      assertOpaqueTargetDemandFailures
  , testCase
      "forward an opaque target through an ignored list-step payload" $ do
      problem <- roleAwareOpaqueStepPayloadProblem
      let input = Length.LengthVariable $ Length.LengthInput 0
      LengthProblem.checkedLengthProblemInputCount problem @?= 1
      LengthProblem.checkedLengthCandidateResult
          (LengthProblem.checkedLengthProblemCandidate problem) @?=
        Length.LengthSum [input, Length.LengthLiteral 1]
  , testCase "separate contract identity from graph and candidate identity" $ do
      session <- adversarialLengthSession [] []
      let target = FunctionType adversarialClosedList adversarialClosedList
      identityContract <- adversarialLengthContract
        session target identityLengthContract
      trivialContract <- adversarialLengthContract
        session target trivialLengthContract
      graph <- sealAdversarialGraph
        $ adversarialIdentityGraphSource adversarialClosedList
      let candidate = adversarialTypedCandidate $ Right graph
      identityProblem <- expectRight
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            session identityContract candidate
      trivialProblem <- expectRight
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            session trivialContract candidate
      let identityCandidate = LengthProblem.checkedLengthProblemCandidate
            identityProblem
          trivialCandidate = LengthProblem.checkedLengthProblemCandidate
            trivialProblem
          identityEnvelope = LengthProblem.checkedLengthProblemBehavioralProblem
            identityProblem
          trivialEnvelope = LengthProblem.checkedLengthProblemBehavioralProblem
            trivialProblem
      LengthProblem.checkedLengthCandidateFingerprint identityCandidate @?=
        LengthProblem.checkedLengthCandidateFingerprint trivialCandidate
      assertBool "contract identity was omitted from concrete encoding" $
        LengthProblem.checkedLengthProblemEncodingFingerprint identityProblem /=
          LengthProblem.checkedLengthProblemEncodingFingerprint trivialProblem
      assertBool "changed encoding did not reach complete problem identity" $
        Djex.behavioralProblemFingerprint identityEnvelope /=
          Djex.behavioralProblemFingerprint trivialEnvelope
  , testCase "keep unused inventory identity out of candidate and encoding" $ do
      unusedName <- expectName "Fixture.unusedProblemInventoryValue"
      baseSession <- adversarialLengthSession [] []
      widenedSession <- adversarialLengthSession
        [ ValueDeclaration
            $ ValueSignature () unusedName adversarialClosedList
        ] []
      let target = FunctionType adversarialClosedList adversarialClosedList
      contract <- adversarialLengthContract
        baseSession target identityLengthContract
      graph <- sealAdversarialGraph
        $ adversarialIdentityGraphSource adversarialClosedList
      let candidate = adversarialTypedCandidate $ Right graph
      baseProblem <- expectRight
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            baseSession contract candidate
      widenedProblem <- expectRight
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            widenedSession contract candidate
      let baseCandidate = LengthProblem.checkedLengthProblemCandidate baseProblem
          widenedCandidate = LengthProblem.checkedLengthProblemCandidate
            widenedProblem
          baseEnvelope = LengthProblem.checkedLengthProblemBehavioralProblem
            baseProblem
          widenedEnvelope = LengthProblem.checkedLengthProblemBehavioralProblem
            widenedProblem
      assertBool "an unused declaration was omitted from inventory identity" $
        Djex.behavioralProblemInventoryFingerprint baseEnvelope /=
          Djex.behavioralProblemInventoryFingerprint widenedEnvelope
      LengthProblem.checkedLengthCandidateFingerprint baseCandidate @?=
        LengthProblem.checkedLengthCandidateFingerprint widenedCandidate
      LengthProblem.checkedLengthProblemEncodingFingerprint baseProblem @?=
        LengthProblem.checkedLengthProblemEncodingFingerprint widenedProblem
      assertBool "changed inventory did not reach complete problem identity" $
        Djex.behavioralProblemFingerprint baseEnvelope /=
          Djex.behavioralProblemFingerprint widenedEnvelope
  , testCase "separate structural graph identity from concrete semantics" $ do
      session <- adversarialLengthSession [] []
      let target = FunctionType adversarialClosedList adversarialClosedList
      contract <- adversarialLengthContract
        session target identityLengthContract
      directGraph <- sealAdversarialGraph
        $ adversarialIdentityGraphSource adversarialClosedList
      letGraph <- sealAdversarialGraph
        $ adversarialLetIdentityGraphSource adversarialClosedList
      directProblem <- expectRight
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right directGraph
      letProblem <- expectRight
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right letGraph
      let directCandidate = LengthProblem.checkedLengthProblemCandidate
            directProblem
          letCandidate = LengthProblem.checkedLengthProblemCandidate letProblem
          directEnvelope = LengthProblem.checkedLengthProblemBehavioralProblem
            directProblem
          letEnvelope = LengthProblem.checkedLengthProblemBehavioralProblem
            letProblem
      LengthProblem.checkedLengthCandidateResult directCandidate @?=
        LengthProblem.checkedLengthCandidateResult letCandidate
      assertBool "structurally distinct graphs shared candidate identity" $
        LengthProblem.checkedLengthCandidateFingerprint directCandidate /=
          LengthProblem.checkedLengthCandidateFingerprint letCandidate
      LengthProblem.checkedLengthProblemEncodingFingerprint directProblem @?=
        LengthProblem.checkedLengthProblemEncodingFingerprint letProblem
      assertBool "changed candidate did not reach complete problem identity" $
        Djex.behavioralProblemFingerprint directEnvelope /=
          Djex.behavioralProblemFingerprint letEnvelope
  , testCase "validate candidate work limits before use" $ do
      LengthProblem.mkLengthProblemLimits Djex.defaultTermGraphLimits 0 (-1)
        @?= Left
          (LengthProblem.NegativeLengthProblemEvaluationStepLimit (-1))
      limits <- expectRight $ LengthProblem.mkLengthProblemLimits
        Djex.defaultTermGraphLimits 0 0
      LengthProblem.lengthProblemTermGraphLimits limits @?=
        Djex.defaultTermGraphLimits
      LengthProblem.lengthProblemGraphFingerprintByteLimit limits @?= 0
      LengthProblem.lengthProblemEvaluationStepLimit limits @?= 0
  , testCase "keep an impredicative list payload opaque end to end" $ do
      let binder = FlexibleVariable 1
          payload = ForallType [binder] []
            $ FunctionType (TypeVariable binder) (TypeVariable binder)
      (session, contract, candidate) <- realListIdentityFixture payload
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract candidate
      LengthProblem.checkedLengthCandidateResult
          (LengthProblem.checkedLengthProblemCandidate problem) @?=
        Length.LengthVariable (Length.LengthInput 0)
      LengthProblem.checkedLengthProblemCounterexampleCondition problem @?=
        Length.LengthTruth False
  , testCase "apply one inventory-owned provider law through a real graph" $ do
      providerName <- expectName "Fixture.lengthDouble"
      let element = FlexibleVariable 0
          providerSpine = TypeApplication (TypeConstructor listName)
            $ TypeVariable element
          providerScheme = ForallType [element] []
            $ FunctionType providerSpine providerSpine
          declaration = ValueDeclaration
            $ ValueSignature () providerName providerScheme
          provider = Length.AssumedProviderSummary
            { Length.lengthProviderName = providerName
            , Length.lengthProviderScheme = providerScheme
            , Length.lengthProviderArgumentRoles =
                [Length.LengthSpineArgument]
            , Length.lengthProviderTransfer = Length.LengthScale 2
                $ Length.LengthVariable $ Length.LengthProviderArgument 0
            }
      environment <- expectRight
        (Djex.mkEnvironment [declaration] ::
          Either (Djex.EnvironmentError Djex.ExferenceTypeVariable)
            Djex.ExferenceEnvironment)
      exferenceSession <- expectRight $ Djex.mkExferenceSession environment
      session <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits
        (Djex.exferenceSessionInventory exferenceSession)
        Length.BuiltinListSpine [provider]
      targetName <- expectName "lengthProviderCandidate"
      target <- expectRight $ Djex.mkDefinitionName targetName
      let goalElement = FlexibleVariable 1
          goalSpine = TypeApplication (TypeConstructor listName)
            $ TypeVariable goalElement
          goal = FunctionType goalSpine goalSpine
          query = Djex.QueryRequest
            { Djex.requestTarget = target
            , Djex.requestGoal = goal
            , Djex.requestContexts = []
            , Djex.requestOptions = Djex.defaultExferenceOptions
                { Djex.exferenceMaximumSteps = 32 }
            }
      request <- expectRight $ Djex.mkExferenceRequest query
      contract <- expectRight $ Length.sealLengthContractInContext
        Length.defaultLengthLimits
        (LengthProblem.checkedLengthSessionContext session)
        goal identityLengthContract
      results <- expectRight
        $ Djex.runExferenceTypedQuery exferenceSession request
      candidate <- case
          [ value
          | result <- results
          , value <- Djex.batchCandidates $ Djex.resultSearch result
          , Right graph <- [Djex.typedCandidateTermGraph value]
          , any (isNamedGlobal providerName . snd) $ Djex.termGraphNodes graph
          ] of
        [] -> assertFailure "the provider query returned no retained provider"
        value : _ -> pure value
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract candidate
      let checkedCandidate = LengthProblem.checkedLengthProblemCandidate problem
      LengthProblem.checkedLengthCandidateResult checkedCandidate @?=
        Length.LengthScale 2
          (Length.LengthVariable $ Length.LengthInput 0)
      LengthProblem.checkedLengthCandidateUsedProviders checkedCandidate @?=
        [providerName]
  , testCase
      "require discharge before interpreting a direct conditional provider" $ do
      className <- expectName "Fixture.DirectConditionalConstraint"
      providerName <- expectName "Fixture.directConditionalProvider"
      let scheme = ForallType [] [Constraint className []]
            adversarialClosedList
          classDeclaration = ClassDeclaration () className [] [] []
          declaration = ValueDeclaration
            $ ValueSignature () providerName scheme
          provider = Length.AssumedConstraintConditionalProviderSummary
            { Length.lengthProviderName = providerName
            , Length.lengthProviderScheme = scheme
            , Length.lengthProviderArgumentRoles = []
            , Length.lengthProviderTransfer = Length.LengthLiteral 0
            }
          source = Djex.TermGraphSource (Djex.termNodeId 0)
            [ ( Djex.termNodeId 0
              , Djex.TermNode adversarialClosedList
                  $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName
              )
            ]
      session <- adversarialLengthSession
        [classDeclaration, declaration] [provider]
      contract <- adversarialLengthContract
        session adversarialClosedList trivialLengthContract
      graph <- sealAdversarialGraph source
      assertLeft
        (LengthProblem.LengthProblemConditionalProviderRequiresDischarge
          (Djex.termNodeId 0) providerName)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right graph
  , testCase "substitute a checked modulo provider transfer into the problem" $ do
      problem <- adversarialModuloProviderProblem 3 identityLengthContract
      let input = Length.LengthVariable $ Length.LengthInput 0
          modulo = Length.LengthModulo 3 input
      LengthProblem.checkedLengthCandidateResult
          (LengthProblem.checkedLengthProblemCandidate problem) @?= modulo
      LengthProblem.checkedLengthProblemCounterexampleCondition problem @?=
        Length.LengthNot (Length.LengthEqual input modulo)
  , testCase "substitute a checked quotient provider transfer into the problem" $ do
      problem <- adversarialQuotientProviderProblem 3 identityLengthContract
      let input = Length.LengthVariable $ Length.LengthInput 0
          quotient = Length.LengthQuotient 3 input
      LengthProblem.checkedLengthCandidateResult
          (LengthProblem.checkedLengthProblemCandidate problem) @?= quotient
      LengthProblem.checkedLengthProblemCounterexampleCondition problem @?=
        Length.LengthNot (Length.LengthEqual input quotient)
  , testCase "retain used provider laws in canonical name order" $ do
      earlierName <- expectName "Fixture.alphaUsedProvider"
      laterName <- expectName "Fixture.omegaUsedProvider"
      let target = FunctionType adversarialClosedList adversarialClosedList
          provider name factor = Length.AssumedProviderSummary
            { Length.lengthProviderName = name
            , Length.lengthProviderScheme = target
            , Length.lengthProviderArgumentRoles =
                [Length.LengthSpineArgument]
            , Length.lengthProviderTransfer = Length.LengthScale factor
                $ Length.LengthVariable $ Length.LengthProviderArgument 0
            }
          earlier = provider earlierName 2
          later = provider laterName 3
          declaration name = ValueDeclaration
            $ ValueSignature () name target
          compositionSource outer inner =
            Djex.TermGraphSource (Djex.termNodeId 5)
              [ ( Djex.termNodeId 0
                , Djex.TermNode target
                    $ Djex.TypedGlobal (Djex.occurrenceId 0) outer
                )
              , ( Djex.termNodeId 1
                , Djex.TermNode target
                    $ Djex.TypedGlobal (Djex.occurrenceId 1) inner
                )
              , ( Djex.termNodeId 2
                , Djex.TermNode adversarialClosedList
                    $ Djex.TypedLocal (Djex.occurrenceId 2) 0
                )
              , ( Djex.termNodeId 3
                , Djex.TermNode adversarialClosedList
                    $ Djex.TypedApply
                        (Djex.termNodeId 1)
                        (Djex.termNodeId 2)
                        (Djex.ApplicationWitness
                          adversarialClosedList adversarialClosedList)
                )
              , ( Djex.termNodeId 4
                , Djex.TermNode adversarialClosedList
                    $ Djex.TypedApply
                        (Djex.termNodeId 0)
                        (Djex.termNodeId 3)
                        (Djex.ApplicationWitness
                          adversarialClosedList adversarialClosedList)
                )
              , ( Djex.termNodeId 5
                , Djex.TermNode target
                    $ Djex.TypedLambda
                        [ Djex.TypedPattern
                            (Djex.occurrenceId 3)
                            adversarialClosedList
                            (Djex.TypedBind 0)
                        ]
                        (Djex.termNodeId 4)
                )
              ]
      session <- adversarialLengthSession
        [declaration laterName, declaration earlierName]
        [later, earlier]
      contract <- adversarialLengthContract
        session target identityLengthContract
      earlierThenLater <- sealAdversarialGraph
        $ compositionSource laterName earlierName
      laterThenEarlier <- sealAdversarialGraph
        $ compositionSource earlierName laterName
      first <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract
        $ adversarialTypedCandidate $ Right earlierThenLater
      second <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract
        $ adversarialTypedCandidate $ Right laterThenEarlier
      let firstCandidate = LengthProblem.checkedLengthProblemCandidate first
          secondCandidate = LengthProblem.checkedLengthProblemCandidate second
          canonicalNames = [earlierName, laterName]
      LengthProblem.checkedLengthCandidateUsedProviders firstCandidate @?=
        canonicalNames
      LengthProblem.checkedLengthCandidateUsedProviders secondCandidate @?=
        canonicalNames
      LengthProblem.checkedLengthCandidateResult firstCandidate @?=
        LengthProblem.checkedLengthCandidateResult secondCandidate
      LengthProblem.checkedLengthProblemEncodingFingerprint first @?=
        LengthProblem.checkedLengthProblemEncodingFingerprint second
      assertBool "distinct provider compositions shared candidate identity" $
        LengthProblem.checkedLengthCandidateFingerprint firstCandidate /=
          LengthProblem.checkedLengthCandidateFingerprint secondCandidate
  , testCase "reject residual dictionaries before inspecting graph semantics" $ do
      className <- expectName "C"
      producerName <- expectName "Fixture.produceList"
      let element = FlexibleVariable 0
          elementType = TypeVariable element
          resultType = TypeApplication (TypeConstructor listName) elementType
          declarations =
            [ ClassDeclaration () className
                [TypeParameter element Nothing] [] []
            , ValueDeclaration $ ValueSignature () producerName
                $ ForallType [element]
                    [Constraint className [elementType]] resultType
            ]
      environment <- expectRight
        (Djex.mkEnvironment declarations ::
          Either (Djex.EnvironmentError Djex.ExferenceTypeVariable)
            Djex.ExferenceEnvironment)
      exferenceSession <- expectRight $ Djex.mkExferenceSession environment
      session <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits
        (Djex.exferenceSessionInventory exferenceSession)
        Length.BuiltinListSpine []
      targetName <- expectName "residualLengthCandidate"
      target <- expectRight $ Djex.mkDefinitionName targetName
      let goalElement = FlexibleVariable 1
          goal = TypeApplication (TypeConstructor listName)
            $ TypeVariable goalElement
          query = Djex.QueryRequest
            { Djex.requestTarget = target
            , Djex.requestGoal = goal
            , Djex.requestContexts = []
            , Djex.requestOptions = Djex.defaultExferenceOptions
                { Djex.exferenceAllowResidualConstraints = True
                , Djex.exferenceMaximumSteps = 64
                }
            }
      request <- expectRight $ Djex.mkExferenceRequest query
      contract <- expectRight $ Length.sealLengthContractInContext
        Length.defaultLengthLimits
        (LengthProblem.checkedLengthSessionContext session)
        goal trivialLengthContract
      results <- expectRight
        $ Djex.runExferenceTypedQuery exferenceSession request
      (candidate, residual) <- case
          [ (value, firstResidual)
          | result <- results
          , value <- Djex.batchCandidates $ Djex.resultSearch result
          , firstResidual : _ <-
              [Djex.candidateResidualConstraints
                $ Djex.typedCandidateCompatibility value]
          ] of
        [] -> assertFailure "the constrained query returned no residual"
        value : _ -> pure value
      assertLeft (LengthProblem.LengthProblemResidualConstraint residual)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            session contract candidate
  , testCase "interpret an inventory-authorized zero constructor" $ do
      typeName <- expectName "Fixture.CandidateSpine"
      zeroName <- expectName "Fixture.CandidateEmpty"
      stepName <- expectName "Fixture.CandidateStep"
      let declaredElement = FlexibleVariable 0
          declaredSpine = TypeApplication (TypeConstructor typeName)
            $ TypeVariable declaredElement
          declaration = DataTypeDeclaration () typeName
            [TypeParameter declaredElement Nothing]
            [ DataConstructor () zeroName []
            , DataConstructor () stepName
                [TypeVariable declaredElement, declaredSpine]
            ]
      environment <- expectRight
        (Djex.mkEnvironment [declaration] ::
          Either (Djex.EnvironmentError Djex.ExferenceTypeVariable)
            Djex.ExferenceEnvironment)
      exferenceSession <- expectRight $ Djex.mkExferenceSession environment
      session <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits
        (Djex.exferenceSessionInventory exferenceSession)
        (Length.DeclaredListSpine typeName zeroName stepName) []
      targetName <- expectName "emptyLengthCandidate"
      target <- expectRight $ Djex.mkDefinitionName targetName
      let element = FlexibleVariable 0
          goal = TypeApplication (TypeConstructor typeName)
            $ TypeVariable element
          query = Djex.QueryRequest
            { Djex.requestTarget = target
            , Djex.requestGoal = goal
            , Djex.requestContexts = []
            , Djex.requestOptions = Djex.defaultExferenceOptions
                { Djex.exferenceMaximumSteps = 16 }
            }
          contractSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (Length.LengthVariable Length.LengthResult)
                (Length.LengthLiteral 0)
      request <- expectRight $ Djex.mkExferenceRequest query
      contract <- expectRight $ Length.sealLengthContractInContext
        Length.defaultLengthLimits
        (LengthProblem.checkedLengthSessionContext session)
        goal contractSource
      results <- expectRight
        $ Djex.runExferenceTypedQuery exferenceSession request
      candidate <- case
          [ value
          | result <- results
          , value <- Djex.batchCandidates $ Djex.resultSearch result
          , Right graph <- [Djex.typedCandidateTermGraph value]
          , any (isNamedGlobal zeroName . snd) $ Djex.termGraphNodes graph
          ] of
        [] -> assertFailure "the empty-list query returned no zero constructor"
        value : _ -> pure value
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract candidate
      LengthProblem.checkedLengthCandidateResult
          (LengthProblem.checkedLengthProblemCandidate problem) @?=
        Length.LengthLiteral 0
      LengthProblem.checkedLengthProblemCounterexampleCondition problem @?=
        Length.LengthTruth False
  , testCase "interpret the recursive field of an authorized step" $ do
      typeName <- expectName "Fixture.StepSpine"
      zeroName <- expectName "Fixture.StepEmpty"
      stepName <- expectName "Fixture.StepLink"
      let declaredElement = FlexibleVariable 0
          declaredSpine = TypeApplication (TypeConstructor typeName)
            $ TypeVariable declaredElement
          declaration = DataTypeDeclaration () typeName
            [TypeParameter declaredElement Nothing]
            [ DataConstructor () zeroName []
            , DataConstructor () stepName
                [TypeVariable declaredElement, declaredSpine]
            ]
      environment <- expectRight
        (Djex.mkEnvironment [declaration] ::
          Either (Djex.EnvironmentError Djex.ExferenceTypeVariable)
            Djex.ExferenceEnvironment)
      exferenceSession <- expectRight $ Djex.mkExferenceSession environment
      session <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits
        (Djex.exferenceSessionInventory exferenceSession)
        (Length.DeclaredListSpine typeName zeroName stepName) []
      targetName <- expectName "stepLengthCandidate"
      target <- expectRight $ Djex.mkDefinitionName targetName
      let element = FlexibleVariable 1
          innerSpine = TypeApplication (TypeConstructor typeName)
            $ TypeVariable element
          outerSpine = TypeApplication (TypeConstructor typeName) innerSpine
          goal = FunctionType innerSpine
            $ FunctionType outerSpine outerSpine
          expectedResult = Length.LengthSum
            [ Length.LengthVariable $ Length.LengthInput 1
            , Length.LengthLiteral 1
            ]
          query = Djex.QueryRequest
            { Djex.requestTarget = target
            , Djex.requestGoal = goal
            , Djex.requestContexts = []
            , Djex.requestOptions = Djex.defaultExferenceOptions
                { Djex.exferenceMaximumSteps = 32 }
            }
          contractSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (Length.LengthVariable Length.LengthResult) expectedResult
      request <- expectRight $ Djex.mkExferenceRequest query
      contract <- expectRight $ Length.sealLengthContractInContext
        Length.defaultLengthLimits
        (LengthProblem.checkedLengthSessionContext session)
        goal contractSource
      results <- expectRight
        $ Djex.runExferenceTypedQuery exferenceSession request
      candidate <- case
          [ value
          | result <- results
          , value <- Djex.batchCandidates $ Djex.resultSearch result
          , Right graph <- [Djex.typedCandidateTermGraph value]
          , any (isNamedGlobal stepName . snd) $ Djex.termGraphNodes graph
          ] of
        [] -> assertFailure "the step query returned no step constructor"
        value : _ -> pure value
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract candidate
      LengthProblem.checkedLengthCandidateResult
          (LengthProblem.checkedLengthProblemCandidate problem) @?=
        expectedResult
      LengthProblem.checkedLengthProblemCounterexampleCondition problem @?=
        Length.LengthTruth False
  , testCase "require fresh distinct rigid root openings" $ do
      session <- adversarialLengthSession [] []
      let flexible = FlexibleVariable "root-flexible"
          existingRigid = RigidVariable "root-existing-rigid"
          freshRigid = RigidVariable "root-fresh-rigid"
          flexibleSpine = adversarialListOf $ TypeVariable flexible
          existingSpine = adversarialListOf $ TypeVariable existingRigid
          freshSpine = adversarialListOf $ TypeVariable freshRigid
          flexibleTarget = FunctionType flexibleSpine flexibleSpine
      contract <- adversarialLengthContract
        session flexibleTarget identityLengthContract

      flexibleGraph <- sealAdversarialGraph
        $ adversarialIdentityGraphSource flexibleSpine
      assertLeft
        (LengthProblem.LengthProblemRootOpeningRejected
          $ LengthProblem.LengthRootOpeningSelectionIsNotRigid 0)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right flexibleGraph

      let collidingTarget = FunctionType flexibleSpine existingSpine
      collidingContract <- adversarialLengthContract
        session collidingTarget trivialLengthContract
      collidingGraph <- sealAdversarialGraph
        $ adversarialIdentityGraphSource existingSpine
      assertLeft
        (LengthProblem.LengthProblemRootOpeningRejected
          $ LengthProblem.LengthRootOpeningRigidIsNotInjective
              0 "root-existing-rigid")
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session collidingContract
            $ adversarialTypedCandidate $ Right collidingGraph

      freshGraph <- sealAdversarialGraph
        $ adversarialIdentityGraphSource freshSpine
      freshProblem <- expectRight
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right freshGraph
      LengthProblem.checkedLengthCandidateResult
          (LengthProblem.checkedLengthProblemCandidate freshProblem) @?=
        Length.LengthVariable (Length.LengthInput 0)
  , testCase "accept exact closed root openings without weakening legacy rigid openings" $ do
      session <- adversarialLengthSession [] []
      let sourceSpine = adversarialListOf $ TypeVariable $ FlexibleVariable "source"
          target = FunctionType sourceSpine sourceSpine
          openedSpine = adversarialListOf $ TypeVariable $ RigidVariable "legacy-open"
      contract <- adversarialLengthContract session target identityLengthContract
      opened <- sealAdversarialGraph $ adversarialIdentityGraphSource openedSpine
      closed <- adversarialQuantifiedIdentityGraph
      mapM_ (\graph -> do
        problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
          LengthProblem.defaultLengthProblemLimits session contract
          $ adversarialTypedCandidate $ Right graph
        LengthProblem.checkedLengthCandidateResult
            (LengthProblem.checkedLengthProblemCandidate problem) @?=
          Length.LengthVariable (Length.LengthInput 0)) [opened, closed]
      Djex.eraseTermGraph closed @?= Djex.eraseTermGraph opened
  , testCase "closed roots use canonical source binder order and existing forall layer" $ do
      session <- adversarialLengthSession [] []
      let firstBinder = FlexibleVariable "canonical-a"
          secondBinder = FlexibleVariable "canonical-b"
          firstSpine = adversarialListOf $ TypeVariable firstBinder
          secondSpine = adversarialListOf $ TypeVariable secondBinder
          body = FunctionType secondSpine $ FunctionType firstSpine secondSpine
          targets = [body, ForallType [secondBinder] [] body]
      (opened, closed) <- adversarialCanonicalFirstGraphs
      Djex.eraseTermGraph closed @?= Djex.eraseTermGraph opened
      forM_ targets $ \target -> do
        contract <- adversarialLengthContract session target identityLengthContract
        -- Contract preparation retains these identities and the existing
        -- forall layer; it does not canonicalize the target's binder order.
        Length.checkedLengthContractTarget contract @?= target
        forM_ [opened, closed] $ \graph -> do
          problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right graph
          LengthProblem.checkedLengthCandidateResult
              (LengthProblem.checkedLengthProblemCandidate problem) @?=
            Length.LengthVariable (Length.LengthInput 0)
  , testCase "reject a closed root with different quantified correlation" $ do
      session <- adversarialLengthSession [] []
      let first = adversarialListOf $ TypeVariable $ FlexibleVariable "source-first"
          second = adversarialListOf $ TypeVariable $ FlexibleVariable "source-second"
      contract <- adversarialLengthContract session
        (FunctionType first second) trivialLengthContract
      closed <- adversarialQuantifiedIdentityGraph
      assertLeft
        (LengthProblem.LengthProblemRootOpeningRejected
          LengthProblem.LengthRootOpeningShapeMismatch)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right closed
  , testCase "closed root equality retains source class constraints" $ do
      session <- adversarialLengthSession [] []
      className <- expectName "Fixture.RootConstraint"
      providerName <- expectName "Fixture.QualifiedIdentity"
      let spine = adversarialListOf $ TypeVariable $ FlexibleVariable "source"
          bound = FlexibleVariable "qualified-source"
          boundType = TypeVariable bound
          boundSpine = adversarialListOf boundType
          qualifiedType = ForallType [bound] [Constraint className [boundType]]
            $ FunctionType boundSpine boundSpine
      contract <- adversarialLengthContract session
        (FunctionType spine spine) identityLengthContract
      -- A global root reaches the root matcher without the earlier rejection
      -- of dictionary-introduction nodes. Missing provider-law authority is a
      -- later boundary and must not mask this exact source-type mismatch.
      qualified <- sealAdversarialGraph $ Djex.TermGraphSource (Djex.termNodeId 0)
        [(Djex.termNodeId 0, Djex.TermNode qualifiedType
          $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName)]
      assertLeft
        (LengthProblem.LengthProblemRootOpeningRejected
          LengthProblem.LengthRootOpeningShapeMismatch)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right qualified
  , testCase "interpret an inventory-owned zero-arity provider" $ do
      providerName <- expectName "Fixture.zeroArityLengthProvider"
      let providerScheme = adversarialClosedList
          provider = Length.AssumedProviderSummary
            { Length.lengthProviderName = providerName
            , Length.lengthProviderScheme = providerScheme
            , Length.lengthProviderArgumentRoles = []
            , Length.lengthProviderTransfer = Length.LengthLiteral 7
            }
          declaration = ValueDeclaration
            $ ValueSignature () providerName providerScheme
          contractSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (Length.LengthVariable Length.LengthResult)
                (Length.LengthLiteral 7)
      session <- adversarialLengthSession [declaration] [provider]
      contract <- adversarialLengthContract session providerScheme contractSource
      graph <- sealAdversarialGraph $ Djex.TermGraphSource
        (Djex.termNodeId 0)
        [ ( Djex.termNodeId 0
          , Djex.TermNode providerScheme
              $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName
          )
        ]
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract
        $ adversarialTypedCandidate $ Right graph
      let checked = LengthProblem.checkedLengthProblemCandidate problem
      LengthProblem.checkedLengthCandidateResult checked @?=
        Length.LengthLiteral 7
      LengthProblem.checkedLengthCandidateUsedProviders checked @?=
        [providerName]
      LengthProblem.checkedLengthProblemCounterexampleCondition problem @?=
        Length.LengthTruth False
  , testCase "reject a visible selection outside the root rigid scope" $ do
      providerName <- expectName "Fixture.visibleLengthProvider"
      let binder = FlexibleVariable "provider-binder"
          escaped = RigidVariable "escaped-visible-selection"
          providerScheme = ForallType [binder] []
            $ adversarialListOf $ TypeVariable binder
          selected = TypeVariable escaped
          selectedSpine = adversarialListOf selected
          provider = Length.AssumedProviderSummary
            { Length.lengthProviderName = providerName
            , Length.lengthProviderScheme = providerScheme
            , Length.lengthProviderArgumentRoles = []
            , Length.lengthProviderTransfer = Length.LengthLiteral 0
            }
          declaration = ValueDeclaration
            $ ValueSignature () providerName providerScheme
          witness = Djex.TypeApplicationWitness
            providerScheme selected selectedSpine Nothing
          ignored = Djex.TypedPattern
            (Djex.occurrenceId 2) selectedSpine Djex.TypedWildcard
          source = Djex.TermGraphSource (Djex.termNodeId 3)
            [ ( Djex.termNodeId 0
              , Djex.TermNode providerScheme
                  $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName
              )
            , ( Djex.termNodeId 1
              , Djex.TermNode selectedSpine
                  $ Djex.TypedVisibleTypeApplication
                      (Djex.occurrenceId 1)
                      (Djex.termNodeId 0)
                      Djex.inferredVisibleTypeArgument
                      witness
              )
            , ( Djex.termNodeId 2
              , Djex.TermNode adversarialClosedList
                  $ Djex.TypedGlobal (Djex.occurrenceId 3) listName
              )
            , ( Djex.termNodeId 3
              , Djex.TermNode adversarialClosedList
                  $ Djex.TypedLet ignored
                      (Djex.termNodeId 1) (Djex.termNodeId 2)
              )
            ]
      session <- adversarialLengthSession [declaration] [provider]
      contract <- adversarialLengthContract
        session adversarialClosedList trivialLengthContract
      graph <- sealAdversarialGraph source
      assertLeft
        (LengthProblem.LengthProblemVisibleTypeSelectionRejected
          (Djex.termNodeId 1) selected)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right graph
  , testCase "admit closed visible selections at their inferred binder kind" $ do
      higherProvider <- expectName "Fixture.higherKindedVisibleProvider"
      let constructorBinder = FlexibleVariable "constructor-binder"
          unitType = TupleType Boxed []
          higherScheme = ForallType [constructorBinder] []
            $ adversarialListOf
            $ TypeApplication (TypeVariable constructorBinder) unitType
          higherSelection = TypeConstructor listName
          higherResult = adversarialListOf
            $ adversarialListOf unitType
      higherProblem <- expectRight
        =<< adversarialVisibleProviderProblem
          higherProvider higherScheme higherSelection higherResult Nothing
      let higherCandidate = LengthProblem.checkedLengthProblemCandidate
            higherProblem
      LengthProblem.checkedLengthCandidateResult higherCandidate @?=
        Length.LengthLiteral 0
      LengthProblem.checkedLengthCandidateUsedProviders higherCandidate @?=
        [higherProvider]

      impredicativeProvider <- expectName
        "Fixture.impredicativeVisibleProvider"
      let elementBinder = FlexibleVariable "element-binder"
          innerBinder = FlexibleVariable "inner-binder"
          impredicativeScheme = ForallType [elementBinder] []
            $ adversarialListOf $ TypeVariable elementBinder
          impredicativeSelection = ForallType [innerBinder] []
            $ FunctionType
                (TypeVariable innerBinder) (TypeVariable innerBinder)
          impredicativeResult = adversarialListOf impredicativeSelection
      impredicativeProblem <- expectRight
        =<< adversarialVisibleProviderProblem
          impredicativeProvider
          impredicativeScheme
          impredicativeSelection
          impredicativeResult
          Nothing
      LengthProblem.checkedLengthCandidateResult
          (LengthProblem.checkedLengthProblemCandidate impredicativeProblem) @?=
        Length.LengthLiteral 0
  , testCase "reject certificate-bearing visible applications at graph identity" $ do
      providerName <- expectName "Fixture.certifiedVisibleProvider"
      let binder = FlexibleVariable "certified-binder"
          selected = TupleType Boxed []
          scheme = ForallType [binder] []
            $ adversarialListOf $ TypeVariable binder
          result = adversarialListOf selected
          certificate = Djex.certificateId 37
      assertLeft
        (LengthProblem.LengthProblemTermGraphFingerprintRejected
          $ Djex.TermGraphFingerprintUnsupportedCertificate certificate)
        =<< adversarialVisibleProviderProblem
          providerName scheme selected result (Just (certificate, 0))
  , testCase "kind-check every graph annotation in the exact session" $ do
      unknownTypeName <- expectName "Fixture.UnknownGraphType"
      unknownValueName <- expectName "Fixture.unknownGraphValue"
      let unknownType = TypeConstructor unknownTypeName
          ignored = Djex.TypedPattern
            (Djex.occurrenceId 1) unknownType Djex.TypedWildcard
          source = Djex.TermGraphSource (Djex.termNodeId 2)
            [ ( Djex.termNodeId 0
              , Djex.TermNode unknownType
                  $ Djex.TypedGlobal (Djex.occurrenceId 0) unknownValueName
              )
            , ( Djex.termNodeId 1
              , Djex.TermNode adversarialClosedList
                  $ Djex.TypedGlobal (Djex.occurrenceId 2) listName
              )
            , ( Djex.termNodeId 2
              , Djex.TermNode adversarialClosedList
                  $ Djex.TypedLet ignored
                      (Djex.termNodeId 0) (Djex.termNodeId 1)
              )
            ]
      session <- adversarialLengthSession [] []
      contract <- adversarialLengthContract
        session adversarialClosedList trivialLengthContract
      graph <- sealAdversarialGraph source
      case LengthProblem.sealLengthTypedCandidateProblem
          LengthProblem.defaultLengthProblemLimits session contract
          (adversarialTypedCandidate $ Right graph) of
        Left LengthProblem.LengthProblemGraphKindRejected{} -> pure ()
        Left other -> assertFailure $ "unexpected rejection: " ++ show other
        Right _ -> assertFailure "an unknown graph type escaped session kinding"
  , testCase "distinguish absent and semantically unmodeled globals" $ do
      missingName <- expectName "Fixture.missingLengthGlobal"
      unmodeledName <- expectName "Fixture.unmodeledLengthGlobal"
      let declaration = ValueDeclaration
            $ ValueSignature () unmodeledName adversarialClosedList
          globalSource name = Djex.TermGraphSource (Djex.termNodeId 0)
            [ ( Djex.termNodeId 0
              , Djex.TermNode adversarialClosedList
                  $ Djex.TypedGlobal (Djex.occurrenceId 0) name
              )
            ]
      session <- adversarialLengthSession [declaration] []
      contract <- adversarialLengthContract
        session adversarialClosedList trivialLengthContract
      missingGraph <- sealAdversarialGraph $ globalSource missingName
      unmodeledGraph <- sealAdversarialGraph $ globalSource unmodeledName
      assertLeft
        (LengthProblem.LengthProblemGlobalNotInSourceInventory
          (Djex.termNodeId 0) missingName)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right missingGraph
      assertLeft
        (LengthProblem.LengthProblemGlobalHasNoLengthSummary
          (Djex.termNodeId 0) unmodeledName)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Right unmodeledGraph
  , testCase "retain typed-graph absence after contract resealing" $ do
      session <- adversarialLengthSession [] []
      contract <- adversarialLengthContract
        session adversarialClosedList trivialLengthContract
      assertLeft (LengthProblem.LengthProblemTypedGraphUnavailable
          "fixture graph unavailable")
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ adversarialTypedCandidate $ Left "fixture graph unavailable"
  , testCase "bound graph identity before symbolic evaluation" $ do
      (session, contract, candidate) <- realListIdentityFixture
        $ TypeVariable $ FlexibleVariable 0
      noGraphBytes <- expectRight $ LengthProblem.mkLengthProblemLimits
        Djex.defaultTermGraphLimits 0 65536
      assertLeft
        (LengthProblem.LengthProblemTermGraphFingerprintRejected
          $ Djex.TermGraphFingerprintByteLimitExceeded 0 1)
        $ LengthProblem.sealLengthTypedCandidateProblem
            noGraphBytes session contract candidate
      noEvaluation <- expectRight $ LengthProblem.mkLengthProblemLimits
        Djex.defaultTermGraphLimits
        Djex.defaultTermGraphFingerprintByteLimit 0
      assertLeft
        (LengthProblem.LengthProblemEvaluationStepLimitExceeded 0 1)
        $ LengthProblem.sealLengthTypedCandidateProblem
            noEvaluation session contract candidate
  ]

associatedCertificateCandidateTests :: TestTree
associatedCertificateCandidateTests = testGroup
  "Length certificate-associated candidates"
  [ testCase "admit one exact obligation-free provider specialization" $ do
      providerName <- expectName "Fixture.associatedLengthProvider"
      let scheme = associatedProviderScheme "associated-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
          declaration = ValueDeclaration
            $ ValueSignature () providerName scheme
          provider = associatedProviderSummary providerName scheme
      checked <- associatedProviderCertificateGraph
        providerName scheme selected result [] 7 0 1 10 11
      session <- adversarialLengthSession [declaration] [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract
        $ associatedAdversarialTypedCandidate adversarialCompatibility checked
      let candidate = LengthProblem.checkedLengthProblemCandidate problem
          bytes = BS.pack $ Fingerprint.fingerprintCanonicalBytes
            $ LengthProblem.checkedLengthCandidateFingerprint candidate
      LengthProblem.checkedLengthCandidateResult candidate @?=
        Length.LengthLiteral 0
      LengthProblem.checkedLengthCandidateUsedProviders candidate @?=
        [providerName]
      BS.unpack (BS.take 10 bytes) @?= fingerprintVersionPrefix 2
      assertBool "associated authority tag was absent" $
        BSC.pack "opaque-associated-certificate/v1" `BS.isInfixOf` bytes
      assertBool "empty-obligation authority tag was absent" $
        BSC.pack "activated-obligations-empty/v1" `BS.isInfixOf` bytes
  , testCase "ignore certificate, node, and occurrence allocation" $ do
      providerName <- expectName "Fixture.renumberedAssociatedProvider"
      let scheme = associatedProviderScheme "renumbered-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
          declaration = ValueDeclaration
            $ ValueSignature () providerName scheme
          provider = associatedProviderSummary providerName scheme
      firstCarrier <- associatedProviderCertificateGraph
        providerName scheme selected result [] 7 0 1 10 11
      secondCarrier <- associatedProviderCertificateGraph
        providerName scheme selected result [] 91 44 87 300 301
      session <- adversarialLengthSession [declaration] [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      let seal carrier = expectRight $
            LengthProblem.sealLengthTypedCandidateProblem
              LengthProblem.defaultLengthProblemLimits session contract
              $ associatedAdversarialTypedCandidate
                  adversarialCompatibility carrier
      first <- seal firstCarrier
      second <- seal secondCarrier
      LengthProblem.checkedLengthCandidateFingerprint
          (LengthProblem.checkedLengthProblemCandidate first) @?=
        LengthProblem.checkedLengthCandidateFingerprint
          (LengthProblem.checkedLengthProblemCandidate second)
      Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem first) @?=
        Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem second)
  , testCase
      "ignore conditional certificate, node, and occurrence allocation" $ do
      providerName <- expectName "Fixture.renumberedConditionalProvider"
      className <- expectName "Fixture.RenumberedConstraint"
      let binder = FlexibleVariable "renumbered-conditional-element"
          classBinder = FlexibleVariable "renumbered-constraint-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
          scheme = ForallType [binder]
            [Constraint className [TypeVariable binder]]
            $ adversarialListOf $ TypeVariable binder
          obligation = Constraint className [selected]
          declarations =
            [ ClassDeclaration () className
                [TypeParameter classBinder (Just ProperTypeKind)] [] []
            , InstanceDeclaration () [] [] obligation
            , ValueDeclaration $ ValueSignature () providerName scheme
            ]
          provider = associatedConditionalProviderSummary
            providerName scheme
      firstCarrier <- associatedProviderCertificateGraph
        providerName scheme selected result [obligation] 7 0 1 10 11
      secondCarrier <- associatedProviderCertificateGraph
        providerName scheme selected result [obligation] 91 44 87 300 301
      session <- adversarialLengthSession declarations [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      let seal carrier = expectRight $
            LengthProblem.sealLengthTypedCandidateProblem
              LengthProblem.defaultLengthProblemLimits session contract
              $ associatedAdversarialTypedCandidate
                  adversarialCompatibility carrier
      first <- seal firstCarrier
      second <- seal secondCarrier
      let firstCandidate = LengthProblem.checkedLengthProblemCandidate first
          secondCandidate = LengthProblem.checkedLengthProblemCandidate second
          firstFingerprint =
            LengthProblem.checkedLengthCandidateFingerprint firstCandidate
      take 10 (Fingerprint.fingerprintCanonicalBytes firstFingerprint) @?=
        fingerprintVersionPrefix 3
      firstFingerprint @?=
        LengthProblem.checkedLengthCandidateFingerprint secondCandidate
      Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem first) @?=
        Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem second)
  , testCase "authorize every row in rooted order, not caller row order" $ do
      firstOwner <- expectName "Fixture.firstRootedAssociatedProvider"
      secondOwner <- expectName "Fixture.secondRootedAssociatedProvider"
      let scheme = associatedProviderScheme "rooted-row-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
          declaration = ValueDeclaration
            $ ValueSignature () firstOwner scheme
          provider = associatedProviderSummary firstOwner scheme
      checked <- twoRowAssociatedLetCertificateGraph
        firstOwner secondOwner scheme selected result
      session <- adversarialLengthSession [declaration] [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateOwnerMissing
          secondOwner 1)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  , testCase "combine exact constructor schemas with an associated provider" $ do
      providerName <- expectName "Fixture.exactAssociatedProvider"
      let payload = TupleType Boxed []
          spine = adversarialListOf payload
          scheme = associatedProviderScheme "exact-associated-element"
          declaration = ValueDeclaration
            $ ValueSignature () providerName scheme
          provider = associatedProviderSummary providerName scheme
          roles = [Length.LengthObservedSpine]
      (checked, target) <- exactCaseAssociatedProviderGraph
        providerName scheme payload spine
      session <- adversarialExactCaseLengthSession
        roles [declaration] [provider]
      contract <- adversarialRoleAwareLengthContract
        session roles target trivialLengthContract
      problem <- expectRight $
        LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
          LengthProblem.defaultLengthProblemLimits session contract
          $ associatedAdversarialTypedCandidate
              adversarialCompatibility checked
      let input = Length.LengthVariable $ Length.LengthInput 0
          expected = Length.LengthIf
            (Length.LengthEqual input $ Length.LengthLiteral 0)
            (Length.LengthLiteral 0)
            (Length.LengthMonus input $ Length.LengthLiteral 1)
          candidate = LengthProblem.checkedLengthProblemCandidate problem
      LengthProblem.checkedLengthCandidateResult candidate @?= expected
      LengthProblem.checkedLengthCandidateUsedProviders candidate @?=
        [providerName]
  , testCase "canonicalize an empty carrier exactly to its plain graph" $ do
      providerName <- expectName "Fixture.emptyAssociatedProvider"
      let scheme = adversarialClosedList
          declaration = ValueDeclaration
            $ ValueSignature () providerName scheme
          provider = associatedProviderSummary providerName scheme
          source = Djex.TermGraphSource (Djex.termNodeId 0)
            [ ( Djex.termNodeId 0
              , Djex.TermNode scheme
                  $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName
              )
            ]
      carrier <- expectRight $
        InternalCertificateAssociation.sealCheckedTypeApplicationCertificateGraph
          InternalCertificate.defaultTypeApplicationCertificateLimits
          Djex.sharedTypeStructure Djex.defaultTermGraphLimits source []
      plainGraph <- sealAdversarialGraph source
      session <- adversarialLengthSession [declaration] [provider]
      contract <- adversarialLengthContract session scheme trivialLengthContract
      plain <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract
        $ adversarialTypedCandidate $ Right plainGraph
      associated <- expectRight $
        LengthProblem.sealLengthTypedCandidateProblem
          LengthProblem.defaultLengthProblemLimits session contract
          $ associatedAdversarialTypedCandidate
              adversarialCompatibility carrier
      LengthProblem.checkedLengthCandidateFingerprint
          (LengthProblem.checkedLengthProblemCandidate associated) @?=
        LengthProblem.checkedLengthCandidateFingerprint
          (LengthProblem.checkedLengthProblemCandidate plain)
      LengthProblem.checkedLengthProblemEncodingFingerprint associated @?=
        LengthProblem.checkedLengthProblemEncodingFingerprint plain
      Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem associated) @?=
        Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem plain)
  , testCase "carry a real exact-scheme Exference specialization into Length" $ do
      providerName <- expectName "Fixture.exferenceAssociatedProvider"
      targetName <- expectName "exferenceAssociatedLengthCandidate"
      target <- expectRight $ Djex.mkDefinitionName targetName
      let binder = FlexibleVariable 0
          selected = TupleType Boxed []
          scheme = ForallType [binder] []
            $ TypeApplication (TypeConstructor listName)
            $ TypeVariable binder
          goal = TypeApplication (TypeConstructor listName) selected
          declaration = ValueDeclaration
            $ ValueSignature () providerName scheme
          provider = Length.AssumedProviderSummary
            { Length.lengthProviderName = providerName
            , Length.lengthProviderScheme = scheme
            , Length.lengthProviderArgumentRoles = []
            , Length.lengthProviderTransfer = Length.LengthLiteral 0
            }
          assignment = Djex.ProviderInstantiationAssignment
            { Djex.providerInstantiationAssignmentProvider = providerName
            , Djex.providerInstantiationAssignmentArguments = [selected]
            }
          query = Djex.QueryRequest
            { Djex.requestTarget = target
            , Djex.requestGoal = goal
            , Djex.requestContexts = []
            , Djex.requestOptions = Djex.defaultExferenceOptions
                { Djex.exferenceMaximumSteps = 16 }
            }
      environment <- expectRight
        (Djex.mkEnvironment [declaration] ::
          Either (Djex.EnvironmentError Djex.ExferenceTypeVariable)
            Djex.ExferenceEnvironment)
      exferenceSession <- expectRight $ Djex.mkExferenceSession environment
      session <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits
        (Djex.exferenceSessionInventory exferenceSession)
        Length.BuiltinListSpine [provider]
      contract <- expectRight $ Length.sealLengthContractInContext
        Length.defaultLengthLimits
        (LengthProblem.checkedLengthSessionContext session)
        goal trivialLengthContract
      request <- expectRight $ Djex.mkExferenceRequest query
      results <- expectRight $
        Djex.runExferenceTypedQueryWithInstantiationAssignments
          exferenceSession [assignment] request
      candidate <- case
          [ value
          | result <- results
          , value <- Djex.batchCandidates $ Djex.resultSearch result
          , Right graph <- [Djex.typedCandidateTermGraph value]
          , any certifiedVisibleApplication $ Djex.termGraphNodes graph
          ] of
        value : _ -> pure value
        [] -> assertFailure
          "the exact-scheme query retained no associated specialization"
      projected <- expectRight $ Djex.typedCandidateTermGraph candidate
      case Djex.fingerprintSharedTermGraph Djex.defaultTermGraphLimits
          Djex.defaultTermGraphFingerprintByteLimit projected of
        Left Djex.TermGraphFingerprintUnsupportedCertificate{} -> pure ()
        Left failure -> assertFailure $
          "unexpected bare associated fingerprint rejection: " ++ show failure
        Right _ -> assertFailure
          "the bare associated graph gained public fingerprint authority"
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract candidate
      let checkedCandidate = LengthProblem.checkedLengthProblemCandidate problem
      LengthProblem.checkedLengthCandidateResult checkedCandidate @?=
        Length.LengthLiteral 0
      LengthProblem.checkedLengthCandidateUsedProviders checkedCandidate @?=
        [providerName]
  , testCase
      "discharge a real Exference C Int provider before SMT lowering" $ do
      integerName <- expectName "Int"
      className <- expectName "C"
      providerName <- expectName "Fixture.exferenceConditionalProvider"
      targetName <- expectName "exferenceConditionalLengthCandidate"
      target <- expectRight $ Djex.mkDefinitionName targetName
      let binder = FlexibleVariable 0
          classBinder = FlexibleVariable 1
          integerType = TypeConstructor integerName
          scheme = ForallType [binder]
            [Constraint className [TypeVariable binder]]
            $ TypeApplication (TypeConstructor listName)
            $ TypeVariable binder
          goal = TypeApplication (TypeConstructor listName) integerType
          obligation = Constraint className [integerType]
          declarations =
            [ AbstractTypeDeclaration () integerName ProperTypeKind
            , ClassDeclaration () className
                [TypeParameter classBinder (Just ProperTypeKind)] [] []
            , InstanceDeclaration () [] [] obligation
            , ValueDeclaration $ ValueSignature () providerName scheme
            ]
          provider = Length.AssumedConstraintConditionalProviderSummary
            { Length.lengthProviderName = providerName
            , Length.lengthProviderScheme = scheme
            , Length.lengthProviderArgumentRoles = []
            , Length.lengthProviderTransfer = Length.LengthLiteral 0
            }
          query = Djex.QueryRequest
            { Djex.requestTarget = target
            , Djex.requestGoal = goal
            , Djex.requestContexts = []
            , Djex.requestOptions = Djex.defaultExferenceOptions
                { Djex.exferenceMaximumSteps = 32 }
            }
      environment <- expectRight
        (Djex.mkEnvironment declarations ::
          Either (Djex.EnvironmentError Djex.ExferenceTypeVariable)
            Djex.ExferenceEnvironment)
      exferenceSession <- expectRight $ Djex.mkExferenceSession environment
      session <- expectRight $ LengthProblem.sealLengthSession
        Length.defaultLengthLimits
        (Djex.exferenceSessionInventory exferenceSession)
        Length.BuiltinListSpine [provider]
      contract <- expectRight $ Length.sealLengthContractInContext
        Length.defaultLengthLimits
        (LengthProblem.checkedLengthSessionContext session)
        goal trivialLengthContract
      request <- expectRight $ Djex.mkExferenceRequest query
      results <- expectRight $
        Djex.runExferenceTypedQuery exferenceSession request
      candidate <- case
          [ value
          | result <- results
          , value <- Djex.batchCandidates $ Djex.resultSearch result
          , null $ Djex.candidateResidualConstraints
              $ Djex.typedCandidateCompatibility value
          , Right graph <- [Djex.typedCandidateTermGraph value]
          , any certifiedVisibleApplication $ Djex.termGraphNodes graph
          ] of
        value : _ -> pure value
        [] -> assertFailure
          "the C Int query retained no residual-free specialization"
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract candidate
      let checkedCandidate = LengthProblem.checkedLengthProblemCandidate problem
          candidateBytes = Fingerprint.fingerprintCanonicalBytes
            $ LengthProblem.checkedLengthCandidateFingerprint checkedCandidate
          policyBytes = Fingerprint.fingerprintCanonicalBytes
            $ LengthProblem.lengthSessionEncodingPolicyFingerprint session
          encodingBytes = Fingerprint.fingerprintCanonicalBytes
            $ LengthProblem.checkedLengthProblemEncodingFingerprint problem
          uniformEvidence = asciiBytes
            "provider-law-uniform-over-dictionary-evidence/v1"
      LengthProblem.checkedLengthCandidateResult checkedCandidate @?=
        Length.LengthLiteral 0
      LengthProblem.checkedLengthCandidateUsedProviders checkedCandidate @?=
        [providerName]
      take 10 policyBytes @?= fingerprintVersionPrefix 8
      take 10 candidateBytes @?= fingerprintVersionPrefix 3
      take 10 encodingBytes @?= fingerprintVersionPrefix 4
      assertBool "conditional candidate omitted evidence uniformity" $
        uniformEvidence `isInfixOf` candidateBytes
      _ <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      pure ()
  , testCase "sanitize missing owner, source, and provider authority" $ do
      providerName <- expectName "Fixture.missingAssociatedAuthority"
      let scheme = associatedProviderScheme "missing-authority-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
      checked <- associatedProviderCertificateGraph
        providerName scheme selected result [] 7 0 1 10 11
      contractSource <- pure trivialLengthContract
      missingSession <- adversarialLengthSession [] []
      missingContract <- adversarialLengthContract
        missingSession result contractSource
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateOwnerMissing
          providerName 0)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            missingSession missingContract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked

      let sourceBinder = FlexibleVariable "source-mismatch-element"
          vacuousBinder = FlexibleVariable "source-mismatch-vacuous"
          sourceScheme = ForallType [sourceBinder, vacuousBinder] []
            $ adversarialListOf $ TypeVariable sourceBinder
          retainedBinder = FlexibleVariable "retained-vacuous"
          specializedScheme = ForallType [retainedBinder] [] result
          mismatchDeclaration = ValueDeclaration
            $ ValueSignature () providerName sourceScheme
          mismatchProvider = associatedProviderSummary
            providerName sourceScheme
      mismatched <- associatedProviderCertificateGraph
        providerName specializedScheme selected result [] 7 0 1 10 11
      mismatchSession <- adversarialLengthSession
        [mismatchDeclaration] [mismatchProvider]
      mismatchContract <- adversarialLengthContract
        mismatchSession result contractSource
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateSourceSchemeMismatch
          providerName 0)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            mismatchSession mismatchContract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility mismatched

      let exactDeclaration = ValueDeclaration
            $ ValueSignature () providerName scheme
      noSummarySession <- adversarialLengthSession [exactDeclaration] []
      noSummaryContract <- adversarialLengthContract
        noSummarySession result contractSource
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateProviderSummaryMissing
          providerName 0)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            noSummarySession noSummaryContract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  , testCase
      "sanitize missing evidence for an associated conditional provider" $ do
      providerName <- expectName "Fixture.contextualAssociatedProvider"
      className <- expectName "Fixture.AssociatedConstraint"
      let binder = FlexibleVariable "contextual-associated-element"
          classBinder = FlexibleVariable "contextual-class-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
          scheme = ForallType [binder]
            [Constraint className [TypeVariable binder]]
            $ adversarialListOf $ TypeVariable binder
          declaration = ValueDeclaration
            $ ValueSignature () providerName scheme
          classDeclaration = ClassDeclaration () className
            [TypeParameter classBinder (Just ProperTypeKind)] [] []
          obligations = [Constraint className [selected]]
          provider = associatedConditionalProviderSummary providerName scheme
      checked <- associatedProviderCertificateGraph
        providerName scheme selected result obligations 7 0 1 10 11
      noSummarySession <- adversarialLengthSession
        [classDeclaration, declaration] []
      noSummaryContract <- adversarialLengthContract
        noSummarySession result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateActivatedObligations
          providerName 0 0 1)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            noSummarySession noSummaryContract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
      session <- adversarialLengthSession
        [classDeclaration, declaration] [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateConstraintDischargeRejected
          providerName 0 0 0
          LengthProblem.LengthAssociatedConstraintEvidenceMissing)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  , testCase
      "sanitize a quantified activated constraint as a rejected query" $ do
      providerName <- expectName "Fixture.quantifiedConditionalProvider"
      className <- expectName "Fixture.QuantifiedAssociatedConstraint"
      let binder = FlexibleVariable "quantified-provider-element"
          classBinder = FlexibleVariable "quantified-class-element"
          selectedBinder = FlexibleVariable "quantified-selected-element"
          selected = ForallType [selectedBinder] []
            $ FunctionType
                (TypeVariable selectedBinder)
                (TypeVariable selectedBinder)
          result = adversarialListOf selected
          scheme = ForallType [binder]
            [Constraint className [TypeVariable binder]]
            $ adversarialListOf $ TypeVariable binder
          obligation = Constraint className [selected]
          declarations =
            [ ClassDeclaration () className
                [TypeParameter classBinder (Just ProperTypeKind)] [] []
            , ValueDeclaration $ ValueSignature () providerName scheme
            ]
          provider = associatedConditionalProviderSummary
            providerName scheme
      checked <- associatedProviderCertificateGraph
        providerName scheme selected result [obligation] 7 0 1 10 11
      session <- adversarialLengthSession declarations [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateConstraintDischargeRejected
          providerName 0 0 0
          LengthProblem.LengthAssociatedConstraintQueryRejected)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  , testCase
      "report the final step and second missing obligation canonically" $ do
      providerName <- expectName "Fixture.twoObligationConditionalProvider"
      firstClass <- expectName "Fixture.FirstAssociatedConstraint"
      secondClass <- expectName "Fixture.SecondAssociatedConstraint"
      let firstBinder = FlexibleVariable "two-obligation-first"
          secondBinder = FlexibleVariable "two-obligation-second"
          firstClassBinder = FlexibleVariable "first-constraint-element"
          secondClassBinder = FlexibleVariable "second-constraint-element"
          firstSelected = TupleType Boxed []
          secondSelected = FunctionType firstSelected firstSelected
          result = adversarialListOf firstSelected
          scheme = ForallType [firstBinder, secondBinder]
            [ Constraint firstClass [TypeVariable firstBinder]
            , Constraint secondClass [TypeVariable secondBinder]
            ] $ adversarialListOf $ TypeVariable firstBinder
          firstResult = ForallType [secondBinder]
            [ Constraint firstClass [firstSelected]
            , Constraint secondClass [TypeVariable secondBinder]
            ] result
          firstObligation = Constraint firstClass [firstSelected]
          secondObligation = Constraint secondClass [secondSelected]
          declarations =
            [ ClassDeclaration () firstClass
                [TypeParameter firstClassBinder (Just ProperTypeKind)] [] []
            , ClassDeclaration () secondClass
                [TypeParameter secondClassBinder (Just ProperTypeKind)] [] []
            , InstanceDeclaration () [] [] firstObligation
            , ValueDeclaration $ ValueSignature () providerName scheme
            ]
          provider = associatedConditionalProviderSummary
            providerName scheme
      checked <- twoStepAssociatedProviderCertificateGraph
        providerName scheme firstSelected firstResult secondSelected result
        [firstObligation, secondObligation]
      session <- adversarialLengthSession declarations [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateConstraintDischargeRejected
          providerName 0 1 1
          LengthProblem.LengthAssociatedConstraintEvidenceMissing)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  , testCase "fail closed when the session resolver cannot seal" $ do
      integerName <- expectName "Fixture.ResolverUnavailableInt"
      className <- expectName "Fixture.ResolverUnavailableConstraint"
      providerName <- expectName "Fixture.resolverUnavailableProvider"
      let binder = FlexibleVariable "resolver-unavailable-element"
          classBinder = FlexibleVariable "resolver-unavailable-class-element"
          instanceBinder = FlexibleVariable
            "resolver-unavailable-instance-element"
          selected = TypeConstructor integerName
          result = adversarialListOf selected
          scheme = ForallType [binder]
            [Constraint className [TypeVariable binder]]
            $ adversarialListOf $ TypeVariable binder
          genericHead = Constraint className [TypeVariable instanceBinder]
          obligation = Constraint className [selected]
          declarations =
            [ AbstractTypeDeclaration () integerName ProperTypeKind
            , ClassDeclaration () className
                [TypeParameter classBinder (Just ProperTypeKind)] [] []
            , InstanceDeclaration () [instanceBinder] [] genericHead
            , InstanceDeclaration () [] [] obligation
            , ValueDeclaration $ ValueSignature () providerName scheme
            ]
          provider = associatedConditionalProviderSummary
            providerName scheme
      checked <- associatedProviderCertificateGraph
        providerName scheme selected result [obligation] 7 0 1 10 11
      session <- adversarialLengthSession declarations [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateConstraintDischargeRejected
          providerName 0 0 0
          LengthProblem.LengthAssociatedClassResolverUnavailable)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  , testCase "authorize a final receipt nested through a let local" $ do
      providerName <- expectName "Fixture.nestedConditionalProvider"
      className <- expectName "Fixture.NestedConditionalConstraint"
      let binder = FlexibleVariable "nested-conditional-element"
          classBinder = FlexibleVariable "nested-constraint-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
          scheme = ForallType [binder]
            [Constraint className [TypeVariable binder]]
            $ adversarialListOf $ TypeVariable binder
          obligation = Constraint className [selected]
          declarations =
            [ ClassDeclaration () className
                [TypeParameter classBinder (Just ProperTypeKind)] [] []
            , InstanceDeclaration () [] [] obligation
            , ValueDeclaration $ ValueSignature () providerName scheme
            ]
          provider = associatedConditionalProviderSummary
            providerName scheme
      checked <- associatedProviderLetLocalCertificateGraph
        providerName scheme selected result [obligation]
      session <- adversarialLengthSession declarations [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract
        $ associatedAdversarialTypedCandidate adversarialCompatibility checked
      let candidate = LengthProblem.checkedLengthProblemCandidate problem
      LengthProblem.checkedLengthCandidateResult candidate @?=
        Length.LengthLiteral 0
      LengthProblem.checkedLengthCandidateUsedProviders candidate @?=
        [providerName]
  , testCase
      "reject a separate same-provider occurrence after ground discharge" $ do
      providerName <- expectName "Fixture.occurrenceConditionalProvider"
      className <- expectName "Fixture.OccurrenceConditionalConstraint"
      let binder = FlexibleVariable "occurrence-conditional-element"
          classBinder = FlexibleVariable "occurrence-constraint-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
          scheme = ForallType [binder]
            [Constraint className [TypeVariable binder]]
            $ adversarialListOf $ TypeVariable binder
          obligation = Constraint className [selected]
          declarations =
            [ ClassDeclaration () className
                [TypeParameter classBinder (Just ProperTypeKind)] [] []
            , InstanceDeclaration () [] [] obligation
            , ValueDeclaration $ ValueSignature () providerName scheme
            ]
          provider = associatedConditionalProviderSummary
            providerName scheme
      checked <- associatedConditionalGraphWithDirectOwner
        providerName scheme selected result [obligation]
      session <- adversarialLengthSession declarations [provider]
      contract <- adversarialLengthContract session result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemConditionalProviderRequiresDischarge
          (Djex.termNodeId 2) providerName)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  , testCase
      "reject a direct conditional occurrence after associated authority" $ do
      associatedName <- expectName "Fixture.associatedLegacyProvider"
      conditionalName <- expectName "Fixture.associatedConditionalProvider"
      className <- expectName "Fixture.AssociatedConditionalConstraint"
      let associatedScheme = associatedProviderScheme
            "associated-legacy-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
          conditionalScheme = ForallType [] [Constraint className []] result
          declarations =
            [ ClassDeclaration () className [] [] []
            , ValueDeclaration
                $ ValueSignature () associatedName associatedScheme
            , ValueDeclaration
                $ ValueSignature () conditionalName conditionalScheme
            ]
          associatedProvider = associatedProviderSummary
            associatedName associatedScheme
          conditionalProvider =
            Length.AssumedConstraintConditionalProviderSummary
            { Length.lengthProviderName = conditionalName
            , Length.lengthProviderScheme = conditionalScheme
            , Length.lengthProviderArgumentRoles = []
            , Length.lengthProviderTransfer = Length.LengthLiteral 0
            }
      checked <- associatedGraphWithDirectConditionalProvider
        associatedName associatedScheme selected result
        conditionalName conditionalScheme
      session <- adversarialLengthSession
        declarations [associatedProvider, conditionalProvider]
      contract <- adversarialLengthContract
        session result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemConditionalProviderRequiresDischarge
          (Djex.termNodeId 2) conditionalName)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  , testCase "keep associated modeled constructors outside this checkpoint" $ do
      let scheme = associatedProviderScheme "associated-constructor-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
      checked <- associatedProviderCertificateGraph
        listName scheme selected result [] 7 0 1 10 11
      session <- adversarialLengthSession [] []
      contract <- adversarialLengthContract session result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemAssociatedCertificateModeledConstructorUnsupported
          listName 0)
        $ LengthProblem.sealLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  , testCase "reject residuals before demanding an associated carrier" $ do
      className <- expectName "Fixture.ResidualBeforeAssociation"
      session <- adversarialLengthSession [] []
      contract <- adversarialLengthContract
        session adversarialClosedList trivialLengthContract
      let residual = Constraint className [adversarialClosedList]
          compatibility = adversarialCompatibility
            { Djex.candidateResidualConstraints = [residual] }
          candidate :: AdversarialCandidate
          candidate = unsafeCoerce $
            InternalTypedCandidate.mkCertificateAssociatedTypedCandidate
              compatibility
              (error "residual rejection demanded the associated carrier" ::
                Either String AdversarialCertificateGraph)
      result <- evaluateWithin $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract candidate
      assertLeft (LengthProblem.LengthProblemResidualConstraint residual) result
  , testCase "enforce graph bytes before associated authorization" $ do
      providerName <- expectName "Fixture.associatedByteLimitProvider"
      let scheme = associatedProviderScheme "byte-limit-element"
          selected = TupleType Boxed []
          result = adversarialListOf selected
      checked <- associatedProviderCertificateGraph
        providerName scheme selected result [] 7 0 1 10 11
      noGraphBytes <- expectRight $ LengthProblem.mkLengthProblemLimits
        Djex.defaultTermGraphLimits 0 65536

      missingSession <- adversarialLengthSession [] []
      missingContract <- adversarialLengthContract
        missingSession result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemTermGraphFingerprintRejected
          $ Djex.TermGraphFingerprintByteLimitExceeded 0 1)
        $ LengthProblem.sealLengthTypedCandidateProblem noGraphBytes
            missingSession missingContract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked

      let declaration = ValueDeclaration
            $ ValueSignature () providerName scheme
          provider = associatedProviderSummary providerName scheme
      authorizedSession <- adversarialLengthSession [declaration] [provider]
      authorizedContract <- adversarialLengthContract
        authorizedSession result trivialLengthContract
      assertLeft
        (LengthProblem.LengthProblemTermGraphFingerprintRejected
          $ Djex.TermGraphFingerprintByteLimitExceeded 0 1)
        $ LengthProblem.sealLengthTypedCandidateProblem noGraphBytes
            authorizedSession authorizedContract
            $ associatedAdversarialTypedCandidate
                adversarialCompatibility checked
  ]

spinePairProblemTests :: TestTree
spinePairProblemTests = testGroup
  "binary product-of-spines candidate problems"
  [ testCase
      "interpret both tuple fields and replay a relational violation" $ do
      let input = Length.LengthVariable $ Length.LengthSpinePairInput 0
          firstResult = pairResultVariable Length.LengthSpinePairFirst
          secondResult = pairResultVariable Length.LengthSpinePairSecond
          relational = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthAll
                [ Length.LengthEqual firstResult input
                , Length.LengthEqual secondResult input
                ]
      problem <- adversarialInputAndZeroSpinePairProblem relational
      let checked = LengthProblem.checkedLengthSpinePairProblemCandidate problem
          symbolic = LengthProblem.checkedLengthSpinePairCandidateResult checked
      Length.lengthSpinePairFirst symbolic @?=
        Length.LengthVariable (Length.LengthInput 0)
      Length.lengthSpinePairSecond symbolic @?= Length.LengthLiteral 0
      LengthProblem.checkedLengthSpinePairCandidateUsedProviders checked @?= []
      LengthProblem.checkedLengthSpinePairProblemInputCount problem @?= 1
      Djex.behavioralProblemDomain
          (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem problem)
        @?= Length.finiteBinaryProductSpineLengthsDomainTag
      force problem `seq` pure ()

      expectNoCounterexample
        $ Evaluate.validateLengthSpinePairProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits problem
            $ Evaluate.LengthProblemAssignment [0]
      evidence <- expectCounterexample
        $ Evaluate.validateLengthSpinePairProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits problem
            $ Evaluate.LengthProblemAssignment [3]
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem problem)
        evidence
      Evaluate.validatedLengthSpinePairCounterexampleInputs receipt @?= [3]
      Evaluate.validatedLengthSpinePairCounterexampleResult receipt @?=
        Length.LengthSpinePair 3 0
      Evaluate.validatedLengthSpinePairCounterexampleBasis receipt @?=
        Evaluate.ProviderIndependentFiniteSpineModel
      force receipt `seq` pure ()

      stale <- adversarialInputAndZeroSpinePairProblem
        trivialSpinePairContract
      assertLeft Djex.ReplayEncodingFingerprintMismatch
        $ Djex.replayBehavioralEvidence
            (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem stale)
            evidence

      scalar <- adversarialConstantZeroProblem identityLengthContract
      let forgedScalarDomainEvidence = unsafeCoerce evidence
            :: SemanticProblem.BehavioralEvidence
                Length.FiniteListSpineLengthV1
                Evaluate.ValidatedLengthSpinePairCounterexample
      assertLeft Djex.ReplayDomainMismatch
        $ Djex.replayBehavioralEvidence
            (LengthProblem.checkedLengthProblemBehavioralProblem scalar)
            forgedScalarDomainEvidence
  , testCase
      "union scalar providers while preserving left and right tuple results" $ do
      (expectedProviders, problem) <- adversarialProviderSpinePairProblem
      let checked = LengthProblem.checkedLengthSpinePairProblemCandidate problem
          symbolic = LengthProblem.checkedLengthSpinePairCandidateResult checked
      Length.lengthSpinePairFirst symbolic @?= Length.LengthLiteral 11
      Length.lengthSpinePairSecond symbolic @?= Length.LengthLiteral 22
      LengthProblem.checkedLengthSpinePairCandidateUsedProviders checked @?=
        expectedProviders
      evidence <- expectCounterexample
        $ Evaluate.validateLengthSpinePairProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits problem
            $ Evaluate.LengthProblemAssignment []
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem problem)
        evidence
      Evaluate.validatedLengthSpinePairCounterexampleResult receipt @?=
        Length.LengthSpinePair 11 22
      Evaluate.validatedLengthSpinePairCounterexampleBasis receipt @?=
        Evaluate.FiniteSpineModelUnderAssumedProviderLaws expectedProviders
  , testCase "force the first tuple field before the second" $ do
      result <- adversarialOpaqueComponentsSpinePairProblem
      assertLeft
        (LengthProblem.LengthSpinePairProblemUnobservedTargetArgumentDemanded
          0 $ LengthProblem.LengthUnobservedTargetSpineDemand
            $ Djex.termNodeId 3)
        result
  , testCase
      "bound detached pair assignment results in source component order" $ do
      let spine = listOf closedPayloadType
          target = TupleType Boxed [spine, spine]
      contract <- expectRight $ sealSpinePairContract
        Length.defaultLengthLimits target trivialSpinePairContract
      assertLeft
        (Evaluate.LengthSpinePairEvaluationValueBitLimitExceeded
          (Evaluate.LengthSpinePairContractResultValue
            Length.LengthSpinePairFirst)
          2 3)
        $ Evaluate.evaluateLengthSpinePairContractAssignment
            (evaluationLimitsWith 2 8) contract
            $ Evaluate.LengthSpinePairContractAssignment []
            $ Length.LengthSpinePair 4 8
  , testCase
      "bind complete finite-box evidence to the nominal product problem" $ do
      Evaluate.lengthSpinePairInputBoxValidationSchemaTag @?=
        asciiBytes
          "finite-binary-product-spine-lengths/bounded-input-box-validation/v1"
      assertBool "pair validation reused the scalar receipt schema" $
        Evaluate.lengthSpinePairInputBoxValidationSchemaTag /=
          Evaluate.lengthInputBoxValidationSchemaTag
      let input = Length.LengthVariable $ Length.LengthSpinePairInput 0
          safeSource = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthAll
                [ Length.LengthEqual
                    (pairResultVariable Length.LengthSpinePairFirst) input
                , Length.LengthEqual
                    (pairResultVariable Length.LengthSpinePairSecond)
                    $ Length.LengthLiteral 0
                ]
      safeProblem <- adversarialInputAndZeroSpinePairProblem safeSource
      validation <- expectRight
        $ Evaluate.validateLengthSpinePairProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits safeProblem [2]
      safeEvidence <- case validation of
        Evaluate.LengthInputBoxValidated evidence -> pure evidence
        Evaluate.LengthInputBoxCounterexample{} -> assertFailure
          "the safe product box produced a counterexample" >> error "unreachable"
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem
          safeProblem)
        safeEvidence
      Evaluate.validatedLengthSpinePairInputBoxInclusiveMaximums receipt @?=
        [2]
      Evaluate.validatedLengthSpinePairInputBoxAssignmentCount receipt @?= 3
      Evaluate.validatedLengthSpinePairInputBoxApplicableAssignmentCount
          receipt @?= 3
      Evaluate.validatedLengthSpinePairInputBoxBasis receipt @?=
        Evaluate.ProviderIndependentFiniteSpineModel
      force receipt `seq` pure ()

      stale <- adversarialInputAndZeroSpinePairProblem
        trivialSpinePairContract
      assertLeft Djex.ReplayEncodingFingerprintMismatch
        $ Djex.replayBehavioralEvidence
            (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem stale)
            safeEvidence
      scalar <- adversarialConstantZeroProblem trivialLengthContract
      let forgedScalarDomainEvidence = unsafeCoerce safeEvidence
            :: SemanticProblem.BehavioralEvidence
                Length.FiniteListSpineLengthV1
                Evaluate.ValidatedLengthSpinePairInputBox
      assertLeft Djex.ReplayDomainMismatch
        $ Djex.replayBehavioralEvidence
            (LengthProblem.checkedLengthProblemBehavioralProblem scalar)
            forgedScalarDomainEvidence
  , testCase
      "stop product-box traversal at its first relational violation" $ do
      let input = Length.LengthVariable $ Length.LengthSpinePairInput 0
          relational = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthAll
                [ Length.LengthEqual
                    (pairResultVariable Length.LengthSpinePairFirst) input
                , Length.LengthEqual
                    (pairResultVariable Length.LengthSpinePairSecond) input
                ]
      problem <- adversarialInputAndZeroSpinePairProblem relational
      validation <- expectRight
        $ Evaluate.validateLengthSpinePairProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits problem [2]
      evidence <- case validation of
        Evaluate.LengthInputBoxCounterexample value -> pure value
        Evaluate.LengthInputBoxValidated{} -> assertFailure
          "the violating product box returned positive evidence"
            >> error "unreachable"
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem problem)
        evidence
      Evaluate.validatedLengthSpinePairCounterexampleInputs receipt @?= [1]
      Evaluate.validatedLengthSpinePairCounterexampleResult receipt @?=
        Length.LengthSpinePair 1 0
      assertLeft
        (Evaluate.LengthSpinePairInputBoxMaximumValueRejected 0
          $ Evaluate.LengthSpinePairEvaluationValueBitLimitExceeded
              (Evaluate.LengthSpinePairProblemInputValue 0) 2 3)
        $ Evaluate.validateLengthSpinePairProblemInputBox
            (evaluationLimitsWith 2 8)
            Evaluate.defaultLengthInputBoxLimits problem [4]
  , testCase "reject pair sealer/case-policy mismatches before graph demand" $ do
      let resultType = TupleType Boxed
            [adversarialClosedList, adversarialClosedList]
          poisonCandidate = adversarialTypedCandidate
            $ error "pair case mismatch demanded the candidate graph"
      ordinarySession <- adversarialLengthSession [] []
      ordinaryContract <- adversarialLengthSpinePairContract
        ordinarySession resultType trivialSpinePairContract
      ordinaryResult <- evaluateWithin
        $ LengthProblem.sealExactSpineCaseLengthSpinePairTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            ordinarySession ordinaryContract poisonCandidate
      assertLeft LengthProblem.LengthSpinePairProblemCasePolicyMismatch
        ordinaryResult

      exactSession <- adversarialExactCaseLengthSession [] [] []
      exactContract <- adversarialLengthSpinePairContract
        exactSession resultType trivialSpinePairContract
      exactResult <- evaluateWithin
        $ LengthProblem.sealLengthSpinePairTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactSession exactContract poisonCandidate
      assertLeft LengthProblem.LengthSpinePairProblemCasePolicyMismatch
        exactResult
  , testCase "publish closed source-ordered result-shape diagnostics" $ do
      let node = Djex.termNodeId 7
          occurrence = Djex.occurrenceId 8
          failures =
            [ LengthProblem.LengthSpinePairProblemExpectedResultTuple node
            , LengthProblem.LengthSpinePairProblemResultTupleArityMismatch
                node 3
            , LengthProblem.LengthSpinePairProblemResultComponentExpectedSpine
                Length.LengthSpinePairFirst node
            , LengthProblem.LengthSpinePairProblemResultTupleDemandedUnobservedTarget
                0 node
            , LengthProblem.LengthSpinePairProblemResultTupleDemandedStepPayload
                occurrence node
            ] :: [LengthProblem.LengthSpinePairProblemError String String Int]
      length failures @?= 5
      force failures `seq` pure ()
  , testCase
      "check pair assignment and finite-box shape before values or traversal" $ do
      unary <- adversarialInputAndZeroSpinePairProblem
        trivialSpinePairContract
      let cyclicInputs = 0 : cyclicInputs
      cyclic <- evaluateWithin
        $ Evaluate.validateLengthSpinePairProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits unary
            $ Evaluate.LengthProblemAssignment cyclicInputs
      assertLeft
        (Evaluate.LengthSpinePairProblemAssignmentArityMismatch 1 2)
        cyclic

      narrow <- inputBoxLimits 0 8
      width <- evaluateWithin
        $ Evaluate.validateLengthSpinePairProblemInputBox
            (error "pair box width demanded evaluation limits")
            narrow unary
            (error "pair box width demanded raw maximums")
      assertLeft
        (Evaluate.LengthSpinePairInputBoxProblemInputLimitExceeded 0 1)
        width
      assertLeft
        (Evaluate.LengthSpinePairInputBoxBoundsArityMismatch 1 0)
        $ Evaluate.validateLengthSpinePairProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits unary []
      oneAssignment <- inputBoxLimits 1 1
      assertLeft
        (Evaluate.LengthSpinePairInputBoxAssignmentLimitExceeded 1 2)
        $ Evaluate.validateLengthSpinePairProblemInputBox
            Evaluate.defaultLengthEvaluationLimits oneAssignment unary [1]

      nullary <- adversarialNullaryZeroSpinePairProblem
        trivialSpinePairContract
      nullaryValidation <- expectRight
        $ Evaluate.validateLengthSpinePairProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits nullary []
      evidence <- case nullaryValidation of
        Evaluate.LengthInputBoxValidated value -> pure value
        Evaluate.LengthInputBoxCounterexample{} -> assertFailure
          "the trivial nullary product box produced a counterexample"
            >> error "unreachable"
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem nullary)
        evidence
      Evaluate.validatedLengthSpinePairInputBoxAssignmentCount receipt @?= 1
      Evaluate.validatedLengthSpinePairInputBoxApplicableAssignmentCount
          receipt @?= 1
  ]

spinePairSMTLibTests :: TestTree
spinePairSMTLibTests = testGroup
  "binary product-of-spines QF_LIA queries and replay"
  [ testCase
      "freeze the product stack and distinguish equal scalar query bytes" $ do
      let input = Length.LengthVariable $ Length.LengthSpinePairInput 0
          source = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (pairResultVariable Length.LengthSpinePairSecond) input
      session <- adversarialLengthSession [] []
      contract <- adversarialLengthSpinePairContract
        session adversarialInputSpinePairTarget source
      graph <- adversarialInputAndZeroSpinePairGraph
      problem <- expectRight
        $ LengthProblem.sealLengthSpinePairTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits session contract
        $ adversarialTypedCandidate $ Right graph
      query <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      scalarProblem <- adversarialConstantZeroProblem identityLengthContract
      scalarQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits scalarProblem

      SMTLib.lengthSpinePairSMTLibQuerySchemaTag @?=
        asciiBytes "djex-length-spine-pair-z3-qf-lia-smtlib2/v1"
      SMTLib.lengthSpinePairSMTLibQueryLogic @?= asciiBytes "QF_LIA"
      SMTLib.lengthSpinePairSMTLibQueryInputSymbols query @?=
        [asciiBytes "djex_length_input_0"]
      SMTLib.lengthSpinePairSMTLibQueryCheckBytes query @?=
        asciiBytes constantZeroSMTLibCheck
      SMTLib.lengthSpinePairSMTLibQueryCheckBytes query @?=
        SMTLib.lengthSMTLibQueryCheckBytes scalarQuery
      SMTLib.lengthSpinePairSMTLibQueryInputValueRequestBytes query @?=
        Just (asciiBytes "(get-value (djex_length_input_0))\n")
      Djex.behavioralProblemDomain
          (SMTLib.lengthSpinePairSMTLibQueryBehavioralProblem query) @?=
        Length.finiteBinaryProductSpineLengthsDomainTag

      let scalarKey = Fingerprint.fingerprintCanonicalBytes
            $ SMTLib.lengthSMTLibQueryFingerprint scalarQuery
          productKey = Fingerprint.fingerprintCanonicalBytes
            $ SMTLib.lengthSpinePairSMTLibQueryFingerprint query
      assertBool "the nominal product query reused scalar query identity"
        $ productKey /= scalarKey
      take 10 productKey @?= fingerprintVersionPrefix 1
      assertBool "the product query role was absent from identity"
        $ asciiBytes
            "finite-binary-product-spine-lengths/z3-qf-lia-query"
              `isInfixOf` productKey
      assertBool "the product query schema was absent from identity"
        $ SMTLib.lengthSpinePairSMTLibQuerySchemaTag `isInfixOf` productKey

      let candidate =
            LengthProblem.checkedLengthSpinePairProblemCandidate problem
          snapshots =
            [ canonicalFingerprintSHA256
                $ Length.lengthSpinePairContractFingerprint contract
            , canonicalFingerprintSHA256
                $ LengthProblem.checkedLengthSpinePairCandidateFingerprint
                    candidate
            , canonicalFingerprintSHA256
                $ LengthProblem.checkedLengthSpinePairProblemEncodingFingerprint
                    problem
            , canonicalFingerprintSHA256
                $ Djex.behavioralProblemFingerprint
                $ LengthProblem.checkedLengthSpinePairProblemBehavioralProblem
                    problem
            , canonicalFingerprintSHA256
                $ SMTLib.lengthSpinePairSMTLibQueryFingerprint query
            ]
      snapshots @?=
        [ "cb618f6bafba54ec2a74e424f75bdf6c292d4e659c33376163d93d48196050a3"
        , "208fd12c5eb2dd4f303937cc306d001e2ed07f996c1b29cdf51ca3a428e4a880"
        , "a253873a60982052609096e00e84ef8fdf94808b6831fcdce36f30fe0faccf18"
        , "00ee1f5688909a57af53078023fe1ea733c9b3dc0792182cfc70eb04d85e3d94"
        , "f6a0c66de9b0406719b5f97a448e26cd2d87b5ecdb12ba8a48d65baed7e64763"
        ]
  , testCase
      "lower both ordered result relations but request only compact inputs" $ do
      let input = Length.LengthVariable $ Length.LengthSpinePairInput 0
          source = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthAll
                [ Length.LengthEqual
                    (pairResultVariable Length.LengthSpinePairFirst)
                    $ Length.LengthSum [input, Length.LengthLiteral 1]
                , Length.LengthEqual
                    (pairResultVariable Length.LengthSpinePairSecond) input
                ]
      problem <- adversarialInputAndZeroSpinePairProblem source
      query <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      SMTLib.lengthSpinePairSMTLibQueryCheckBytes query @?=
        asciiBytes spinePairRelationalSMTLibCheck
      SMTLib.lengthSpinePairSMTLibQueryInputSymbols query @?=
        [asciiBytes "djex_length_input_0"]
      SMTLib.lengthSpinePairSMTLibQueryInputValueRequestBytes query @?=
        Just (asciiBytes "(get-value (djex_length_input_0))\n")
      let script = SMTLib.lengthSpinePairSMTLibQueryCheckBytes query
      assertBool "a modeled result component escaped into the query"
        $ not $ asciiBytes "result" `isInfixOf` script
      case SMTLib.lengthSpinePairSMTLibQueryInputSymbols query of
        [symbol] -> do
          evidence <- expectCounterexample
            $ SMTLib.validateLengthSpinePairSMTLibCounterexample
                Evaluate.defaultLengthEvaluationLimits query
                [smtIntegerBinding symbol 3]
          receipt <- expectRight $ Djex.replayBehavioralEvidence
            (SMTLib.lengthSpinePairSMTLibQueryBehavioralProblem query)
            evidence
          Evaluate.validatedLengthSpinePairCounterexampleInputs receipt @?=
            [3]
          Evaluate.validatedLengthSpinePairCounterexampleResult receipt @?=
            Length.LengthSpinePair 3 0
          Evaluate.validatedLengthSpinePairCounterexampleBasis receipt @?=
            Evaluate.ProviderIndependentFiniteSpineModel
        symbols -> assertFailure $ "unexpected product input symbols: " ++
          show symbols
  , testCase
      "make decoded, direct, and origin replay agree without stale authority" $
      do
        let input = Length.LengthVariable $ Length.LengthSpinePairInput 0
            source = spinePairContractWith (Length.LengthTruth True)
              $ Length.LengthAll
                  [ Length.LengthEqual
                      (pairResultVariable Length.LengthSpinePairFirst) input
                  , Length.LengthEqual
                      (pairResultVariable Length.LengthSpinePairSecond)
                      $ Length.LengthLiteral 1
                  ]
        problem <- adversarialInputAndZeroSpinePairProblem source
        query <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits problem
        evidence <- case SMTLib.lengthSpinePairSMTLibQueryInputSymbols query of
          [symbol] -> expectCounterexample
            $ SMTLib.validateLengthSpinePairSMTLibCounterexample
                Evaluate.defaultLengthEvaluationLimits query
                [smtIntegerBinding symbol 0]
          symbols -> assertFailure
            ("unexpected product input symbols: " ++ show symbols)
              >> error "unreachable"
        decoded <- expectRight $ Djex.replayBehavioralEvidence
          (SMTLib.lengthSpinePairSMTLibQueryBehavioralProblem query) evidence
        direct <- expectCounterexample
          $ SMTLib.replayLengthSpinePairSMTLibCounterexampleInputs
              Evaluate.defaultLengthEvaluationLimits query [0]
        origin <- expectCounterexample
          $ SMTLib.probeLengthSpinePairSMTLibCounterexampleAtOrigin
              Evaluate.defaultLengthEvaluationLimits query
        decoded @?= direct
        direct @?= origin

        stale <- adversarialInputAndZeroSpinePairProblem
          trivialSpinePairContract
        assertLeft Djex.ReplayEncodingFingerprintMismatch
          $ Djex.replayBehavioralEvidence
              (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem
                stale)
              evidence
        scalar <- adversarialConstantZeroProblem trivialLengthContract
        let forgedScalarEvidence = unsafeCoerce evidence
              :: SemanticProblem.BehavioralEvidence
                  Length.FiniteListSpineLengthV1
                  Evaluate.ValidatedLengthSpinePairCounterexample
        assertLeft Djex.ReplayDomainMismatch
          $ Djex.replayBehavioralEvidence
              (LengthProblem.checkedLengthProblemBehavioralProblem scalar)
              forgedScalarEvidence
  , testCase
      "associate positive and counterexample boxes through the exact query" $
      do
        let input = Length.LengthVariable $ Length.LengthSpinePairInput 0
            safeSource = spinePairContractWith (Length.LengthTruth True)
              $ Length.LengthAll
                  [ Length.LengthEqual
                      (pairResultVariable Length.LengthSpinePairFirst) input
                  , Length.LengthEqual
                      (pairResultVariable Length.LengthSpinePairSecond)
                      $ Length.LengthLiteral 0
                  ]
            violatingSource = spinePairContractWith (Length.LengthTruth True)
              $ Length.LengthAll
                  [ Length.LengthEqual
                      (pairResultVariable Length.LengthSpinePairFirst) input
                  , Length.LengthEqual
                      (pairResultVariable Length.LengthSpinePairSecond) input
                  ]
        safeProblem <- adversarialInputAndZeroSpinePairProblem safeSource
        safeQuery <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits safeProblem
        safe <- expectRight
          $ SMTLib.validateLengthSpinePairSMTLibQueryInputBox
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits safeQuery [2]
        safeReceipt <- case safe of
          Evaluate.LengthInputBoxValidated receipt -> pure receipt
          Evaluate.LengthInputBoxCounterexample{} -> assertFailure
            "the safe product query box produced a counterexample"
              >> error "unreachable"
        Evaluate.validatedLengthSpinePairInputBoxInclusiveMaximums
            safeReceipt @?= [2]
        Evaluate.validatedLengthSpinePairInputBoxAssignmentCount safeReceipt
          @?= 3
        Evaluate.validatedLengthSpinePairInputBoxApplicableAssignmentCount
            safeReceipt @?= 3

        violatingProblem <- adversarialInputAndZeroSpinePairProblem
          violatingSource
        violatingQuery <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits violatingProblem
        violating <- expectRight
          $ SMTLib.validateLengthSpinePairSMTLibQueryInputBox
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits violatingQuery [2]
        counterexample <- case violating of
          Evaluate.LengthInputBoxCounterexample receipt -> pure receipt
          Evaluate.LengthInputBoxValidated{} -> assertFailure
            "the violating product query box produced positive evidence"
              >> error "unreachable"
        Evaluate.validatedLengthSpinePairCounterexampleInputs counterexample
          @?= [1]
        Evaluate.validatedLengthSpinePairCounterexampleResult counterexample
          @?= Length.LengthSpinePair 1 0
  , testCase
      "retain the unioned provider-law basis in a nullary decoded model" $ do
      (providers, problem) <- adversarialProviderSpinePairProblem
      query <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      SMTLib.lengthSpinePairSMTLibQueryInputSymbols query @?= []
      SMTLib.lengthSpinePairSMTLibQueryInputValueRequestBytes query @?= Nothing
      evidence <- expectCounterexample
        $ SMTLib.validateLengthSpinePairSMTLibCounterexample
            Evaluate.defaultLengthEvaluationLimits query []
      decoded <- expectRight $ Djex.replayBehavioralEvidence
        (SMTLib.lengthSpinePairSMTLibQueryBehavioralProblem query) evidence
      origin <- expectCounterexample
        $ SMTLib.probeLengthSpinePairSMTLibCounterexampleAtOrigin
            Evaluate.defaultLengthEvaluationLimits query
      decoded @?= origin
      Evaluate.validatedLengthSpinePairCounterexampleInputs origin @?= []
      Evaluate.validatedLengthSpinePairCounterexampleResult origin @?=
        Length.LengthSpinePair 11 22
      Evaluate.validatedLengthSpinePairCounterexampleBasis origin @?=
        Evaluate.FiniteSpineModelUnderAssumedProviderLaws providers
  , testCase
      "reject malformed models before pair replay and over-arity values" $ do
      problem <- adversarialInputAndZeroSpinePairProblem
        $ spinePairContractWith (Length.LengthTruth True)
        $ Length.LengthEqual
            (pairResultVariable Length.LengthSpinePairSecond)
            (Length.LengthVariable $ Length.LengthSpinePairInput 0)
      query <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      case SMTLib.lengthSpinePairSMTLibQueryInputSymbols query of
        [symbol] -> do
          let validate = SMTLib.validateLengthSpinePairSMTLibCounterexample
                Evaluate.defaultLengthEvaluationLimits query
              unknown = asciiBytes "djex_length_input_9"
          assertLeft
            (SMTLib.LengthSpinePairSMTLibBindingArityMismatch 1 0)
            $ validate []
          assertLeft
            (SMTLib.LengthSpinePairSMTLibUnknownInputSymbol 0 unknown)
            $ validate [smtIntegerBinding unknown 1]
          assertLeft
            (SMTLib.LengthSpinePairSMTLibNegativeInputValue 0 symbol (-1))
            $ validate [smtIntegerBinding symbol (-1)]
          expectNoCounterexample $ validate [smtIntegerBinding symbol 0]
          assertLeft
            (SMTLib.LengthSpinePairSMTLibCounterexampleReplayRejected
              $ Evaluate.LengthSpinePairEvaluationValueBitLimitExceeded
                  (Evaluate.LengthSpinePairProblemInputValue 0) 2 3)
            $ SMTLib.validateLengthSpinePairSMTLibCounterexample
                (evaluationLimitsWith 2 8) query
                [smtIntegerBinding symbol 4]

          let cyclicBindings = smtIntegerBinding symbol 0 : cyclicBindings
          cyclicBindingResult <- evaluateWithin $ validate cyclicBindings
          assertLeft
            (SMTLib.LengthSpinePairSMTLibBindingArityMismatch 1 2)
            cyclicBindingResult
          let cyclicSymbol = fromIntegral (fromEnum 'x') : cyclicSymbol
              symbolLimit = fromIntegral $ length symbol
          cyclicSymbolResult <- evaluateWithin
            $ validate [smtIntegerBinding cyclicSymbol 0]
          assertLeft
            (SMTLib.LengthSpinePairSMTLibBindingSymbolByteLimitExceeded
              0 symbolLimit (symbolLimit + 1))
            cyclicSymbolResult
          let poisonedInputs =
                [ error "pair query replay demanded the first over-arity value"
                , error "pair query replay demanded the extra over-arity value"
                ]
          poisonedResult <- evaluateWithin
            $ SMTLib.replayLengthSpinePairSMTLibCounterexampleInputs
                Evaluate.defaultLengthEvaluationLimits query poisonedInputs
          assertLeft
            (SMTLib.LengthSpinePairSMTLibInputReplayEvaluationRejected
              $ Evaluate.LengthSpinePairProblemAssignmentArityMismatch 1 2)
            poisonedResult
        symbols -> assertFailure $ "unexpected product input symbols: " ++
          show symbols
  , testCase
      "preserve query resource precedence and pair-specific failures" $ do
      let input = Length.LengthVariable $ Length.LengthSpinePairInput 0
          literalSource = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (pairResultVariable Length.LengthSpinePairSecond)
                $ Length.LengthSum [input, Length.LengthLiteral 4]
      problem <- adversarialInputAndZeroSpinePairProblem literalSource
      let makeLimits change = expectRight $ SMTLib.mkLengthSMTLibLimits
            $ change SMTLib.defaultLengthSMTLibLimitSource
      noCommands <- makeLimits $ \source -> source
        { SMTLib.lengthSMTLibLimitSourceCommandBytes = 0
        , SMTLib.lengthSMTLibLimitSourceFingerprintBytes = 0
        }
      assertLeft
        (SMTLib.LengthSpinePairSMTLibCommandByteLimitExceeded
          SMTLib.LengthSMTLibCheckCommand 0 1)
        $ SMTLib.sealLengthSpinePairSMTLibQuery noCommands problem

      noNumerals <- makeLimits $ \source -> source
        { SMTLib.lengthSMTLibLimitSourceNumeralBits = 2 }
      assertLeft
        (SMTLib.LengthSpinePairSMTLibNumeralBitLimitExceeded
          SMTLib.LengthSMTLibLiteralNumeral 2 3)
        $ SMTLib.sealLengthSpinePairSMTLibQuery noNumerals problem

      baseline <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      let commandBytes = fromIntegral $ length
            $ SMTLib.lengthSpinePairSMTLibQueryCheckBytes baseline
      noFingerprint <- makeLimits $ \source -> source
        { SMTLib.lengthSMTLibLimitSourceCommandBytes = commandBytes
        , SMTLib.lengthSMTLibLimitSourceFingerprintBytes = 0
        }
      assertLeft
        (SMTLib.LengthSpinePairSMTLibFingerprintByteLimitExceeded 0 1)
        $ SMTLib.sealLengthSpinePairSMTLibQuery noFingerprint problem
  ]

problemReplayTests :: TestTree
problemReplayTests = testGroup "exact candidate problem replay"
  [ testCase "find no counterexample for one real Exference identity" $ do
      (session, contract, candidate) <- realListIdentityFixture
        $ TypeVariable $ FlexibleVariable 0
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract candidate
      LengthProblem.checkedLengthProblemInputCount problem @?= 1
      mapM_ (\input -> expectNoCounterexample
        $ Evaluate.validateLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits problem
            $ Evaluate.LengthProblemAssignment [input]) [0, 1, 8]
  , testCase "compute a violating candidate result and bind its evidence" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      LengthProblem.checkedLengthProblemInputCount problem @?= 1
      evidence <- expectCounterexample
        $ Evaluate.validateLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits problem
            $ Evaluate.LengthProblemAssignment [3]
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence
      Evaluate.validatedLengthCounterexampleInputs receipt @?= [3]
      Evaluate.validatedLengthCounterexampleResult receipt @?= 0
      Evaluate.validatedLengthCounterexampleBasis receipt @?=
        Evaluate.ProviderIndependentFiniteSpineModel

      -- The assignment API has no result field: zero above is recomputed from
      -- the sealed candidate rather than accepted from a model decoder.
      expectNoCounterexample
        $ Evaluate.validateLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits problem
            $ Evaluate.LengthProblemAssignment [0]

      differentEncoding <- adversarialConstantZeroProblem trivialLengthContract
      assertLeft Djex.ReplayEncodingFingerprintMismatch
        $ Djex.replayBehavioralEvidence
            (LengthProblem.checkedLengthProblemBehavioralProblem differentEncoding)
            evidence
  , testCase "reject problem assignment shape and values productively" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      let replay limits inputs = Evaluate.validateLengthProblemCounterexample
            limits problem $ Evaluate.LengthProblemAssignment inputs
      assertLeft (Evaluate.LengthProblemAssignmentArityMismatch 1 0)
        $ replay Evaluate.defaultLengthEvaluationLimits []
      assertLeft (Evaluate.LengthProblemAssignmentArityMismatch 1 2)
        $ replay Evaluate.defaultLengthEvaluationLimits
            [0, 2 ^ (5000 :: Int)]
      assertLeft
        (Evaluate.LengthEvaluationValueBitLimitExceeded
          (Evaluate.LengthProblemInputValue 0) 2 3)
        $ replay (evaluationLimitsWith 2 8) [4]

      let cyclicInputs = 0 : cyclicInputs
      cyclicResult <- evaluateWithin
        $ replay Evaluate.defaultLengthEvaluationLimits cyclicInputs
      assertLeft (Evaluate.LengthProblemAssignmentArityMismatch 1 2)
        cyclicResult
  , testCase "short-circuit an input-dependent false precondition" $ do
      let input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          precondition = Length.LengthEqual input $ Length.LengthLiteral 0
          postcondition = Length.LengthEqual result $ Length.LengthLiteral 0
          source = contractWith precondition postcondition
      problem <- adversarialConstantProviderProblem 7 source
      LengthProblem.checkedLengthProblemInputCount problem @?= 1
      LengthProblem.checkedLengthCandidateResult
          (LengthProblem.checkedLengthProblemCandidate problem) @?=
        Length.LengthLiteral 7
      assertBool "the retained precondition was collapsed to false" $
        LengthProblem.checkedLengthProblemPrecondition problem /=
          Length.LengthTruth False
      case LengthProblem.checkedLengthProblemPostcondition problem of
        Length.LengthEqual left right -> assertBool
          "the retained postcondition no longer references the result"
          $ left == result || right == result
        other -> assertFailure $ "unexpected retained postcondition: " ++ show other

      -- Input one makes the precondition false.  If replay forces either the
      -- candidate's literal seven or the result-dependent postcondition, the
      -- zero-bit intermediate limit rejects it instead of returning Nothing.
      expectNoCounterexample
        $ Evaluate.validateLengthProblemCounterexample
            (evaluationLimitsWith 1 0) problem
            $ Evaluate.LengthProblemAssignment [1]

      evidence <- expectCounterexample
        $ Evaluate.validateLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits problem
            $ Evaluate.LengthProblemAssignment [0]
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence
      providerName <- expectName "Fixture.problemReplayConstant"
      Evaluate.validatedLengthCounterexampleInputs receipt @?= [0]
      Evaluate.validatedLengthCounterexampleResult receipt @?= 7
      Evaluate.validatedLengthCounterexampleBasis receipt @?=
        Evaluate.FiniteSpineModelUnderAssumedProviderLaws [providerName]

      -- With a true result-independent postcondition, replay also leaves the
      -- shared candidate-result computation unforced after precondition
      -- success.
      irrelevantResult <- adversarialConstantProviderProblem
        7 trivialLengthContract
      expectNoCounterexample
        $ Evaluate.validateLengthProblemCounterexample
            (evaluationLimitsWith 0 0) irrelevantResult
            $ Evaluate.LengthProblemAssignment [0]

      -- Canonical conjunction ordering used to move this bad-postcondition
      -- clause ahead of the false precondition.  Evaluating the scaled result
      -- at input one exceeds the one-bit intermediate bound, so returning no
      -- counterexample demonstrates that replay no longer consumes the sorted
      -- combined formula as its operational plan.
      let orderedPrecondition = Length.LengthNot
            $ Length.LengthAtMost input $ Length.LengthLiteral 1
          orderedSource = contractWith orderedPrecondition postcondition
      scaledResult <- adversarialScaledProviderProblem 2 orderedSource
      case LengthProblem.checkedLengthProblemCounterexampleCondition
          scaledResult of
        Length.LengthAll [firstClause, _] -> assertBool
          "the adversarial combined formula did not reorder its bad post first"
          $ firstClause /=
              LengthProblem.checkedLengthProblemPrecondition scaledResult
        other -> assertFailure $ "unexpected adversarial condition: " ++ show other
      expectNoCounterexample
        $ Evaluate.validateLengthProblemCounterexample
            (evaluationLimitsWith 1 1) scaledResult
            $ Evaluate.LengthProblemAssignment [1]
  ]

counterexampleBankTests :: TestTree
counterexampleBankTests = testGroup
  "candidate-independent bounded counterexample banks"
  [ testCase "validate nominal scalar and product limits in fixed order" $ do
      LengthBank.mkLengthCounterexampleBankLimits 4 8 256 4096 256 @?=
        Right LengthBank.defaultLengthCounterexampleBankLimits
      map ($ LengthBank.defaultLengthCounterexampleBankLimits)
        [ LengthBank.lengthCounterexampleBankEntryLimit
        , LengthBank.lengthCounterexampleBankSampleWidthLimit
        , LengthBank.lengthCounterexampleBankNaturalBitLimit
        ] @?= [4, 8, 256]
      LengthBank.lengthCounterexampleBankEncodedByteLimit
          LengthBank.defaultLengthCounterexampleBankLimits @?= 4096
      LengthBank.lengthCounterexampleBankReplayAttemptLimit
          LengthBank.defaultLengthCounterexampleBankLimits @?= 256
      [ LengthBank.LengthCounterexampleBankEntries
        , LengthBank.LengthCounterexampleBankSampleWidth
        , LengthBank.LengthCounterexampleBankNaturalBits
        ] @?= [minBound .. maxBound]
      assertLeft
        (LengthBank.NegativeLengthCounterexampleBankLimit
          LengthBank.LengthCounterexampleBankEntries (-1))
        $ LengthBank.mkLengthCounterexampleBankLimits
            (-1) maxBound maxBound 0 0
      assertLeft
        (LengthBank.NegativeLengthCounterexampleBankLimit
          LengthBank.LengthCounterexampleBankSampleWidth (-2))
        $ LengthBank.mkLengthCounterexampleBankLimits
            0 (-2) maxBound 0 0
      assertLeft
        (LengthBank.NegativeLengthCounterexampleBankLimit
          LengthBank.LengthCounterexampleBankNaturalBits (-3))
        $ LengthBank.mkLengthCounterexampleBankLimits 0 0 (-3) 0 0
      assertLeft
        (LengthBank.UnobservableLengthCounterexampleBankFirstExcess
          LengthBank.LengthCounterexampleBankSampleWidth maxBound)
        $ LengthBank.mkLengthCounterexampleBankLimits
            0 maxBound 0 0 0
      assertLeft
        (LengthBank.UnobservableLengthCounterexampleBankFirstExcess
          LengthBank.LengthCounterexampleBankNaturalBits maxBound)
        $ LengthBank.mkLengthCounterexampleBankLimits
            0 0 maxBound 0 0
      scalarMaximums <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits
            maxBound (maxBound - 1) (maxBound - 1) 0 0
      LengthBank.lengthCounterexampleBankEntryLimit scalarMaximums @?=
        maxBound
      LengthBank.lengthCounterexampleBankSampleWidthLimit scalarMaximums @?=
        maxBound - 1
      LengthBank.lengthCounterexampleBankNaturalBitLimit scalarMaximums @?=
        maxBound - 1

      LengthBank.mkLengthSpinePairCounterexampleBankLimits
          4 8 256 4096 256 @?=
        Right LengthBank.defaultLengthSpinePairCounterexampleBankLimits
      map ($ LengthBank.defaultLengthSpinePairCounterexampleBankLimits)
        [ LengthBank.lengthSpinePairCounterexampleBankEntryLimit
        , LengthBank.lengthSpinePairCounterexampleBankSampleWidthLimit
        , LengthBank.lengthSpinePairCounterexampleBankNaturalBitLimit
        ] @?= [4, 8, 256]
      LengthBank.lengthSpinePairCounterexampleBankEncodedByteLimit
          LengthBank.defaultLengthSpinePairCounterexampleBankLimits @?= 4096
      LengthBank.lengthSpinePairCounterexampleBankReplayAttemptLimit
          LengthBank.defaultLengthSpinePairCounterexampleBankLimits @?= 256
      [ LengthBank.LengthSpinePairCounterexampleBankEntries
        , LengthBank.LengthSpinePairCounterexampleBankSampleWidth
        , LengthBank.LengthSpinePairCounterexampleBankNaturalBits
        ] @?= [minBound .. maxBound]
      assertLeft
        (LengthBank.NegativeLengthSpinePairCounterexampleBankLimit
          LengthBank.LengthSpinePairCounterexampleBankEntries (-1))
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
            (-1) maxBound maxBound 0 0
      assertLeft
        (LengthBank.NegativeLengthSpinePairCounterexampleBankLimit
          LengthBank.LengthSpinePairCounterexampleBankSampleWidth (-2))
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
            0 (-2) maxBound 0 0
      assertLeft
        (LengthBank.NegativeLengthSpinePairCounterexampleBankLimit
          LengthBank.LengthSpinePairCounterexampleBankNaturalBits (-3))
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits 0 0 (-3) 0 0
      assertLeft
        (LengthBank.UnobservableLengthSpinePairCounterexampleBankFirstExcess
          LengthBank.LengthSpinePairCounterexampleBankSampleWidth maxBound)
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
            0 maxBound 0 0 0
      assertLeft
        (LengthBank.UnobservableLengthSpinePairCounterexampleBankFirstExcess
          LengthBank.LengthSpinePairCounterexampleBankNaturalBits maxBound)
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
            0 0 maxBound 0 0
      pairMaximums <- expectRight
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
            maxBound (maxBound - 1) (maxBound - 1) 0 0
      LengthBank.lengthSpinePairCounterexampleBankEntryLimit pairMaximums @?=
        maxBound
      LengthBank.lengthSpinePairCounterexampleBankSampleWidthLimit
          pairMaximums @?= maxBound - 1
      LengthBank.lengthSpinePairCounterexampleBankNaturalBitLimit
          pairMaximums @?= maxBound - 1
  , testCase
      "share scalar and product scopes across candidate and query identity" $
      do
        scalarSession <- adversarialLengthSession [] []
        let scalarTarget =
              FunctionType adversarialClosedList adversarialClosedList
        scalarContract <- adversarialLengthContract scalarSession scalarTarget
          identityLengthContract
        scalarIdentityGraph <- sealAdversarialGraph
          $ adversarialIdentityGraphSource adversarialClosedList
        scalarZeroGraph <- adversarialConstantZeroGraph
        scalarIdentity <- sealAdversarialLengthProblem
          scalarSession scalarContract scalarIdentityGraph
        scalarZero <- sealAdversarialLengthProblem
          scalarSession scalarContract scalarZeroGraph
        let scalarIdentityCandidate =
              LengthProblem.checkedLengthProblemCandidate scalarIdentity
            scalarZeroCandidate =
              LengthProblem.checkedLengthProblemCandidate scalarZero
            scalarIdentityScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope
                scalarIdentity
            scalarZeroScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope
                scalarZero
        assertBool "different scalar graphs shared candidate identity"
          $ LengthProblem.checkedLengthCandidateFingerprint
              scalarIdentityCandidate /=
            LengthProblem.checkedLengthCandidateFingerprint scalarZeroCandidate
        assertBool "different scalar results were collapsed"
          $ LengthProblem.checkedLengthCandidateResult scalarIdentityCandidate /=
            LengthProblem.checkedLengthCandidateResult scalarZeroCandidate
        assertBool "different scalar conditions were collapsed"
          $ LengthProblem.checkedLengthProblemCounterexampleCondition
              scalarIdentity /=
            LengthProblem.checkedLengthProblemCounterexampleCondition scalarZero
        LengthBank.lengthCounterexampleBankScopeFingerprint
            scalarIdentityScope @?=
          LengthBank.lengthCounterexampleBankScopeFingerprint scalarZeroScope
        scalarIdentityQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits scalarIdentity
        scalarZeroQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits scalarZero
        assertBool "candidate drift disappeared from scalar query identity"
          $ SMTLib.lengthSMTLibQueryFingerprint scalarIdentityQuery /=
            SMTLib.lengthSMTLibQueryFingerprint scalarZeroQuery
        LengthBank.lengthCounterexampleBankScopeFingerprint
            (SMTLib.lengthSMTLibQueryCounterexampleBankScope
              scalarIdentityQuery) @?=
          LengthBank.lengthCounterexampleBankScopeFingerprint
            scalarIdentityScope
        widenedQueryLimits <- expectRight
          $ SMTLib.mkLengthSMTLibLimits
          $ SMTLib.defaultLengthSMTLibLimitSource
              { SMTLib.lengthSMTLibLimitSourceCommandBytes = 131072
              , SMTLib.lengthSMTLibLimitSourceFingerprintBytes = 524288
              , SMTLib.lengthSMTLibLimitSourceNumeralBits = 8192
              }
        widenedScalarQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
          widenedQueryLimits scalarIdentity
        SMTLib.lengthSMTLibQueryFingerprint widenedScalarQuery @?=
          SMTLib.lengthSMTLibQueryFingerprint scalarIdentityQuery
        LengthBank.lengthCounterexampleBankScopeFingerprint
            (SMTLib.lengthSMTLibQueryCounterexampleBankScope
              widenedScalarQuery) @?=
          LengthBank.lengthCounterexampleBankScopeFingerprint
            scalarIdentityScope
        let scalarBank = LengthBank.emptyLengthCounterexampleBank
              LengthBank.defaultLengthCounterexampleBankLimits
              scalarIdentityScope
        assertBool "a scalar bank did not cross candidate/query identity"
          $ LengthBank.lengthCounterexampleBankMatchesScope
              scalarZeroScope scalarBank

        pairSession <- adversarialLengthSession [] []
        let pairInput = Length.LengthVariable
              $ Length.LengthSpinePairInput 0
            pairContractSource = spinePairContractWith
              (Length.LengthTruth True)
              $ Length.LengthEqual
                  (pairResultVariable Length.LengthSpinePairFirst) pairInput
        pairContract <- adversarialLengthSpinePairContract pairSession
          adversarialInputSpinePairTarget pairContractSource
        inputZeroGraph <- adversarialInputAndZeroSpinePairGraph
        zeroInputGraph <- adversarialZeroAndInputSpinePairGraph
        inputZero <- sealAdversarialLengthSpinePairProblem
          pairSession pairContract inputZeroGraph
        zeroInput <- sealAdversarialLengthSpinePairProblem
          pairSession pairContract zeroInputGraph
        let inputZeroCandidate =
              LengthProblem.checkedLengthSpinePairProblemCandidate inputZero
            zeroInputCandidate =
              LengthProblem.checkedLengthSpinePairProblemCandidate zeroInput
            inputZeroScope =
              LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
                inputZero
            zeroInputScope =
              LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
                zeroInput
        assertBool "different product graphs shared candidate identity"
          $ LengthProblem.checkedLengthSpinePairCandidateFingerprint
              inputZeroCandidate /=
            LengthProblem.checkedLengthSpinePairCandidateFingerprint
              zeroInputCandidate
        assertBool "different product results were collapsed"
          $ LengthProblem.checkedLengthSpinePairCandidateResult
              inputZeroCandidate /=
            LengthProblem.checkedLengthSpinePairCandidateResult
              zeroInputCandidate
        assertBool "different product conditions were collapsed"
          $ LengthProblem.checkedLengthSpinePairProblemCounterexampleCondition
              inputZero /=
            LengthProblem.checkedLengthSpinePairProblemCounterexampleCondition
              zeroInput
        LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
            inputZeroScope @?=
          LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
            zeroInputScope
        inputZeroQuery <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits inputZero
        zeroInputQuery <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits zeroInput
        assertBool "candidate drift disappeared from product query identity"
          $ SMTLib.lengthSpinePairSMTLibQueryFingerprint inputZeroQuery /=
            SMTLib.lengthSpinePairSMTLibQueryFingerprint zeroInputQuery
        LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
            (SMTLib.lengthSpinePairSMTLibQueryCounterexampleBankScope
              inputZeroQuery) @?=
          LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
            inputZeroScope
        widenedPairQuery <- expectRight
          $ SMTLib.sealLengthSpinePairSMTLibQuery
              widenedQueryLimits inputZero
        SMTLib.lengthSpinePairSMTLibQueryFingerprint widenedPairQuery @?=
          SMTLib.lengthSpinePairSMTLibQueryFingerprint inputZeroQuery
        LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
            (SMTLib.lengthSpinePairSMTLibQueryCounterexampleBankScope
              widenedPairQuery) @?=
          LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
            inputZeroScope
        let pairBank = LengthBank.emptyLengthSpinePairCounterexampleBank
              LengthBank.defaultLengthSpinePairCounterexampleBankLimits
              inputZeroScope
        assertBool "a product bank did not cross candidate/query identity"
          $ LengthBank.lengthSpinePairCounterexampleBankMatchesScope
              zeroInputScope pairBank
  , testCase
      "bind scalar and product scopes to the exact nominal target and domain" $
      do
        session <- adversarialLengthSession [] []
        let firstSpine = adversarialClosedList
            secondSpine = adversarialListOf
              $ FunctionType (TupleType Boxed []) (TupleType Boxed [])
            scalarTarget spine = FunctionType spine spine
        firstContract <- adversarialLengthContract session
          (scalarTarget firstSpine) trivialLengthContract
        secondContract <- adversarialLengthContract session
          (scalarTarget secondSpine) trivialLengthContract
        Length.lengthContractFingerprint firstContract @?=
          Length.lengthContractFingerprint secondContract
        firstGraph <- sealAdversarialGraph
          $ adversarialIdentityGraphSource firstSpine
        secondGraph <- sealAdversarialGraph
          $ adversarialIdentityGraphSource secondSpine
        firstProblem <- sealAdversarialLengthProblem
          session firstContract firstGraph
        secondProblem <- sealAdversarialLengthProblem
          session secondContract secondGraph
        let firstScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope
                firstProblem
            secondScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope
                secondProblem
            firstBank = LengthBank.emptyLengthCounterexampleBank
              LengthBank.defaultLengthCounterexampleBankLimits firstScope
        assertBool "opaque scalar target payload was omitted from target identity"
          $ LengthBank.lengthCounterexampleBankScopeTargetFingerprint
              firstScope /=
            LengthBank.lengthCounterexampleBankScopeTargetFingerprint
              secondScope
        assertBool "opaque scalar target payload was omitted from bank scope"
          $ LengthBank.lengthCounterexampleBankScopeFingerprint firstScope /=
            LengthBank.lengthCounterexampleBankScopeFingerprint secondScope
        assertBool "a scalar bank matched a foreign target scope"
          $ not $ LengthBank.lengthCounterexampleBankMatchesScope
              secondScope firstBank

        firstPairContract <- adversarialLengthSpinePairContract session
          (adversarialInputSpinePairTargetFor firstSpine)
          trivialSpinePairContract
        secondPairContract <- adversarialLengthSpinePairContract session
          (adversarialInputSpinePairTargetFor secondSpine)
          trivialSpinePairContract
        Length.lengthSpinePairContractFingerprint firstPairContract @?=
          Length.lengthSpinePairContractFingerprint secondPairContract
        firstPairGraph <- adversarialInputAndZeroSpinePairGraphFor firstSpine
        secondPairGraph <- adversarialInputAndZeroSpinePairGraphFor secondSpine
        firstPairProblem <- sealAdversarialLengthSpinePairProblem
          session firstPairContract firstPairGraph
        secondPairProblem <- sealAdversarialLengthSpinePairProblem
          session secondPairContract secondPairGraph
        let firstPairScope =
              LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
                firstPairProblem
            secondPairScope =
              LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
                secondPairProblem
            firstPairBank = LengthBank.emptyLengthSpinePairCounterexampleBank
              LengthBank.defaultLengthSpinePairCounterexampleBankLimits
              firstPairScope
        assertBool "opaque product target payload was omitted from target identity"
          $ LengthBank.lengthSpinePairCounterexampleBankScopeTargetFingerprint
              firstPairScope /=
            LengthBank.lengthSpinePairCounterexampleBankScopeTargetFingerprint
              secondPairScope
        assertBool "opaque product target payload was omitted from bank scope"
          $ LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
              firstPairScope /=
            LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
              secondPairScope
        assertBool "a product bank matched a foreign target scope"
          $ not $ LengthBank.lengthSpinePairCounterexampleBankMatchesScope
              secondPairScope firstPairBank

        assertBool "the scalar and product bank domains shared scope bytes"
          $ Fingerprint.fingerprintCanonicalBytes
              (LengthBank.lengthCounterexampleBankScopeFingerprint firstScope) /=
            Fingerprint.fingerprintCanonicalBytes
              (LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
                firstPairScope)
        LengthBank.lengthCounterexampleBankScopeSchemaTag @?=
          asciiBytes "djex-length-counterexample-bank-scope/v1"
        LengthBank.lengthSpinePairCounterexampleBankScopeSchemaTag @?=
          asciiBytes "djex-length-spine-pair-counterexample-bank-scope/v1"
  , testCase
      "canonicalize target variable names but retain flexible versus rigid" $
      do
        session <- adversarialLengthSession [] []
        let flexibleSpine name = adversarialListOf
              $ TypeVariable $ FlexibleVariable name
            rigidSpine name = adversarialListOf
              $ TypeVariable $ RigidVariable name
            target spine = FunctionType spine spine
            sealFlexible sourceName graphName = do
              contract <- adversarialLengthContract session
                (target $ flexibleSpine sourceName) trivialLengthContract
              graph <- sealAdversarialGraph
                $ adversarialIdentityGraphSource $ rigidSpine graphName
              sealAdversarialLengthProblem session contract graph
        alpha <- sealFlexible "alpha-source" "alpha-fresh"
        renamed <- sealFlexible "renamed-source" "renamed-fresh"
        let alphaScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope alpha
            renamedScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope renamed
        LengthBank.lengthCounterexampleBankScopeTargetFingerprint alphaScope @?=
          LengthBank.lengthCounterexampleBankScopeTargetFingerprint renamedScope
        LengthBank.lengthCounterexampleBankScopeFingerprint alphaScope @?=
          LengthBank.lengthCounterexampleBankScopeFingerprint renamedScope

        rigidContract <- adversarialLengthContract session
          (target $ rigidSpine "alpha-source") trivialLengthContract
        rigidGraph <- sealAdversarialGraph
          $ adversarialIdentityGraphSource $ rigidSpine "alpha-source"
        rigid <- sealAdversarialLengthProblem
          session rigidContract rigidGraph
        let rigidScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope rigid
        assertBool "flexible and rigid target variables shared target identity"
          $ LengthBank.lengthCounterexampleBankScopeTargetFingerprint
              alphaScope /=
            LengthBank.lengthCounterexampleBankScopeTargetFingerprint rigidScope
        assertBool "flexible and rigid target variables shared bank scope"
          $ LengthBank.lengthCounterexampleBankScopeFingerprint alphaScope /=
            LengthBank.lengthCounterexampleBankScopeFingerprint rigidScope
  , testCase "bind scalar and product scopes to contract pre- and postconditions" $
      do
        session <- adversarialLengthSession [] []
        let scalarTarget =
              FunctionType adversarialClosedList adversarialClosedList
            scalarInput = Length.LengthVariable $ Length.LengthInput 0
            scalarPre = contractWith
              (Length.LengthAtMost scalarInput $ Length.LengthLiteral 0)
              (Length.LengthTruth True)
            scalarPost = contractWith
              (Length.LengthTruth True)
              (Length.LengthEqual
                (Length.LengthVariable Length.LengthResult) scalarInput)
        scalarTrivialContract <- adversarialLengthContract
          session scalarTarget trivialLengthContract
        scalarPreContract <- adversarialLengthContract
          session scalarTarget scalarPre
        scalarPostContract <- adversarialLengthContract
          session scalarTarget scalarPost
        scalarGraph <- adversarialConstantZeroGraph
        scalarTrivialProblem <- sealAdversarialLengthProblem
          session scalarTrivialContract scalarGraph
        scalarPreProblem <- sealAdversarialLengthProblem
          session scalarPreContract scalarGraph
        scalarPostProblem <- sealAdversarialLengthProblem
          session scalarPostContract scalarGraph
        let scalarScope =
              LengthBank.lengthCounterexampleBankScopeFingerprint
              . LengthProblem.checkedLengthProblemCounterexampleBankScope
        assertBool "scalar precondition was omitted from bank scope"
          $ scalarScope scalarTrivialProblem /= scalarScope scalarPreProblem
        assertBool "scalar postcondition was omitted from bank scope"
          $ scalarScope scalarTrivialProblem /= scalarScope scalarPostProblem
        assertBool "different scalar contracts shared a bank scope"
          $ scalarScope scalarPreProblem /= scalarScope scalarPostProblem

        let pairInput = Length.LengthVariable
              $ Length.LengthSpinePairInput 0
            pairPre = spinePairContractWith
              (Length.LengthAtMost pairInput $ Length.LengthLiteral 0)
              (Length.LengthTruth True)
            pairPost = spinePairContractWith
              (Length.LengthTruth True)
              $ Length.LengthEqual
                  (pairResultVariable Length.LengthSpinePairFirst) pairInput
        pairTrivialContract <- adversarialLengthSpinePairContract session
          adversarialInputSpinePairTarget trivialSpinePairContract
        pairPreContract <- adversarialLengthSpinePairContract session
          adversarialInputSpinePairTarget pairPre
        pairPostContract <- adversarialLengthSpinePairContract session
          adversarialInputSpinePairTarget pairPost
        pairGraph <- adversarialInputAndZeroSpinePairGraph
        pairTrivialProblem <- sealAdversarialLengthSpinePairProblem
          session pairTrivialContract pairGraph
        pairPreProblem <- sealAdversarialLengthSpinePairProblem
          session pairPreContract pairGraph
        pairPostProblem <- sealAdversarialLengthSpinePairProblem
          session pairPostContract pairGraph
        let pairScope =
              LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
              . LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
        assertBool "product precondition was omitted from bank scope"
          $ pairScope pairTrivialProblem /= pairScope pairPreProblem
        assertBool "product postcondition was omitted from bank scope"
          $ pairScope pairTrivialProblem /= pairScope pairPostProblem
        assertBool "different product contracts shared a bank scope"
          $ pairScope pairPreProblem /= pairScope pairPostProblem
  , testCase
      "bind scopes to unused inventory and the complete provider-law basis" $
      do
        unusedName <- expectName "Fixture.bankUnusedInventory"
        providerName <- expectName "Fixture.bankUnusedProvider"
        className <- expectName "Fixture.BankConditional"
        let target = FunctionType adversarialClosedList adversarialClosedList
            graphAction = sealAdversarialGraph
              $ adversarialIdentityGraphSource adversarialClosedList
            scalarProblem session = do
              contract <- adversarialLengthContract
                session target trivialLengthContract
              graph <- graphAction
              sealAdversarialLengthProblem session contract graph
            pairProblem session = do
              contract <- adversarialLengthSpinePairContract session
                adversarialInputSpinePairTarget trivialSpinePairContract
              graph <- adversarialInputAndZeroSpinePairGraph
              sealAdversarialLengthSpinePairProblem session contract graph
            scalarScope =
              LengthBank.lengthCounterexampleBankScopeFingerprint
              . LengthProblem.checkedLengthProblemCounterexampleBankScope
            pairScope =
              LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
              . LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
            provider transfer = Length.AssumedProviderSummary
              { Length.lengthProviderName = providerName
              , Length.lengthProviderScheme = target
              , Length.lengthProviderArgumentRoles =
                  [Length.LengthSpineArgument]
              , Length.lengthProviderTransfer = transfer
              }
            providerDeclaration = ValueDeclaration
              $ ValueSignature () providerName target
            identityTransfer = Length.LengthVariable
              $ Length.LengthProviderArgument 0
            scaledTransfer = Length.LengthScale 2 identityTransfer
        baseSession <- adversarialLengthSession [] []
        widenedSession <- adversarialLengthSession
          [ValueDeclaration $ ValueSignature () unusedName adversarialClosedList]
          []
        baseScalar <- scalarProblem baseSession
        widenedScalar <- scalarProblem widenedSession
        assertBool "unused inventory was omitted from scalar bank scope"
          $ scalarScope baseScalar /= scalarScope widenedScalar
        basePair <- pairProblem baseSession
        widenedPair <- pairProblem widenedSession
        assertBool "unused inventory was omitted from product bank scope"
          $ pairScope basePair /= pairScope widenedPair

        identityProviderSession <- adversarialLengthSession
          [providerDeclaration] [provider identityTransfer]
        scaledProviderSession <- adversarialLengthSession
          [providerDeclaration] [provider scaledTransfer]
        identityProviderScalar <- scalarProblem identityProviderSession
        scaledProviderScalar <- scalarProblem scaledProviderSession
        LengthProblem.checkedLengthCandidateUsedProviders
            (LengthProblem.checkedLengthProblemCandidate
              identityProviderScalar) @?= []
        LengthProblem.checkedLengthCandidateUsedProviders
            (LengthProblem.checkedLengthProblemCandidate
              scaledProviderScalar) @?= []
        assertBool "unused provider transfer was omitted from scalar scope"
          $ scalarScope identityProviderScalar /=
            scalarScope scaledProviderScalar
        identityProviderPair <- pairProblem identityProviderSession
        scaledProviderPair <- pairProblem scaledProviderSession
        assertBool "unused provider transfer was omitted from product scope"
          $ pairScope identityProviderPair /= pairScope scaledProviderPair

        let conditionalScheme = ForallType [] [Constraint className []] target
            conditionalProvider =
              Length.AssumedConstraintConditionalProviderSummary
                { Length.lengthProviderName = providerName
                , Length.lengthProviderScheme = conditionalScheme
                , Length.lengthProviderArgumentRoles =
                    [Length.LengthSpineArgument]
                , Length.lengthProviderTransfer = identityTransfer
                }
            conditionalDeclarations =
              [ ClassDeclaration () className [] [] []
              , ValueDeclaration $ ValueSignature () providerName
                  conditionalScheme
              ]
        conditionalSession <- adversarialLengthSession
          conditionalDeclarations [conditionalProvider]
        map Length.checkedLengthProviderTrust
            (Length.checkedLengthProviderSummaries
              $ LengthProblem.checkedLengthSessionProviderInventory
                  identityProviderSession) @?=
          [Length.AssumedProviderLaw]
        map Length.checkedLengthProviderTrust
            (Length.checkedLengthProviderSummaries
              $ LengthProblem.checkedLengthSessionProviderInventory
                  conditionalSession) @?=
          [Length.AssumedProviderLawConditionalOnConstraintDischarge]
        conditionalScalar <- scalarProblem conditionalSession
        conditionalPair <- pairProblem conditionalSession
        assertBool "provider trust boundary was omitted from scalar scope"
          $ scalarScope identityProviderScalar /= scalarScope conditionalScalar
        assertBool "provider trust boundary was omitted from product scope"
          $ pairScope identityProviderPair /= pairScope conditionalPair
  , testCase
      "bind scopes to exact case policy and ordered mixed target roles" $ do
      let observedRoles = [Length.LengthObservedSpine]
          unaryTarget =
            FunctionType adversarialClosedList adversarialClosedList
      ordinarySession <- adversarialRoleAwareLengthSession observedRoles [] []
      exactSession <- adversarialExactCaseLengthSession observedRoles [] []
      ordinaryContract <- adversarialRoleAwareLengthContract
        ordinarySession observedRoles unaryTarget trivialLengthContract
      exactContract <- adversarialRoleAwareLengthContract
        exactSession observedRoles unaryTarget trivialLengthContract
      identityGraph <- sealAdversarialGraph
        $ adversarialIdentityGraphSource adversarialClosedList
      let candidate = adversarialTypedCandidate $ Right identityGraph
      ordinary <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            ordinarySession ordinaryContract candidate
      exact <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactSession exactContract candidate
      let scalarScope =
            LengthBank.lengthCounterexampleBankScopeFingerprint
            . LengthProblem.checkedLengthProblemCounterexampleBankScope
      assertBool "scalar exact-case policy was omitted from bank scope"
        $ scalarScope ordinary /= scalarScope exact

      ordinaryPairContract <- adversarialRoleAwareLengthSpinePairContract
        ordinarySession observedRoles adversarialInputSpinePairTarget
        trivialSpinePairContract
      exactPairContract <- adversarialRoleAwareLengthSpinePairContract
        exactSession observedRoles adversarialInputSpinePairTarget
        trivialSpinePairContract
      pairGraph <- adversarialInputAndZeroSpinePairGraph
      let pairCandidate = adversarialTypedCandidate $ Right pairGraph
      ordinaryPair <- expectRight
        $ LengthProblem.sealRoleAwareLengthSpinePairTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            ordinarySession ordinaryPairContract pairCandidate
      exactPair <- expectRight
        $ LengthProblem.sealExactSpineCaseLengthSpinePairTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            exactSession exactPairContract pairCandidate
      let pairScope =
            LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
            . LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
      assertBool "product exact-case policy was omitted from bank scope"
        $ pairScope ordinaryPair /= pairScope exactPair

      let firstRoles =
            [ Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
          secondRoles = reverse firstRoles
      firstSession <- adversarialRoleAwareLengthSession firstRoles [] []
      secondSession <- adversarialRoleAwareLengthSession secondRoles [] []
      firstContract <- adversarialRoleAwareLengthContract firstSession
        firstRoles adversarialBinaryConstantZeroTarget trivialLengthContract
      secondContract <- adversarialRoleAwareLengthContract secondSession
        secondRoles adversarialBinaryConstantZeroTarget trivialLengthContract
      binaryGraph <- adversarialBinaryConstantZeroGraph
      let binaryCandidate = adversarialTypedCandidate $ Right binaryGraph
      first <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            firstSession firstContract binaryCandidate
      second <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            secondSession secondContract binaryCandidate
      assertBool "ordered scalar mixed roles were omitted from bank scope"
        $ scalarScope first /= scalarScope second

      firstPairContract <- adversarialRoleAwareLengthSpinePairContract
        firstSession firstRoles adversarialBinaryZeroSpinePairTarget
        trivialSpinePairContract
      secondPairContract <- adversarialRoleAwareLengthSpinePairContract
        secondSession secondRoles adversarialBinaryZeroSpinePairTarget
        trivialSpinePairContract
      binaryPairGraph <- adversarialBinaryZeroSpinePairGraph
      let binaryPairCandidate = adversarialTypedCandidate
            $ Right binaryPairGraph
      firstPair <- expectRight
        $ LengthProblem.sealRoleAwareLengthSpinePairTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            firstSession firstPairContract binaryPairCandidate
      secondPair <- expectRight
        $ LengthProblem.sealRoleAwareLengthSpinePairTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            secondSession secondPairContract binaryPairCandidate
      assertBool "ordered product mixed roles were omitted from bank scope"
        $ pairScope firstPair /= pairScope secondPair
  , testCase
      "exclude each candidate's used-law subset from scalar and product scope" $
      do
        providerName <- expectName "Fixture.bankCandidateProvider"
        let target = FunctionType adversarialClosedList adversarialClosedList
            provider = Length.AssumedProviderSummary
              { Length.lengthProviderName = providerName
              , Length.lengthProviderScheme = target
              , Length.lengthProviderArgumentRoles =
                  [Length.LengthSpineArgument]
              , Length.lengthProviderTransfer = Length.LengthVariable
                  $ Length.LengthProviderArgument 0
              }
            declaration = ValueDeclaration
              $ ValueSignature () providerName target
            providerGraphSource = Djex.TermGraphSource (Djex.termNodeId 3)
              [ ( Djex.termNodeId 0
                , Djex.TermNode target
                    $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName
                )
              , ( Djex.termNodeId 1
                , Djex.TermNode adversarialClosedList
                    $ Djex.TypedLocal (Djex.occurrenceId 1) 0
                )
              , ( Djex.termNodeId 2
                , Djex.TermNode adversarialClosedList
                    $ Djex.TypedApply
                        (Djex.termNodeId 0)
                        (Djex.termNodeId 1)
                        (Djex.ApplicationWitness
                          adversarialClosedList adversarialClosedList)
                )
              , ( Djex.termNodeId 3
                , Djex.TermNode target
                    $ Djex.TypedLambda
                        [ Djex.TypedPattern (Djex.occurrenceId 2)
                            adversarialClosedList (Djex.TypedBind 0)
                        ]
                        (Djex.termNodeId 2)
                )
              ]
        session <- adversarialLengthSession [declaration] [provider]
        contract <- adversarialLengthContract
          session target trivialLengthContract
        directGraph <- sealAdversarialGraph
          $ adversarialIdentityGraphSource adversarialClosedList
        providerGraph <- sealAdversarialGraph providerGraphSource
        direct <- sealAdversarialLengthProblem session contract directGraph
        throughProvider <- sealAdversarialLengthProblem
          session contract providerGraph
        LengthProblem.checkedLengthCandidateUsedProviders
            (LengthProblem.checkedLengthProblemCandidate direct) @?= []
        LengthProblem.checkedLengthCandidateUsedProviders
            (LengthProblem.checkedLengthProblemCandidate throughProvider) @?=
          [providerName]
        assertBool "used provider subset did not change scalar encoding"
          $ LengthProblem.checkedLengthProblemEncodingFingerprint direct /=
            LengthProblem.checkedLengthProblemEncodingFingerprint
              throughProvider
        let directScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope direct
            providerScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope
                throughProvider
        LengthBank.lengthCounterexampleBankScopeFingerprint directScope @?=
          LengthBank.lengthCounterexampleBankScopeFingerprint providerScope

        pairContract <- adversarialLengthSpinePairContract session
          adversarialInputSpinePairTarget trivialSpinePairContract
        plainPairGraph <- adversarialInputAndZeroSpinePairGraph
        let pairResult = TupleType Boxed
              [adversarialClosedList, adversarialClosedList]
            providerPairSource = Djex.TermGraphSource (Djex.termNodeId 5)
              [ ( Djex.termNodeId 0
                , Djex.TermNode target
                    $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName
                )
              , ( Djex.termNodeId 1
                , Djex.TermNode adversarialClosedList
                    $ Djex.TypedLocal (Djex.occurrenceId 1) 0
                )
              , ( Djex.termNodeId 2
                , Djex.TermNode adversarialClosedList
                    $ Djex.TypedApply
                        (Djex.termNodeId 0)
                        (Djex.termNodeId 1)
                        (Djex.ApplicationWitness
                          adversarialClosedList adversarialClosedList)
                )
              , ( Djex.termNodeId 3
                , Djex.TermNode adversarialClosedList
                    $ Djex.TypedGlobal (Djex.occurrenceId 2) listName
                )
              , ( Djex.termNodeId 4
                , Djex.TermNode pairResult
                    $ Djex.TypedTuple
                        [Djex.termNodeId 2, Djex.termNodeId 3]
                )
              , ( Djex.termNodeId 5
                , Djex.TermNode adversarialInputSpinePairTarget
                    $ Djex.TypedLambda
                        [ Djex.TypedPattern (Djex.occurrenceId 3)
                            adversarialClosedList (Djex.TypedBind 0)
                        ]
                        (Djex.termNodeId 4)
                )
              ]
        providerPairGraph <- sealAdversarialGraph providerPairSource
        plainPair <- sealAdversarialLengthSpinePairProblem
          session pairContract plainPairGraph
        providerPair <- sealAdversarialLengthSpinePairProblem
          session pairContract providerPairGraph
        LengthProblem.checkedLengthSpinePairCandidateUsedProviders
            (LengthProblem.checkedLengthSpinePairProblemCandidate plainPair) @?=
          []
        LengthProblem.checkedLengthSpinePairCandidateUsedProviders
            (LengthProblem.checkedLengthSpinePairProblemCandidate providerPair)
          @?= [providerName]
        assertBool "used provider subset did not change product encoding"
          $ LengthProblem.checkedLengthSpinePairProblemEncodingFingerprint
              plainPair /=
            LengthProblem.checkedLengthSpinePairProblemEncodingFingerprint
              providerPair
        LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
            (LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
              plainPair) @?=
          LengthBank.lengthSpinePairCounterexampleBankScopeFingerprint
            (LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
              providerPair)
  , testCase "exclude solver launch configuration from replay-bank scope" $ do
      problem <- adversarialConstantZeroProblem trivialLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      let scope = SMTLib.lengthSMTLibQueryCounterexampleBankScope query
          source =
            InternalSMTLibExecution.defaultLengthSMTLibExecutionConfigSource
              absoluteFixtureExecutable Nothing
          changedSource = source
            { InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
                17
            , InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
                23
            }
          executionLimits =
            InternalSMTLibExecution.defaultLengthSMTLibExecutionLimits
      baseline <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibExecutionConfig
            executionLimits source
      changed <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundExecutionConfig
            executionLimits changedSource
      assertBool "different launches shared execution-policy identity"
        $ InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint
            baseline /=
          InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint
            changed
      evaluate (force baseline) >> evaluate (force changed) >> pure ()
      let bank = LengthBank.emptyLengthCounterexampleBank
            LengthBank.defaultLengthCounterexampleBankLimits scope
      assertBool "launch policy contaminated scalar bank association"
        $ LengthBank.lengthCounterexampleBankMatchesScope
            (LengthProblem.checkedLengthProblemCounterexampleBankScope problem)
            bank
  , testCase
      "reject zero-capacity scalar and product inserts before any sample demand" $
      do
        scalarProblem <- adversarialConstantZeroProblem trivialLengthContract
        scalarLimits <- expectRight
          $ LengthBank.mkLengthCounterexampleBankLimits 0 0 0 0 0
        let scalarBank = LengthBank.emptyLengthCounterexampleBank scalarLimits
              $ LengthProblem.checkedLengthProblemCounterexampleBankScope
                  scalarProblem
        scalarResult <- evaluateWithin
          $ LengthBank.insertLengthCounterexampleBankSample
              (error "zero-capacity scalar origin was forced")
              (error "zero-capacity scalar vector was forced")
              scalarBank
        assertLeft
          (LengthBank.LengthCounterexampleBankEntryLimitExceeded 0 1)
          scalarResult

        pairProblem <- adversarialInputAndZeroSpinePairProblem
          trivialSpinePairContract
        pairLimits <- expectRight
          $ LengthBank.mkLengthSpinePairCounterexampleBankLimits 0 0 0 0 0
        let pairBank = LengthBank.emptyLengthSpinePairCounterexampleBank
              pairLimits
              $ LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
                  pairProblem
        pairResult <- evaluateWithin
          $ LengthBank.insertLengthSpinePairCounterexampleBankSample
              (error "zero-capacity product origin was forced")
              (error "zero-capacity product vector was forced")
              pairBank
        assertLeft
          (LengthBank.LengthSpinePairCounterexampleBankEntryLimitExceeded 0 1)
          pairResult
  , testCase
      "bound scalar width, natural bits, and encoded bytes productively" $ do
      problem <- adversarialConstantZeroProblem trivialLengthContract
      limits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 4 2 2 4096 2
      let empty = LengthBank.emptyLengthCounterexampleBank limits
            $ LengthProblem.checkedLengthProblemCounterexampleBankScope problem
          origin = LengthBank.lengthCounterexampleBankLiveModelReplayOrigin
          cyclic = 0 : cyclic
          poisonThird = [0, 0, error "scalar excess element was forced"]
      admitted <- expectRight
        $ LengthBank.insertLengthCounterexampleBankSample origin [0, 3] empty
      void (evaluate (force admitted))
      cyclicResult <- evaluateWithin
        $ LengthBank.insertLengthCounterexampleBankSample origin cyclic admitted
      assertLeft
        (LengthBank.LengthCounterexampleBankSampleWidthLimitExceeded 2 3)
        cyclicResult
      poisonedResult <- evaluateWithin
        $ LengthBank.insertLengthCounterexampleBankSample
            origin poisonThird admitted
      assertLeft
        (LengthBank.LengthCounterexampleBankSampleWidthLimitExceeded 2 3)
        poisonedResult
      bitResult <- evaluateWithin
        $ LengthBank.insertLengthCounterexampleBankSample
            origin [3, 4, error "scalar bit failure demanded a later value"]
            admitted
      assertLeft
        (LengthBank.LengthCounterexampleBankSampleWidthLimitExceeded 2 3)
        bitResult
      indexedBitResult <- evaluateWithin
        $ LengthBank.insertLengthCounterexampleBankSample
            origin [3, 4] admitted
      assertLeft
        (LengthBank.LengthCounterexampleBankNaturalBitLimitExceeded 1 2 3)
        indexedBitResult
      earlyBitResult <- evaluateWithin
        $ LengthBank.insertLengthCounterexampleBankSample
            origin [4, error "scalar bit failure demanded the next element"]
            admitted
      assertLeft
        (LengthBank.LengthCounterexampleBankNaturalBitLimitExceeded 0 2 3)
        earlyBitResult

      sample <- case LengthBank.lengthCounterexampleBankSamples admitted of
        [value] -> pure value
        samples -> assertFailure
          ("unexpected admitted scalar bank: " ++ show samples) >>
          error "unreachable"
      let exactBytes =
            LengthBank.lengthCounterexampleBankSampleEncodedByteCount sample
      exactLimits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 1 2 2 exactBytes 0
      _ <- expectRight $ LengthBank.insertLengthCounterexampleBankSample origin
        [0, 3]
        $ LengthBank.emptyLengthCounterexampleBank exactLimits
        $ LengthProblem.checkedLengthProblemCounterexampleBankScope problem
      shortLimits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits
            1 2 2 (exactBytes - 1) 0
      assertLeft
        (LengthBank.LengthCounterexampleBankSampleEncodedByteLimitExceeded
          (exactBytes - 1) exactBytes)
        $ LengthBank.insertLengthCounterexampleBankSample origin [0, 3]
        $ LengthBank.emptyLengthCounterexampleBank shortLimits
        $ LengthProblem.checkedLengthProblemCounterexampleBankScope problem

      zeroBitLimits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 1 1 0 4096 0
      let zeroBitBank = LengthBank.emptyLengthCounterexampleBank zeroBitLimits
            $ LengthProblem.checkedLengthProblemCounterexampleBankScope problem
      _ <- expectRight $ LengthBank.insertLengthCounterexampleBankSample origin
        [0] zeroBitBank
      assertLeft
        (LengthBank.LengthCounterexampleBankNaturalBitLimitExceeded 0 0 1)
        $ LengthBank.insertLengthCounterexampleBankSample origin [1] zeroBitBank
  , testCase
      "bound product width, natural bits, and encoded bytes productively" $ do
      problem <- adversarialInputAndZeroSpinePairProblem trivialSpinePairContract
      limits <- expectRight
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits 4 2 3 4096 2
      let empty = LengthBank.emptyLengthSpinePairCounterexampleBank limits
            $ LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
                problem
          origin =
            LengthBank.lengthSpinePairCounterexampleBankLiveModelReplayOrigin
          cyclic = 0 : cyclic
      admitted <- expectRight
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample
            origin [0, 7] empty
      void (evaluate (force admitted))
      cyclicResult <- evaluateWithin
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample
            origin cyclic admitted
      assertLeft
        (LengthBank.LengthSpinePairCounterexampleBankSampleWidthLimitExceeded
          2 3)
        cyclicResult
      poisonedResult <- evaluateWithin
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample
            origin [0, 0, error "product excess element was forced"] admitted
      assertLeft
        (LengthBank.LengthSpinePairCounterexampleBankSampleWidthLimitExceeded
          2 3)
        poisonedResult
      bitResult <- evaluateWithin
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample
            origin [7, 8] admitted
      assertLeft
        (LengthBank.LengthSpinePairCounterexampleBankNaturalBitLimitExceeded
          1 3 4)
        bitResult
      earlyBitResult <- evaluateWithin
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample
            origin [8, error "product bit failure demanded the next element"]
            admitted
      assertLeft
        (LengthBank.LengthSpinePairCounterexampleBankNaturalBitLimitExceeded
          0 3 4)
        earlyBitResult
      sample <- case
          LengthBank.lengthSpinePairCounterexampleBankSamples admitted of
        [value] -> pure value
        samples -> assertFailure
          ("unexpected admitted product bank: " ++ show samples) >>
          error "unreachable"
      let exactBytes =
            LengthBank.lengthSpinePairCounterexampleBankSampleEncodedByteCount
              sample
      exactLimits <- expectRight
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
            1 2 3 exactBytes 0
      _ <- expectRight
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample origin [0, 7]
        $ LengthBank.emptyLengthSpinePairCounterexampleBank exactLimits
        $ LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
            problem
      shortLimits <- expectRight
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
            1 2 3 (exactBytes - 1) 0
      assertLeft
        (LengthBank.LengthSpinePairCounterexampleBankSampleEncodedByteLimitExceeded
          (exactBytes - 1) exactBytes)
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample origin [0, 7]
        $ LengthBank.emptyLengthSpinePairCounterexampleBank shortLimits
        $ LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
            problem
  , testCase
      "promote exact scalar inputs and evict the deterministic oldest tail" $ do
      problem <- adversarialConstantZeroProblem trivialLengthContract
      limits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 2 1 8 4096 2
      let scope = LengthProblem.checkedLengthProblemCounterexampleBankScope
            problem
          empty = LengthBank.emptyLengthCounterexampleBank limits scope
          live = LengthBank.lengthCounterexampleBankLiveModelReplayOrigin
          pureOrigin =
            LengthBank.lengthCounterexampleBankSolverIndependentReplayOrigin
          simplified =
            LengthBank.lengthCounterexampleBankSimplificationReplayOrigin
      first <- expectRight
        $ LengthBank.insertLengthCounterexampleBankSample live [1] empty
      second <- expectRight
        $ LengthBank.insertLengthCounterexampleBankSample pureOrigin [2] first
      promoted <- expectRight
        $ LengthBank.insertLengthCounterexampleBankSample simplified [1] second
      map LengthBank.lengthCounterexampleBankSampleInputs
          (LengthBank.lengthCounterexampleBankSamples promoted) @?=
        [[1], [2]]
      map LengthBank.lengthCounterexampleBankSampleOrigin
          (LengthBank.lengthCounterexampleBankSamples promoted) @?=
        [simplified, pureOrigin]
      evicted <- expectRight
        $ LengthBank.insertLengthCounterexampleBankSample live [3] promoted
      map LengthBank.lengthCounterexampleBankSampleInputs
          (LengthBank.lengthCounterexampleBankSamples evicted) @?=
        [[3], [1]]
      scalarBankStats evicted @?=
        (2, scalarBankEncodedBytes evicted, 4, 1, 1, 0)
      assertBool "the scalar bank rejected its own exact scope"
        $ LengthBank.lengthCounterexampleBankMatchesScope scope evicted
      firstAttempt <- expectRight
        $ LengthBank.recordLengthCounterexampleBankReplayAttempt evicted
      secondAttempt <- expectRight
        $ LengthBank.recordLengthCounterexampleBankReplayAttempt firstAttempt
      scalarBankStats secondAttempt @?=
        (2, scalarBankEncodedBytes secondAttempt, 4, 1, 1, 2)
      let poisonedContinuation = do
            spent <- LengthBank.recordLengthCounterexampleBankReplayAttempt
              secondAttempt
            LengthBank.insertLengthCounterexampleBankSample
              (error "scalar attempt cap demanded a future origin")
              (error "scalar attempt cap demanded a future sample") spent
      attemptResult <- evaluateWithin poisonedContinuation
      assertLeft
        (LengthBank.LengthCounterexampleBankReplayAttemptLimitExceeded 2 3)
        attemptResult
      void (evaluate (force secondAttempt))
  , testCase
      "promote exact product inputs and evict the deterministic oldest tail" $
      do
        problem <- adversarialInputAndZeroSpinePairProblem
          trivialSpinePairContract
        limits <- expectRight
          $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
              2 1 8 4096 2
        let scope =
              LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
                problem
            empty = LengthBank.emptyLengthSpinePairCounterexampleBank
              limits scope
            live =
              LengthBank.lengthSpinePairCounterexampleBankLiveModelReplayOrigin
            pureOrigin =
              LengthBank.lengthSpinePairCounterexampleBankSolverIndependentReplayOrigin
            simplified =
              LengthBank.lengthSpinePairCounterexampleBankSimplificationReplayOrigin
        first <- expectRight
          $ LengthBank.insertLengthSpinePairCounterexampleBankSample
              live [1] empty
        second <- expectRight
          $ LengthBank.insertLengthSpinePairCounterexampleBankSample
              pureOrigin [2] first
        promoted <- expectRight
          $ LengthBank.insertLengthSpinePairCounterexampleBankSample
              simplified [1] second
        map LengthBank.lengthSpinePairCounterexampleBankSampleInputs
            (LengthBank.lengthSpinePairCounterexampleBankSamples promoted) @?=
          [[1], [2]]
        map LengthBank.lengthSpinePairCounterexampleBankSampleOrigin
            (LengthBank.lengthSpinePairCounterexampleBankSamples promoted) @?=
          [simplified, pureOrigin]
        evicted <- expectRight
          $ LengthBank.insertLengthSpinePairCounterexampleBankSample
              live [3] promoted
        map LengthBank.lengthSpinePairCounterexampleBankSampleInputs
            (LengthBank.lengthSpinePairCounterexampleBankSamples evicted) @?=
          [[3], [1]]
        pairBankStats evicted @?=
          (2, pairBankEncodedBytes evicted, 4, 1, 1, 0)
        assertBool "the product bank rejected its own exact scope"
          $ LengthBank.lengthSpinePairCounterexampleBankMatchesScope
              scope evicted
        firstAttempt <- expectRight
          $ LengthBank.recordLengthSpinePairCounterexampleBankReplayAttempt
              evicted
        secondAttempt <- expectRight
          $ LengthBank.recordLengthSpinePairCounterexampleBankReplayAttempt
              firstAttempt
        pairBankStats secondAttempt @?=
          (2, pairBankEncodedBytes secondAttempt, 4, 1, 1, 2)
        let poisonedContinuation = do
              spent <-
                LengthBank.recordLengthSpinePairCounterexampleBankReplayAttempt
                  secondAttempt
              LengthBank.insertLengthSpinePairCounterexampleBankSample
                (error "product attempt cap demanded a future origin")
                (error "product attempt cap demanded a future sample") spent
        attemptResult <- evaluateWithin poisonedContinuation
        assertLeft
          (LengthBank.LengthSpinePairCounterexampleBankReplayAttemptLimitExceeded
            2 3)
          attemptResult
        void (evaluate (force secondAttempt))
  , testCase
      "evict scalar and product tails at the exact aggregate byte cap" $ do
      scalarProblem <- adversarialConstantZeroProblem trivialLengthContract
      let scalarScope =
            LengthProblem.checkedLengthProblemCounterexampleBankScope
              scalarProblem
          scalarOrigin =
            LengthBank.lengthCounterexampleBankLiveModelReplayOrigin
      scalarProbe <- expectRight
        $ LengthBank.insertLengthCounterexampleBankSample scalarOrigin [1]
        $ LengthBank.emptyLengthCounterexampleBank
            LengthBank.defaultLengthCounterexampleBankLimits scalarScope
      scalarSampleBytes <- case
          LengthBank.lengthCounterexampleBankSamples scalarProbe of
        [sample] -> pure
          $ LengthBank.lengthCounterexampleBankSampleEncodedByteCount sample
        samples -> assertFailure
          ("unexpected scalar byte probe: " ++ show samples) >>
          error "unreachable"
      scalarLimits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits
            4 1 8 scalarSampleBytes 0
      scalarFirst <- expectRight
        $ LengthBank.insertLengthCounterexampleBankSample scalarOrigin [1]
        $ LengthBank.emptyLengthCounterexampleBank scalarLimits scalarScope
      scalarSecond <- expectRight
        $ LengthBank.insertLengthCounterexampleBankSample scalarOrigin [2]
            scalarFirst
      map LengthBank.lengthCounterexampleBankSampleInputs
          (LengthBank.lengthCounterexampleBankSamples scalarSecond) @?= [[2]]
      scalarBankStats scalarSecond @?=
        (1, scalarSampleBytes, 2, 0, 1, 0)
      scalarZeroBytes <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 1 0 0 0 0
      assertLeft
        (LengthBank.LengthCounterexampleBankSampleEncodedByteLimitExceeded 0 1)
        $ LengthBank.insertLengthCounterexampleBankSample scalarOrigin []
        $ LengthBank.emptyLengthCounterexampleBank scalarZeroBytes scalarScope
      scalarZeroAttempts <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 1 0 0 4096 0
      assertLeft
        (LengthBank.LengthCounterexampleBankReplayAttemptLimitExceeded 0 1)
        $ LengthBank.recordLengthCounterexampleBankReplayAttempt
        $ LengthBank.emptyLengthCounterexampleBank scalarZeroAttempts scalarScope

      pairProblem <- adversarialInputAndZeroSpinePairProblem
        trivialSpinePairContract
      let pairScope =
            LengthProblem.checkedLengthSpinePairProblemCounterexampleBankScope
              pairProblem
          pairOrigin =
            LengthBank.lengthSpinePairCounterexampleBankLiveModelReplayOrigin
      pairProbe <- expectRight
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample pairOrigin [1]
        $ LengthBank.emptyLengthSpinePairCounterexampleBank
            LengthBank.defaultLengthSpinePairCounterexampleBankLimits pairScope
      pairSampleBytes <- case
          LengthBank.lengthSpinePairCounterexampleBankSamples pairProbe of
        [sample] -> pure
          $ LengthBank.lengthSpinePairCounterexampleBankSampleEncodedByteCount
              sample
        samples -> assertFailure
          ("unexpected product byte probe: " ++ show samples) >>
          error "unreachable"
      pairLimits <- expectRight
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
            4 1 8 pairSampleBytes 0
      pairFirst <- expectRight
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample pairOrigin [1]
        $ LengthBank.emptyLengthSpinePairCounterexampleBank pairLimits pairScope
      pairSecond <- expectRight
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample pairOrigin [2]
            pairFirst
      map LengthBank.lengthSpinePairCounterexampleBankSampleInputs
          (LengthBank.lengthSpinePairCounterexampleBankSamples pairSecond) @?=
        [[2]]
      pairBankStats pairSecond @?=
        (1, pairSampleBytes, 2, 0, 1, 0)
      pairZeroBytes <- expectRight
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits 1 0 0 0 0
      assertLeft
        (LengthBank.LengthSpinePairCounterexampleBankSampleEncodedByteLimitExceeded
          0 1)
        $ LengthBank.insertLengthSpinePairCounterexampleBankSample pairOrigin []
        $ LengthBank.emptyLengthSpinePairCounterexampleBank
            pairZeroBytes pairScope
      pairZeroAttempts <- expectRight
        $ LengthBank.mkLengthSpinePairCounterexampleBankLimits 1 0 0 4096 0
      assertLeft
        (LengthBank.LengthSpinePairCounterexampleBankReplayAttemptLimitExceeded
          0 1)
        $ LengthBank.recordLengthSpinePairCounterexampleBankReplayAttempt
        $ LengthBank.emptyLengthSpinePairCounterexampleBank
            pairZeroAttempts pairScope
  ]

scalarBankEncodedBytes
  :: LengthBank.LengthCounterexampleBank identity -> Natural
scalarBankEncodedBytes = sum
  . map LengthBank.lengthCounterexampleBankSampleEncodedByteCount
  . LengthBank.lengthCounterexampleBankSamples

scalarBankStats
  :: LengthBank.LengthCounterexampleBank identity
  -> (Natural, Natural, Natural, Natural, Natural, Natural)
scalarBankStats bank =
  let stats = LengthBank.lengthCounterexampleBankStats bank
  in ( LengthBank.lengthCounterexampleBankStatsRetainedEntryCount stats
     , LengthBank.lengthCounterexampleBankStatsRetainedEncodedByteCount stats
     , LengthBank.lengthCounterexampleBankStatsRecordedSampleCount stats
     , LengthBank.lengthCounterexampleBankStatsDuplicatePromotionCount stats
     , LengthBank.lengthCounterexampleBankStatsEvictedSampleCount stats
     , LengthBank.lengthCounterexampleBankStatsReplayAttemptCount stats
     )

pairBankEncodedBytes
  :: LengthBank.LengthSpinePairCounterexampleBank identity -> Natural
pairBankEncodedBytes = sum
  . map LengthBank.lengthSpinePairCounterexampleBankSampleEncodedByteCount
  . LengthBank.lengthSpinePairCounterexampleBankSamples

pairBankStats
  :: LengthBank.LengthSpinePairCounterexampleBank identity
  -> (Natural, Natural, Natural, Natural, Natural, Natural)
pairBankStats bank =
  let stats = LengthBank.lengthSpinePairCounterexampleBankStats bank
  in ( LengthBank.lengthSpinePairCounterexampleBankStatsRetainedEntryCount stats
     , LengthBank.lengthSpinePairCounterexampleBankStatsRetainedEncodedByteCount
        stats
     , LengthBank.lengthSpinePairCounterexampleBankStatsRecordedSampleCount stats
     , LengthBank.lengthSpinePairCounterexampleBankStatsDuplicatePromotionCount
        stats
     , LengthBank.lengthSpinePairCounterexampleBankStatsEvictedSampleCount stats
     , LengthBank.lengthSpinePairCounterexampleBankStatsReplayAttemptCount stats
     )

counterexampleBankBridgeTests :: TestTree
counterexampleBankBridgeTests = testGroup
  "counterexample-bank SMT-LIB association and replay bridge"
  [ testCase
      "A. record fresh scalar inputs and return a query-owned receipt" $ do
      ((zeroProblem, zeroQuery), _) <-
        scalarCounterexampleBankBridgeFixture successorLengthContract
      oldReceipt <- validatedLengthCounterexampleAt zeroProblem [3]
      let origin =
            LengthBank.lengthCounterexampleBankSolverIndependentReplayOrigin
          empty = LengthBank.emptyLengthCounterexampleBank
            LengthBank.defaultLengthCounterexampleBankLimits
            $ SMTLib.lengthSMTLibQueryCounterexampleBankScope zeroQuery
          (recorded, outcome) =
            SMTLib.recordLengthSMTLibQueryCounterexampleInBank
              Evaluate.defaultLengthEvaluationLimits zeroQuery origin
              oldReceipt empty
      fresh <- expectRight outcome
      Evaluate.validatedLengthCounterexampleInputs fresh @?= [3]
      Evaluate.validatedLengthCounterexampleResult fresh @?= 0
      Evaluate.validatedLengthCounterexampleBasis fresh @?=
        Evaluate.ProviderIndependentFiniteSpineModel
      case LengthBank.lengthCounterexampleBankSamples recorded of
        [sample] -> do
          LengthBank.lengthCounterexampleBankSampleInputs sample @?= [3]
          LengthBank.lengthCounterexampleBankSampleOrigin sample @?= origin
        samples -> assertFailure $ "unexpected scalar bridge bank: " ++
          show samples
      scalarBankStats recorded @?=
        (1, scalarBankEncodedBytes recorded, 1, 0, 0, 1)

  , testCase
      "B. mint a current scalar receipt or miss from foreign same-scope evidence" $
      do
        ((zeroProblem, _), (_, identityQuery)) <-
          scalarCounterexampleBankBridgeFixture successorLengthContract
        oldReceipt <- validatedLengthCounterexampleAt zeroProblem [3]
        let origin = LengthBank.lengthCounterexampleBankLiveModelReplayOrigin
            empty = LengthBank.emptyLengthCounterexampleBank
              LengthBank.defaultLengthCounterexampleBankLimits
              $ SMTLib.lengthSMTLibQueryCounterexampleBankScope identityQuery
            (recorded, outcome) =
              SMTLib.recordLengthSMTLibQueryCounterexampleInBank
                Evaluate.defaultLengthEvaluationLimits identityQuery origin
                oldReceipt empty
        fresh <- expectRight outcome
        Evaluate.validatedLengthCounterexampleInputs fresh @?= [3]
        Evaluate.validatedLengthCounterexampleResult oldReceipt @?= 0
        Evaluate.validatedLengthCounterexampleResult fresh @?= 3
        Evaluate.validatedLengthCounterexampleBasis fresh @?=
          Evaluate.ProviderIndependentFiniteSpineModel
        map LengthBank.lengthCounterexampleBankSampleInputs
            (LengthBank.lengthCounterexampleBankSamples recorded) @?= [[3]]
        scalarBankStats recorded @?=
          (1, scalarBankEncodedBytes recorded, 1, 0, 0, 1)

        ((missProblem, _), (_, missQuery)) <-
          scalarCounterexampleBankBridgeFixture identityLengthContract
        missReceipt <- validatedLengthCounterexampleAt missProblem [3]
        let missEmpty = LengthBank.emptyLengthCounterexampleBank
              LengthBank.defaultLengthCounterexampleBankLimits
              $ SMTLib.lengthSMTLibQueryCounterexampleBankScope missQuery
        (missBank, missOutcome) <- evaluateWithin $ force $
          SMTLib.recordLengthSMTLibQueryCounterexampleInBank
            Evaluate.defaultLengthEvaluationLimits missQuery
            (error "scalar record miss demanded origin")
            missReceipt missEmpty
        missOutcome @?= Left
          SMTLib.LengthSMTLibCounterexampleBankRecordCounterexampleNotReproduced
        LengthBank.lengthCounterexampleBankSamples missBank @?= []
        scalarBankStats missBank @?= (0, 0, 0, 0, 0, 1)

  , testCase
      "C. give scalar record scope and attempt admission strict precedence" $ do
      ((zeroProblem, zeroQuery), _) <-
        scalarCounterexampleBankBridgeFixture successorLengthContract
      ((_, foreignQuery), _) <-
        scalarCounterexampleBankBridgeFixture identityLengthContract
      let ordinaryEmpty = LengthBank.emptyLengthCounterexampleBank
            LengthBank.defaultLengthCounterexampleBankLimits
            $ LengthProblem.checkedLengthProblemCounterexampleBankScope
                zeroProblem
      (scopeBank, scopeOutcome) <- evaluateWithin $ force $
        SMTLib.recordLengthSMTLibQueryCounterexampleInBank
          (error "scope mismatch demanded scalar evaluation limits")
          foreignQuery
          (error "scope mismatch demanded scalar origin")
          (error "scope mismatch demanded scalar receipt")
          ordinaryEmpty
      scopeOutcome @?= Left
        SMTLib.LengthSMTLibCounterexampleBankRecordScopeMismatch
      LengthBank.lengthCounterexampleBankSamples scopeBank @?= []
      scalarBankStats scopeBank @?= (0, 0, 0, 0, 0, 0)

      cappedLimits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 1 1 8 4096 0
      let capped = LengthBank.emptyLengthCounterexampleBank cappedLimits
            $ SMTLib.lengthSMTLibQueryCounterexampleBankScope zeroQuery
      (attemptBank, attemptOutcome) <- evaluateWithin $ force $
        SMTLib.recordLengthSMTLibQueryCounterexampleInBank
          (error "attempt cap demanded scalar evaluation limits")
          zeroQuery
          (error "attempt cap demanded scalar origin")
          (error "attempt cap demanded scalar receipt")
          capped
      attemptOutcome @?= Left
        (SMTLib.LengthSMTLibCounterexampleBankRecordAttemptRejected
          $ LengthBank.LengthCounterexampleBankReplayAttemptLimitExceeded 0 1)
      LengthBank.lengthCounterexampleBankSamples attemptBank @?= []
      scalarBankStats attemptBank @?= (0, 0, 0, 0, 0, 0)

  , testCase
      "D. retain a charged scalar bank after admitted replay rejection" $ do
      ((zeroProblem, zeroQuery), _) <-
        scalarCounterexampleBankBridgeFixture successorLengthContract
      receipt <- validatedLengthCounterexampleAt zeroProblem [3]
      let empty = LengthBank.emptyLengthCounterexampleBank
            LengthBank.defaultLengthCounterexampleBankLimits
            $ SMTLib.lengthSMTLibQueryCounterexampleBankScope zeroQuery
          (charged, outcome) =
            SMTLib.recordLengthSMTLibQueryCounterexampleInBank
              (evaluationLimitsWith 1 8) zeroQuery
              (error "replay rejection demanded scalar origin")
              receipt empty
          evaluationFailure =
            Evaluate.LengthEvaluationValueBitLimitExceeded
              (Evaluate.LengthProblemInputValue 0) 1 2
      outcome @?= Left
        (SMTLib.LengthSMTLibCounterexampleBankRecordInputReplayRejected
          $ SMTLib.LengthSMTLibInputReplayEvaluationRejected evaluationFailure)
      LengthBank.lengthCounterexampleBankSamples charged @?= []
      scalarBankStats charged @?= (0, 0, 0, 0, 0, 1)

  , testCase
      "E. replay before scalar insertion caps and preserve charged state" $ do
      ((zeroProblem, zeroQuery), _) <-
        scalarCounterexampleBankBridgeFixture successorLengthContract
      receipt <- validatedLengthCounterexampleAt zeroProblem [3]
      entryLimits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 0 1 8 4096 1
      widthLimits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 1 0 8 4096 1
      bitLimits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 1 1 1 4096 1
      byteLimits <- expectRight
        $ LengthBank.mkLengthCounterexampleBankLimits 1 1 8 0 1
      let scope = SMTLib.lengthSMTLibQueryCounterexampleBankScope zeroQuery
          check limits origin expected = do
            let empty = LengthBank.emptyLengthCounterexampleBank limits scope
            (charged, outcome) <- evaluateWithin $ force $
              SMTLib.recordLengthSMTLibQueryCounterexampleInBank
                Evaluate.defaultLengthEvaluationLimits zeroQuery origin
                receipt empty
            outcome @?= Left
              (SMTLib.LengthSMTLibCounterexampleBankRecordInsertionRejected
                expected)
            LengthBank.lengthCounterexampleBankSamples charged @?= []
            scalarBankStats charged @?= (0, 0, 0, 0, 0, 1)
      check entryLimits
        (error "zero-entry insertion demanded scalar origin")
        $ LengthBank.LengthCounterexampleBankEntryLimitExceeded 0 1
      check widthLimits
        (error "width rejection demanded scalar origin")
        $ LengthBank.LengthCounterexampleBankSampleWidthLimitExceeded 0 1
      check bitLimits
        (error "natural-bit rejection demanded scalar origin")
        $ LengthBank.LengthCounterexampleBankNaturalBitLimitExceeded 0 1 2
      check byteLimits
        (error "encoded-byte rejection demanded scalar origin")
        $ LengthBank.LengthCounterexampleBankSampleEncodedByteLimitExceeded 0 1

  , testCase
      "F. delegate duplicate promotion and MRU accounting to scalar insertion" $
      do
        ((zeroProblem, zeroQuery), _) <-
          scalarCounterexampleBankBridgeFixture successorLengthContract
        firstReceipt <- validatedLengthCounterexampleAt zeroProblem [2]
        secondReceipt <- validatedLengthCounterexampleAt zeroProblem [3]
        limits <- expectRight
          $ LengthBank.mkLengthCounterexampleBankLimits 2 1 8 4096 3
        let scope = SMTLib.lengthSMTLibQueryCounterexampleBankScope zeroQuery
            empty = LengthBank.emptyLengthCounterexampleBank limits scope
            live = LengthBank.lengthCounterexampleBankLiveModelReplayOrigin
            independent =
              LengthBank.lengthCounterexampleBankSolverIndependentReplayOrigin
            simplified =
              LengthBank.lengthCounterexampleBankSimplificationReplayOrigin
            record origin receipt bank =
              SMTLib.recordLengthSMTLibQueryCounterexampleInBank
                Evaluate.defaultLengthEvaluationLimits zeroQuery origin
                receipt bank
        (first, firstOutcome) <- pure $ record live firstReceipt empty
        _ <- expectRight firstOutcome
        (second, secondOutcome) <- pure
          $ record independent secondReceipt first
        _ <- expectRight secondOutcome
        (promoted, promotedOutcome) <- pure
          $ record simplified firstReceipt second
        _ <- expectRight promotedOutcome
        map LengthBank.lengthCounterexampleBankSampleInputs
            (LengthBank.lengthCounterexampleBankSamples promoted) @?=
          [[2], [3]]
        map LengthBank.lengthCounterexampleBankSampleOrigin
            (LengthBank.lengthCounterexampleBankSamples promoted) @?=
          [simplified, independent]
        scalarBankStats promoted @?=
          (2, scalarBankEncodedBytes promoted, 3, 1, 0, 3)

  , testCase
      "G. replay one exact scalar sample with membership and charged semantics" $
      do
        ((zeroProblem, zeroQuery), (_, identityQuery)) <-
          scalarCounterexampleBankBridgeFixture successorLengthContract
        oldReceipt <- validatedLengthCounterexampleAt zeroProblem [3]
        let live = LengthBank.lengthCounterexampleBankLiveModelReplayOrigin
            independent =
              LengthBank.lengthCounterexampleBankSolverIndependentReplayOrigin
            scope = SMTLib.lengthSMTLibQueryCounterexampleBankScope zeroQuery
            empty = LengthBank.emptyLengthCounterexampleBank
              LengthBank.defaultLengthCounterexampleBankLimits scope
            (recorded, recordedOutcome) =
              SMTLib.recordLengthSMTLibQueryCounterexampleInBank
                Evaluate.defaultLengthEvaluationLimits zeroQuery live
                oldReceipt empty
        _ <- expectRight recordedOutcome
        sample <- case LengthBank.lengthCounterexampleBankSamples recorded of
          [value] -> pure value
          values -> assertFailure
            ("unexpected recorded scalar samples: " ++ show values) >>
            error "unreachable"
        let beforeSamples = LengthBank.lengthCounterexampleBankSamples recorded
            (replayed, replayOutcome) =
              SMTLib.replayLengthSMTLibCounterexampleBankSample
                Evaluate.defaultLengthEvaluationLimits identityQuery sample
                recorded
        fresh <- expectCounterexample replayOutcome
        Evaluate.validatedLengthCounterexampleInputs fresh @?= [3]
        Evaluate.validatedLengthCounterexampleResult oldReceipt @?= 0
        Evaluate.validatedLengthCounterexampleResult fresh @?= 3
        LengthBank.lengthCounterexampleBankSamples replayed @?= beforeSamples
        scalarBankStats recorded @?=
          (1, scalarBankEncodedBytes recorded, 1, 0, 0, 1)
        scalarBankStats replayed @?=
          (1, scalarBankEncodedBytes replayed, 1, 0, 0, 2)

        ((_, foreignQuery), _) <-
          scalarCounterexampleBankBridgeFixture identityLengthContract
        (scopeBank, scopeOutcome) <- evaluateWithin $ force $
          SMTLib.replayLengthSMTLibCounterexampleBankSample
            (error "sample scope mismatch demanded scalar evaluation limits")
            foreignQuery
            (error "sample scope mismatch demanded scalar sample")
            recorded
        scopeOutcome @?= Left
          SMTLib.LengthSMTLibCounterexampleBankSampleReplayScopeMismatch
        scalarBankStats scopeBank @?= scalarBankStats recorded

        cappedLimits <- expectRight
          $ LengthBank.mkLengthCounterexampleBankLimits 1 1 8 4096 0
        liveBank <- expectRight
          $ LengthBank.insertLengthCounterexampleBankSample live [3]
          $ LengthBank.emptyLengthCounterexampleBank cappedLimits scope
        independentBank <- expectRight
          $ LengthBank.insertLengthCounterexampleBankSample independent [3]
          $ LengthBank.emptyLengthCounterexampleBank cappedLimits scope
        liveSample <- case LengthBank.lengthCounterexampleBankSamples liveBank of
          [value] -> pure value
          values -> assertFailure
            ("unexpected live-origin scalar samples: " ++ show values) >>
            error "unreachable"
        independentSample <- case
            LengthBank.lengthCounterexampleBankSamples independentBank of
          [value] -> pure value
          values -> assertFailure
            ("unexpected independent-origin scalar samples: " ++ show values) >>
            error "unreachable"
        (memberBank, memberOutcome) <- evaluateWithin $ force $
          SMTLib.replayLengthSMTLibCounterexampleBankSample
            (error "foreign sample demanded scalar evaluation limits")
            zeroQuery liveSample independentBank
        memberOutcome @?= Left
          SMTLib.LengthSMTLibCounterexampleBankSampleReplaySampleNotRetained
        scalarBankStats memberBank @?=
          (1, scalarBankEncodedBytes memberBank, 1, 0, 0, 0)
        (attemptBank, attemptOutcome) <- evaluateWithin $ force $
          SMTLib.replayLengthSMTLibCounterexampleBankSample
            (error "sample attempt cap demanded scalar evaluation limits")
            zeroQuery independentSample independentBank
        attemptOutcome @?= Left
          (SMTLib.LengthSMTLibCounterexampleBankSampleReplayAttemptRejected
            $ LengthBank.LengthCounterexampleBankReplayAttemptLimitExceeded
                0 1)
        scalarBankStats attemptBank @?=
          (1, scalarBankEncodedBytes attemptBank, 1, 0, 0, 0)

        ((_, _), (identityProblem, identityMissQuery)) <-
          scalarCounterexampleBankBridgeFixture identityLengthContract
        let missScope =
              LengthProblem.checkedLengthProblemCounterexampleBankScope
                identityProblem
            missEmpty = LengthBank.emptyLengthCounterexampleBank
              LengthBank.defaultLengthCounterexampleBankLimits missScope
        missStored <- expectRight
          $ LengthBank.insertLengthCounterexampleBankSample live [3] missEmpty
        missSample <- case
            LengthBank.lengthCounterexampleBankSamples missStored of
          [value] -> pure value
          values -> assertFailure
            ("unexpected scalar miss samples: " ++ show values) >>
            error "unreachable"
        let (missBank, missOutcome) =
              SMTLib.replayLengthSMTLibCounterexampleBankSample
                Evaluate.defaultLengthEvaluationLimits identityMissQuery
                missSample missStored
        missOutcome @?= Right Nothing
        LengthBank.lengthCounterexampleBankSamples missBank @?=
          LengthBank.lengthCounterexampleBankSamples missStored
        scalarBankStats missBank @?=
          (1, scalarBankEncodedBytes missBank, 1, 0, 0, 1)

        inputStored <- expectRight
          $ LengthBank.insertLengthCounterexampleBankSample live [3] empty
        inputSample <- case
            LengthBank.lengthCounterexampleBankSamples inputStored of
          [value] -> pure value
          values -> assertFailure
            ("unexpected scalar input-error samples: " ++ show values) >>
            error "unreachable"
        let (inputBank, inputOutcome) =
              SMTLib.replayLengthSMTLibCounterexampleBankSample
                (evaluationLimitsWith 1 8) zeroQuery inputSample inputStored
            inputFailure = Evaluate.LengthEvaluationValueBitLimitExceeded
              (Evaluate.LengthProblemInputValue 0) 1 2
        inputOutcome @?= Left
          (SMTLib.LengthSMTLibCounterexampleBankSampleReplayInputRejected
            $ SMTLib.LengthSMTLibInputReplayEvaluationRejected inputFailure)
        LengthBank.lengthCounterexampleBankSamples inputBank @?=
          LengthBank.lengthCounterexampleBankSamples inputStored
        scalarBankStats inputBank @?=
          (1, scalarBankEncodedBytes inputBank, 1, 0, 0, 1)

  , testCase
      "H. preserve nominal product receipts, gates, and charged sample replay" $
      do
        ((zeroInputProblem, zeroInputQuery), (_, inputZeroQuery)) <-
          pairCounterexampleBankBridgeFixture
            firstSuccessorSpinePairContract
        oldReceipt <- validatedLengthSpinePairCounterexampleAt
          zeroInputProblem [3]
        let live =
              LengthBank.lengthSpinePairCounterexampleBankLiveModelReplayOrigin
            independent =
              LengthBank.lengthSpinePairCounterexampleBankSolverIndependentReplayOrigin
            scope =
              SMTLib.lengthSpinePairSMTLibQueryCounterexampleBankScope
                inputZeroQuery
            empty = LengthBank.emptyLengthSpinePairCounterexampleBank
              LengthBank.defaultLengthSpinePairCounterexampleBankLimits scope
            (recorded, recordOutcome) =
              SMTLib.recordLengthSpinePairSMTLibQueryCounterexampleInBank
                Evaluate.defaultLengthEvaluationLimits inputZeroQuery live
                oldReceipt empty
        fresh <- expectRight recordOutcome
        Evaluate.validatedLengthSpinePairCounterexampleInputs fresh @?= [3]
        Evaluate.validatedLengthSpinePairCounterexampleResult oldReceipt @?=
          Length.LengthSpinePair 0 3
        Evaluate.validatedLengthSpinePairCounterexampleResult fresh @?=
          Length.LengthSpinePair 3 0
        Evaluate.validatedLengthSpinePairCounterexampleBasis fresh @?=
          Evaluate.ProviderIndependentFiniteSpineModel
        pairBankStats recorded @?=
          (1, pairBankEncodedBytes recorded, 1, 0, 0, 1)
        sample <- case
            LengthBank.lengthSpinePairCounterexampleBankSamples recorded of
          [value] -> pure value
          values -> assertFailure
            ("unexpected recorded product samples: " ++ show values) >>
            error "unreachable"
        let recordedSamples =
              LengthBank.lengthSpinePairCounterexampleBankSamples recorded
            (replayed, replayOutcome) =
              SMTLib.replayLengthSpinePairSMTLibCounterexampleBankSample
                Evaluate.defaultLengthEvaluationLimits zeroInputQuery sample
                recorded
        replayFresh <- expectCounterexample replayOutcome
        Evaluate.validatedLengthSpinePairCounterexampleResult replayFresh @?=
          Length.LengthSpinePair 0 3
        LengthBank.lengthSpinePairCounterexampleBankSamples replayed @?=
          recordedSamples
        pairBankStats replayed @?=
          (1, pairBankEncodedBytes replayed, 1, 0, 0, 2)

        let (inputBank, inputOutcome) =
              SMTLib.replayLengthSpinePairSMTLibCounterexampleBankSample
                (evaluationLimitsWith 1 8) inputZeroQuery sample replayed
            inputFailure =
              Evaluate.LengthSpinePairEvaluationValueBitLimitExceeded
                (Evaluate.LengthSpinePairProblemInputValue 0) 1 2
        inputOutcome @?= Left
          (SMTLib.LengthSpinePairSMTLibCounterexampleBankSampleReplayInputRejected
            $ SMTLib.LengthSpinePairSMTLibInputReplayEvaluationRejected
                inputFailure)
        LengthBank.lengthSpinePairCounterexampleBankSamples inputBank @?=
          recordedSamples
        pairBankStats inputBank @?=
          (1, pairBankEncodedBytes inputBank, 1, 0, 0, 3)

        let recordInputEmpty =
              LengthBank.emptyLengthSpinePairCounterexampleBank
                LengthBank.defaultLengthSpinePairCounterexampleBankLimits
                scope
            (recordInputBank, recordInputOutcome) =
              SMTLib.recordLengthSpinePairSMTLibQueryCounterexampleInBank
                (evaluationLimitsWith 1 8) inputZeroQuery
                (error "record input rejection demanded product origin")
                oldReceipt recordInputEmpty
        recordInputOutcome @?= Left
          (SMTLib.LengthSpinePairSMTLibCounterexampleBankRecordInputReplayRejected
            $ SMTLib.LengthSpinePairSMTLibInputReplayEvaluationRejected
                inputFailure)
        pairBankStats recordInputBank @?= (0, 0, 0, 0, 0, 1)

        ((missProblem, _), (_, missQuery)) <-
          pairCounterexampleBankBridgeFixture
          firstIdentitySpinePairContract
        missReceipt <- validatedLengthSpinePairCounterexampleAt missProblem [3]
        let missScope =
              SMTLib.lengthSpinePairSMTLibQueryCounterexampleBankScope
                missQuery
            missEmpty = LengthBank.emptyLengthSpinePairCounterexampleBank
              LengthBank.defaultLengthSpinePairCounterexampleBankLimits
              missScope
        (recordMissBank, recordMissOutcome) <- evaluateWithin $ force $
          SMTLib.recordLengthSpinePairSMTLibQueryCounterexampleInBank
            Evaluate.defaultLengthEvaluationLimits missQuery
            (error "product record miss demanded origin")
            missReceipt missEmpty
        recordMissOutcome @?= Left
          SMTLib.LengthSpinePairSMTLibCounterexampleBankRecordCounterexampleNotReproduced
        LengthBank.lengthSpinePairCounterexampleBankSamples recordMissBank @?=
          []
        pairBankStats recordMissBank @?= (0, 0, 0, 0, 0, 1)

        missStored <- expectRight
          $ LengthBank.insertLengthSpinePairCounterexampleBankSample
              live [3] missEmpty
        missSample <- case
            LengthBank.lengthSpinePairCounterexampleBankSamples missStored of
          [value] -> pure value
          values -> assertFailure
            ("unexpected product miss samples: " ++ show values) >>
            error "unreachable"
        let (missBank, missOutcome) =
              SMTLib.replayLengthSpinePairSMTLibCounterexampleBankSample
                Evaluate.defaultLengthEvaluationLimits missQuery missSample
                missStored
        missOutcome @?= Right Nothing
        pairBankStats missBank @?=
          (1, pairBankEncodedBytes missBank, 1, 0, 0, 1)

        (recordScopeBank, recordScopeOutcome) <- evaluateWithin $ force $
          SMTLib.recordLengthSpinePairSMTLibQueryCounterexampleInBank
            (error "record scope mismatch demanded product evaluation limits")
            missQuery
            (error "record scope mismatch demanded product origin")
            (error "record scope mismatch demanded product receipt")
            recorded
        recordScopeOutcome @?= Left
          SMTLib.LengthSpinePairSMTLibCounterexampleBankRecordScopeMismatch
        LengthBank.lengthSpinePairCounterexampleBankSamples recordScopeBank @?=
          recordedSamples
        pairBankStats recordScopeBank @?= pairBankStats recorded

        (sampleScopeBank, sampleScopeOutcome) <- evaluateWithin $ force $
          SMTLib.replayLengthSpinePairSMTLibCounterexampleBankSample
            (error "sample scope mismatch demanded product evaluation limits")
            missQuery
            (error "sample scope mismatch demanded product sample")
            recorded
        sampleScopeOutcome @?= Left
          SMTLib.LengthSpinePairSMTLibCounterexampleBankSampleReplayScopeMismatch
        LengthBank.lengthSpinePairCounterexampleBankSamples sampleScopeBank @?=
          recordedSamples
        pairBankStats sampleScopeBank @?= pairBankStats recorded

        entryLimits <- expectRight
          $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
              0 1 8 4096 1
        let noEntries = LengthBank.emptyLengthSpinePairCounterexampleBank
              entryLimits scope
        (entryBank, entryOutcome) <- evaluateWithin $ force $
          SMTLib.recordLengthSpinePairSMTLibQueryCounterexampleInBank
            Evaluate.defaultLengthEvaluationLimits inputZeroQuery
            (error "zero-entry insertion demanded product origin")
            oldReceipt noEntries
        entryOutcome @?= Left
          (SMTLib.LengthSpinePairSMTLibCounterexampleBankRecordInsertionRejected
            $ LengthBank.LengthSpinePairCounterexampleBankEntryLimitExceeded
                0 1)
        pairBankStats entryBank @?= (0, 0, 0, 0, 0, 1)

        cappedLimits <- expectRight
          $ LengthBank.mkLengthSpinePairCounterexampleBankLimits
              1 1 8 4096 0
        capped <- expectRight
          $ LengthBank.insertLengthSpinePairCounterexampleBankSample live [3]
          $ LengthBank.emptyLengthSpinePairCounterexampleBank
              cappedLimits scope
        independentCapped <- expectRight
          $ LengthBank.insertLengthSpinePairCounterexampleBankSample
              independent [3]
          $ LengthBank.emptyLengthSpinePairCounterexampleBank
              cappedLimits scope
        cappedSample <- case
            LengthBank.lengthSpinePairCounterexampleBankSamples capped of
          [value] -> pure value
          values -> assertFailure
            ("unexpected capped product samples: " ++ show values) >>
            error "unreachable"
        independentCappedSample <- case
            LengthBank.lengthSpinePairCounterexampleBankSamples
              independentCapped of
          [value] -> pure value
          values -> assertFailure
            ("unexpected independent capped product samples: " ++
              show values) >>
            error "unreachable"

        (memberBank, memberOutcome) <- evaluateWithin $ force $
          SMTLib.replayLengthSpinePairSMTLibCounterexampleBankSample
            (error "foreign sample demanded product evaluation limits")
            inputZeroQuery cappedSample independentCapped
        memberOutcome @?= Left
          SMTLib.LengthSpinePairSMTLibCounterexampleBankSampleReplaySampleNotRetained
        pairBankStats memberBank @?=
          (1, pairBankEncodedBytes memberBank, 1, 0, 0, 0)

        (recordAttemptBank, recordAttemptOutcome) <- evaluateWithin $ force $
          SMTLib.recordLengthSpinePairSMTLibQueryCounterexampleInBank
            (error "record attempt cap demanded product evaluation limits")
            inputZeroQuery
            (error "record attempt cap demanded product origin")
            (error "record attempt cap demanded product receipt")
            independentCapped
        recordAttemptOutcome @?= Left
          (SMTLib.LengthSpinePairSMTLibCounterexampleBankRecordAttemptRejected
            $ LengthBank.LengthSpinePairCounterexampleBankReplayAttemptLimitExceeded
                0 1)
        pairBankStats recordAttemptBank @?=
          ( 1, pairBankEncodedBytes recordAttemptBank, 1, 0, 0, 0 )

        (sampleAttemptBank, sampleAttemptOutcome) <- evaluateWithin $ force $
          SMTLib.replayLengthSpinePairSMTLibCounterexampleBankSample
            (error "sample attempt cap demanded product evaluation limits")
            inputZeroQuery independentCappedSample independentCapped
        sampleAttemptOutcome @?= Left
          (SMTLib.LengthSpinePairSMTLibCounterexampleBankSampleReplayAttemptRejected
            $ LengthBank.LengthSpinePairCounterexampleBankReplayAttemptLimitExceeded
                0 1)
        pairBankStats sampleAttemptBank @?=
          (1, pairBankEncodedBytes sampleAttemptBank, 1, 0, 0, 0)
  ]

counterexampleSimplificationTests :: TestTree
counterexampleSimplificationTests = testGroup
  "query-owned bounded counterexample simplification"
  [ testCase
      "strictly reduce scalar and product anchors with exact inspected counts" $
      do
        Evaluate.lengthCounterexampleSimplificationSchemaTag @?=
          asciiBytes
            "finite-list-spine-length/bounded-counterexample-simplification/v1"
        Evaluate.lengthSpinePairCounterexampleSimplificationSchemaTag @?=
          asciiBytes
            "finite-binary-product-spine-lengths/bounded-counterexample-simplification/v1"
        assertBool "product simplification reused the scalar receipt schema" $
          Evaluate.lengthSpinePairCounterexampleSimplificationSchemaTag /=
            Evaluate.lengthCounterexampleSimplificationSchemaTag

        let first = Length.LengthVariable $ Length.LengthInput 0
            result = Length.LengthVariable Length.LengthResult
            scalarSource = contractWith (Length.LengthTruth True)
              $ Length.LengthEqual result first
        scalarProblem <- adversarialBinaryConstantZeroProblem scalarSource
        scalarAnchor <- validatedLengthCounterexampleAt scalarProblem [2, 2]
        (scalarEvidence, scalarReceipt) <- expectLengthSimplification
          scalarProblem
          $ Evaluate.simplifyLengthProblemCounterexample
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits
              scalarProblem scalarAnchor
        -- In the [0..2] x [0..2] box, [1,0] has zero-based mixed-radix
        -- ordinal three because the final source input varies fastest.
        assertValidatedLengthCounterexampleSimplification
          scalarReceipt [2, 2] 4 [1, 0] 0
          Evaluate.ProviderIndependentFiniteSpineModel
        scalarFresh <- validatedLengthCounterexampleAt scalarProblem [1, 0]
        Evaluate.validatedLengthCounterexampleSimplificationCounterexample
            scalarReceipt @?= scalarFresh
        force scalarReceipt `seq` pure ()

        let pairInput = Length.LengthVariable
              $ Length.LengthSpinePairInput 0
            pairSource = spinePairContractWith (Length.LengthTruth True)
              $ Length.LengthAll
                  [ Length.LengthEqual
                      (pairResultVariable Length.LengthSpinePairFirst) pairInput
                  , Length.LengthEqual
                      (pairResultVariable Length.LengthSpinePairSecond) pairInput
                  ]
        pairProblem <- adversarialInputAndZeroSpinePairProblem pairSource
        pairAnchor <- validatedLengthSpinePairCounterexampleAt pairProblem [3]
        (pairEvidence, pairReceipt) <- expectLengthSpinePairSimplification
          pairProblem
          $ Evaluate.simplifyLengthSpinePairProblemCounterexample
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits
              pairProblem pairAnchor
        assertValidatedLengthSpinePairCounterexampleSimplification
          pairReceipt [3] 2 [1] (Length.LengthSpinePair 1 0)
          Evaluate.ProviderIndependentFiniteSpineModel
        pairFresh <- validatedLengthSpinePairCounterexampleAt pairProblem [1]
        Evaluate.validatedLengthSpinePairCounterexampleSimplificationCounterexample
            pairReceipt @?= pairFresh
        force pairReceipt `seq` pure ()

        let scalarAsPair = unsafeCoerce scalarEvidence
              :: SemanticProblem.BehavioralEvidence
                  Length.FiniteBinaryProductSpineLengthsV1
                  Evaluate.ValidatedLengthSpinePairCounterexampleSimplification
            pairAsScalar = unsafeCoerce pairEvidence
              :: SemanticProblem.BehavioralEvidence
                  Length.FiniteListSpineLengthV1
                  Evaluate.ValidatedLengthCounterexampleSimplification
        assertLeft SemanticProblem.ReplayDomainMismatch
          $ SemanticProblem.replayBehavioralEvidence
              (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem
                pairProblem)
              scalarAsPair
        assertLeft SemanticProblem.ReplayDomainMismatch
          $ SemanticProblem.replayBehavioralEvidence
              (LengthProblem.checkedLengthProblemBehavioralProblem
                scalarProblem)
              pairAsScalar
  , testCase "return no receipt for unchanged and nullary anchors" $ do
      scalar <- adversarialConstantZeroProblem identityLengthContract
      scalarAnchor <- validatedLengthCounterexampleAt scalar [1]
      expectNoCounterexample
        $ Evaluate.simplifyLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits scalar scalarAnchor

      let result = Length.LengthVariable Length.LengthResult
          nullarySource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral 1
      nullary <- adversarialZeroInputProblem nullarySource
      nullaryAnchor <- validatedLengthCounterexampleAt nullary []
      expectNoCounterexample
        $ Evaluate.simplifyLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits nullary nullaryAnchor

      let pairInput = Length.LengthVariable
            $ Length.LengthSpinePairInput 0
          pairSource = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (pairResultVariable Length.LengthSpinePairSecond) pairInput
      pair <- adversarialInputAndZeroSpinePairProblem pairSource
      pairAnchor <- validatedLengthSpinePairCounterexampleAt pair [1]
      expectNoCounterexample
        $ Evaluate.simplifyLengthSpinePairProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits pair pairAnchor

      let nullaryPairSource = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (pairResultVariable Length.LengthSpinePairFirst)
                (Length.LengthLiteral 1)
      nullaryPair <- adversarialNullaryZeroSpinePairProblem nullaryPairSource
      nullaryPairAnchor <- validatedLengthSpinePairCounterexampleAt
        nullaryPair []
      expectNoCounterexample
        $ Evaluate.simplifyLengthSpinePairProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits
            nullaryPair nullaryPairAnchor
  , testCase
      "treat width and Cartesian-product admission misses as unavailable" $ do
      binary <- adversarialBinaryConstantZeroProblem identityLengthContract
      binaryAnchor <- validatedLengthCounterexampleAt binary [1, 1]
      narrow <- inputBoxLimits 1 16
      widthResult <- evaluateWithin
        $ Evaluate.simplifyLengthProblemCounterexample
            (error "width admission demanded scalar evaluation limits")
            narrow binary binaryAnchor
      expectNoCounterexample widthResult

      let pairInput = Length.LengthVariable
            $ Length.LengthSpinePairInput 0
          pairSource = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (pairResultVariable Length.LengthSpinePairSecond) pairInput
      pair <- adversarialInputAndZeroSpinePairProblem pairSource
      pairAnchor <- validatedLengthSpinePairCounterexampleAt pair [2]
      twoAssignments <- inputBoxLimits 1 2
      expectNoCounterexample
        $ Evaluate.simplifyLengthSpinePairProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits
            twoAssignments pair pairAnchor
  , testCase
      "reject stale scalar anchor shape, values, and replay states in order" $ do
      unary <- adversarialConstantZeroProblem identityLengthContract
      unaryAnchor <- validatedLengthCounterexampleAt unary [1]
      binary <- adversarialBinaryConstantZeroProblem identityLengthContract
      shapeResult <- evaluateWithin
        $ Evaluate.simplifyLengthProblemCounterexample
            (error "anchor arity demanded evaluation limits")
            Evaluate.defaultLengthInputBoxLimits binary unaryAnchor
      assertLeft
        (Evaluate.LengthCounterexampleSimplificationInputBoxValidationRejected
          $ Evaluate.LengthInputBoxBoundsArityMismatch 2 1)
        shapeResult

      largeAnchor <- validatedLengthCounterexampleAt unary [4]
      assertLeft
        (Evaluate.LengthCounterexampleSimplificationInputBoxValidationRejected
          $ Evaluate.LengthInputBoxMaximumValueRejected 0
          $ Evaluate.LengthEvaluationValueBitLimitExceeded
              (Evaluate.LengthProblemInputValue 0) 2 3)
        $ Evaluate.simplifyLengthProblemCounterexample
            (evaluationLimitsWith 2 8)
            Evaluate.defaultLengthInputBoxLimits unary largeAnchor

      safe <- adversarialConstantZeroProblem trivialLengthContract
      assertLeft
        Evaluate.LengthCounterexampleSimplificationAnchorNotCounterexample
        $ Evaluate.simplifyLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits safe unaryAnchor

      let result = Length.LengthVariable Length.LengthResult
          overflowingSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral 4
      overflowing <- adversarialConstantZeroProblem overflowingSource
      assertLeft
        (Evaluate.LengthCounterexampleSimplificationAnchorEvaluationRejected
          $ Evaluate.LengthEvaluationValueBitLimitExceeded
              Evaluate.LengthIntermediateValue 2 3)
        $ Evaluate.simplifyLengthProblemCounterexample
            (evaluationLimitsWith 2 2)
            Evaluate.defaultLengthInputBoxLimits overflowing unaryAnchor
  , testCase
      "reject stale product anchor shape, values, and replay states in order" $
      do
        let pairInput = Length.LengthVariable
              $ Length.LengthSpinePairInput 0
            violatingSource = spinePairContractWith (Length.LengthTruth True)
              $ Length.LengthEqual
                  (pairResultVariable Length.LengthSpinePairSecond) pairInput
        unary <- adversarialInputAndZeroSpinePairProblem violatingSource
        unaryAnchor <- validatedLengthSpinePairCounterexampleAt unary [1]
        nullary <- adversarialNullaryZeroSpinePairProblem trivialSpinePairContract
        shapeResult <- evaluateWithin
          $ Evaluate.simplifyLengthSpinePairProblemCounterexample
              (error "pair anchor arity demanded evaluation limits")
              Evaluate.defaultLengthInputBoxLimits nullary unaryAnchor
        assertLeft
          (Evaluate.LengthSpinePairCounterexampleSimplificationInputBoxValidationRejected
            $ Evaluate.LengthSpinePairInputBoxBoundsArityMismatch 0 1)
          shapeResult

        largeAnchor <- validatedLengthSpinePairCounterexampleAt unary [4]
        assertLeft
          (Evaluate.LengthSpinePairCounterexampleSimplificationInputBoxValidationRejected
            $ Evaluate.LengthSpinePairInputBoxMaximumValueRejected 0
            $ Evaluate.LengthSpinePairEvaluationValueBitLimitExceeded
                (Evaluate.LengthSpinePairProblemInputValue 0) 2 3)
          $ Evaluate.simplifyLengthSpinePairProblemCounterexample
              (evaluationLimitsWith 2 8)
              Evaluate.defaultLengthInputBoxLimits unary largeAnchor

        safe <- adversarialInputAndZeroSpinePairProblem trivialSpinePairContract
        assertLeft
          Evaluate.LengthSpinePairCounterexampleSimplificationAnchorNotCounterexample
          $ Evaluate.simplifyLengthSpinePairProblemCounterexample
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits safe unaryAnchor

        let overflowingSource = spinePairContractWith (Length.LengthTruth True)
              $ Length.LengthEqual
                  (pairResultVariable Length.LengthSpinePairSecond)
                  (Length.LengthLiteral 4)
        overflowing <- adversarialInputAndZeroSpinePairProblem overflowingSource
        assertLeft
          (Evaluate.LengthSpinePairCounterexampleSimplificationAnchorEvaluationRejected
            $ Evaluate.LengthSpinePairEvaluationValueBitLimitExceeded
                Evaluate.LengthSpinePairIntermediateValue 2 3)
          $ Evaluate.simplifyLengthSpinePairProblemCounterexample
              (evaluationLimitsWith 2 2)
              Evaluate.defaultLengthInputBoxLimits overflowing unaryAnchor
  , testCase "fail closed on an earlier admitted scalar or product trial" $ do
      let scalarInput = Length.LengthVariable $ Length.LengthInput 0
          scalarResult = Length.LengthVariable Length.LengthResult
          scalarIsZero = Length.LengthEqual scalarInput
            $ Length.LengthLiteral 0
          scalarSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual scalarResult
            $ Length.LengthIf scalarIsZero
                (Length.LengthLiteral 2)
                (Length.LengthLiteral 1)
      scalar <- adversarialConstantZeroProblem scalarSource
      scalarAnchor <- validatedLengthCounterexampleAt scalar [2]
      let scalarOverflow = Evaluate.LengthEvaluationValueBitLimitExceeded
            Evaluate.LengthIntermediateValue 1 2
      assertLeft
        (Evaluate.LengthCounterexampleSimplificationInputBoxValidationRejected
          $ Evaluate.LengthInputBoxAssignmentEvaluationRejected
              0 scalarOverflow)
        $ Evaluate.simplifyLengthProblemCounterexample
            (evaluationLimitsWith 2 1)
            Evaluate.defaultLengthInputBoxLimits scalar scalarAnchor

      let pairInput = Length.LengthVariable
            $ Length.LengthSpinePairInput 0
          pairIsZero = Length.LengthEqual pairInput $ Length.LengthLiteral 0
          pairSource = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (pairResultVariable Length.LengthSpinePairSecond)
            $ Length.LengthIf pairIsZero
                (Length.LengthLiteral 2)
                (Length.LengthLiteral 1)
      pair <- adversarialInputAndZeroSpinePairProblem pairSource
      pairAnchor <- validatedLengthSpinePairCounterexampleAt pair [2]
      let pairOverflow =
            Evaluate.LengthSpinePairEvaluationValueBitLimitExceeded
              Evaluate.LengthSpinePairIntermediateValue 1 2
      assertLeft
        (Evaluate.LengthSpinePairCounterexampleSimplificationInputBoxValidationRejected
          $ Evaluate.LengthSpinePairInputBoxAssignmentEvaluationRejected
              0 pairOverflow)
        $ Evaluate.simplifyLengthSpinePairProblemCounterexample
            (evaluationLimitsWith 2 1)
            Evaluate.defaultLengthInputBoxLimits pair pairAnchor
  , testCase "retain the scalar anchor's assumed-provider basis" $ do
      let input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          source = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result input
      problem <- adversarialConstantProviderProblem 7 source
      anchor <- validatedLengthCounterexampleAt problem [3]
      (_, receipt) <- expectLengthSimplification problem
        $ Evaluate.simplifyLengthProblemCounterexample
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits problem anchor
      providerName <- expectName "Fixture.problemReplayConstant"
      assertValidatedLengthCounterexampleSimplification
        receipt [3] 1 [0] 7
        $ Evaluate.FiniteSpineModelUnderAssumedProviderLaws [providerName]
  , testCase
      "associate scalar and product query wrappers without changing identity" $
      do
        let scalarFirst = Length.LengthVariable $ Length.LengthInput 0
            scalarResult = Length.LengthVariable Length.LengthResult
            scalarSource = contractWith (Length.LengthTruth True)
              $ Length.LengthEqual scalarResult scalarFirst
        scalarProblem <- adversarialBinaryConstantZeroProblem scalarSource
        scalarAnchor <- validatedLengthCounterexampleAt scalarProblem [2, 2]
        (_, directScalar) <- expectLengthSimplification scalarProblem
          $ Evaluate.simplifyLengthProblemCounterexample
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits
              scalarProblem scalarAnchor
        scalarQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits scalarProblem
        let scalarFingerprint = SMTLib.lengthSMTLibQueryFingerprint scalarQuery
            scalarCheck = SMTLib.lengthSMTLibQueryCheckBytes scalarQuery
            scalarSymbols = SMTLib.lengthSMTLibQueryInputSymbols scalarQuery
            scalarRequest =
              SMTLib.lengthSMTLibQueryInputValueRequestBytes scalarQuery
        queryScalar <- expectCounterexample
          $ SMTLib.simplifyLengthSMTLibQueryCounterexample
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits scalarQuery scalarAnchor
        queryScalar @?= directScalar
        SMTLib.lengthSMTLibQueryFingerprint scalarQuery @?= scalarFingerprint
        SMTLib.lengthSMTLibQueryCheckBytes scalarQuery @?= scalarCheck
        SMTLib.lengthSMTLibQueryInputSymbols scalarQuery @?= scalarSymbols
        SMTLib.lengthSMTLibQueryInputValueRequestBytes scalarQuery @?=
          scalarRequest

        let pairInput = Length.LengthVariable
              $ Length.LengthSpinePairInput 0
            pairSource = spinePairContractWith (Length.LengthTruth True)
              $ Length.LengthEqual
                  (pairResultVariable Length.LengthSpinePairSecond) pairInput
        pairProblem <- adversarialInputAndZeroSpinePairProblem pairSource
        pairAnchor <- validatedLengthSpinePairCounterexampleAt pairProblem [3]
        (_, directPair) <- expectLengthSpinePairSimplification pairProblem
          $ Evaluate.simplifyLengthSpinePairProblemCounterexample
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits pairProblem pairAnchor
        pairQuery <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits pairProblem
        let pairFingerprint =
              SMTLib.lengthSpinePairSMTLibQueryFingerprint pairQuery
            pairCheck = SMTLib.lengthSpinePairSMTLibQueryCheckBytes pairQuery
            pairSymbols = SMTLib.lengthSpinePairSMTLibQueryInputSymbols pairQuery
            pairRequest =
              SMTLib.lengthSpinePairSMTLibQueryInputValueRequestBytes pairQuery
        queryPair <- expectCounterexample
          $ SMTLib.simplifyLengthSpinePairSMTLibQueryCounterexample
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits pairQuery pairAnchor
        queryPair @?= directPair
        SMTLib.lengthSpinePairSMTLibQueryFingerprint pairQuery @?=
          pairFingerprint
        SMTLib.lengthSpinePairSMTLibQueryCheckBytes pairQuery @?= pairCheck
        SMTLib.lengthSpinePairSMTLibQueryInputSymbols pairQuery @?= pairSymbols
        SMTLib.lengthSpinePairSMTLibQueryInputValueRequestBytes pairQuery @?=
          pairRequest

        let scalarValueFailure =
              Evaluate.LengthCounterexampleSimplificationInputBoxValidationRejected
                $ Evaluate.LengthInputBoxMaximumValueRejected 0
                $ Evaluate.LengthEvaluationValueBitLimitExceeded
                    (Evaluate.LengthProblemInputValue 0) 1 2
        assertLeft
          (SMTLib.LengthSMTLibCounterexampleSimplificationRejected
            scalarValueFailure)
          $ SMTLib.simplifyLengthSMTLibQueryCounterexample
              (evaluationLimitsWith 1 8)
              Evaluate.defaultLengthInputBoxLimits scalarQuery scalarAnchor
  ]

validatedLengthCounterexampleAt
  :: LengthProblem.CheckedLengthProblem
      AdversarialIdentity AdversarialLocal
  -> [Natural]
  -> IO Evaluate.ValidatedLengthCounterexample
validatedLengthCounterexampleAt problem inputs = do
  evidence <- expectCounterexample
    $ Evaluate.validateLengthProblemCounterexample
        Evaluate.defaultLengthEvaluationLimits problem
        $ Evaluate.LengthProblemAssignment inputs
  expectRight $ SemanticProblem.replayBehavioralEvidence
    (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence

validatedLengthSpinePairCounterexampleAt
  :: LengthProblem.CheckedLengthSpinePairProblem
      AdversarialIdentity AdversarialLocal
  -> [Natural]
  -> IO Evaluate.ValidatedLengthSpinePairCounterexample
validatedLengthSpinePairCounterexampleAt problem inputs = do
  evidence <- expectCounterexample
    $ Evaluate.validateLengthSpinePairProblemCounterexample
        Evaluate.defaultLengthEvaluationLimits problem
        $ Evaluate.LengthProblemAssignment inputs
  expectRight $ SemanticProblem.replayBehavioralEvidence
    (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem problem)
    evidence

expectLengthSimplification
  :: LengthProblem.CheckedLengthProblem
      AdversarialIdentity AdversarialLocal
  -> Either Evaluate.LengthCounterexampleSimplificationError
      (Maybe
        (SemanticProblem.BehavioralEvidence
          Length.FiniteListSpineLengthV1
          Evaluate.ValidatedLengthCounterexampleSimplification))
  -> IO
      ( SemanticProblem.BehavioralEvidence
          Length.FiniteListSpineLengthV1
          Evaluate.ValidatedLengthCounterexampleSimplification
      , Evaluate.ValidatedLengthCounterexampleSimplification
      )
expectLengthSimplification problem simplification = do
  evidence <- expectCounterexample simplification
  receipt <- expectRight $ SemanticProblem.replayBehavioralEvidence
    (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence
  pure (evidence, receipt)

expectLengthSpinePairSimplification
  :: LengthProblem.CheckedLengthSpinePairProblem
      AdversarialIdentity AdversarialLocal
  -> Either Evaluate.LengthSpinePairCounterexampleSimplificationError
      (Maybe
        (SemanticProblem.BehavioralEvidence
          Length.FiniteBinaryProductSpineLengthsV1
          Evaluate.ValidatedLengthSpinePairCounterexampleSimplification))
  -> IO
      ( SemanticProblem.BehavioralEvidence
          Length.FiniteBinaryProductSpineLengthsV1
          Evaluate.ValidatedLengthSpinePairCounterexampleSimplification
      , Evaluate.ValidatedLengthSpinePairCounterexampleSimplification
      )
expectLengthSpinePairSimplification problem simplification = do
  evidence <- expectCounterexample simplification
  receipt <- expectRight $ SemanticProblem.replayBehavioralEvidence
    (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem problem)
    evidence
  pure (evidence, receipt)

assertValidatedLengthCounterexampleSimplification
  :: Evaluate.ValidatedLengthCounterexampleSimplification
  -> [Natural]
  -> Natural
  -> [Natural]
  -> Natural
  -> Evaluate.LengthCounterexampleBasis
  -> IO ()
assertValidatedLengthCounterexampleSimplification receipt original inspected
    inputs result basis = do
  Evaluate.validatedLengthCounterexampleSimplificationOriginalInputs receipt @?=
    original
  Evaluate.validatedLengthCounterexampleSimplificationInspectedAssignmentCount
      receipt @?= inspected
  Evaluate.validatedLengthCounterexampleSimplificationInputs receipt @?= inputs
  Evaluate.validatedLengthCounterexampleSimplificationResult receipt @?= result
  Evaluate.validatedLengthCounterexampleSimplificationBasis receipt @?= basis
  Evaluate.validatedLengthCounterexampleSimplificationChanged receipt @?= True

assertValidatedLengthSpinePairCounterexampleSimplification
  :: Evaluate.ValidatedLengthSpinePairCounterexampleSimplification
  -> [Natural]
  -> Natural
  -> [Natural]
  -> Length.LengthSpinePair Natural
  -> Evaluate.LengthCounterexampleBasis
  -> IO ()
assertValidatedLengthSpinePairCounterexampleSimplification receipt original
    inspected inputs result basis = do
  Evaluate.validatedLengthSpinePairCounterexampleSimplificationOriginalInputs
      receipt @?= original
  Evaluate.validatedLengthSpinePairCounterexampleSimplificationInspectedAssignmentCount
      receipt @?= inspected
  Evaluate.validatedLengthSpinePairCounterexampleSimplificationInputs receipt @?=
    inputs
  Evaluate.validatedLengthSpinePairCounterexampleSimplificationResult receipt @?=
    result
  Evaluate.validatedLengthSpinePairCounterexampleSimplificationBasis receipt @?=
    basis
  Evaluate.validatedLengthSpinePairCounterexampleSimplificationChanged receipt @?=
    True

inputBoxValidationTests :: TestTree
inputBoxValidationTests = testGroup "bounded exhaustive input-box validation"
  [ testCase "seal fixed limits and validate the one nullary assignment" $ do
      Evaluate.mkLengthInputBoxLimits
          Evaluate.defaultLengthInputBoxLimitSource @?=
        Right Evaluate.defaultLengthInputBoxLimits
      Evaluate.lengthInputBoxInputLimit
          Evaluate.defaultLengthInputBoxLimits @?= 8
      Evaluate.lengthInputBoxAssignmentLimit
          Evaluate.defaultLengthInputBoxLimits @?= 65536
      Evaluate.lengthInputBoxValidationSchemaTag @?=
        asciiBytes
          "finite-list-spine-length/bounded-input-box-validation/v1"
      Evaluate.mkLengthInputBoxLimits
          (Evaluate.defaultLengthInputBoxLimitSource
            { Evaluate.lengthInputBoxLimitSourceMaximumInputs = -1
            }) @?=
        Left (Evaluate.NegativeLengthInputBoxLimit
          Evaluate.LengthInputBoxMaximumInputs (-1))

      let result = Length.LengthVariable Length.LengthResult
          source expected = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral expected
      safeProblem <- adversarialZeroInputProblem $ source 0
      safeReceipt <- expectValidatedLengthInputBox safeProblem
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits safeProblem []
      assertValidatedLengthInputBox safeReceipt [] 1 1
        Evaluate.ProviderIndependentFiniteSpineModel

      violatingProblem <- adversarialZeroInputProblem $ source 1
      counterexample <- expectLengthInputBoxCounterexample violatingProblem
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits violatingProblem []
      Evaluate.validatedLengthCounterexampleInputs counterexample @?= []
      Evaluate.validatedLengthCounterexampleResult counterexample @?= 0

      noAssignments <- inputBoxLimits 0 0
      assertLeft (Evaluate.LengthInputBoxAssignmentLimitExceeded 0 1)
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits noAssignments safeProblem []
  , testCase
      "return the first unary and source-lexicographic binary violation" $ do
      unary <- adversarialConstantZeroProblem identityLengthContract
      unaryCounterexample <- expectLengthInputBoxCounterexample unary
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits unary [2]
      Evaluate.validatedLengthCounterexampleInputs unaryCounterexample @?= [1]
      Evaluate.validatedLengthCounterexampleResult unaryCounterexample @?= 0

      let first = Length.LengthVariable $ Length.LengthInput 0
          second = Length.LengthVariable $ Length.LengthInput 1
          result = Length.LengthVariable Length.LengthResult
          sumSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthSum [first, second]
      binary <- adversarialBinaryConstantZeroProblem sumSource
      binaryCounterexample <- expectLengthInputBoxCounterexample binary
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits binary [1, 1]
      -- Both [0,1] and [1,0] violate.  This result distinguishes the promised
      -- source-lexicographic order with the leftmost input varying slowest.
      Evaluate.validatedLengthCounterexampleInputs binaryCounterexample @?=
        [0, 1]
      Evaluate.validatedLengthCounterexampleResult binaryCounterexample @?= 0
  , testCase "retain complete safe boxes and applicable-assignment counts" $ do
      let result = Length.LengthVariable Length.LengthResult
          zeroSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral 0
      unary <- adversarialConstantZeroProblem zeroSource
      unaryReceipt <- expectValidatedLengthInputBox unary
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits unary [2]
      assertValidatedLengthInputBox unaryReceipt [2] 3 3
        Evaluate.ProviderIndependentFiniteSpineModel

      binary <- adversarialBinaryConstantZeroProblem trivialLengthContract
      binaryReceipt <- expectValidatedLengthInputBox binary
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits binary [1, 2]
      assertValidatedLengthInputBox binaryReceipt [1, 2] 6 6
        Evaluate.ProviderIndependentFiniteSpineModel

      let input = Length.LengthVariable $ Length.LengthInput 0
          providerContractSource = contractWith
            (Length.LengthAtMost input $ Length.LengthLiteral 1)
            $ Length.LengthEqual result $ Length.LengthLiteral 7
      providerProblem <- adversarialConstantProviderProblem
        7 providerContractSource
      providerReceipt <- expectValidatedLengthInputBox providerProblem
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits providerProblem [2]
      providerName <- expectName "Fixture.problemReplayConstant"
      assertValidatedLengthInputBox providerReceipt [2] 3 2
        $ Evaluate.FiniteSpineModelUnderAssumedProviderLaws [providerName]

      let vacuousSource = contractWith (Length.LengthTruth False)
            $ Length.LengthEqual result $ Length.LengthLiteral 7
      vacuousProblem <- adversarialConstantProviderProblem 7 vacuousSource
      vacuousReceipt <- expectValidatedLengthInputBox vacuousProblem
        $ Evaluate.validateLengthProblemInputBox
            (evaluationLimitsWith 1 0)
            Evaluate.defaultLengthInputBoxLimits vacuousProblem [1]
      -- A false precondition must avoid both the result and postcondition
      -- literals under the zero-bit intermediate cap, while the receipt still
      -- records its conservative assumed-provider basis.
      assertValidatedLengthInputBox vacuousReceipt [1] 2 0
        $ Evaluate.FiniteSpineModelUnderAssumedProviderLaws [providerName]
  , testCase "enforce width, shape, value, and assignment caps in order" $ do
      binary <- adversarialBinaryConstantZeroProblem trivialLengthContract
      narrow <- inputBoxLimits 1 16
      widthResult <- evaluateWithin
        $ Evaluate.validateLengthProblemInputBox
            (error "input width rejection demanded evaluation limits")
            narrow binary
            (error "input width rejection demanded raw maximums")
      assertLeft (Evaluate.LengthInputBoxProblemInputLimitExceeded 1 2)
        widthResult

      unary <- adversarialConstantZeroProblem identityLengthContract
      let poisonedMaximums =
            [ error "box arity demanded its first maximum"
            , error "box arity demanded its excess maximum"
            ]
          cyclicMaximums = 0 : cyclicMaximums
          validate maximums = Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits unary maximums
      poisonedResult <- evaluateWithin $ validate poisonedMaximums
      assertLeft (Evaluate.LengthInputBoxBoundsArityMismatch 1 2)
        poisonedResult
      cyclicResult <- evaluateWithin $ validate cyclicMaximums
      assertLeft (Evaluate.LengthInputBoxBoundsArityMismatch 1 2) cyclicResult

      maximumResult <- evaluateWithin
        $ Evaluate.validateLengthProblemInputBox
            (evaluationLimitsWith 2 8)
            Evaluate.defaultLengthInputBoxLimits binary
            [4, error "maximum checking demanded a later value"]
      assertLeft
        (Evaluate.LengthInputBoxMaximumValueRejected 0
          $ Evaluate.LengthEvaluationValueBitLimitExceeded
              (Evaluate.LengthProblemInputValue 0) 2 3)
        maximumResult

      let result = Length.LengthVariable Length.LengthResult
          demandingSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral 1
      demanding <- adversarialBinaryConstantZeroProblem demandingSource
      threeAssignments <- inputBoxLimits 2 3
      -- The two-bit box has four assignments.  Its product cap must win
      -- before the zero-bit intermediate evaluator reaches literal one.
      assertLeft (Evaluate.LengthInputBoxAssignmentLimitExceeded 3 4)
        $ Evaluate.validateLengthProblemInputBox
            (evaluationLimitsWith 1 0) threeAssignments demanding [1, 1]
  , testCase "stop at the first violation or evaluation error ordinal" $ do
      let input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          isZero = Length.LengthEqual input $ Length.LengthLiteral 0
          source whenZero whenNonzero = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result
            $ Length.LengthIf isZero
                (Length.LengthLiteral whenZero)
                (Length.LengthLiteral whenNonzero)
          validate problem = Evaluate.validateLengthProblemInputBox
            (evaluationLimitsWith 1 1)
            Evaluate.defaultLengthInputBoxLimits problem [1]
          overflow = Evaluate.LengthEvaluationValueBitLimitExceeded
            Evaluate.LengthIntermediateValue 1 2

      violationFirst <- adversarialConstantZeroProblem $ source 1 2
      counterexample <- expectLengthInputBoxCounterexample violationFirst
        $ validate violationFirst
      Evaluate.validatedLengthCounterexampleInputs counterexample @?= [0]

      errorFirst <- adversarialConstantZeroProblem $ source 2 1
      assertLeft
        (Evaluate.LengthInputBoxAssignmentEvaluationRejected 0 overflow)
        $ validate errorFirst

      errorSecond <- adversarialConstantZeroProblem $ source 0 2
      assertLeft
        (Evaluate.LengthInputBoxAssignmentEvaluationRejected 1 overflow)
        $ validate errorSecond
  , testCase "associate both evidence arms and reject stale problems" $ do
      let result = Length.LengthVariable Length.LengthResult
          safeSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral 0
      safeProblem <- adversarialConstantZeroProblem safeSource
      safeValidation <- expectRight
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits safeProblem [1]
      safeEvidence <- case safeValidation of
        Evaluate.LengthInputBoxValidated evidence -> pure evidence
        Evaluate.LengthInputBoxCounterexample{} -> assertFailure
          "the safe box produced counterexample evidence" >> error "unreachable"
      staleSafe <- adversarialConstantZeroProblem identityLengthContract
      assertLeft SemanticProblem.ReplayEncodingFingerprintMismatch
        $ SemanticProblem.replayBehavioralEvidence
            (LengthProblem.checkedLengthProblemBehavioralProblem staleSafe)
            safeEvidence

      counterexampleProblem <- adversarialConstantZeroProblem
        identityLengthContract
      counterexampleValidation <- expectRight
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits counterexampleProblem [1]
      counterexampleEvidence <- case counterexampleValidation of
        Evaluate.LengthInputBoxCounterexample evidence -> pure evidence
        Evaluate.LengthInputBoxValidated{} -> assertFailure
          "the violating box produced positive evidence" >> error "unreachable"
      staleCounterexample <- adversarialConstantZeroProblem
        trivialLengthContract
      assertLeft SemanticProblem.ReplayEncodingFingerprintMismatch
        $ SemanticProblem.replayBehavioralEvidence
            (LengthProblem.checkedLengthProblemBehavioralProblem
              staleCounterexample)
            counterexampleEvidence
  , testCase "make the query-owned wrapper exactly match independent replay" $ do
      let result = Length.LengthVariable Length.LengthResult
          providerContractSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral 7
      safeProblem <- adversarialConstantProviderProblem
        7 providerContractSource
      safeQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits safeProblem
      directSafe <- expectValidatedLengthInputBox safeProblem
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits safeProblem [2]
      querySafe <- expectRight
        $ SMTLib.validateLengthSMTLibQueryInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits safeQuery [2]
      case querySafe of
        Evaluate.LengthInputBoxValidated receipt -> receipt @?= directSafe
        Evaluate.LengthInputBoxCounterexample{} -> assertFailure
          "query-owned safe validation returned a counterexample"

      let first = Length.LengthVariable $ Length.LengthInput 0
          second = Length.LengthVariable $ Length.LengthInput 1
          sumSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthSum [first, second]
      violatingProblem <- adversarialBinaryConstantZeroProblem sumSource
      violatingQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits violatingProblem
      directCounterexample <- expectLengthInputBoxCounterexample
        violatingProblem
        $ Evaluate.validateLengthProblemInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits violatingProblem [1, 1]
      queryCounterexample <- expectRight
        $ SMTLib.validateLengthSMTLibQueryInputBox
            Evaluate.defaultLengthEvaluationLimits
            Evaluate.defaultLengthInputBoxLimits violatingQuery [1, 1]
      case queryCounterexample of
        Evaluate.LengthInputBoxCounterexample receipt ->
          receipt @?= directCounterexample
        Evaluate.LengthInputBoxValidated{} -> assertFailure
          "query-owned violating validation returned a positive receipt"

      unary <- adversarialConstantZeroProblem identityLengthContract
      unaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits unary
      assertLeft
        (SMTLib.LengthSMTLibInputBoxValidationRejected
          $ Evaluate.LengthInputBoxMaximumValueRejected 0
          $ Evaluate.LengthEvaluationValueBitLimitExceeded
              (Evaluate.LengthProblemInputValue 0) 2 3)
        $ SMTLib.validateLengthSMTLibQueryInputBox
            (evaluationLimitsWith 2 8)
            Evaluate.defaultLengthInputBoxLimits unaryQuery [4]
  ]

applicableDomainValidationTests
  :: TestTree
applicableDomainValidationTests =
  testGroup
    "current guarded recursive piecewise-affine applicable-domain validation"
    [ testCase
        "establish finite scalar guards and retain every negative alternative" $ do
        let input = Length.LengthVariable $ Length.LengthInput 0
            literal value = Length.LengthLiteral value
            bound expression maximumValue =
              Length.LengthAtMost expression $ literal maximumValue
            validate limits problem =
              Evaluate.validateLengthProblemApplicableDomain
                Evaluate.defaultLengthEvaluationLimits
                Evaluate.defaultLengthInputBoxLimits limits problem
            establish limits source = do
              problem <- adversarialConstantZeroProblem
                $ contractWith source $ Length.LengthTruth True
              receipt <- expectValidatedLengthApplicableDomain problem
                $ validate limits problem
              pure (problem, receipt)

            finiteGuard = Length.LengthAtMost
              (Length.LengthIf (bound input 2) input $ literal 5)
              $ literal 3
        finiteProblem <- adversarialConstantZeroProblem
          $ contractWith finiteGuard $ Length.LengthTruth True
        cap1 <- booleanFiniteUnionLimits 1 64 4096 256 262144
        finiteCapped <- evaluateWithin $ validate cap1 finiteProblem
        assertLeft
          (Evaluate.LengthApplicableDomainGeneratedBranchLimitExceeded 1 2)
          finiteCapped
        cap2 <- booleanFiniteUnionLimits 2 64 4096 256 262144
        (_, finiteReceipt) <- establish cap2 finiteGuard
        assertValidatedLengthApplicableDomain
          finiteReceipt [[2]] 1 3 3 3
            Evaluate.ProviderIndependentFiniteSpineModel

        let negativeEquality = Length.LengthAtMost
              (Length.LengthIf
                (Length.LengthEqual input $ literal 0)
                (literal 1) input)
              $ literal 2
        negativeEqualityProblem <- adversarialConstantZeroProblem
          $ contractWith negativeEquality $ Length.LengthTruth True
        negativeEqualityCapped <- evaluateWithin
          $ validate cap2 negativeEqualityProblem
        assertLeft
          (Evaluate.LengthApplicableDomainGeneratedBranchLimitExceeded 2 3)
          negativeEqualityCapped
        cap3 <- booleanFiniteUnionLimits 3 64 4096 256 262144
        (_, negativeEqualityReceipt) <- establish cap3 negativeEquality
        assertValidatedLengthApplicableDomain
          negativeEqualityReceipt [[2]] 1 3 3 3
            Evaluate.ProviderIndependentFiniteSpineModel

        let unboundedNegativeGuard = Length.LengthAtMost
              (Length.LengthIf (bound input 1) (literal 0) input)
              $ literal 3
        (_, unboundedNegativeReceipt) <- establish cap2 unboundedNegativeGuard
        assertValidatedLengthApplicableDomain
          unboundedNegativeReceipt [[3]] 1 4 4 4
            Evaluate.ProviderIndependentFiniteSpineModel
    , testCase
        "compose guarded extrema and monus without finite-domain undercoverage" $ do
        let first = Length.LengthVariable $ Length.LengthInput 0
            second = Length.LengthVariable $ Length.LengthInput 1
            literal value = Length.LengthLiteral value
            bound expression maximumValue =
              Length.LengthAtMost expression $ literal maximumValue
            guarded = Length.LengthIf
              (bound first 1)
              (Length.LengthMaximum first second)
              (Length.LengthMonus first second)
            precondition = Length.LengthAll
              [bound second 2, bound guarded 2]
            source = contractWith precondition $ Length.LengthTruth True
            validate limits problem =
              Evaluate.validateLengthProblemApplicableDomain
                Evaluate.defaultLengthEvaluationLimits
                Evaluate.defaultLengthInputBoxLimits limits problem
        problem <- adversarialBinaryConstantZeroProblem source

        branchLimits <- booleanFiniteUnionLimits 3 0 0 0 0
        branches <- evaluateWithin $ validate branchLimits problem
        assertLeft
          (Evaluate.LengthApplicableDomainGeneratedBranchLimitExceeded 3 4)
          branches

        ruleLimits <- booleanFiniteUnionLimits 4 3 0 0 0
        rules <- evaluateWithin $ validate ruleLimits problem
        assertLeft
          (Evaluate.LengthApplicableDomainRuleLimitExceeded 0 3 4)
          rules

        closureLimits <- booleanFiniteUnionLimits 4 4 3 0 0
        closure <- evaluateWithin $ validate closureLimits problem
        assertLeft
          (Evaluate.LengthApplicableDomainClosureInspectionLimitExceeded
            0 3 4)
          closure

        exactLimits <- booleanFiniteUnionLimits 4 4 6 1 15
        receipt <-
          expectValidatedLengthApplicableDomain
            problem
            $ validate exactLimits problem
        assertValidatedLengthApplicableDomain
          receipt [[4, 2]] 1 15 15 12
            Evaluate.ProviderIndependentFiniteSpineModel

        let listType = listOf closedPayloadType
            target = FunctionType listType $ FunctionType listType listType
        checkedContract <- expectRight $ sealContract
          Length.defaultLengthLimits target source
        let assignments =
              [[firstValue, secondValue]
              | firstValue <- [0 .. 5]
              , secondValue <- [0 .. 3]
              ]
            boxes =
              Evaluate.validatedLengthApplicableDomainInclusiveMaximumBoxes
                receipt
            covered inputs maximums =
              length inputs == length maximums
                && and (zipWith (<=) inputs maximums)
            replay inputs = Evaluate.evaluateLengthContractAssignment
              Evaluate.defaultLengthEvaluationLimits checkedContract
              $ Evaluate.LengthContractAssignment inputs 0
        applicable <- fmap concat $ mapM (\inputs -> case replay inputs of
            Left failure -> assertFailure
              ("guarded undercoverage oracle rejected " ++ show inputs
                ++ ": " ++ show failure)
                >> pure []
            Right Evaluate.LengthPostconditionViolated -> assertFailure
              ("truth-postcondition oracle violated at " ++ show inputs)
                >> pure []
            Right Evaluate.LengthPreconditionNotMet -> pure []
            Right Evaluate.LengthPostconditionSatisfied -> do
              assertBool
                ("guarded finite union omitted satisfying assignment "
                  ++ show inputs)
                $ any (covered inputs) boxes
              pure [inputs]) assignments
        length applicable @?= 12
    , testCase
        "reject a conditional atom when either selected arm is unsupported" $ do
        let input = Length.LengthVariable $ Length.LengthInput 0
            literal value = Length.LengthLiteral value
            bound expression maximumValue =
              Length.LengthAtMost expression $ literal maximumValue
            trapped = Length.LengthAtMost
              (Length.LengthIf
                (bound input 2)
                input
                (Length.LengthModulo 2 input))
              $ literal 3
            source = contractWith trapped $ Length.LengthTruth True
        problem <- adversarialConstantZeroProblem source
        reason <- expectLengthApplicableDomainInapplicability
          $ Evaluate.validateLengthProblemApplicableDomain
              (error "unsupported-arm trap demanded evaluation limits")
              Evaluate.defaultLengthInputBoxLimits
              Evaluate.defaultLengthBooleanFiniteUnionLimits problem
        reason @?= Evaluate.LengthApplicableDomainInputUpperBoundMissing 0
    , testCase
        "preserve selector laws and signed relation conversion exactly" $ do
        let first = Length.LengthVariable $ Length.LengthInput 0
            second = Length.LengthVariable $ Length.LengthInput 1
            literal value = Length.LengthLiteral value
            bound expression maximumValue =
              Length.LengthAtMost expression $ literal maximumValue
            source precondition = contractWith precondition
              $ Length.LengthTruth True
            validate problem =
              Evaluate.validateLengthProblemApplicableDomain
                Evaluate.defaultLengthEvaluationLimits
                Evaluate.defaultLengthInputBoxLimits
                Evaluate.defaultLengthBooleanFiniteUnionLimits problem
            assertBinary precondition boxes visits assignments applicable = do
              problem <- adversarialBinaryConstantZeroProblem
                $ source precondition
              receipt <-
                expectValidatedLengthApplicableDomain
                  problem $ validate problem
              assertValidatedLengthApplicableDomain
                receipt boxes (fromIntegral $ length boxes) visits assignments
                  applicable Evaluate.ProviderIndependentFiniteSpineModel
            embeddedMinimum = Length.LengthAll
              [ Length.LengthAtMost
                  (Length.LengthSum
                    [Length.LengthMinimum first second, literal 1])
                  $ literal 2
              , bound first 3
              , bound second 3
              ]
            embeddedMaximum = Length.LengthAll
              [ Length.LengthAtMost
                  (Length.LengthSum
                    [Length.LengthMaximum first second, literal 1])
                  $ literal 2
              , bound first 3
              , bound second 3
              ]
            embeddedMonus = Length.LengthSum
              [Length.LengthMonus first second, literal 1]
            strictMonus = Length.LengthAll
              [ Length.LengthNot
                  $ Length.LengthAtMost embeddedMonus $ literal 2
              , bound first 3
              , bound second 3
              ]
        assertBinary embeddedMinimum [[1, 3], [3, 1]] 16 12 12
        assertBinary embeddedMaximum [[1, 1]] 4 4 4
        assertBinary strictMonus [[3, 1]] 8 8 3
        mapM_ (\equality -> assertBinary
            (Length.LengthAll [equality, bound first 3, bound second 3])
            [[3, 2]] 12 12 3)
          [ Length.LengthEqual embeddedMonus $ literal 2
          , Length.LengthEqual (literal 2) embeddedMonus
          ]
    , testCase
        "admit both-root nested embedded mixed and n-ary recursive shapes" $ do
        let first = Length.LengthVariable $ Length.LengthInput 0
            second = Length.LengthVariable $ Length.LengthInput 1
            third = Length.LengthVariable $ Length.LengthInput 2
            literal value = Length.LengthLiteral value
            source precondition = contractWith precondition
              $ Length.LengthTruth True
            assertBinaryBranches observed precondition = do
              problem <- adversarialBinaryConstantZeroProblem
                $ source precondition
              limits <- booleanFiniteUnionLimits
                (observed - 1) 64 4096 256 262144
              result <- evaluateWithin
                $ Evaluate.validateLengthProblemApplicableDomain
                    (error "recursive branch preparation demanded evaluation limits")
                    Evaluate.defaultLengthInputBoxLimits limits problem
              assertLeft
                (Evaluate.LengthApplicableDomainGeneratedBranchLimitExceeded
                  (observed - 1) observed)
                result
            bothRoot = Length.LengthAtMost
              (Length.LengthMaximum first second)
              (Length.LengthMonus (literal 3)
                $ Length.LengthMinimum first second)
            nested = Length.LengthAtMost
              (Length.LengthMinimum
                (Length.LengthMaximum first second)
                $ Length.LengthMonus first second)
              $ literal 2
            embedded = Length.LengthAtMost
              (Length.LengthSum
                [ Length.LengthMinimum first second
                , Length.LengthScale 2 $ Length.LengthMaximum first second
                ])
              $ literal 10
            mixed = Length.LengthAtMost
              (Length.LengthMaximum first second)
              (Length.LengthSum
                [ Length.LengthMinimum first second
                , Length.LengthMonus second first
                ])
            scaled = Length.LengthAtMost
              (Length.LengthScale 2 $ Length.LengthMinimum first second)
              $ literal 4
        assertBinaryBranches 8 bothRoot
        assertBinaryBranches 8 nested
        assertBinaryBranches 4 embedded
        assertBinaryBranches 8 mixed
        assertBinaryBranches 2 scaled

        let effectivelyNary = Length.LengthAtMost
              (Length.LengthMaximum
                (Length.LengthMaximum first second) third)
              $ literal 2
        ternaryProblem <- adversarialWideConstantZeroProblemWithContract 3
          $ source effectivelyNary
        ternaryLimits <- booleanFiniteUnionLimits 3 64 4096 256 262144
        ternaryResult <- evaluateWithin
          $ Evaluate.validateLengthProblemApplicableDomain
              (error "n-ary preparation demanded evaluation limits")
              Evaluate.defaultLengthInputBoxLimits ternaryLimits ternaryProblem
        assertLeft
          (Evaluate.LengthApplicableDomainGeneratedBranchLimitExceeded 3 4)
          ternaryResult
    , testCase
        "count recursive contradictions and Boolean products before cleanup" $ do
        let input = Length.LengthVariable $ Length.LengthInput 0
            literal value = Length.LengthLiteral value
            successor = Length.LengthSum [input, literal 1]
            branching = Length.LengthAtMost
              (Length.LengthSum
                [Length.LengthMaximum input successor, literal 1])
              $ literal 4
            source precondition = contractWith precondition
              $ Length.LengthTruth True
            validate limits problem =
              Evaluate.validateLengthProblemApplicableDomain
                (error "raw recursive preparation demanded evaluation limits")
                Evaluate.defaultLengthInputBoxLimits limits problem
            assertBranchLimit limit observed precondition = do
              problem <- adversarialConstantZeroProblem $ source precondition
              limits <- booleanFiniteUnionLimits limit 64 4096 256 262144
              result <- evaluateWithin $ validate limits problem
              assertLeft
                (Evaluate.LengthApplicableDomainGeneratedBranchLimitExceeded
                  limit observed)
                result
        assertBranchLimit 1 2 branching
        assertBranchLimit 3 4
          $ Length.LengthAll [branching, Length.LengthNot branching]
        assertBranchLimit 3 4 $ Length.LengthNot
          $ Length.LengthEqual
              (Length.LengthSum
                [Length.LengthMaximum input successor, literal 1])
              $ literal 4

        problem <- adversarialConstantZeroProblem $ source branching
        exactLimits <- booleanFiniteUnionLimits 2 64 4096 256 262144
        receipt <-
          expectValidatedLengthApplicableDomain
            problem $ Evaluate.validateLengthProblemApplicableDomain
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits exactLimits problem
        assertValidatedLengthApplicableDomain
          receipt [[2]] 1 3 3 3
            Evaluate.ProviderIndependentFiniteSpineModel
    , testCase
        "retain raw rule closure and evaluation failure precedence" $ do
        let first = Length.LengthVariable $ Length.LengthInput 0
            second = Length.LengthVariable $ Length.LengthInput 1
            result = Length.LengthVariable Length.LengthResult
            literal value = Length.LengthLiteral value
            bound expression maximumValue =
              Length.LengthAtMost expression $ literal maximumValue
            recursiveRelation = Length.LengthAtMost
              (Length.LengthMaximum first second)
              (Length.LengthMonus (literal 3)
                $ Length.LengthMinimum first second)
            recursiveUnion = Length.LengthAll
              [recursiveRelation, bound first 3, bound second 3]
            source precondition postcondition =
              contractWith precondition postcondition
            validate evaluation box limits problem =
              Evaluate.validateLengthProblemApplicableDomain
                evaluation box limits problem

        widthProblem <- adversarialBinaryConstantZeroProblem
          $ source recursiveUnion $ Length.LengthTruth True
        narrow <- inputBoxLimits 1 16
        width <- evaluateWithin $ validate
          (error "width rejection demanded evaluation limits") narrow
          (error "width rejection demanded finite-union limits") widthProblem
        assertLeft
          (Evaluate.LengthApplicableDomainProblemInputLimitExceeded 1 2)
          width

        branchLimits <- booleanFiniteUnionLimits 7 64 4096 256 262144
        branches <- evaluateWithin $ validate
          (error "raw-branch rejection demanded evaluation limits")
          Evaluate.defaultLengthInputBoxLimits branchLimits widthProblem
        assertLeft
          (Evaluate.LengthApplicableDomainGeneratedBranchLimitExceeded 7 8)
          branches

        ruleProblem <- adversarialBinaryConstantZeroProblem
          $ source
              (Length.LengthEqual
                (Length.LengthSum
                  [Length.LengthMaximum first second, literal 1])
                $ literal 4)
              $ Length.LengthTruth True
        ruleLimits <- booleanFiniteUnionLimits 2 2 4096 256 262144
        rules <- evaluateWithin $ validate
          (error "rule rejection demanded evaluation limits")
          Evaluate.defaultLengthInputBoxLimits ruleLimits ruleProblem
        assertLeft
          (Evaluate.LengthApplicableDomainRuleLimitExceeded 0 2 3)
          rules

        defaultRuleProblem <- adversarialBinaryConstantZeroProblem
          $ source
              (Length.LengthAll $
                [ Length.LengthEqual
                    (Length.LengthSum
                      [Length.LengthMaximum first second, literal 1])
                    $ literal 63
                , Length.LengthEqual
                    (Length.LengthMaximum first
                      $ Length.LengthSum [second, literal 1])
                    $ literal 64
                , Length.LengthEqual
                    (Length.LengthMaximum first
                      $ Length.LengthSum [second, literal 2])
                    $ literal 65
                ]
                ++ [ Length.LengthAtMost
                      (Length.LengthMaximum first
                        $ Length.LengthSum [second, literal offset])
                      $ literal 100
                   | offset <- [3 .. 30]
                   ])
              $ Length.LengthTruth True
        defaultRules <- evaluateWithin $ validate
          (error "default-rule rejection demanded evaluation limits")
          Evaluate.defaultLengthInputBoxLimits
          Evaluate.defaultLengthBooleanFiniteUnionLimits defaultRuleProblem
        assertLeft
          (Evaluate.LengthApplicableDomainRuleLimitExceeded 0 64 65)
          defaultRules

        closureProblem <- adversarialBinaryConstantZeroProblem
          $ source
              (Length.LengthAtMost
                (Length.LengthSum
                  [Length.LengthMinimum first second, literal 1])
                $ literal 2)
              $ Length.LengthTruth True
        closureLimits <- booleanFiniteUnionLimits 2 3 1 256 262144
        closure <- evaluateWithin $ validate
          (error "closure rejection demanded evaluation limits")
          Evaluate.defaultLengthInputBoxLimits closureLimits closureProblem
        assertLeft
          (Evaluate.LengthApplicableDomainClosureInspectionLimitExceeded
            0 1 2)
          closure

        let unsupportedConditional = Length.LengthAtMost
              (Length.LengthSum
                [ Length.LengthMinimum
                    (Length.LengthIf
                      (bound first 1)
                      first
                      $ Length.LengthQuotient 2 first)
                    first
                , literal 1
                ])
              $ literal 3
        missingProblem <- adversarialConstantZeroProblem
          $ source unsupportedConditional $ Length.LengthTruth True
        missing <-
          expectLengthApplicableDomainInapplicability
            $ validate
                (error "missing coverage demanded evaluation limits")
                Evaluate.defaultLengthInputBoxLimits
                Evaluate.defaultLengthBooleanFiniteUnionLimits missingProblem
        missing @?= Evaluate.LengthApplicableDomainInputUpperBoundMissing 0

        boxLimits <- booleanFiniteUnionLimits 8 64 4096 1 262144
        retained <- evaluateWithin $ validate
          (error "retained-box rejection demanded evaluation limits")
          Evaluate.defaultLengthInputBoxLimits boxLimits widthProblem
        assertLeft
          (Evaluate.LengthApplicableDomainRetainedBoxLimitExceeded 1 2)
          retained

        maximumProblem <- adversarialConstantZeroProblem
          $ source (bound first 3) $ Length.LengthTruth True
        noVisits <- booleanFiniteUnionLimits 1 1 1 1 0
        assertLeft
          (Evaluate.LengthApplicableDomainMaximumValueRejected 0 0
            $ Evaluate.LengthEvaluationValueBitLimitExceeded
                (Evaluate.LengthProblemInputValue 0) 1 2)
          $ validate (evaluationLimitsWith 1 8)
              Evaluate.defaultLengthInputBoxLimits noVisits maximumProblem

        visitLimits <- booleanFiniteUnionLimits 8 64 4096 2 23
        assertLeft
          (Evaluate.LengthApplicableDomainAssignmentVisitLimitExceeded
            23 24)
          $ validate Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits visitLimits widthProblem

        exactVisitLimits <- booleanFiniteUnionLimits 8 64 4096 2 24
        uniqueFourteen <- inputBoxLimits 2 14
        assertLeft
          (Evaluate.LengthApplicableDomainAssignmentLimitExceeded 14 15)
          $ validate Evaluate.defaultLengthEvaluationLimits uniqueFourteen
              exactVisitLimits widthProblem

        let isZero = Length.LengthEqual first $ literal 0
            replaySource = source (bound first 0)
              $ Length.LengthEqual result
              $ Length.LengthIf isZero (literal 1) (literal 0)
        replayProblem <- adversarialConstantZeroProblem replaySource
        oneVisit <- booleanFiniteUnionLimits 1 1 1 1 1
        oneAssignment <- inputBoxLimits 1 1
        assertLeft
          (Evaluate.LengthApplicableDomainAssignmentEvaluationRejected 0
            $ Evaluate.LengthEvaluationValueBitLimitExceeded
                Evaluate.LengthIntermediateValue 0 1)
          $ validate (evaluationLimitsWith 0 0) oneAssignment oneVisit
              replayProblem
    , testCase
        "keep incomparable boxes and replay once in global lexicographic order" $ do
        let first = Length.LengthVariable $ Length.LengthInput 0
            second = Length.LengthVariable $ Length.LengthInput 1
            third = Length.LengthVariable $ Length.LengthInput 2
            literal value = Length.LengthLiteral value
            bound expression maximumValue =
              Length.LengthAtMost expression $ literal maximumValue
            precondition = Length.LengthAll
              [ bound first 1
              , Length.LengthAtMost
                  (Length.LengthSum
                    [Length.LengthMinimum second third, literal 1])
                  $ literal 2
              , bound second 3
              , bound third 3
              ]
            validSource = contractWith precondition $ Length.LengthTruth True
            validate problem =
              Evaluate.validateLengthProblemApplicableDomain
                Evaluate.defaultLengthEvaluationLimits
                Evaluate.defaultLengthInputBoxLimits
                Evaluate.defaultLengthBooleanFiniteUnionLimits problem
        validProblem <- adversarialWideConstantZeroProblemWithContract 3
          validSource
        receipt <-
          expectValidatedLengthApplicableDomain
            validProblem $ validate validProblem
        assertValidatedLengthApplicableDomain
          receipt [[1, 1, 3], [1, 3, 1]] 2 32 24 24
            Evaluate.ProviderIndependentFiniteSpineModel

        let violatingSource = contractWith precondition $ Length.LengthAll
              [bound first 0, bound second 1]
        violatingProblem <- adversarialWideConstantZeroProblemWithContract 3
          violatingSource
        counterexample <- case validate violatingProblem of
          Left failure -> assertFailure
            ("recursive finite-union validation failed: " ++ show failure)
              >> error "unreachable"
          Right (Evaluate.LengthApplicableDomainInapplicable reason) ->
            assertFailure ("recursive finite union was inapplicable: "
              ++ show reason) >> error "unreachable"
          Right (Evaluate.LengthApplicableDomainEstablished _) -> assertFailure
            "the violating recursive union produced positive evidence"
              >> error "unreachable"
          Right (Evaluate.LengthApplicableDomainCounterexample evidence) ->
            expectRight $ SemanticProblem.replayBehavioralEvidence
              (LengthProblem.checkedLengthProblemBehavioralProblem
                violatingProblem)
              evidence
        Evaluate.validatedLengthCounterexampleInputs counterexample @?=
          [0, 2, 0]
        Evaluate.validatedLengthCounterexampleResult counterexample @?= 0
        Evaluate.validatedLengthCounterexampleBasis counterexample @?=
          Evaluate.ProviderIndependentFiniteSpineModel
    , testCase
        "preserve direct quotient extrema monus and DNF semantics" $ do
        let input = Length.LengthVariable $ Length.LengthInput 0
            literal value = Length.LengthLiteral value
            source precondition = contractWith precondition
              $ Length.LengthTruth True
            validate problem =
              Evaluate.validateLengthProblemApplicableDomain
                Evaluate.defaultLengthEvaluationLimits
                Evaluate.defaultLengthInputBoxLimits
                Evaluate.defaultLengthBooleanFiniteUnionLimits problem
            disjoin formulas = Length.LengthNot
              $ Length.LengthAll $ map Length.LengthNot formulas
            observe precondition = do
              problem <- adversarialConstantZeroProblem $ source precondition
              receipt <-
                expectValidatedLengthApplicableDomain
                  problem $ validate problem
              pure
                ( Evaluate.validatedLengthApplicableDomainInclusiveMaximumBoxes
                    receipt
                , Evaluate.validatedLengthApplicableDomainBoxCount receipt
                , Evaluate.validatedLengthApplicableDomainAssignmentVisitCount
                    receipt
                , Evaluate.validatedLengthApplicableDomainAssignmentCount
                    receipt
                , Evaluate.validatedLengthApplicableDomainApplicableAssignmentCount
                    receipt
                , Evaluate.validatedLengthApplicableDomainBasis receipt
                )
        observations <- mapM observe
          [ Length.LengthAtMost input $ literal 2
          , Length.LengthAtMost (Length.LengthQuotient 3 input) $ literal 1
          , Length.LengthAtMost
              (Length.LengthMaximum input
                $ Length.LengthSum [Length.LengthScale 2 input, literal 1])
              $ literal 5
          , Length.LengthAtMost (literal 1)
              $ Length.LengthMonus (literal 3) input
          , disjoin
              [ Length.LengthAtMost input $ literal 1
              , Length.LengthAtMost input $ literal 3
              ]
          ]
        let independent = Evaluate.ProviderIndependentFiniteSpineModel
        observations @?=
          [ ([[2]], 1, 3, 3, 3, independent)
          , ([[5]], 1, 6, 6, 6, independent)
          , ([[2]], 1, 3, 3, 3, independent)
          , ([[2]], 1, 3, 3, 3, independent)
          , ([[3]], 1, 4, 4, 4, independent)
          ]

        let first = Length.LengthVariable $ Length.LengthInput 0
            second = Length.LengthVariable $ Length.LengthInput 1
            bound expression maximumValue =
              Length.LengthAtMost expression $ literal maximumValue
            assertMissing unsupported = do
              problem <- adversarialBinaryConstantZeroProblem $ source
                $ Length.LengthAll [unsupported, bound second 3]
              reason <-
                expectLengthApplicableDomainInapplicability
                  $ validate problem
              reason @?=
                Evaluate.LengthApplicableDomainInputUpperBoundMissing 0
            unsupportedConditional = Length.LengthIf
              (bound first 1) first $ Length.LengthModulo 2 first
        mapM_ assertMissing
          [ Length.LengthAtMost
              (Length.LengthSum
                [ Length.LengthMinimum
                    (Length.LengthQuotient 2 first) second
                , literal 1
                ])
              $ literal 5
          , Length.LengthAtMost
              (Length.LengthSum
                [ Length.LengthMinimum
                    (Length.LengthModulo 2 first) second
                , literal 1
                ])
              $ literal 5
          , Length.LengthAtMost
              (Length.LengthSum
                [ Length.LengthMinimum unsupportedConditional second
                , literal 1
                ])
              $ literal 5
          , Length.LengthAtMost
              (Length.LengthScale 0 $ Length.LengthMinimum first second)
              $ literal 0
          ]
    , testCase
        "associate guarded scalar evidence without changing query identity" $ do
        let first = Length.LengthVariable $ Length.LengthInput 0
            second = Length.LengthVariable $ Length.LengthInput 1
            literal value = Length.LengthLiteral value
            bound expression maximumValue =
              Length.LengthAtMost expression $ literal maximumValue
            guarded maximumGuard = Length.LengthIf
              (bound first maximumGuard)
              (Length.LengthMaximum first second)
              (Length.LengthMonus first second)
            precondition maximumGuard = Length.LengthAll
              [bound second 2, bound (guarded maximumGuard) 2]
            source = contractWith (precondition 1) $ Length.LengthTruth True
        problem <- adversarialBinaryConstantZeroProblem source
        let directValidation =
              Evaluate.validateLengthProblemApplicableDomain
                Evaluate.defaultLengthEvaluationLimits
                Evaluate.defaultLengthInputBoxLimits
                Evaluate.defaultLengthBooleanFiniteUnionLimits problem
        (evidence, receipt) <- case directValidation of
          Right (Evaluate.LengthApplicableDomainEstablished established) -> do
            replayed <- expectRight
              $ SemanticProblem.replayBehavioralEvidence
                  (LengthProblem.checkedLengthProblemBehavioralProblem problem)
                  established
            pure (established, replayed)
          Left failure -> assertFailure
            ("scalar guarded validation failed: " ++ show failure)
              >> error "unreachable"
          Right (Evaluate.LengthApplicableDomainInapplicable reason) ->
            assertFailure ("scalar guarded validation was inapplicable: "
              ++ show reason) >> error "unreachable"
          Right (Evaluate.LengthApplicableDomainCounterexample _) ->
            assertFailure "scalar guarded validation found a counterexample"
              >> error "unreachable"
        assertValidatedLengthApplicableDomain
          receipt [[4, 2]] 1 15 15 12
            Evaluate.ProviderIndependentFiniteSpineModel
        force receipt `seq` pure ()

        stale <- adversarialBinaryConstantZeroProblem
          $ contractWith (precondition 0) $ Length.LengthTruth True
        assertLeft SemanticProblem.ReplayEncodingFingerprintMismatch
          $ SemanticProblem.replayBehavioralEvidence
              (LengthProblem.checkedLengthProblemBehavioralProblem stale)
              evidence

        query <- expectRight $ SMTLib.sealLengthSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits problem
        let fingerprintBefore = SMTLib.lengthSMTLibQueryFingerprint query
            checkBefore = SMTLib.lengthSMTLibQueryCheckBytes query
            symbolsBefore = SMTLib.lengthSMTLibQueryInputSymbols query
            valuesBefore = SMTLib.lengthSMTLibQueryInputValueRequestBytes query
        associated <- expectRight
          $ SMTLib.validateLengthSMTLibQueryApplicableDomain
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits
              Evaluate.defaultLengthBooleanFiniteUnionLimits query
        case associated of
          Evaluate.LengthApplicableDomainEstablished queryReceipt ->
            queryReceipt @?= receipt
          Evaluate.LengthApplicableDomainInapplicable reason -> assertFailure
            ("scalar guarded query was inapplicable: " ++ show reason)
          Evaluate.LengthApplicableDomainCounterexample{} -> assertFailure
            "scalar guarded query produced a counterexample"
        SMTLib.lengthSMTLibQueryFingerprint query @?= fingerprintBefore
        SMTLib.lengthSMTLibQueryCheckBytes query @?= checkBefore
        SMTLib.lengthSMTLibQueryInputSymbols query @?= symbolsBefore
        SMTLib.lengthSMTLibQueryInputValueRequestBytes query @?= valuesBefore
    , testCase
        "pin guarded product receipt nominality and query identity" $ do
        let first = Length.LengthVariable $ Length.LengthSpinePairInput 0
            second = Length.LengthVariable $ Length.LengthSpinePairInput 1
            literal value = Length.LengthLiteral value
            bound expression maximumValue =
              Length.LengthAtMost expression $ literal maximumValue
            guarded = Length.LengthIf
              (bound first 1)
              (Length.LengthMaximum first second)
              (Length.LengthMonus first second)
            precondition = Length.LengthAll
              [bound second 2, bound guarded 2]
            source = spinePairContractWith precondition
              $ Length.LengthTruth True
        problem <- adversarialBinaryZeroSpinePairProblem source

        cap3 <- booleanFiniteUnionLimits 3 64 4096 256 262144
        capped <- evaluateWithin
          $ Evaluate.validateLengthSpinePairProblemApplicableDomain
              (error "guarded product preparation demanded evaluation limits")
              Evaluate.defaultLengthInputBoxLimits cap3 problem
        assertLeft
          (Evaluate.LengthSpinePairApplicableDomainGeneratedBranchLimitExceeded
            3 4)
          capped

        cap4 <- booleanFiniteUnionLimits 4 64 4096 256 262144
        let directValidation =
              Evaluate.validateLengthSpinePairProblemApplicableDomain
                Evaluate.defaultLengthEvaluationLimits
                Evaluate.defaultLengthInputBoxLimits cap4 problem
        (evidence, receipt) <- case directValidation of
          Right (Evaluate.LengthApplicableDomainEstablished established) -> do
            replayed <- expectRight
              $ SemanticProblem.replayBehavioralEvidence
                  (LengthProblem.checkedLengthSpinePairProblemBehavioralProblem
                    problem)
                  established
            pure (established, replayed)
          Left failure -> assertFailure
            ("product guarded validation failed: " ++ show failure)
              >> error "unreachable"
          Right (Evaluate.LengthApplicableDomainInapplicable reason) ->
            assertFailure ("product guarded validation was inapplicable: "
              ++ show reason) >> error "unreachable"
          Right (Evaluate.LengthApplicableDomainCounterexample _) ->
            assertFailure "product guarded validation found a counterexample"
              >> error "unreachable"
        assertValidatedLengthSpinePairApplicableDomain
          receipt [[4, 2]] 1 15 15 12
            Evaluate.ProviderIndependentFiniteSpineModel
        force receipt `seq` pure ()

        scalar <- adversarialConstantZeroProblem
          $ contractWith
              (Length.LengthAtMost
                (Length.LengthSum
                  [ Length.LengthMinimum
                      (Length.LengthVariable $ Length.LengthInput 0)
                      $ literal 3
                  , literal 1
                  ])
                $ literal 2)
              $ Length.LengthTruth True
        let forgedScalarEvidence = unsafeCoerce evidence
              :: SemanticProblem.BehavioralEvidence
                  Length.FiniteListSpineLengthV1
                  Evaluate.ValidatedLengthApplicableDomain
        assertLeft SemanticProblem.ReplayDomainMismatch
          $ SemanticProblem.replayBehavioralEvidence
              (LengthProblem.checkedLengthProblemBehavioralProblem scalar)
              forgedScalarEvidence

        query <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
          SMTLib.defaultLengthSMTLibLimits problem
        let fingerprintBefore =
              SMTLib.lengthSpinePairSMTLibQueryFingerprint query
            checkBefore = SMTLib.lengthSpinePairSMTLibQueryCheckBytes query
            symbolsBefore = SMTLib.lengthSpinePairSMTLibQueryInputSymbols query
            valuesBefore =
              SMTLib.lengthSpinePairSMTLibQueryInputValueRequestBytes query
        associated <- expectRight
          $ SMTLib.validateLengthSpinePairSMTLibQueryApplicableDomain
              Evaluate.defaultLengthEvaluationLimits
              Evaluate.defaultLengthInputBoxLimits cap4 query
        case associated of
          Evaluate.LengthApplicableDomainEstablished queryReceipt ->
            queryReceipt @?= receipt
          Evaluate.LengthApplicableDomainInapplicable reason -> assertFailure
            ("product guarded query was inapplicable: " ++ show reason)
          Evaluate.LengthApplicableDomainCounterexample{} -> assertFailure
            "product guarded query produced a counterexample"
        SMTLib.lengthSpinePairSMTLibQueryFingerprint query @?=
          fingerprintBefore
        SMTLib.lengthSpinePairSMTLibQueryCheckBytes query @?= checkBefore
        SMTLib.lengthSpinePairSMTLibQueryInputSymbols query @?= symbolsBefore
        SMTLib.lengthSpinePairSMTLibQueryInputValueRequestBytes query @?=
          valuesBefore
    ]

type AdversarialLengthApplicableDomainValidation =
  Either Evaluate.LengthApplicableDomainValidationError
    (Evaluate.LengthApplicableDomainValidation
      (SemanticProblem.BehavioralEvidence
        Length.FiniteListSpineLengthV1
        Evaluate.ValidatedLengthCounterexample)
      (SemanticProblem.BehavioralEvidence
        Length.FiniteListSpineLengthV1
        Evaluate.ValidatedLengthApplicableDomain))

expectLengthApplicableDomainInapplicability
  :: AdversarialLengthApplicableDomainValidation
  -> IO Evaluate.LengthApplicableDomainInapplicability
expectLengthApplicableDomainInapplicability
    validation = case validation of
  Left failure -> assertFailure
    ("unexpected recursive piecewise-affine rejection: " ++ show failure)
      >> error "unreachable"
  Right (Evaluate.LengthApplicableDomainInapplicable reason) -> pure reason
  Right (Evaluate.LengthApplicableDomainCounterexample _) -> assertFailure
    "an inapplicable recursive piecewise-affine union produced a counterexample"
      >> error "unreachable"
  Right (Evaluate.LengthApplicableDomainEstablished _) -> assertFailure
    "an inapplicable recursive piecewise-affine union produced evidence"
      >> error "unreachable"

expectValidatedLengthApplicableDomain
  :: LengthProblem.CheckedLengthProblem
      AdversarialIdentity AdversarialLocal
  -> AdversarialLengthApplicableDomainValidation
  -> IO
      Evaluate.ValidatedLengthApplicableDomain
expectValidatedLengthApplicableDomain
    problem validation = case validation of
  Left failure -> assertFailure
    ("unexpected recursive piecewise-affine rejection: " ++ show failure)
      >> error "unreachable"
  Right (Evaluate.LengthApplicableDomainInapplicable reason) -> assertFailure
    ("the recursive piecewise-affine union was not bounded: " ++ show reason)
      >> error "unreachable"
  Right (Evaluate.LengthApplicableDomainCounterexample _) -> assertFailure
    "the recursive piecewise-affine union contained a counterexample"
      >> error "unreachable"
  Right (Evaluate.LengthApplicableDomainEstablished evidence) -> expectRight
    $ SemanticProblem.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence

assertValidatedLengthApplicableDomain
  :: Evaluate.ValidatedLengthApplicableDomain
  -> [[Natural]]
  -> Natural
  -> Natural
  -> Natural
  -> Natural
  -> Evaluate.LengthCounterexampleBasis
  -> IO ()
assertValidatedLengthApplicableDomain
    receipt boxes boxCount visits assignments applicable basis = do
  Evaluate.validatedLengthApplicableDomainInclusiveMaximumBoxes
      receipt @?= boxes
  Evaluate.validatedLengthApplicableDomainBoxCount
      receipt @?= boxCount
  Evaluate.validatedLengthApplicableDomainAssignmentVisitCount
      receipt @?= visits
  Evaluate.validatedLengthApplicableDomainAssignmentCount
      receipt @?= assignments
  Evaluate.validatedLengthApplicableDomainApplicableAssignmentCount
      receipt @?= applicable
  Evaluate.validatedLengthApplicableDomainBasis
      receipt @?= basis

assertValidatedLengthSpinePairApplicableDomain
  :: Evaluate.ValidatedLengthSpinePairApplicableDomain
  -> [[Natural]]
  -> Natural
  -> Natural
  -> Natural
  -> Natural
  -> Evaluate.LengthCounterexampleBasis
  -> IO ()
assertValidatedLengthSpinePairApplicableDomain
    receipt boxes boxCount visits assignments applicable basis = do
  Evaluate.validatedLengthSpinePairApplicableDomainInclusiveMaximumBoxes
      receipt @?= boxes
  Evaluate.validatedLengthSpinePairApplicableDomainBoxCount
      receipt @?= boxCount
  Evaluate.validatedLengthSpinePairApplicableDomainAssignmentVisitCount
      receipt @?= visits
  Evaluate.validatedLengthSpinePairApplicableDomainAssignmentCount
      receipt @?= assignments
  Evaluate.validatedLengthSpinePairApplicableDomainApplicableAssignmentCount
      receipt @?= applicable
  Evaluate.validatedLengthSpinePairApplicableDomainBasis
      receipt @?= basis

booleanFiniteUnionLimits
  :: Int -> Int -> Int -> Int -> Int
  -> IO Evaluate.LengthBooleanFiniteUnionLimits
booleanFiniteUnionLimits branches rules inspections boxes visits = expectRight
  $ Evaluate.mkLengthBooleanFiniteUnionLimits
      Evaluate.LengthBooleanFiniteUnionLimitSource
        { Evaluate.lengthBooleanFiniteUnionLimitSourceMaximumGeneratedBranches =
            branches
        , Evaluate.lengthBooleanFiniteUnionLimitSourceMaximumRulesPerBranch =
            rules
        , Evaluate.lengthBooleanFiniteUnionLimitSourceMaximumClosureInspectionsPerBranch =
            inspections
        , Evaluate.lengthBooleanFiniteUnionLimitSourceMaximumRetainedBoxes =
            boxes
        , Evaluate.lengthBooleanFiniteUnionLimitSourceMaximumAssignmentVisits =
            visits
        }

type AdversarialLengthInputBoxValidation =
  Either Evaluate.LengthInputBoxValidationError
    (Evaluate.LengthInputBoxValidation
      (SemanticProblem.BehavioralEvidence
        Length.FiniteListSpineLengthV1
        Evaluate.ValidatedLengthCounterexample)
      (SemanticProblem.BehavioralEvidence
        Length.FiniteListSpineLengthV1
        Evaluate.ValidatedLengthInputBox))

inputBoxLimits :: Int -> Natural -> IO Evaluate.LengthInputBoxLimits
inputBoxLimits maximumInputs maximumAssignments = expectRight
  $ Evaluate.mkLengthInputBoxLimits Evaluate.LengthInputBoxLimitSource
      { Evaluate.lengthInputBoxLimitSourceMaximumInputs = maximumInputs
      , Evaluate.lengthInputBoxLimitSourceMaximumAssignments =
          maximumAssignments
      }

expectValidatedLengthInputBox
  :: LengthProblem.CheckedLengthProblem
      AdversarialIdentity AdversarialLocal
  -> AdversarialLengthInputBoxValidation
  -> IO Evaluate.ValidatedLengthInputBox
expectValidatedLengthInputBox problem validation = case validation of
  Left failure -> assertFailure
    ("unexpected input-box rejection: " ++ show failure) >> error "unreachable"
  Right (Evaluate.LengthInputBoxCounterexample _) -> assertFailure
    "the input box unexpectedly contained a counterexample" >> error "unreachable"
  Right (Evaluate.LengthInputBoxValidated evidence) -> expectRight
    $ SemanticProblem.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence

expectLengthInputBoxCounterexample
  :: LengthProblem.CheckedLengthProblem
      AdversarialIdentity AdversarialLocal
  -> AdversarialLengthInputBoxValidation
  -> IO Evaluate.ValidatedLengthCounterexample
expectLengthInputBoxCounterexample problem validation = case validation of
  Left failure -> assertFailure
    ("unexpected input-box rejection: " ++ show failure) >> error "unreachable"
  Right (Evaluate.LengthInputBoxValidated _) -> assertFailure
    "the violating input box produced a positive receipt" >> error "unreachable"
  Right (Evaluate.LengthInputBoxCounterexample evidence) -> expectRight
    $ SemanticProblem.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence

assertValidatedLengthInputBox
  :: Evaluate.ValidatedLengthInputBox
  -> [Natural]
  -> Natural
  -> Natural
  -> Evaluate.LengthCounterexampleBasis
  -> IO ()
assertValidatedLengthInputBox receipt maximums assignments applicable basis = do
  Evaluate.validatedLengthInputBoxInclusiveMaximums receipt @?= maximums
  Evaluate.validatedLengthInputBoxAssignmentCount receipt @?= assignments
  Evaluate.validatedLengthInputBoxApplicableAssignmentCount receipt @?=
    applicable
  Evaluate.validatedLengthInputBoxBasis receipt @?= basis

smtLibTests :: TestTree
smtLibTests = testGroup
  "bounded QF_LIA query, execution policy, response, and model boundary"
  [ testCase "publish one pure fixed Z3 execution-policy default" $ do
      SMTLibExecution.lengthSMTLibExecutionPolicySchemaTag @?=
        asciiBytes "djex-length-z3-smtlib2-execution-policy/v2"
      SMTLibExecution.lengthSMTLibExecutionProtocolSchemaTag @?=
        asciiBytes "djex-length-z3-smtlib2-session-protocol/v1"
      SMTLibExecution.lengthSMTLibExecutionArgumentPrefix @?=
        ["-in", "-smt2", "smtlib2_compliant=true"]
      SMTLibExecution.lengthSMTLibExecutionArgumentVector @?=
        SMTLibExecution.lengthSMTLibExecutionArgumentPrefix
      SMTLibExecution.lengthSMTLibExecutionStartupCommandBytes @?=
        asciiBytes "(set-option :print-success false)\n"
      SMTLibExecution.lengthSMTLibExecutionQueryResetBytes @?=
        asciiBytes "(reset)\n(set-option :print-success false)\n"
      SMTLibExecution.lengthSMTLibExecutionEnvironmentPolicyTag @?=
        asciiBytes "empty-environment/v1"
      SMTLibExecution.lengthSMTLibExecutionWorkingDirectoryPolicyTag @?=
        asciiBytes "fresh-empty-working-directory/v1"
      SMTLibExecution.lengthSMTLibExecutionExpectedDigestSchemaTag @?=
        asciiBytes "sha256/exact-executable-file-bytes/v1"
      SMTLibExecution.lengthSMTLibMinimumHostDeadlineMarginMilliseconds @?= 100
      assertBool "validated execution defaults changed representation"
        $ SMTLibExecution.mkLengthSMTLibExecutionLimits
            SMTLibExecution.defaultLengthSMTLibExecutionLimitSource ==
          SMTLibExecution.defaultLengthSMTLibExecutionLimits
      SMTLibExecution.lengthSMTLibExecutionExecutablePathCharacterLimit
          SMTLibExecution.defaultLengthSMTLibExecutionLimits @?= 4096
      SMTLibExecution.lengthSMTLibExecutionPolicyFingerprintByteLimit
          SMTLibExecution.defaultLengthSMTLibExecutionLimits @?= 262144
      config <- expectRight $ SMTLibExecution.mkLengthSMTLibExecutionConfig
        SMTLibExecution.defaultLengthSMTLibExecutionLimits
        $ SMTLibExecution.defaultLengthSMTLibExecutionConfigSource
            absoluteFixtureExecutable Nothing
      SMTLibExecution.lengthSMTLibExecutionExecutableLaunchStrategy config @?=
        SMTLibExecution.LengthSMTLibPathSnapshotThenDirectSpawn
      SMTLibExecution.lengthSMTLibExecutionSolverTimeoutMilliseconds config
        @?= 1000
      SMTLibExecution.lengthSMTLibExecutionSolverResourceLimit config
        @?= 100000
      SMTLibExecution.lengthSMTLibExecutionConfiguredArgumentVector config @?=
        [ "-in"
        , "-smt2"
        , "smtlib2_compliant=true"
        , "timeout=1000"
        , "rlimit=100000"
        ]
      nondefaultConfig <- expectRight
        $ SMTLibExecution.mkLengthSMTLibExecutionConfig
            SMTLibExecution.defaultLengthSMTLibExecutionLimits
        $ (SMTLibExecution.defaultLengthSMTLibExecutionConfigSource
            absoluteFixtureExecutable Nothing)
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
                17
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
                23
            }
      SMTLibExecution.lengthSMTLibExecutionConfiguredArgumentVector
          nondefaultConfig @?=
        [ "-in"
        , "-smt2"
        , "smtlib2_compliant=true"
        , "timeout=17"
        , "rlimit=23"
        ]
      SMTLibExecution.lengthSMTLibExecutionHostDeadlineMilliseconds config
        @?= 1500
      SMTLibExecution.lengthSMTLibExecutionArtifactPolicy config @?=
        SMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      SMTLibExecution.lengthSMTLibExecutionResponseLimits config @?=
        SMTLibResponse.defaultLengthSMTLibResponseLimits
  , testCase "share one admitted Z3 launch profile below Length policy" $ do
      Z3Execution.z3SMTLibExecutionArgumentPrefix @?=
        SMTLibExecution.lengthSMTLibExecutionArgumentPrefix
      Z3Execution.z3SMTLibExecutionStartupCommandBytes @?=
        SMTLibExecution.lengthSMTLibExecutionStartupCommandBytes
      Z3Execution.z3SMTLibExecutionQueryResetBytes @?=
        SMTLibExecution.lengthSMTLibExecutionQueryResetBytes
      Z3Execution.z3SMTLibExecutionChildEnvironment @?= Just []
      Z3Execution.z3SMTLibExecutionEnvironmentPolicyTag @?=
        SMTLibExecution.lengthSMTLibExecutionEnvironmentPolicyTag
      Z3Execution.z3SMTLibExecutionWorkingDirectoryPolicyTag @?=
        SMTLibExecution.lengthSMTLibExecutionWorkingDirectoryPolicyTag
      Z3Execution.z3SMTLibExecutionExpectedDigestSchemaTag @?=
        SMTLibExecution.lengthSMTLibExecutionExpectedDigestSchemaTag
      Z3Execution.z3SMTLibMinimumHostDeadlineMarginMilliseconds @?=
        SMTLibExecution.lengthSMTLibMinimumHostDeadlineMarginMilliseconds
      let limits = Z3Execution.mkZ3SMTLibExecutionLimits 4096
          source = Z3Execution.Z3SMTLibExecutionSource
            { Z3Execution.z3SMTLibExecutionSourceExecutablePath =
                absoluteFixtureExecutable
            , Z3Execution.z3SMTLibExecutionSourceExpectedExecutableSHA256 =
                Nothing
            , Z3Execution.z3SMTLibExecutionSourceSolverTimeoutMilliseconds =
                1000
            , Z3Execution.z3SMTLibExecutionSourceSolverResourceLimit = 100000
            , Z3Execution.z3SMTLibExecutionSourceHostDeadlineMilliseconds =
                1500
            }
      profile <- expectRight
        $ Z3Execution.mkZ3SMTLibExecutionProfile limits source
      Z3Execution.z3SMTLibExecutionExecutablePathCharacterLimit limits @?=
        4096
      Z3Execution.z3SMTLibExecutionExecutablePath profile @?=
        absoluteFixtureExecutable
      Z3Execution.z3SMTLibExecutionExpectedExecutableSHA256 profile @?=
        Nothing
      Z3Execution.z3SMTLibExecutionSolverTimeoutMilliseconds profile @?= 1000
      Z3Execution.z3SMTLibExecutionSolverResourceLimit profile @?= 100000
      Z3Execution.z3SMTLibExecutionHostDeadlineMilliseconds profile @?= 1500
      Z3Execution.z3SMTLibExecutionConfiguredArgumentVector profile @?=
        [ "-in"
        , "-smt2"
        , "smtlib2_compliant=true"
        , "timeout=1000"
        , "rlimit=100000"
        ]
      length (Z3Execution.z3SMTLibExecutionFingerprintFields profile) @?= 11
  , testCase "preserve the complete Length execution identity bytes" $ do
      let limits =
            InternalSMTLibExecution.defaultLengthSMTLibExecutionLimits
          source =
            InternalSMTLibExecution.defaultLengthSMTLibExecutionConfigSource
              "//djex/z3" $ Just [0 .. 31]
      config <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibExecutionConfig
            limits source
      descriptorBound <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundExecutionConfig
            limits source
      effectiveID <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessExecutionConfig
            limits source
      execveCheck <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundExecveCheckExecutableAccessExecutionConfig
            limits source
      let postLaunch =
            InternalSMTLibExecution.retainLengthSMTLibPostLaunchExecutionPolicy
              config
      InternalSMTLibExecution.lengthSMTLibPostLaunchHostDeadlineMilliseconds
          postLaunch @?=
        InternalSMTLibExecution.lengthSMTLibExecutionHostDeadlineMilliseconds
          config
      InternalSMTLibExecution.lengthSMTLibPostLaunchArtifactPolicy postLaunch
        @?=
          InternalSMTLibExecution.lengthSMTLibExecutionArtifactPolicy config
      InternalSMTLibExecution.lengthSMTLibPostLaunchResponseLimits postLaunch
        @?=
          InternalSMTLibExecution.lengthSMTLibExecutionResponseLimits config
      InternalSMTLibExecution.lengthSMTLibPostLaunchExecutionPolicyFingerprint
          postLaunch @?=
        InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint config
      -- This digest is only a regression snapshot of the collision-free
      -- canonical bytes. The complete reversible fingerprint remains the
      -- actual policy identity.
      let canonicalSnapshot value =
            let canonical = InternalFingerprint.fingerprintCanonicalBytes
                  $ InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint
                      value
            in (length canonical, SHA256.hash $ BS.pack canonical)
      map canonicalSnapshot
          [ config, descriptorBound, effectiveID, execveCheck ] @?=
        [ ( 687
          , BS.pack
              [ 120, 191, 6, 55, 236, 94, 65, 71
              , 119, 151, 24, 172, 60, 109, 49, 218
              , 119, 204, 67, 169, 246, 79, 102, 234
              , 34, 15, 131, 202, 152, 1, 148, 128
              ]
          )
        , ( 950
          , BS.pack
              [ 9, 221, 56, 122, 86, 141, 87, 81
              , 14, 64, 129, 18, 7, 93, 247, 26
              , 148, 56, 112, 96, 151, 202, 156, 137
              , 136, 71, 212, 177, 214, 62, 212, 143
              ]
          )
        , ( 1188
          , BS.pack
              [ 144, 19, 207, 84, 100, 28, 129, 41
              , 19, 85, 217, 140, 11, 39, 88, 111
              , 23, 95, 39, 128, 135, 234, 14, 94
              , 236, 230, 184, 105, 229, 162, 17, 45
              ]
          )
        , ( 1439
          , BS.pack
              [ 227, 50, 111, 40, 118, 31, 65, 84
              , 53, 212, 158, 143, 113, 227, 154, 246
              , 35, 22, 141, 132, 127, 193, 3, 245
              , 200, 145, 23, 91, 238, 181, 19, 131
              ]
          )
        ]
  , testCase "distinguish all launch strategies without changing policy facts" $ do
      let source = InternalSMTLibExecution.defaultLengthSMTLibExecutionConfigSource
            absoluteFixtureExecutable $ Just $ replicate 32 7
          limits = InternalSMTLibExecution.defaultLengthSMTLibExecutionLimits
      legacy <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibExecutionConfig limits source
      descriptorBound <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundExecutionConfig
            limits source
      effectiveID <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessExecutionConfig
            limits source
      execveCheck <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundExecveCheckExecutableAccessExecutionConfig
            limits source
      InternalSMTLibExecution.lengthSMTLibExecutionExecutableLaunchStrategy
          legacy @?=
        InternalSMTLibExecution.LengthSMTLibPathSnapshotThenDirectSpawn
      InternalSMTLibExecution.lengthSMTLibExecutionExecutableLaunchStrategy
          descriptorBound @?=
        InternalSMTLibExecution.LengthSMTLibDescriptorBoundExecutableLaunch
      InternalSMTLibExecution.lengthSMTLibExecutionExecutableLaunchStrategy
          effectiveID @?=
        InternalSMTLibExecution.LengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunch
      InternalSMTLibExecution.lengthSMTLibExecutionExecutableLaunchStrategy
          execveCheck @?=
        InternalSMTLibExecution.LengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunch
      assertBool "four launch strategies did not have distinct policies"
        $ length (nub [legacy, descriptorBound, effectiveID, execveCheck]) == 4
      _ <- evaluate $ force effectiveID
      _ <- evaluate $ force execveCheck
      InternalSMTLibExecution.lengthSMTLibExecutionConfiguredArgumentVector
          descriptorBound @?=
        InternalSMTLibExecution.lengthSMTLibExecutionConfiguredArgumentVector
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionExecutableDigestExpectation
          descriptorBound @?=
        InternalSMTLibExecution.lengthSMTLibExecutionExecutableDigestExpectation
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionSolverTimeoutMilliseconds
          descriptorBound @?=
        InternalSMTLibExecution.lengthSMTLibExecutionSolverTimeoutMilliseconds
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionSolverResourceLimit
          descriptorBound @?=
        InternalSMTLibExecution.lengthSMTLibExecutionSolverResourceLimit legacy
      InternalSMTLibExecution.lengthSMTLibExecutionHostDeadlineMilliseconds
          descriptorBound @?=
        InternalSMTLibExecution.lengthSMTLibExecutionHostDeadlineMilliseconds
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionArtifactPolicy
          descriptorBound @?=
        InternalSMTLibExecution.lengthSMTLibExecutionArtifactPolicy legacy
      InternalSMTLibExecution.lengthSMTLibExecutionResponseLimits
          descriptorBound @?=
        InternalSMTLibExecution.lengthSMTLibExecutionResponseLimits legacy
      InternalSMTLibExecution.lengthSMTLibExecutionConfiguredArgumentVector
          effectiveID @?=
        InternalSMTLibExecution.lengthSMTLibExecutionConfiguredArgumentVector
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionExecutableDigestExpectation
          effectiveID @?=
        InternalSMTLibExecution.lengthSMTLibExecutionExecutableDigestExpectation
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionSolverTimeoutMilliseconds
          effectiveID @?=
        InternalSMTLibExecution.lengthSMTLibExecutionSolverTimeoutMilliseconds
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionSolverResourceLimit
          effectiveID @?=
        InternalSMTLibExecution.lengthSMTLibExecutionSolverResourceLimit legacy
      InternalSMTLibExecution.lengthSMTLibExecutionHostDeadlineMilliseconds
          effectiveID @?=
        InternalSMTLibExecution.lengthSMTLibExecutionHostDeadlineMilliseconds
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionArtifactPolicy effectiveID
        @?= InternalSMTLibExecution.lengthSMTLibExecutionArtifactPolicy legacy
      InternalSMTLibExecution.lengthSMTLibExecutionResponseLimits effectiveID
        @?= InternalSMTLibExecution.lengthSMTLibExecutionResponseLimits legacy
      InternalSMTLibExecution.lengthSMTLibExecutionConfiguredArgumentVector
          execveCheck @?=
        InternalSMTLibExecution.lengthSMTLibExecutionConfiguredArgumentVector
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionExecutableDigestExpectation
          execveCheck @?=
        InternalSMTLibExecution.lengthSMTLibExecutionExecutableDigestExpectation
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionSolverTimeoutMilliseconds
          execveCheck @?=
        InternalSMTLibExecution.lengthSMTLibExecutionSolverTimeoutMilliseconds
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionSolverResourceLimit
          execveCheck @?=
        InternalSMTLibExecution.lengthSMTLibExecutionSolverResourceLimit legacy
      InternalSMTLibExecution.lengthSMTLibExecutionHostDeadlineMilliseconds
          execveCheck @?=
        InternalSMTLibExecution.lengthSMTLibExecutionHostDeadlineMilliseconds
          legacy
      InternalSMTLibExecution.lengthSMTLibExecutionArtifactPolicy execveCheck
        @?= InternalSMTLibExecution.lengthSMTLibExecutionArtifactPolicy legacy
      InternalSMTLibExecution.lengthSMTLibExecutionResponseLimits execveCheck
        @?= InternalSMTLibExecution.lengthSMTLibExecutionResponseLimits legacy
      let legacyIdentity = InternalFingerprint.fingerprintCanonicalBytes
            $ InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint legacy
          descriptorIdentity = InternalFingerprint.fingerprintCanonicalBytes
            $ InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint
                descriptorBound
          effectiveIDIdentity = InternalFingerprint.fingerprintCanonicalBytes
            $ InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint
                effectiveID
          execveCheckIdentity = InternalFingerprint.fingerprintCanonicalBytes
            $ InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint
                execveCheck
          descriptorPostLaunch =
            InternalSMTLibExecution.retainLengthSMTLibPostLaunchExecutionPolicy
              descriptorBound
          effectiveIDPostLaunch =
            InternalSMTLibExecution.retainLengthSMTLibPostLaunchExecutionPolicy
              effectiveID
          execveCheckPostLaunch =
            InternalSMTLibExecution.retainLengthSMTLibPostLaunchExecutionPolicy
              execveCheck
      assertBool "descriptor-bound launch was absent from private identity"
        $ legacyIdentity /= descriptorIdentity
      assertBool "descriptor-bound identity omitted its strategy schema"
        $ asciiBytes
            "djex-length-z3-smtlib2-execution-policy/descriptor-bound-main-image/v1"
              `isInfixOf` descriptorIdentity
      assertBool "descriptor-bound identity omitted sealed-image mechanism"
        $ asciiBytes
            "opened-source-hash-copy-sealed-memfd-execveat/main-image-bytes/v1"
              `isInfixOf` descriptorIdentity
      assertBool "descriptor-bound identity omitted sealed-image scope"
        $ asciiBytes "sealed-staged-main-image-bytes-only/v1"
              `isInfixOf` descriptorIdentity
      assertBool "descriptor-bound identity omitted its authority exclusion"
        $ asciiBytes (concat
            [ "no-setuid-file-capability-loader-library-interpreter-or-solver-"
            , "authority/v1"
            ]) `isInfixOf` descriptorIdentity
      assertBool "legacy identity acquired descriptor-bound semantics"
        $ not $ asciiBytes
            "opened-source-hash-copy-sealed-memfd-execveat/main-image-bytes/v1"
              `isInfixOf` legacyIdentity
      assertBool "effective-ID launch was absent from its private identity"
        $ effectiveIDIdentity /= legacyIdentity &&
            effectiveIDIdentity /= descriptorIdentity
      mapM_ (\literal -> assertBool
          ("effective-ID identity omitted " ++ literal)
          $ asciiBytes literal `isInfixOf` effectiveIDIdentity)
        [ "djex-length-z3-smtlib2-execution-policy/descriptor-bound-effective-id-executable-access/v1"
        , "opened-source-two-point-faccessat2-x-ok-at-empty-path-at-eaccess-hash-copy-sealed-memfd-execveat/point-in-time-effective-id-source-vfs-executable-access-and-main-image-bytes/v1"
        , "two-point-point-in-time-effective-id-source-vfs-executable-access-only/v1"
        , "sealed-staged-main-image-bytes-only/v1"
        , "no-setuid-file-capability-loader-library-interpreter-or-solver-authority/v1"
        ]
      assertBool "old descriptor identity acquired effective-ID semantics"
        $ not $ asciiBytes
            "two-point-point-in-time-effective-id-source-vfs-executable-access-only/v1"
              `isInfixOf` descriptorIdentity
      assertBool "exec-check launch was absent from its private identity"
        $ execveCheckIdentity /= legacyIdentity &&
            execveCheckIdentity /= descriptorIdentity &&
            execveCheckIdentity /= effectiveIDIdentity
      mapM_ (\literal -> assertBool
          ("exec-check identity omitted " ++ literal)
          $ asciiBytes literal `isInfixOf` execveCheckIdentity)
        [ "djex-length-z3-smtlib2-execution-policy/descriptor-bound-execve-check-executable-access/v1"
        , "two-point-source-faccessat2-and-execve-check-plus-one-sealed-staged-image-execve-check-point-in-time-only/v1"
        , "mfd-exec-fixed-0500-seal-write-grow-shrink-future-write-exec-seal-main-image-bytes-only/v1"
        , "no-source-authorization-transfer-format-binfmt-bprm-check-credential-transition-interpreter-loader-library-solver-or-result-authority/v1"
        ]
      assertBool "effective-ID identity acquired exec-check semantics"
        $ not $ asciiBytes
            "two-point-source-faccessat2-and-execve-check-plus-one-sealed-staged-image-execve-check-point-in-time-only/v1"
              `isInfixOf` effectiveIDIdentity
      InternalSMTLibExecution.lengthSMTLibPostLaunchExecutableLaunchStrategy
          descriptorPostLaunch @?=
        InternalSMTLibExecution.LengthSMTLibDescriptorBoundExecutableLaunch
      InternalSMTLibExecution.lengthSMTLibPostLaunchExecutionPolicyFingerprint
          descriptorPostLaunch @?=
        InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint
          descriptorBound
      InternalSMTLibExecution.lengthSMTLibPostLaunchExecutableLaunchStrategy
          effectiveIDPostLaunch @?=
        InternalSMTLibExecution.LengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunch
      InternalSMTLibExecution.lengthSMTLibPostLaunchExecutionPolicyFingerprint
          effectiveIDPostLaunch @?=
        InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint
          effectiveID
      InternalSMTLibExecution.lengthSMTLibPostLaunchExecutableLaunchStrategy
          execveCheckPostLaunch @?=
        InternalSMTLibExecution.LengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunch
      InternalSMTLibExecution.lengthSMTLibPostLaunchExecutionPolicyFingerprint
          execveCheckPostLaunch @?=
        InternalSMTLibExecution.lengthSMTLibExecutionPolicyFingerprint
          execveCheck
      [ InternalSMTLibExecution.LengthSMTLibPathSnapshotThenDirectSpawn
        , InternalSMTLibExecution.LengthSMTLibDescriptorBoundExecutableLaunch
        , InternalSMTLibExecution.LengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunch
        , InternalSMTLibExecution.LengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunch
        ] @?= [minBound .. maxBound]
      map fromEnum
        [ InternalSMTLibExecution.LengthSMTLibPathSnapshotThenDirectSpawn
        , InternalSMTLibExecution.LengthSMTLibDescriptorBoundExecutableLaunch
        , InternalSMTLibExecution.LengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunch
        , InternalSMTLibExecution.LengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunch
        ] @?= [0, 1, 2, 3]
      let invalid = source
            { InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceExecutablePath =
                "relative-z3"
            }
      case
          ( InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundExecutionConfig
              limits invalid
          , InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessExecutionConfig
              limits invalid
          , InternalSMTLibExecution.mkLengthSMTLibDescriptorBoundExecveCheckExecutableAccessExecutionConfig
              limits invalid
          , InternalSMTLibExecution.mkLengthSMTLibExecutionConfig limits invalid
          ) of
        ( Left descriptorFailure, Left effectiveIDFailure
          , Left execveCheckFailure, Left legacyFailure
          ) ->
          (descriptorFailure, effectiveIDFailure, execveCheckFailure) @?=
            (legacyFailure, legacyFailure, legacyFailure)
        _ -> assertFailure
          "relative executable path did not fail identically across strategies"
  , testCase "classify only sealed executable digest expectation presence" $ do
      let seal expectedDigest = expectRight
            $ SMTLibExecution.mkLengthSMTLibExecutionConfig
                SMTLibExecution.defaultLengthSMTLibExecutionLimits
            $ SMTLibExecution.defaultLengthSMTLibExecutionConfigSource
                absoluteFixtureExecutable expectedDigest
      withoutExpectation <- seal Nothing
      withExpectation <- seal $ Just $ replicate 32 0
      SMTLibExecution.lengthSMTLibExecutionExecutableDigestExpectation
          withoutExpectation @?=
        SMTLibExecution.LengthSMTLibExecutableDigestExpectationAbsent
      SMTLibExecution.lengthSMTLibExecutionExecutableDigestExpectation
          withExpectation @?=
        SMTLibExecution.LengthSMTLibExecutableDigestExpectationPresent
      [ SMTLibExecution.LengthSMTLibExecutableDigestExpectationAbsent
        , SMTLibExecution.LengthSMTLibExecutableDigestExpectationPresent
        ] @?= [minBound .. maxBound]
  , testCase "reject signed policy fields in declaration order" $ do
      let defaults = SMTLibExecution.defaultLengthSMTLibExecutionConfigSource
            "relative-z3" (Just [0])
          seal source = SMTLibExecution.mkLengthSMTLibExecutionConfig
            SMTLibExecution.defaultLengthSMTLibExecutionLimits source
      assertLeft
        (SMTLibExecution.NegativeLengthSMTLibExecutionConfigField
          SMTLibExecution.LengthSMTLibExecutionSolverTimeoutMilliseconds (-1))
        $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds = -1
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit = -1
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds = -1
            }
      assertLeft
        (SMTLibExecution.NegativeLengthSMTLibExecutionConfigField
          SMTLibExecution.LengthSMTLibExecutionSolverResourceLimit (-1))
        $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit = -1
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds = -1
            }
      assertLeft
        (SMTLibExecution.NegativeLengthSMTLibExecutionConfigField
          SMTLibExecution.LengthSMTLibExecutionHostDeadlineMilliseconds (-1))
        $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds = -1
            }
  , testCase "preserve launch validation demand and failure order" $ do
      let defaults = SMTLibExecution.defaultLengthSMTLibExecutionConfigSource
            absoluteFixtureExecutable Nothing
          sealWith limits = SMTLibExecution.mkLengthSMTLibExecutionConfig limits
          seal = sealWith SMTLibExecution.defaultLengthSMTLibExecutionLimits
          poisonLater source = source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceExecutablePath =
                error "path-demand"
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceExpectedExecutableSHA256 =
                error "digest-demand"
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
                error "artifact-demand"
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
                error "response-demand"
            }
      assertLeft
        (SMTLibExecution.NegativeLengthSMTLibExecutionConfigField
          SMTLibExecution.LengthSMTLibExecutionSolverTimeoutMilliseconds (-1))
        $ seal $ (poisonLater defaults)
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
                -1
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
                error "resource-demand"
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
                error "deadline-demand"
            }
      assertLeft
        (SMTLibExecution.NegativeLengthSMTLibExecutionConfigField
          SMTLibExecution.LengthSMTLibExecutionSolverResourceLimit (-1))
        $ seal $ (poisonLater defaults)
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
                -1
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
                error "deadline-demand"
            }
      assertLeft
        (SMTLibExecution.NegativeLengthSMTLibExecutionConfigField
          SMTLibExecution.LengthSMTLibExecutionHostDeadlineMilliseconds (-1))
        $ seal $ (poisonLater defaults)
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
                -1
            }
      assertLeft SMTLibExecution.LengthSMTLibExecutionExecutablePathNotAbsolute
        $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceExecutablePath =
                "z3"
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceExpectedExecutableSHA256 =
                error "digest-demand"
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
                error "artifact-demand"
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
                error "response-demand"
            }
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionExpectedExecutableSHA256LengthMismatch
          32 1)
        $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceExpectedExecutableSHA256 =
                Just [0]
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
                error "artifact-demand"
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
                error "response-demand"
            }
      let noFingerprint = SMTLibExecution.mkLengthSMTLibExecutionLimits
            SMTLibExecution.defaultLengthSMTLibExecutionLimitSource
              { SMTLibExecution.lengthSMTLibExecutionLimitSourcePolicyFingerprintBytes =
                  0
              }
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionPolicyFingerprintByteLimitExceeded
          0 1)
        $ sealWith noFingerprint defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
                error "artifact-demand"
            , SMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
                error "response-demand"
            }
  , testCase "bound and validate executable paths and digest pins productively" $ do
      let defaults path digest =
            SMTLibExecution.defaultLengthSMTLibExecutionConfigSource path digest
          sealWith limits = SMTLibExecution.mkLengthSMTLibExecutionConfig limits
          seal = sealWith SMTLibExecution.defaultLengthSMTLibExecutionLimits
      assertLeft SMTLibExecution.LengthSMTLibExecutionEmptyExecutablePath
        $ seal $ defaults "" Nothing
      assertLeft SMTLibExecution.LengthSMTLibExecutionExecutablePathNotAbsolute
        $ seal $ defaults "z3" $ Just []
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionInvalidExecutablePathCharacter 3
          SMTLibExecution.LengthSMTLibExecutionPathContainsNul)
        $ seal $ defaults (absoluteFixturePrefix ++ ['\0']) Nothing
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionInvalidExecutablePathCharacter 3
          SMTLibExecution.LengthSMTLibExecutionPathContainsSurrogate)
        $ seal $ defaults (absoluteFixturePrefix ++ [toEnum 0xd800]) Nothing
      let tinyLimits = SMTLibExecution.mkLengthSMTLibExecutionLimits
            SMTLibExecution.defaultLengthSMTLibExecutionLimitSource
              { SMTLibExecution.lengthSMTLibExecutionLimitSourceExecutablePathCharacters = 3 }
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionExecutablePathCharacterLimitExceeded
          3 4)
        $ sealWith tinyLimits $ defaults (absoluteFixturePrefix ++ "x") Nothing
      let cyclicTail = 'z' : cyclicTail
          cyclicPath = absoluteFixturePrefix ++ cyclicTail
      cyclicPathResult <- evaluateWithin
        $ sealWith tinyLimits $ defaults cyclicPath Nothing
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionExecutablePathCharacterLimitExceeded
          3 4)
        cyclicPathResult
      _ <- expectRight
        $ seal $ defaults absoluteFixtureExecutable $ Just $ replicate 32 0
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionExpectedExecutableSHA256LengthMismatch
          32 31)
        $ seal $ defaults absoluteFixtureExecutable $ Just $ replicate 31 0
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionExpectedExecutableSHA256LengthMismatch
          32 33)
        $ seal $ defaults absoluteFixtureExecutable $ Just $ replicate 33 0
      let cyclicDigest = 0 : cyclicDigest
      cyclicDigestResult <- evaluateWithin
        $ seal $ defaults absoluteFixtureExecutable $ Just cyclicDigest
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionExpectedExecutableSHA256LengthMismatch
          32 33)
        cyclicDigestResult
  , testCase "validate finite solver and stricter host time budgets" $ do
      let defaults = SMTLibExecution.defaultLengthSMTLibExecutionConfigSource
            absoluteFixtureExecutable Nothing
          seal source = SMTLibExecution.mkLengthSMTLibExecutionConfig
            SMTLibExecution.defaultLengthSMTLibExecutionLimits source
          fieldError field maximumValue observed =
            SMTLibExecution.LengthSMTLibExecutionConfigFieldAboveMaximum
              field maximumValue observed
      assertLeft
        (SMTLibExecution.ZeroLengthSMTLibExecutionConfigField
          SMTLibExecution.LengthSMTLibExecutionSolverTimeoutMilliseconds)
        $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds = 0 }
      assertLeft
        (SMTLibExecution.ZeroLengthSMTLibExecutionConfigField
          SMTLibExecution.LengthSMTLibExecutionSolverResourceLimit)
        $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit = 0 }
      let word32Maximum = 4294967295 :: Integer
      when (toInteger (maxBound :: Int) >= word32Maximum) $ do
          let maximumInt = fromInteger word32Maximum
          assertLeft
            (fieldError
              SMTLibExecution.LengthSMTLibExecutionSolverTimeoutMilliseconds
              (word32Maximum - 1) word32Maximum)
            $ seal defaults
                { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
                    maximumInt }
          _ <- expectRight $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
                maximumInt }
          pure ()
      when (toInteger (maxBound :: Int) > word32Maximum) $ do
          let aboveMaximumInt = fromInteger $ word32Maximum + 1
          assertLeft
            (fieldError SMTLibExecution.LengthSMTLibExecutionSolverResourceLimit
              word32Maximum (word32Maximum + 1))
            $ seal defaults
                { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
                    aboveMaximumInt }
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionHostDeadlineMarginTooSmall
          1000 1099 100)
        $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
                1099 }
      exactMargin <- expectRight $ seal defaults
        { SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
            1100 }
      SMTLibExecution.lengthSMTLibExecutionHostDeadlineMilliseconds exactMargin
        @?= 1100
      let overflowDeadline = maxBound `div` 1000 + 1
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionHostDeadlineMicrosecondsOverflow
          overflowDeadline)
        $ seal defaults
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
                overflowDeadline }
  , testCase "bind every configurable policy field into private identity" $ do
      let source = SMTLibExecution.defaultLengthSMTLibExecutionConfigSource
            absoluteFixtureExecutable Nothing
          sealWith limits candidate = expectRight
            $ SMTLibExecution.mkLengthSMTLibExecutionConfig limits candidate
          seal = sealWith SMTLibExecution.defaultLengthSMTLibExecutionLimits
          response change = expectRight
            $ SMTLibResponse.mkLengthSMTLibResponseLimits
            $ change SMTLibResponse.defaultLengthSMTLibResponseLimitSource
      baseline <- seal source
      responseBytes <- response $ \limits -> limits
        { SMTLibResponse.lengthSMTLibResponseLimitSourceBytes = 65535 }
      responseDepth <- response $ \limits -> limits
        { SMTLibResponse.lengthSMTLibResponseLimitSourceNestingDepth = 63 }
      responseNodes <- response $ \limits -> limits
        { SMTLibResponse.lengthSMTLibResponseLimitSourceNodes = 4095 }
      responseTokens <- response $ \limits -> limits
        { SMTLibResponse.lengthSMTLibResponseLimitSourceTokenBytes = 4095 }
      responseIntegers <- response $ \limits -> limits
        { SMTLibResponse.lengthSMTLibResponseLimitSourceIntegerBits = 4095 }
      changed <- mapM seal
        [ source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceExecutablePath =
                absoluteFixtureExecutable ++ "-other" }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceExecutablePath =
                absoluteFixtureExecutable ++ "-\945" }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceExecutablePath =
                absoluteFixtureExecutable ++ [toEnum 0x0101] }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceExecutablePath =
                absoluteFixtureExecutable ++ [toEnum 0x0201] }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceExpectedExecutableSHA256 =
                Just $ replicate 32 0 }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceExpectedExecutableSHA256 =
                Just $ 1 : replicate 31 0 }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
                1001 }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
                100001 }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
                1501 }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
                SMTLibExecution.LengthSMTLibStatusOnly }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
                responseBytes }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
                responseDepth }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
                responseNodes }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
                responseTokens }
        , source
            { SMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
                responseIntegers }
        ]
      assertBool "a retained policy field was absent from private identity"
        $ notElem baseline changed
      assertBool "distinct retained field values shared private identity"
        $ length (nub $ baseline : changed) == length changed + 1
      let widerAdmission = SMTLibExecution.mkLengthSMTLibExecutionLimits
            SMTLibExecution.defaultLengthSMTLibExecutionLimitSource
              { SMTLibExecution.lengthSMTLibExecutionLimitSourceExecutablePathCharacters =
                  8192 }
      resealed <- sealWith widerAdmission source
      assertBool "admission-only limits changed sealed policy identity"
        $ resealed == baseline
  , testCase "bound the private complete policy fingerprint" $ do
      let noFingerprint = SMTLibExecution.mkLengthSMTLibExecutionLimits
            SMTLibExecution.defaultLengthSMTLibExecutionLimitSource
              { SMTLibExecution.lengthSMTLibExecutionLimitSourcePolicyFingerprintBytes =
                  0 }
      assertLeft
        (SMTLibExecution.LengthSMTLibExecutionPolicyFingerprintByteLimitExceeded
          0 1)
        $ SMTLibExecution.mkLengthSMTLibExecutionConfig noFingerprint
        $ SMTLibExecution.defaultLengthSMTLibExecutionConfigSource
            absoluteFixtureExecutable Nothing
  , testCase "emit one exact canonical constant-zero query" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      SMTLib.lengthSMTLibQuerySchemaTag @?=
        asciiBytes "djex-length-z3-qf-lia-smtlib2/v2"
      SMTLib.lengthSMTLibQueryLogic @?= asciiBytes "QF_LIA"
      -- This digest is only a test snapshot of the collision-free canonical
      -- bytes; it is not used as query identity or semantic authority.
      SHA256.hash
          (BS.pack $ Fingerprint.fingerprintCanonicalBytes
            $ SMTLib.lengthSMTLibQueryFingerprint query) @?=
        BS.pack
          [ 120, 51, 36, 160, 42, 77, 181, 66
          , 235, 172, 87, 175, 113, 83, 194, 243
          , 160, 146, 209, 159, 142, 143, 178, 222
          , 89, 220, 90, 38, 240, 18, 31, 237
          ]
      let noModuloKeyBytes = Fingerprint.fingerprintCanonicalBytes
            $ SMTLib.lengthSMTLibQueryFingerprint query
      assertBool "a no-modulo query gained the conditional lowering tag"
        $ not $ asciiBytes
            "djex-length-z3-qf-lia-positive-literal-modulo-witness/v1"
              `isInfixOf` noModuloKeyBytes
      assertBool "a no-modulo problem gained the conditional node tag"
        $ not $ asciiBytes "positive-literal-natural-modulo/v1"
              `isInfixOf` noModuloKeyBytes
      SMTLib.lengthSMTLibQueryInputSymbols query @?=
        [asciiBytes "djex_length_input_0"]
      SMTLib.lengthSMTLibQueryCheckBytes query @?=
        asciiBytes constantZeroSMTLibCheck
      SMTLib.lengthSMTLibQueryInputValueRequestBytes query @?=
        Just (asciiBytes "(get-value (djex_length_input_0))\n")
      Djex.behavioralProblemFingerprint
          (SMTLib.lengthSMTLibQueryBehavioralProblem query) @?=
        Djex.behavioralProblemFingerprint
          (LengthProblem.checkedLengthProblemBehavioralProblem problem)
  , testCase
      "request and replay only compact observed inputs for a mixed target" $ do
      let input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          violatingContract = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result
            $ Length.LengthSum [input, Length.LengthLiteral 1]
      (_, session, contract, candidate) <-
        roleAwareMapFixtureWithContract violatingContract
      problem <- expectRight
        $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
            LengthProblem.defaultLengthProblemLimits
            session contract candidate
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      SMTLib.lengthSMTLibQueryInputSymbols query @?=
        [asciiBytes "djex_length_input_0"]
      SMTLib.lengthSMTLibQueryInputValueRequestBytes query @?=
        Just (asciiBytes "(get-value (djex_length_input_0))\n")
      case SMTLib.lengthSMTLibQueryInputSymbols query of
        [symbol] -> do
          evidence <- expectCounterexample
            $ SMTLib.validateLengthSMTLibCounterexample
                Evaluate.defaultLengthEvaluationLimits query
                [smtIntegerBinding symbol 3]
          receipt <- expectRight $ Djex.replayBehavioralEvidence
            (LengthProblem.checkedLengthProblemBehavioralProblem problem)
            evidence
          Evaluate.validatedLengthCounterexampleInputs receipt @?= [3]
          Evaluate.validatedLengthCounterexampleResult receipt @?= 3
        symbols -> assertFailure $ "unexpected mixed-role symbols: " ++
          show symbols
  , testCase "rederive a widened exact symbol and request plan productively" $ do
      let inputCount = 32
          expectedSymbols =
            [ asciiBytes $ "djex_length_input_" ++ show index
            | index <- [0 .. inputCount - 1]
            ]
          expectedRequest = Just $ asciiBytes $
            "(get-value (" ++ intercalate " "
              (map (BSC.unpack . BS.pack) expectedSymbols) ++ "))\n"
      problem <- adversarialWideConstantZeroProblem inputCount
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      exact <- evaluateWithin $
        SMTLib.lengthSMTLibQueryInputSymbols query == expectedSymbols &&
        SMTLib.lengthSMTLibQueryInputValueRequestBytes query == expectedRequest
      assertBool "widened query artifacts were not canonically rederived" exact
      execution <- protocolExecutionConfig
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      plan <- expectRight =<< evaluateWithin
        (SMTLibProtocol.sealLengthSMTLibProtocolPlan
          SMTLibProtocol.defaultLengthSMTLibProtocolLimits
          execution query protocolCheckNonce $ Just protocolValueNonce)
      valueBarrier <- protocolSentinel protocolValueNonce
      SMTLibProtocol.lengthSMTLibProtocolInputValueWriteBytes plan @?=
        fmap (++ SMTLibStream.smtLibEchoSentinelCommandBytes valueBarrier)
          expectedRequest
  , testGroup "query-owned input replay"
      [ testCase "match the decoded-binding replay receipt exactly" $ do
          problem <- adversarialConstantZeroProblem identityLengthContract
          query <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits problem
          case SMTLib.lengthSMTLibQueryInputSymbols query of
            [symbol] -> do
              evidence <- expectCounterexample
                $ SMTLib.validateLengthSMTLibCounterexample
                    Evaluate.defaultLengthEvaluationLimits query
                    [smtIntegerBinding symbol 3]
              decodedReceipt <- expectRight $ Djex.replayBehavioralEvidence
                (SMTLib.lengthSMTLibQueryBehavioralProblem query) evidence
              inputReceipt <- expectCounterexample
                $ SMTLib.replayLengthSMTLibCounterexampleInputs
                    Evaluate.defaultLengthEvaluationLimits query [3]
              inputReceipt @?= decodedReceipt
            symbols -> assertFailure $ "unexpected input symbols: " ++
              show symbols
      , testCase
          "derive exact nullary, unary, and binary origin receipts" $ do
          let result = Length.LengthVariable Length.LengthResult
              originViolation = contractWith (Length.LengthTruth True)
                $ Length.LengthEqual result $ Length.LengthLiteral 1
          zeroProblem <- adversarialZeroInputProblem originViolation
          unaryProblem <- adversarialConstantZeroProblem originViolation
          binaryProblem <- adversarialBinaryConstantZeroProblem
            originViolation
          zeroQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits zeroProblem
          unaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits unaryProblem
          binaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits binaryProblem
          zeroReceipt <- expectCounterexample
            $ SMTLib.probeLengthSMTLibCounterexampleAtOrigin
                Evaluate.defaultLengthEvaluationLimits zeroQuery
          unaryReceipt <- expectCounterexample
            $ SMTLib.probeLengthSMTLibCounterexampleAtOrigin
                Evaluate.defaultLengthEvaluationLimits unaryQuery
          binaryReceipt <- expectCounterexample
            $ SMTLib.probeLengthSMTLibCounterexampleAtOrigin
                Evaluate.defaultLengthEvaluationLimits binaryQuery
          map Evaluate.validatedLengthCounterexampleInputs
              [zeroReceipt, unaryReceipt, binaryReceipt] @?=
            [[], [0], [0, 0]]
          map Evaluate.validatedLengthCounterexampleResult
              [zeroReceipt, unaryReceipt, binaryReceipt] @?= [0, 0, 0]
          map Evaluate.validatedLengthCounterexampleBasis
              [zeroReceipt, unaryReceipt, binaryReceipt] @?=
            replicate 3 Evaluate.ProviderIndependentFiniteSpineModel
          directBinary <- expectCounterexample
            $ SMTLib.replayLengthSMTLibCounterexampleInputs
                Evaluate.defaultLengthEvaluationLimits binaryQuery [0, 0]
          binaryReceipt @?= directBinary

          providerProblem <- adversarialConstantProviderProblem
            7 identityLengthContract
          providerQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits providerProblem
          providerReceipt <- expectCounterexample
            $ SMTLib.probeLengthSMTLibCounterexampleAtOrigin
                Evaluate.defaultLengthEvaluationLimits providerQuery
          providerName <- expectName "Fixture.problemReplayConstant"
          Evaluate.validatedLengthCounterexampleInputs providerReceipt @?= [0]
          Evaluate.validatedLengthCounterexampleResult providerReceipt @?= 7
          Evaluate.validatedLengthCounterexampleBasis providerReceipt @?=
            Evaluate.FiniteSpineModelUnderAssumedProviderLaws [providerName]
      , testCase
          "preserve origin misses, demand order, and evaluation rejection" $ do
          safeProblem <- adversarialConstantZeroProblem identityLengthContract
          safeQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits safeProblem
          expectNoCounterexample
            $ SMTLib.probeLengthSMTLibCounterexampleAtOrigin
                Evaluate.defaultLengthEvaluationLimits safeQuery

          let result = Length.LengthVariable Length.LengthResult
              vacuousSource = contractWith (Length.LengthTruth False)
                $ Length.LengthEqual result $ Length.LengthLiteral 1
          vacuousProblem <- adversarialConstantProviderProblem 7 vacuousSource
          vacuousQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits vacuousProblem
          expectNoCounterexample
            $ SMTLib.probeLengthSMTLibCounterexampleAtOrigin
                (evaluationLimitsWith 0 0) vacuousQuery

          demandingProblem <- adversarialConstantZeroProblem
            $ contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral 1
          demandingQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits demandingProblem
          assertLeft
            (SMTLib.LengthSMTLibInputReplayEvaluationRejected
              $ Evaluate.LengthEvaluationValueBitLimitExceeded
                  Evaluate.LengthIntermediateValue 0 1)
            $ SMTLib.probeLengthSMTLibCounterexampleAtOrigin
                (evaluationLimitsWith 0 0) demandingQuery
      , testCase "derive a widened origin without caller arity data" $ do
          let inputCount = 32
          problem <- adversarialWideConstantZeroProblem inputCount
          query <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits problem
          origin <- evaluateWithin
            $ SMTLib.probeLengthSMTLibCounterexampleAtOrigin
                Evaluate.defaultLengthEvaluationLimits query
          expectNoCounterexample origin
      , testCase
          "recompute each exact query result and provider-law basis" $ do
          independentProblem <- adversarialConstantZeroProblem
            identityLengthContract
          providerProblem <- adversarialConstantProviderProblem
            7 identityLengthContract
          independentQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits independentProblem
          providerQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits providerProblem
          assertBool "distinct replay problems shared one query identity" $
            SMTLib.lengthSMTLibQueryFingerprint independentQuery /=
              SMTLib.lengthSMTLibQueryFingerprint providerQuery
          independentReceipt <- expectCounterexample
            $ SMTLib.replayLengthSMTLibCounterexampleInputs
                Evaluate.defaultLengthEvaluationLimits independentQuery [3]
          providerReceipt <- expectCounterexample
            $ SMTLib.replayLengthSMTLibCounterexampleInputs
                Evaluate.defaultLengthEvaluationLimits providerQuery [3]
          providerName <- expectName "Fixture.problemReplayConstant"
          map Evaluate.validatedLengthCounterexampleInputs
              [independentReceipt, providerReceipt] @?= [[3], [3]]
          map Evaluate.validatedLengthCounterexampleResult
              [independentReceipt, providerReceipt] @?= [0, 7]
          map Evaluate.validatedLengthCounterexampleBasis
              [independentReceipt, providerReceipt] @?=
            [ Evaluate.ProviderIndependentFiniteSpineModel
            , Evaluate.FiniteSpineModelUnderAssumedProviderLaws [providerName]
            ]
      , testCase "enforce exact zero, unary, and binary input arities" $ do
          let result = Length.LengthVariable Length.LengthResult
              zeroSource = contractWith (Length.LengthTruth True)
                $ Length.LengthEqual result $ Length.LengthLiteral 1
          zeroProblem <- adversarialZeroInputProblem zeroSource
          unaryProblem <- adversarialConstantZeroProblem identityLengthContract
          binaryProblem <- adversarialBinaryConstantZeroProblem
            identityLengthContract
          zeroQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits zeroProblem
          unaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits unaryProblem
          binaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits binaryProblem
          zeroReceipt <- expectCounterexample
            $ SMTLib.replayLengthSMTLibCounterexampleInputs
                Evaluate.defaultLengthEvaluationLimits zeroQuery []
          unaryReceipt <- expectCounterexample
            $ SMTLib.replayLengthSMTLibCounterexampleInputs
                Evaluate.defaultLengthEvaluationLimits unaryQuery [3]
          binaryReceipt <- expectCounterexample
            $ SMTLib.replayLengthSMTLibCounterexampleInputs
                Evaluate.defaultLengthEvaluationLimits binaryQuery [3, 7]
          map Evaluate.validatedLengthCounterexampleInputs
              [zeroReceipt, unaryReceipt, binaryReceipt] @?=
            [[], [3], [3, 7]]
          let arityFailure expected observed =
                SMTLib.LengthSMTLibInputReplayEvaluationRejected
                  $ Evaluate.LengthProblemAssignmentArityMismatch
                      expected observed
              replay query = SMTLib.replayLengthSMTLibCounterexampleInputs
                Evaluate.defaultLengthEvaluationLimits query
          assertLeft (arityFailure 0 1) $ replay zeroQuery [0]
          assertLeft (arityFailure 1 0) $ replay unaryQuery []
          assertLeft (arityFailure 2 1) $ replay binaryQuery [0]
          assertLeft (arityFailure 2 3) $ replay binaryQuery [0, 0, 0]
      , testCase
          "reject maximum-plus-one and cyclic tails before input values" $ do
          problem <- adversarialConstantZeroProblem identityLengthContract
          query <- expectRight $ SMTLib.sealLengthSMTLibQuery
            SMTLib.defaultLengthSMTLibLimits problem
          let replay = SMTLib.replayLengthSMTLibCounterexampleInputs
                Evaluate.defaultLengthEvaluationLimits query
              expected = SMTLib.LengthSMTLibInputReplayEvaluationRejected
                $ Evaluate.LengthProblemAssignmentArityMismatch 1 2
              poisonedInputs =
                [ error "query input replay demanded the first over-arity value"
                , error "query input replay demanded the extra over-arity value"
                ]
              cyclicInputs = 0 : cyclicInputs
          poisonedResult <- evaluateWithin $ replay poisonedInputs
          assertLeft expected poisonedResult
          cyclicResult <- evaluateWithin $ replay cyclicInputs
          assertLeft expected cyclicResult
      , testCase
          "wrap evaluation rejection and preserve a valid non-counterexample" $
          do
            problem <- adversarialConstantZeroProblem identityLengthContract
            query <- expectRight $ SMTLib.sealLengthSMTLibQuery
              SMTLib.defaultLengthSMTLibLimits problem
            assertLeft
              (SMTLib.LengthSMTLibInputReplayEvaluationRejected
                $ Evaluate.LengthEvaluationValueBitLimitExceeded
                    (Evaluate.LengthProblemInputValue 0) 2 3)
              $ SMTLib.replayLengthSMTLibCounterexampleInputs
                  (evaluationLimitsWith 2 8) query [4]
            expectNoCounterexample
              $ SMTLib.replayLengthSMTLibCounterexampleInputs
                  Evaluate.defaultLengthEvaluationLimits query [0]
      ]
  , testCase "decode input symbols order independently and replay the model" $ do
      problem <- adversarialBinaryConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      case SMTLib.lengthSMTLibQueryInputSymbols query of
        [first, second] -> do
          evidence <- expectCounterexample
            $ SMTLib.validateLengthSMTLibCounterexample
                Evaluate.defaultLengthEvaluationLimits query
                [ smtIntegerBinding second 7
                , smtIntegerBinding first 3
                ]
          receipt <- expectRight $ Djex.replayBehavioralEvidence
            (LengthProblem.checkedLengthProblemBehavioralProblem problem)
            evidence
          Evaluate.validatedLengthCounterexampleInputs receipt @?= [3, 7]
          Evaluate.validatedLengthCounterexampleResult receipt @?= 0
        symbols -> assertFailure $ "unexpected input symbols: " ++ show symbols
  , testCase "omit value requests for a zero-input counterexample" $ do
      let result = Length.LengthVariable Length.LengthResult
          source = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral 1
      problem <- adversarialZeroInputProblem source
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      SMTLib.lengthSMTLibQueryInputSymbols query @?= []
      SMTLib.lengthSMTLibQueryInputValueRequestBytes query @?= Nothing
      evidence <- expectCounterexample
        $ SMTLib.validateLengthSMTLibCounterexample
            Evaluate.defaultLengthEvaluationLimits query []
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence
      Evaluate.validatedLengthCounterexampleInputs receipt @?= []
      Evaluate.validatedLengthCounterexampleResult receipt @?= 0
  , testCase "lower nested positive-literal modulo through QF_LIA witnesses" $ do
      let input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          nested = Length.LengthModulo 5 $ Length.LengthModulo 3 input
          sibling = Length.LengthIf
            (Length.LengthAtMost input $ Length.LengthLiteral 10)
            (Length.LengthModulo 7 input)
            (Length.LengthLiteral 0)
          source = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthSum [nested, sibling]
      problem <- adversarialConstantZeroProblem source
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      let script = map (toEnum . fromIntegral)
            $ SMTLib.lengthSMTLibQueryCheckBytes query
          witnessBlock = concat
            [ "(declare-const djex_length_modulo_quotient_0 Int)\n"
            , "(declare-const djex_length_modulo_remainder_0 Int)\n"
            , "(declare-const djex_length_modulo_quotient_1 Int)\n"
            , "(declare-const djex_length_modulo_remainder_1 Int)\n"
            , "(declare-const djex_length_modulo_quotient_2 Int)\n"
            , "(declare-const djex_length_modulo_remainder_2 Int)\n"
            , "(assert (<= 0 djex_length_input_0))\n"
            , "(assert (<= 0 djex_length_modulo_quotient_0))\n"
            , "(assert (<= 0 djex_length_modulo_remainder_0))\n"
            , "(assert (<= djex_length_modulo_remainder_0 4))\n"
            , "(assert (= djex_length_modulo_remainder_1 "
            , "(+ (* 5 djex_length_modulo_quotient_0) "
            , "djex_length_modulo_remainder_0)))\n"
            , "(assert (<= 0 djex_length_modulo_quotient_1))\n"
            , "(assert (<= 0 djex_length_modulo_remainder_1))\n"
            , "(assert (<= djex_length_modulo_remainder_1 2))\n"
            , "(assert (= djex_length_input_0 "
            , "(+ (* 3 djex_length_modulo_quotient_1) "
            , "djex_length_modulo_remainder_1)))\n"
            , "(assert (<= 0 djex_length_modulo_quotient_2))\n"
            , "(assert (<= 0 djex_length_modulo_remainder_2))\n"
            , "(assert (<= djex_length_modulo_remainder_2 6))\n"
            , "(assert (= djex_length_input_0 "
            , "(+ (* 7 djex_length_modulo_quotient_2) "
            , "djex_length_modulo_remainder_2)))\n"
            ]
          keyBytes = Fingerprint.fingerprintCanonicalBytes
            $ SMTLib.lengthSMTLibQueryFingerprint query
          keyDigest = SHA256.hash $ BS.pack keyBytes
          loweringTag = asciiBytes
            "djex-length-z3-qf-lia-positive-literal-modulo-witness/v1"
          expressionTag = asciiBytes "positive-literal-natural-modulo/v1"
      assertBool "modulo witnesses were not allocated in expression preorder"
        $ witnessBlock `isInfixOf` script
      assertBool "the bad-state formula did not consume the witness remainders"
        $ ("(assert (not (= 0 (+ djex_length_modulo_remainder_0 " ++
            "(ite (<= djex_length_input_0 10) " ++
            "djex_length_modulo_remainder_2 0)))))\n") `isInfixOf` script
      assertBool "the QF_LIA query emitted the forbidden SMT-LIB mod operator"
        $ not $ "(mod " `isInfixOf` script
      SMTLib.lengthSMTLibQueryInputSymbols query @?=
        [asciiBytes "djex_length_input_0"]
      SMTLib.lengthSMTLibQueryInputValueRequestBytes query @?=
        Just (asciiBytes "(get-value (djex_length_input_0))\n")
      assertBool "modulo lowering schema was absent from query identity"
        $ loweringTag `isInfixOf` keyBytes
      assertBool "modulo-only query gained the quotient lowering schema"
        $ not $ asciiBytes
            "djex-length-z3-qf-lia-positive-literal-natural-quotient-witness/v1"
              `isInfixOf` keyBytes
      assertBool "normalized modulo node was absent from problem identity"
        $ expressionTag `isInfixOf` keyBytes
      -- Snapshot only the canonical reversible key bytes; the digest is not
      -- runtime identity or semantic authority.
      keyDigest @?= BS.pack
        [ 167, 96, 10, 155, 31, 163, 70, 66
        , 177, 104, 34, 107, 248, 24, 191, 245
        , 110, 150, 98, 173, 222, 225, 194, 66
        , 103, 3, 116, 172, 115, 159, 104, 122
        ]
      evidence <- expectCounterexample
        $ SMTLib.validateLengthSMTLibCounterexample
            Evaluate.defaultLengthEvaluationLimits query
            [smtIntegerBinding (asciiBytes "djex_length_input_0") 8]
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence
      Evaluate.validatedLengthCounterexampleInputs receipt @?= [8]
      Evaluate.validatedLengthCounterexampleResult receipt @?= 0
  , testCase
      "lower nested mixed quotient/modulo with shared Euclidean witnesses" $ do
      let input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          mixed = Length.LengthIf
            (Length.LengthAtMost input $ Length.LengthLiteral 10)
            (Length.LengthQuotient 5 $ Length.LengthModulo 3 input)
            (Length.LengthModulo 7 $ Length.LengthQuotient 2 input)
          source = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result mixed
      problem <- adversarialConstantZeroProblem source
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      let script = map (toEnum . fromIntegral)
            $ SMTLib.lengthSMTLibQueryCheckBytes query
          witnessBlock = concat
            [ "(declare-const djex_length_quotient_quotient_0 Int)\n"
            , "(declare-const djex_length_quotient_remainder_0 Int)\n"
            , "(declare-const djex_length_modulo_quotient_1 Int)\n"
            , "(declare-const djex_length_modulo_remainder_1 Int)\n"
            , "(declare-const djex_length_modulo_quotient_2 Int)\n"
            , "(declare-const djex_length_modulo_remainder_2 Int)\n"
            , "(declare-const djex_length_quotient_quotient_3 Int)\n"
            , "(declare-const djex_length_quotient_remainder_3 Int)\n"
            , "(assert (<= 0 djex_length_input_0))\n"
            , "(assert (<= 0 djex_length_quotient_quotient_0))\n"
            , "(assert (<= 0 djex_length_quotient_remainder_0))\n"
            , "(assert (<= djex_length_quotient_remainder_0 4))\n"
            , "(assert (= djex_length_modulo_remainder_1 "
            , "(+ (* 5 djex_length_quotient_quotient_0) "
            , "djex_length_quotient_remainder_0)))\n"
            , "(assert (<= 0 djex_length_modulo_quotient_1))\n"
            , "(assert (<= 0 djex_length_modulo_remainder_1))\n"
            , "(assert (<= djex_length_modulo_remainder_1 2))\n"
            , "(assert (= djex_length_input_0 "
            , "(+ (* 3 djex_length_modulo_quotient_1) "
            , "djex_length_modulo_remainder_1)))\n"
            , "(assert (<= 0 djex_length_modulo_quotient_2))\n"
            , "(assert (<= 0 djex_length_modulo_remainder_2))\n"
            , "(assert (<= djex_length_modulo_remainder_2 6))\n"
            , "(assert (= djex_length_quotient_quotient_3 "
            , "(+ (* 7 djex_length_modulo_quotient_2) "
            , "djex_length_modulo_remainder_2)))\n"
            , "(assert (<= 0 djex_length_quotient_quotient_3))\n"
            , "(assert (<= 0 djex_length_quotient_remainder_3))\n"
            , "(assert (<= djex_length_quotient_remainder_3 1))\n"
            , "(assert (= djex_length_input_0 "
            , "(+ (* 2 djex_length_quotient_quotient_3) "
            , "djex_length_quotient_remainder_3)))\n"
            ]
          keyBytes = Fingerprint.fingerprintCanonicalBytes
            $ SMTLib.lengthSMTLibQueryFingerprint query
          moduloLoweringTag = asciiBytes
            "djex-length-z3-qf-lia-positive-literal-modulo-witness/v1"
          quotientLoweringTag = asciiBytes
            "djex-length-z3-qf-lia-positive-literal-natural-quotient-witness/v1"
      assertBool "mixed witnesses lost global expression-preorder allocation"
        $ witnessBlock `isInfixOf` script
      assertBool "the bad-state formula did not project q and r separately"
        $ ("(assert (not (= 0 (ite (<= djex_length_input_0 10) " ++
            "djex_length_quotient_quotient_0 " ++
            "djex_length_modulo_remainder_2))))\n") `isInfixOf` script
      assertBool "the QF_LIA query emitted the forbidden SMT-LIB div operator"
        $ not $ "(div " `isInfixOf` script
      assertBool "the QF_LIA query emitted the forbidden SMT-LIB mod operator"
        $ not $ "(mod " `isInfixOf` script
      assertBool "mixed query identity omitted modulo witness policy"
        $ moduloLoweringTag `isInfixOf` keyBytes
      assertBool "mixed query identity omitted quotient witness policy"
        $ quotientLoweringTag `isInfixOf` keyBytes
      assertBool "problem identity omitted normalized quotient syntax"
        $ asciiBytes "positive-literal-natural-quotient/v1"
            `isInfixOf` keyBytes
      assertBool "problem identity omitted normalized modulo syntax"
        $ asciiBytes "positive-literal-natural-modulo/v1"
            `isInfixOf` keyBytes
      evidence <- expectCounterexample
        $ SMTLib.validateLengthSMTLibCounterexample
            Evaluate.defaultLengthEvaluationLimits query
            [smtIntegerBinding (asciiBytes "djex_length_input_0") 17]
      receipt <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence
      Evaluate.validatedLengthCounterexampleInputs receipt @?= [17]
      Evaluate.validatedLengthCounterexampleResult receipt @?= 0
  , testCase "translate every other normalized Length operator into QF_LIA" $ do
      let input = Length.LengthVariable $ Length.LengthInput 0
          literal = Length.LengthLiteral
          bounded expression = Length.LengthAtMost expression $ literal 100
          source = contractWith
            (Length.LengthAll
              [ bounded $ Length.LengthSum [input, literal 1]
              , bounded $ Length.LengthScale 2 input
              , bounded $ Length.LengthMonus input $ literal 1
              , bounded $ Length.LengthMinimum input $ literal 2
              , bounded $ Length.LengthMaximum input $ literal 3
              , bounded $ Length.LengthIf
                  (Length.LengthAtMost input $ literal 4)
                  input
                  $ literal 1
              , Length.LengthEqual input $ literal 5
              , Length.LengthNot $ Length.LengthEqual input $ literal 6
              ])
            $ Length.LengthTruth False
      problem <- adversarialConstantZeroProblem source
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      let script = map (toEnum . fromIntegral)
            $ SMTLib.lengthSMTLibQueryCheckBytes query
          expectedFragments =
            [ "(<= (+ djex_length_input_0 1) 100)"
            , "(<= (* 2 djex_length_input_0) 100)"
            , "(<= (djex_nat_monus djex_length_input_0 1) 100)"
            , "(<= (djex_nat_min djex_length_input_0 2) 100)"
            , "(<= (djex_nat_max djex_length_input_0 3) 100)"
            , "(<= (ite (<= djex_length_input_0 4) \
                \djex_length_input_0 1) 100)"
            , "(= djex_length_input_0 5)"
            , "(not (= djex_length_input_0 6))"
            ]
      mapM_ (\fragment -> assertBool
          ("missing translated fragment: " ++ fragment)
          $ fragment `isInfixOf` script)
        expectedFragments
      evidence <- expectCounterexample
        $ SMTLib.validateLengthSMTLibCounterexample
            Evaluate.defaultLengthEvaluationLimits query
            [smtIntegerBinding (asciiBytes "djex_length_input_0") 5]
      _ <- expectRight $ Djex.replayBehavioralEvidence
        (LengthProblem.checkedLengthProblemBehavioralProblem problem) evidence
      pure ()
  , testCase "replay a decoded identity model without manufacturing evidence" $ do
      (session, contract, candidate) <- realListIdentityFixture
        $ TypeVariable $ FlexibleVariable 0
      problem <- expectRight $ LengthProblem.sealLengthTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract candidate
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      case SMTLib.lengthSMTLibQueryInputSymbols query of
        [symbol] -> expectNoCounterexample
          $ SMTLib.validateLengthSMTLibCounterexample
              Evaluate.defaultLengthEvaluationLimits query
              [smtIntegerBinding symbol 8]
        symbols -> assertFailure $ "unexpected input symbols: " ++ show symbols
  , testCase "reject malformed decoded models before independent replay" $ do
      unaryProblem <- adversarialConstantZeroProblem identityLengthContract
      unaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits unaryProblem
      binaryProblem <- adversarialBinaryConstantZeroProblem
        identityLengthContract
      binaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits binaryProblem
      case ( SMTLib.lengthSMTLibQueryInputSymbols unaryQuery
           , SMTLib.lengthSMTLibQueryInputSymbols binaryQuery
           ) of
        ([unary], [first, _]) -> do
          let validateUnary = SMTLib.validateLengthSMTLibCounterexample
                Evaluate.defaultLengthEvaluationLimits unaryQuery
              unknown = asciiBytes "djex.input.999"
          assertLeft (SMTLib.LengthSMTLibBindingArityMismatch 1 0)
            $ validateUnary []
          assertLeft (SMTLib.LengthSMTLibBindingArityMismatch 1 2)
            $ validateUnary
                [smtIntegerBinding unary 1, smtIntegerBinding unary 2]
          assertLeft (SMTLib.LengthSMTLibUnknownInputSymbol 0 unknown)
            $ validateUnary [smtIntegerBinding unknown 1]
          assertLeft (SMTLib.LengthSMTLibNegativeInputValue 0 unary (-1))
            $ validateUnary [smtIntegerBinding unary (-1)]
          assertLeft (SMTLib.LengthSMTLibDuplicateInputSymbol 1 first)
            $ SMTLib.validateLengthSMTLibCounterexample
                Evaluate.defaultLengthEvaluationLimits binaryQuery
                [smtIntegerBinding first 1, smtIntegerBinding first 2]
          assertLeft
            (SMTLib.LengthSMTLibCounterexampleReplayRejected
              $ Evaluate.LengthEvaluationValueBitLimitExceeded
                  (Evaluate.LengthProblemInputValue 0) 2 3)
            $ SMTLib.validateLengthSMTLibCounterexample
                (evaluationLimitsWith 2 8) unaryQuery
                [smtIntegerBinding unary 4]

          let cyclicBindings = smtIntegerBinding unary 1 : cyclicBindings
          cyclicBindingsResult <- evaluateWithin $ validateUnary cyclicBindings
          assertLeft (SMTLib.LengthSMTLibBindingArityMismatch 1 2)
            cyclicBindingsResult

          let cyclicSymbol = fromIntegral (fromEnum 'x') : cyclicSymbol
              symbolLimit = fromIntegral $ length unary
          cyclicSymbolResult <- evaluateWithin $ validateUnary
            [smtIntegerBinding cyclicSymbol 1]
          assertLeft
            (SMTLib.LengthSMTLibBindingSymbolByteLimitExceeded
              0 symbolLimit (symbolLimit + 1))
            cyclicSymbolResult
        symbols -> assertFailure $ "unexpected input symbols: " ++ show symbols
  , testCase "bind query identity to the exact checked problem" $ do
      identityProblem <- adversarialConstantZeroProblem identityLengthContract
      trivialProblem <- adversarialConstantZeroProblem trivialLengthContract
      identityQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits identityProblem
      trivialQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits trivialProblem
      assertBool "distinct checked problems shared one SMT-LIB query identity" $
        SMTLib.lengthSMTLibQueryFingerprint identityQuery /=
          SMTLib.lengthSMTLibQueryFingerprint trivialQuery
  , testCase "associate and replay every bounded raw solver status exactly" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      satisfiableArtifact <- smtRawArtifact [0x73, 0x61, 0x74] [1]
      unsatisfiableArtifact <- smtRawArtifact [0x75, 0x6e, 0x73, 0x61, 0x74] [2]
      unknownArtifact <- smtRawArtifact [0x75, 0x6e, 0x6b] [3]
      let observations ::
            [ SMTLibObservation.LengthSMTLibRawSolverObservation () () () ]
          observations =
            [ Observation.SatisfiableObservation satisfiableArtifact
            , Observation.UnsatisfiableObservation unsatisfiableArtifact
            , Observation.UnknownObservation unknownArtifact
            ]
          associated = map
            (SMTLibObservation.associateLengthSMTLibSolverObservation query)
            observations
          poisonObservation ::
            SMTLibObservation.LengthSMTLibRawSolverObservation () () ()
          poisonObservation = Observation.SatisfiableObservation
            (error "status projection forced a raw artifact")
          poisonAssociated =
            SMTLibObservation.associateLengthSMTLibSolverObservation
              query poisonObservation
      map SMTLibObservation.associatedLengthSMTLibQueryFingerprint associated
        @?= replicate 3 (SMTLib.lengthSMTLibQueryFingerprint query)
      map SMTLibObservation.associatedLengthSMTLibSolverStatus associated @?=
        [ Observation.SolverSatisfiable
        , Observation.SolverUnsatisfiable
        , Observation.SolverUnknown
        ]
      map SMTLibObservation.associatedLengthSMTLibResultStrength associated @?=
        [ SemanticProblem.RawSolverModelHint
        , SemanticProblem.RawSolverUnsatRelativeToEncoding
        , SemanticProblem.RawSolverUnknown
        ]
      map SMTLibObservation.associatedLengthSMTLibUse associated @?=
        replicate 3 SemanticProblem.HeuristicRankingOnly
      SMTLibObservation.associatedLengthSMTLibSolverStatus poisonAssociated
        @?= Observation.SolverSatisfiable
      SMTLibObservation.associatedLengthSMTLibResultStrength poisonAssociated
        @?= SemanticProblem.RawSolverModelHint
      SMTLibObservation.associatedLengthSMTLibUse poisonAssociated
        @?= SemanticProblem.HeuristicRankingOnly
      map
          (SMTLibObservation.replayAssociatedLengthSMTLibSolverObservation query)
          associated
        @?= map Right observations
  , testCase "wrap a stale checked problem mismatch before revealing raw bytes" $ do
      originalProblem <- adversarialConstantZeroProblem identityLengthContract
      staleProblem <- adversarialConstantZeroProblem trivialLengthContract
      originalQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits originalProblem
      staleQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits staleProblem
      artifact <- smtRawArtifact [0x75, 0x6e, 0x6b] [0]
      let observation ::
            SMTLibObservation.LengthSMTLibRawSolverObservation () () ()
          observation = Observation.UnknownObservation artifact
          associated =
            SMTLibObservation.associateLengthSMTLibSolverObservation
              originalQuery observation
      SMTLibObservation.replayAssociatedLengthSMTLibSolverObservation
          staleQuery associated @?=
        Left
          (SMTLibObservation.LengthSMTLibObservationProblemMismatch
            SemanticProblem.ReplayEncodingFingerprintMismatch)
  , testCase "parse exact statuses and classify standard solver failures" $ do
      let parse = SMTLibResponse.parseLengthSMTLibCheckResponse
            SMTLibResponse.defaultLengthSMTLibResponseLimits . asciiBytes
      parse "sat" @?= Right Observation.SolverSatisfiable
      parse "\t; before status\r\nunsat ; after status" @?=
        Right Observation.SolverUnsatisfiable
      parse "unknown\n" @?= Right Observation.SolverUnknown
      parse "unsupported" @?=
        Left SMTLibResponse.LengthSMTLibUnsupportedResponse
      parse "(error \"bad \"\"model\"\"\\path\")" @?=
        Left (SMTLibResponse.LengthSMTLibSolverErrorResponse
          $ asciiBytes "bad \"model\"\\path")
      parse "success" @?=
        Left SMTLibResponse.LengthSMTLibSuccessWhereStatusExpected
      parse "satjunk" @?=
        Left SMTLibResponse.LengthSMTLibUnexpectedCheckResponse
      parse "|sat|" @?=
        Left SMTLibResponse.LengthSMTLibUnexpectedCheckResponse
      parse "(sat)" @?=
        Left SMTLibResponse.LengthSMTLibUnexpectedCheckResponse
      parse "sat unsat" @?=
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibTrailingExpression 4)
  , testCase "decode unordered quoted input valuations in query order" $ do
      problem <- adversarialBinaryConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      case SMTLib.lengthSMTLibQueryInputSymbols query of
        [first, second] -> do
          bindings <- expectRight
            $ SMTLibResponse.parseLengthSMTLibInputValueResponse
                SMTLibResponse.defaultLengthSMTLibResponseLimits query
                $ asciiBytes
                  "((|djex_length_input_1| 7)\n\
                  \ (djex_length_input_0 3))"
          bindings @?=
            [smtIntegerBinding first 3, smtIntegerBinding second 7]
          evidence <- expectCounterexample
            $ SMTLib.validateLengthSMTLibCounterexample
                Evaluate.defaultLengthEvaluationLimits query bindings
          receipt <- expectRight $ Djex.replayBehavioralEvidence
            (LengthProblem.checkedLengthProblemBehavioralProblem problem)
            evidence
          Evaluate.validatedLengthCounterexampleInputs receipt @?= [3, 7]
          Evaluate.validatedLengthCounterexampleResult receipt @?= 0
        symbols -> assertFailure $ "unexpected input symbols: " ++ show symbols
  , testCase "parse standard negative integers but leave naturals to replay" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      case SMTLib.lengthSMTLibQueryInputSymbols query of
        [symbol] -> do
          bindings <- expectRight
            $ SMTLibResponse.parseLengthSMTLibInputValueResponse
                SMTLibResponse.defaultLengthSMTLibResponseLimits query
                $ asciiBytes "((djex_length_input_0 (- 3)))"
          bindings @?= [smtIntegerBinding symbol (-3)]
          assertLeft
            (SMTLib.LengthSMTLibNegativeInputValue 0 symbol (-3))
            $ SMTLib.validateLengthSMTLibCounterexample
                Evaluate.defaultLengthEvaluationLimits query bindings
          assertLeft (SMTLibResponse.LengthSMTLibNegativeZeroIntegerValue 0)
            $ SMTLibResponse.parseLengthSMTLibInputValueResponse
                SMTLibResponse.defaultLengthSMTLibResponseLimits query
                $ asciiBytes "((djex_length_input_0 (- 0)))"
        symbols -> assertFailure $ "unexpected input symbols: " ++ show symbols
  , testCase "reject malformed valuation shapes and sorts deterministically" $ do
      unaryProblem <- adversarialConstantZeroProblem identityLengthContract
      unaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits unaryProblem
      binaryProblem <- adversarialBinaryConstantZeroProblem
        identityLengthContract
      binaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits binaryProblem
      let parseUnary = SMTLibResponse.parseLengthSMTLibInputValueResponse
            SMTLibResponse.defaultLengthSMTLibResponseLimits unaryQuery
            . asciiBytes
          parseBinary = SMTLibResponse.parseLengthSMTLibInputValueResponse
            SMTLibResponse.defaultLengthSMTLibResponseLimits binaryQuery
            . asciiBytes
          unknown = asciiBytes "djex_length_input_9"
          first = asciiBytes "djex_length_input_0"
      parseUnary "()" @?= Left
        (SMTLibResponse.LengthSMTLibInputValueArityMismatch 1 0)
      parseUnary "((djex_length_input_0 1) (djex_length_input_0 2))" @?=
        Left (SMTLibResponse.LengthSMTLibInputValueArityMismatch 1 2)
      parseUnary "(djex_length_input_0)" @?=
        Left (SMTLibResponse.LengthSMTLibValuationPairExpected 0)
      parseUnary "((djex_length_input_0))" @?=
        Left (SMTLibResponse.LengthSMTLibValuationPairArityMismatch 0 1)
      parseUnary "(((djex_length_input_0) 1))" @?=
        Left (SMTLibResponse.LengthSMTLibValuationTermNotSymbol 0)
      parseUnary "((djex_length_input_9 1))" @?=
        Left (SMTLibResponse.LengthSMTLibUnknownValuationSymbol 0 unknown)
      parseBinary
          "((djex_length_input_0 1) (djex_length_input_0 2))" @?=
        Left (SMTLibResponse.LengthSMTLibDuplicateValuationSymbol 1 first)
      map parseUnary
          [ "((djex_length_input_0 1.0))"
          , "((djex_length_input_0 #x01))"
          , "((djex_length_input_0 #b01))"
          , "((djex_length_input_0 (+ 1)))"
          , "((djex_length_input_0 \"1\"))"
          , "((djex_length_input_0 :reason))"
          , "((djex_length_input_0 :56))"
          , "((djex_length_input_0 let))"
          ] @?= replicate 8
            (Left $ SMTLibResponse.LengthSMTLibValuationValueNotInteger 0)
      case parseUnary "((djex_length_input_0 01))" of
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
            (SMTLibResponse.SMTLibInvalidBareToken _ token)) ->
          token @?= asciiBytes "01"
        other -> assertFailure $ "unexpected leading-zero result: " ++ show other
      parseUnary "unsupported" @?=
        Left SMTLibResponse.LengthSMTLibUnsupportedResponse
      parseUnary "(error \"no model\")" @?=
        Left (SMTLibResponse.LengthSMTLibSolverErrorResponse
          $ asciiBytes "no model")
  , testCase "keep quoted-symbol comments local and reject forbidden escapes" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      let parse = SMTLibResponse.parseLengthSMTLibInputValueResponse
            SMTLibResponse.defaultLengthSMTLibResponseLimits query
          quotedUnknown = asciiBytes "djex_length_input_0;not-a-comment"
      parse (asciiBytes "((|djex_length_input_0;not-a-comment| 1))") @?=
        Left
          (SMTLibResponse.LengthSMTLibUnknownValuationSymbol 0 quotedUnknown)
      case parse (asciiBytes "((|djex_length\\input| 1))") of
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
            (SMTLibResponse.SMTLibInvalidQuotedSymbolByte _ byte)) ->
          byte @?= fromIntegral (fromEnum '\\')
        other -> assertFailure $ "unexpected quoted-symbol result: " ++ show other
  , testCase "reject incomplete syntax and retain opaque non-ASCII text" $ do
      let parse = SMTLibResponse.parseLengthSMTLibCheckResponse
            SMTLibResponse.defaultLengthSMTLibResponseLimits
          syntax expected bytes = parse bytes @?=
            Left (SMTLibResponse.LengthSMTLibResponseSyntaxError expected)
      syntax SMTLibResponse.SMTLibEmptyResponse []
      syntax (SMTLibResponse.SMTLibUnexpectedClosingParenthesis 0)
        $ asciiBytes ")"
      syntax (SMTLibResponse.SMTLibUnterminatedList 0)
        $ asciiBytes "(sat"
      syntax (SMTLibResponse.SMTLibUnterminatedString 7)
        $ asciiBytes "(error \"unfinished"
      syntax (SMTLibResponse.SMTLibUnterminatedQuotedSymbol 0)
        $ asciiBytes "|unfinished"
      syntax (SMTLibResponse.SMTLibInvalidStringByte 8 0)
        $ asciiBytes "(error \"" ++ [0] ++ asciiBytes "\")"
      parse (asciiBytes "(error \"" ++ [0x80, 0xff] ++ asciiBytes "\")") @?=
        Left (SMTLibResponse.LengthSMTLibSolverErrorResponse [0x80, 0xff])

      stringLimit <- expectRight
        $ SMTLibResponse.mkLengthSMTLibResponseLimits
            SMTLibResponse.defaultLengthSMTLibResponseLimitSource
              { SMTLibResponse.lengthSMTLibResponseLimitSourceTokenBytes = 2 }
      SMTLibResponse.parseLengthSMTLibCheckResponse stringLimit
          (asciiBytes "\"abc\"") @?=
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibTokenByteLimitExceeded
              SMTLibResponse.SMTLibStringToken 2 3)
      SMTLibResponse.parseLengthSMTLibCheckResponse stringLimit
          (asciiBytes "|abc|") @?=
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibTokenByteLimitExceeded
              SMTLibResponse.SMTLibQuotedSymbolToken 2 3)
  , testCase "enforce every response resource bound productively" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      let limits change = expectRight $ SMTLibResponse.mkLengthSMTLibResponseLimits
            $ change SMTLibResponse.defaultLengthSMTLibResponseLimitSource
          parseWith configured =
            SMTLibResponse.parseLengthSMTLibInputValueResponse configured query
      noBytes <- limits $ \source -> source
        { SMTLibResponse.lengthSMTLibResponseLimitSourceBytes = 0 }
      parseWith noBytes (asciiBytes "(") @?=
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibResponseByteLimitExceeded 0 1)
      oneDepth <- limits $ \source -> source
        { SMTLibResponse.lengthSMTLibResponseLimitSourceNestingDepth = 1 }
      parseWith oneDepth (asciiBytes "(())") @?=
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibNestingDepthLimitExceeded 1 2)
      twoNodes <- limits $ \source -> source
        { SMTLibResponse.lengthSMTLibResponseLimitSourceNodes = 2 }
      parseWith twoNodes (asciiBytes "((djex_length_input_0 1))") @?=
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibNodeLimitExceeded 2 3)
      twoTokenBytes <- limits $ \source -> source
        { SMTLibResponse.lengthSMTLibResponseLimitSourceTokenBytes = 2 }
      parseWith twoTokenBytes (asciiBytes "((djex_length_input_0 1))") @?=
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibTokenByteLimitExceeded
              SMTLibResponse.SMTLibBareToken 2 3)
      twoIntegerBits <- limits $ \source -> source
        { SMTLibResponse.lengthSMTLibResponseLimitSourceIntegerBits = 2 }
      parseWith twoIntegerBits
          (asciiBytes "((djex_length_input_0 4))") @?=
        Left (SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibNumeralBitLimitExceeded 2 3)

      threeBytes <- limits $ \source -> source
        { SMTLibResponse.lengthSMTLibResponseLimitSourceBytes = 3 }
      let cyclicStatus = asciiBytes "sat" ++ cyclicStatus
      cyclicResult <- evaluateWithin
        $ SMTLibResponse.parseLengthSMTLibCheckResponse
            threeBytes cyclicStatus
      assertLeft
        (SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibResponseByteLimitExceeded 3 4)
        cyclicResult
  , testCase "refuse unsolicited values for a zero-input query" $ do
      let result = Length.LengthVariable Length.LengthResult
          source = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral 1
      problem <- adversarialZeroInputProblem source
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      let cyclicBytes = fromIntegral (fromEnum '(') : cyclicBytes
      observed <- evaluateWithin
        $ SMTLibResponse.parseLengthSMTLibInputValueResponse
            SMTLibResponse.defaultLengthSMTLibResponseLimits query cyclicBytes
      observed @?= Left SMTLibResponse.LengthSMTLibInputValueResponseNotExpected
  , testCase "publish validated conservative response defaults" $ do
      SMTLibResponse.lengthSMTLibResponseSchemaTag @?=
        asciiBytes "djex-length-z3-smtlib2-response/v1"
      SMTLibResponse.mkLengthSMTLibResponseLimits
          SMTLibResponse.defaultLengthSMTLibResponseLimitSource @?=
        Right SMTLibResponse.defaultLengthSMTLibResponseLimits
      let limits = SMTLibResponse.defaultLengthSMTLibResponseLimits
      SMTLibResponse.lengthSMTLibResponseByteLimit limits @?= 65536
      SMTLibResponse.lengthSMTLibResponseNestingDepthLimit limits @?= 64
      SMTLibResponse.lengthSMTLibResponseNodeLimit limits @?= 4096
      SMTLibResponse.lengthSMTLibResponseTokenByteLimit limits @?= 4096
      SMTLibResponse.lengthSMTLibResponseIntegerBitLimit limits @?= 4096
      let legacyShow =
            "LengthSMTLibResponseLimits 65536 64 4096 4096 4096 " ++
            "(SMTLibResponseLimits 65536 64 4096 4096 4096)"
      show limits @?= legacyShow
      showsPrec 11 limits "" @?= "(" ++ legacyShow ++ ")"

      let customSource = SMTLibResponse.LengthSMTLibResponseLimitSource
            { SMTLibResponse.lengthSMTLibResponseLimitSourceBytes = 17
            , SMTLibResponse.lengthSMTLibResponseLimitSourceNestingDepth = 3
            , SMTLibResponse.lengthSMTLibResponseLimitSourceNodes = 19
            , SMTLibResponse.lengthSMTLibResponseLimitSourceTokenBytes = 23
            , SMTLibResponse.lengthSMTLibResponseLimitSourceIntegerBits = 29
            }
          largerSource = customSource
            { SMTLibResponse.lengthSMTLibResponseLimitSourceIntegerBits = 31 }
      custom <- expectRight
        $ SMTLibResponse.mkLengthSMTLibResponseLimits customSource
      larger <- expectRight
        $ SMTLibResponse.mkLengthSMTLibResponseLimits largerSource
      ( SMTLibResponse.lengthSMTLibResponseByteLimit custom
        , SMTLibResponse.lengthSMTLibResponseNestingDepthLimit custom
        , SMTLibResponse.lengthSMTLibResponseNodeLimit custom
        , SMTLibResponse.lengthSMTLibResponseTokenByteLimit custom
        , SMTLibResponse.lengthSMTLibResponseIntegerBitLimit custom
        ) @?= (17, 3, 19, 23, 29)
      SMTLibResponse.mkLengthSMTLibResponseLimits customSource @?= Right custom
      compare custom larger @?= compare customSource largerSource

      assertLeft
        (SMTLibResponse.NegativeLengthSMTLibResponseLimit
          SMTLibResponse.LengthSMTLibResponseNestingDepth (-1))
        $ SMTLibResponse.mkLengthSMTLibResponseLimits
            SMTLibResponse.defaultLengthSMTLibResponseLimitSource
              { SMTLibResponse.lengthSMTLibResponseLimitSourceNestingDepth = -1 }
      assertLeft
        (SMTLibResponse.NegativeLengthSMTLibResponseLimit
          SMTLibResponse.LengthSMTLibResponseIntegerBits (-1))
        $ SMTLibResponse.mkLengthSMTLibResponseLimits
            SMTLibResponse.defaultLengthSMTLibResponseLimitSource
              { SMTLibResponse.lengthSMTLibResponseLimitSourceIntegerBits = -1 }

      let poisonNaturalFields = SMTLibResponse.LengthSMTLibResponseLimitSource
            { SMTLibResponse.lengthSMTLibResponseLimitSourceBytes =
                error "response-byte-demand"
            , SMTLibResponse.lengthSMTLibResponseLimitSourceNestingDepth = -1
            , SMTLibResponse.lengthSMTLibResponseLimitSourceNodes =
                error "response-node-demand"
            , SMTLibResponse.lengthSMTLibResponseLimitSourceTokenBytes =
                error "response-token-demand"
            , SMTLibResponse.lengthSMTLibResponseLimitSourceIntegerBits =
                error "response-integer-demand"
            }
      assertLeft
        (SMTLibResponse.NegativeLengthSMTLibResponseLimit
          SMTLibResponse.LengthSMTLibResponseNestingDepth (-1))
        $ SMTLibResponse.mkLengthSMTLibResponseLimits poisonNaturalFields
      assertLeft
        (SMTLibResponse.NegativeLengthSMTLibResponseLimit
          SMTLibResponse.LengthSMTLibResponseIntegerBits (-1))
        $ SMTLibResponse.mkLengthSMTLibResponseLimits
            poisonNaturalFields
              { SMTLibResponse.lengthSMTLibResponseLimitSourceNestingDepth = 0
              , SMTLibResponse.lengthSMTLibResponseLimitSourceIntegerBits = -1
              }

      let poisonSuccessfulSource = customSource
            { SMTLibResponse.lengthSMTLibResponseLimitSourceNodes =
                error "response-node-demand"
            }
          poisonSuccessful = SMTLibResponse.mkLengthSMTLibResponseLimits
            poisonSuccessfulSource
      case poisonSuccessful of
        Left failure -> assertFailure
          $ "poisoned admitted limits were unexpectedly rejected: " ++
            show failure
        Right _ -> pure ()
      attempted <- try $ evaluate $ case poisonSuccessful of
        Left _ -> 0
        Right admitted -> SMTLibResponse.lengthSMTLibResponseByteLimit admitted
      case attempted :: Either SomeException Natural of
        Left failure -> assertBool
          "forcing admitted response limits did not force the shared policy"
          $ "response-node-demand" `isInfixOf` displayException failure
        Right _ -> assertFailure
          "forcing admitted response limits left a poisoned shared field lazy"
  , testCase "validate declaration and emission bounds productively" $ do
      SMTLib.mkLengthSMTLibLimits SMTLib.defaultLengthSMTLibLimitSource @?=
        Right SMTLib.defaultLengthSMTLibLimits
      SMTLib.lengthSMTLibCommandByteLimit SMTLib.defaultLengthSMTLibLimits
        @?= 65536
      SMTLib.lengthSMTLibFingerprintByteLimit
          SMTLib.defaultLengthSMTLibLimits @?= 262144
      SMTLib.lengthSMTLibNumeralBitLimit SMTLib.defaultLengthSMTLibLimits
        @?= 4096
      [ minBound .. maxBound :: SMTLib.LengthSMTLibNumeralSite ] @?=
        [ SMTLib.LengthSMTLibLiteralNumeral
        , SMTLib.LengthSMTLibScaleNumeral
        , SMTLib.LengthSMTLibModuloDivisorNumeral
        , SMTLib.LengthSMTLibQuotientDivisorNumeral
        ]
      assertLeft
        (SMTLib.NegativeLengthSMTLibLimit
          SMTLib.LengthSMTLibNumeralBits (-1))
        $ SMTLib.mkLengthSMTLibLimits
            SMTLib.defaultLengthSMTLibLimitSource
              { SMTLib.lengthSMTLibLimitSourceNumeralBits = -1 }

      problem <- adversarialConstantZeroProblem identityLengthContract
      noCommand <- expectRight $ SMTLib.mkLengthSMTLibLimits
        SMTLib.defaultLengthSMTLibLimitSource
          { SMTLib.lengthSMTLibLimitSourceCommandBytes = 0 }
      assertLeft
        (SMTLib.LengthSMTLibCommandByteLimitExceeded
          SMTLib.LengthSMTLibCheckCommand 0 1)
        $ SMTLib.sealLengthSMTLibQuery noCommand problem

      noFingerprint <- expectRight $ SMTLib.mkLengthSMTLibLimits
        SMTLib.defaultLengthSMTLibLimitSource
          { SMTLib.lengthSMTLibLimitSourceFingerprintBytes = 0 }
      assertLeft (SMTLib.LengthSMTLibFingerprintByteLimitExceeded 0 1)
        $ SMTLib.sealLengthSMTLibQuery noFingerprint problem

      scaledProblem <- adversarialScaledProviderProblem 2
        identityLengthContract
      oneBitNumerals <- expectRight $ SMTLib.mkLengthSMTLibLimits
        SMTLib.defaultLengthSMTLibLimitSource
          { SMTLib.lengthSMTLibLimitSourceNumeralBits = 1 }
      assertLeft
        (SMTLib.LengthSMTLibNumeralBitLimitExceeded
          SMTLib.LengthSMTLibScaleNumeral 1 2)
        $ SMTLib.sealLengthSMTLibQuery oneBitNumerals scaledProblem

      moduloProblem <- adversarialConstantZeroProblem $ contractWith
        (Length.LengthTruth True)
        (Length.LengthEqual
          (Length.LengthVariable Length.LengthResult)
          (Length.LengthModulo 2
            $ Length.LengthVariable $ Length.LengthInput 0))
      assertLeft
        (SMTLib.LengthSMTLibNumeralBitLimitExceeded
          SMTLib.LengthSMTLibModuloDivisorNumeral 1 2)
        $ SMTLib.sealLengthSMTLibQuery oneBitNumerals moduloProblem

      quotientProblem <- adversarialConstantZeroProblem $ contractWith
        (Length.LengthTruth True)
        (Length.LengthEqual
          (Length.LengthVariable Length.LengthResult)
          (Length.LengthQuotient 2
            $ Length.LengthVariable $ Length.LengthInput 0))
      assertLeft
        (SMTLib.LengthSMTLibNumeralBitLimitExceeded
          SMTLib.LengthSMTLibQuotientDivisorNumeral 1 2)
        $ SMTLib.sealLengthSMTLibQuery oneBitNumerals quotientProblem
  ]

smtLibProtocolTests :: TestTree
smtLibProtocolTests = testGroup
  "package-private bounded Length SMT-LIB protocol"
  [ testCase "derive one canonical echo command from its exact response" $ do
      sentinel <- protocolSentinel protocolCheckNonce
      let content = concat
            [ "djex-smtlib-frame/v1/"
            , "000102030405060708090a0b0c0d0e0f"
            , "101112131415161718191a1b1c1d1e1f"
            ]
      SMTLibStream.smtLibEchoSentinelResponseBytes sentinel @?=
        asciiBytes ('"' : content ++ "\"")
      SMTLibStream.smtLibEchoSentinelCommandBytes sentinel @?=
        asciiBytes ("(echo \"" ++ content ++ "\")\n")
  , testCase "seal exact initial and conditional value writes" $ do
      (query, plan) <- protocolUnaryPlan
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      checkBarrier <- protocolSentinel protocolCheckNonce
      valueBarrier <- protocolSentinel protocolValueNonce
      let expectedInitial =
            InternalSMTLibExecution.lengthSMTLibExecutionQueryResetBytes ++
            SMTLib.lengthSMTLibQueryCheckBytes query ++
            SMTLibStream.smtLibEchoSentinelCommandBytes checkBarrier
          expectedValue =
            fmap (++ SMTLibStream.smtLibEchoSentinelCommandBytes valueBarrier)
              $ SMTLib.lengthSMTLibQueryInputValueRequestBytes query
      SMTLibProtocol.lengthSMTLibProtocolInitialWriteBytes plan @?=
        expectedInitial
      SMTLibProtocol.lengthSMTLibProtocolInputValueWriteBytes plan @?=
        expectedValue
      SMTLib.lengthSMTLibQueryFingerprint
          (SMTLibProtocol.lengthSMTLibProtocolPlanQuery plan) @?=
        SMTLib.lengthSMTLibQueryFingerprint query
      SMTLibProtocol.lengthSMTLibProtocolPlanArtifactPolicy plan @?=
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      -- This digest is only a regression snapshot of the collision-free
      -- canonical bytes. It is not used as protocol identity or authority.
      -- The retained execution policy includes the exact executable path,
      -- so the two platform-specific absolute fixture paths have distinct
      -- snapshots even though their SMT-LIB wire bytes are identical.
      SHA256.hash
          (BS.pack
            $ InternalFingerprint.fingerprintCanonicalBytes
            $ SMTLibProtocol.lengthSMTLibProtocolPlanFingerprint plan) @?=
        BS.pack (if SystemInfo.os == "mingw32"
          then
            [ 111, 201, 71, 253, 24, 184, 101, 237
            , 221, 115, 138, 60, 208, 125, 174, 135
            , 65, 123, 99, 186, 143, 242, 58, 176
            , 159, 168, 13, 25, 116, 14, 194, 144
            ]
          else
            [ 184, 6, 142, 55, 253, 114, 15, 174
            , 57, 52, 196, 159, 68, 202, 30, 249
            , 187, 57, 62, 212, 139, 254, 69, 52
            , 48, 42, 15, 218, 134, 243, 136, 234
            ])
      checkReceiver <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInitialQueryWrite
        expectedInitial
        $ SMTLibProtocol.startLengthSMTLibProtocol plan
      SMTLibProtocol.lengthSMTLibProtocolReceiverPhase checkReceiver @?=
        SMTLibProtocol.LengthSMTLibProtocolCheckStatusPhase
      checkAction <- feedProtocolChunks checkReceiver
        $ map (: [])
        $ asciiBytes "sat\n" ++
          SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier ++
          asciiBytes "\n"
      valueReceiver <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInputValueWrite
        (fromMaybe [] expectedValue) checkAction
      SMTLibProtocol.lengthSMTLibProtocolReceiverPhase valueReceiver @?=
        SMTLibProtocol.LengthSMTLibProtocolInputValuePhase
      let rawValues = protocolValueFrame query [3]
      valueAction <- feedProtocolChunks valueReceiver
        $ map (: [])
        $ rawValues ++ asciiBytes "\n" ++
          SMTLibStream.smtLibEchoSentinelResponseBytes valueBarrier ++
          asciiBytes "\n"
      decoded <- expectProtocolComplete valueAction
      SMTLibProtocol.lengthSMTLibProtocolDecodedObservation decoded @?=
        Observation.SatisfiableObservation
          (Just [smtIntegerBinding (asciiBytes "djex_length_input_0") 3])
  , testCase
      "preserve exact scalar wire bytes behind a nominal product plan" $ do
      (scalarQuery, pairQuery) <- liveWireTwinQueries
      execution <- protocolExecutionConfig
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      scalarPlan <- expectRight $ SMTLibProtocol.sealLengthSMTLibProtocolPlan
        SMTLibProtocol.defaultLengthSMTLibProtocolLimits
        execution scalarQuery protocolCheckNonce $ Just protocolValueNonce
      pairPlan <- expectRight
        $ SMTLibSpinePairProtocol.sealLengthSpinePairSMTLibProtocolPlan
            SMTLibSpinePairProtocol.defaultLengthSpinePairSMTLibProtocolLimits
            execution pairQuery protocolCheckNonce $ Just protocolValueNonce

      SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolPlanSchemaTag @?=
        asciiBytes "djex-length-spine-pair-z3-smtlib2-protocol-plan/v1"
      SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolPhaseMachineSchemaTag
        @?= asciiBytes
          "djex-length-spine-pair-z3-smtlib2-protocol-phase-machine/v1"
      SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolPostBarrierSchemaTag
        @?= SMTLibProtocol.lengthSMTLibProtocolPostBarrierSchemaTag
      SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolInitialWriteBytes
          pairPlan @?=
        SMTLibProtocol.lengthSMTLibProtocolInitialWriteBytes scalarPlan
      SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolInputValueWriteBytes
          pairPlan @?=
        SMTLibProtocol.lengthSMTLibProtocolInputValueWriteBytes scalarPlan
      SMTLib.lengthSpinePairSMTLibQueryFingerprint
          (SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolPlanQuery
            pairPlan) @?=
        SMTLib.lengthSpinePairSMTLibQueryFingerprint pairQuery
      SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolPlanArtifactPolicy
          pairPlan @?=
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      let scalarIdentity = InternalFingerprint.fingerprintCanonicalBytes
            $ SMTLibProtocol.lengthSMTLibProtocolPlanFingerprint scalarPlan
          pairIdentity = InternalFingerprint.fingerprintCanonicalBytes
            $ SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolPlanFingerprint
                pairPlan
      assertBool "wire-identical scalar and pair plans shared nominal identity"
        $ scalarIdentity /= pairIdentity
      assertBool "the product protocol schema was absent from its identity"
        $ SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolPlanSchemaTag
            `isInfixOf` pairIdentity

      checkBarrier <- protocolSentinel protocolCheckNonce
      valueBarrier <- protocolSentinel protocolValueNonce
      checkReceiver <- expectSpinePairProtocolWrite
        SMTLibSpinePairProtocol.LengthSMTLibProtocolInitialQueryWrite
        (SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolInitialWriteBytes
          pairPlan)
        $ SMTLibSpinePairProtocol.startLengthSpinePairSMTLibProtocol pairPlan
      valueAction <- expectRight
        $ SMTLibSpinePairProtocol.feedLengthSpinePairSMTLibProtocol
            checkReceiver
        $ asciiBytes "sat\n" ++
          SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier ++
          asciiBytes "\n"
      valueReceiver <- expectSpinePairProtocolWrite
        SMTLibSpinePairProtocol.LengthSMTLibProtocolInputValueWrite
        (fromMaybe []
          $ SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolInputValueWriteBytes
              pairPlan)
        valueAction
      decoded <- expectSpinePairProtocolComplete =<< expectRight
        (SMTLibSpinePairProtocol.feedLengthSpinePairSMTLibProtocol
          valueReceiver
          $ protocolSpinePairValueFrame pairQuery [3] ++
            SMTLibStream.smtLibEchoSentinelResponseBytes valueBarrier ++
            asciiBytes "\n")
      SMTLibSpinePairProtocol.lengthSpinePairSMTLibProtocolDecodedObservation
          decoded @?=
        Observation.SatisfiableObservation
          (Just [smtIntegerBinding (asciiBytes "djex_length_input_0") 3])
  , testCase "publish schemas, validated defaults, and exact admission minima" $ do
      SMTLibProtocol.lengthSMTLibProtocolPlanSchemaTag @?=
        asciiBytes "djex-length-z3-smtlib2-protocol-plan/v1"
      SMTLibProtocol.lengthSMTLibProtocolPhaseMachineSchemaTag @?=
        asciiBytes "djex-length-z3-smtlib2-protocol-phase-machine/v1"
      SMTLibProtocol.lengthSMTLibProtocolPostBarrierSchemaTag @?=
        asciiBytes "djex-smtlib2-post-barrier-whitespace/v1"
      assertBool "validated protocol defaults changed representation"
        $ SMTLibProtocol.mkLengthSMTLibProtocolLimits
            SMTLibProtocol.defaultLengthSMTLibProtocolLimitSource ==
          SMTLibProtocol.defaultLengthSMTLibProtocolLimits
      let defaults = SMTLibProtocol.defaultLengthSMTLibProtocolLimits
          stream = SMTLibProtocol.lengthSMTLibProtocolStreamLimits defaults
      stream @?= SMTLibStream.defaultSMTLibStreamLimits
      SMTLibStream.smtLibStreamTotalByteLimit stream @?= 131072
      SMTLibStream.smtLibStreamFrameByteLimit stream @?= 65536
      SMTLibStream.smtLibStreamNestingDepthLimit stream @?= 64
      SMTLibProtocol.lengthSMTLibProtocolCumulativeStdoutByteLimit defaults
        @?= 524288
      SMTLibProtocol.lengthSMTLibProtocolPlanFingerprintByteLimit defaults
        @?= 262144

      problem <- adversarialConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      execution <- protocolExecutionConfig
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      let seal limits configured =
            SMTLibProtocol.sealLengthSMTLibProtocolPlan limits configured query
              protocolCheckNonce $ Just protocolValueNonce
          protocolLimits change = SMTLibProtocol.mkLengthSMTLibProtocolLimits
            $ change SMTLibProtocol.defaultLengthSMTLibProtocolLimitSource
          streamLimits change = protocolLimits $ \source -> source
            { SMTLibProtocol.lengthSMTLibProtocolLimitSourceStreamLimits =
                change SMTLibStream.defaultSMTLibStreamLimitSource }
          tooSmall site field admitted required =
            SMTLibProtocol.LengthSMTLibProtocolRequiredLimitTooSmall
              site field admitted required
      let nondefaultCumulative = 600000
          nondefaultLimits = protocolLimits $ \source -> source
            { SMTLibProtocol.lengthSMTLibProtocolLimitSourceCumulativeStdoutBytes =
                nondefaultCumulative }
      nondefaultPlan <- expectRight $ seal nondefaultLimits execution
      SMTLibProtocol.lengthSMTLibProtocolPlanCumulativeStdoutByteLimit
          nondefaultPlan @?=
        nondefaultCumulative
      assertLeft
        (tooSmall SMTLibProtocol.LengthSMTLibProtocolCheckStatusFrame
          SMTLibProtocol.LengthSMTLibProtocolStreamTotalBytes 6 7)
        $ seal (streamLimits $ \source -> source
            { SMTLibStream.smtLibStreamLimitSourceTotalBytes = 6 }) execution
      assertLeft
        (tooSmall SMTLibProtocol.LengthSMTLibProtocolCheckStatusFrame
          SMTLibProtocol.LengthSMTLibProtocolStreamFrameBytes 6 7)
        $ seal (streamLimits $ \source -> source
            { SMTLibStream.smtLibStreamLimitSourceFrameBytes = 6 }) execution
      assertLeft
        (tooSmall SMTLibProtocol.LengthSMTLibProtocolCheckBarrierFrame
          SMTLibProtocol.LengthSMTLibProtocolStreamTotalBytes 86 87)
        $ seal (streamLimits $ \source -> source
            { SMTLibStream.smtLibStreamLimitSourceTotalBytes = 86 }) execution
      assertLeft
        (tooSmall SMTLibProtocol.LengthSMTLibProtocolInputValueFrame
          SMTLibProtocol.LengthSMTLibProtocolStreamNestingDepth 1 2)
        $ seal (streamLimits $ \source -> source
            { SMTLibStream.smtLibStreamLimitSourceNestingDepth = 1 }) execution

      let response change = expectRight $ SMTLibResponse.mkLengthSMTLibResponseLimits
            $ change SMTLibResponse.defaultLengthSMTLibResponseLimitSource
          responseCase change expected = do
            configured <- protocolExecutionConfigWithResponse
              InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
              =<< response change
            assertLeft expected $ seal defaults configured
      responseCase
        (\source -> source
          { SMTLibResponse.lengthSMTLibResponseLimitSourceBytes = 6 })
        $ tooSmall SMTLibProtocol.LengthSMTLibProtocolCheckStatusFrame
            SMTLibProtocol.LengthSMTLibProtocolResponseBytes 6 7
      responseCase
        (\source -> source
          { SMTLibResponse.lengthSMTLibResponseLimitSourceNestingDepth = 1 })
        $ tooSmall SMTLibProtocol.LengthSMTLibProtocolInputValueFrame
            SMTLibProtocol.LengthSMTLibProtocolResponseNestingDepth 1 2
      responseCase
        (\source -> source
          { SMTLibResponse.lengthSMTLibResponseLimitSourceNodes = 3 })
        $ tooSmall SMTLibProtocol.LengthSMTLibProtocolInputValueFrame
            SMTLibProtocol.LengthSMTLibProtocolResponseNodes 3 4
      responseCase
        (\source -> source
          { SMTLibResponse.lengthSMTLibResponseLimitSourceTokenBytes = 18 })
        $ tooSmall SMTLibProtocol.LengthSMTLibProtocolInputValueFrame
            SMTLibProtocol.LengthSMTLibProtocolResponseTokenBytes 18 19

      let tooLittleStdout = protocolLimits $ \source -> source
            { SMTLibProtocol.lengthSMTLibProtocolLimitSourceCumulativeStdoutBytes =
                204 }
          noFingerprint = protocolLimits $ \source -> source
            { SMTLibProtocol.lengthSMTLibProtocolLimitSourcePlanFingerprintBytes =
                0 }
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolMinimumStdoutByteLimitExceeded
          204 205)
        $ seal tooLittleStdout execution
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolPlanFingerprintByteLimitExceeded
          0 1)
        $ seal noFingerprint execution
  , testCase "complete every non-value status without a later write" $ do
      checkBarrier <- protocolSentinel protocolCheckNonce
      let marker = SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier
          cases =
            [ ("sat", Observation.SolverSatisfiable)
            , ("unsat", Observation.SolverUnsatisfiable)
            , ("unknown", Observation.SolverUnknown)
            ]
      (_, statusOnly) <- protocolUnaryPlan
        InternalSMTLibExecution.LengthSMTLibStatusOnly
      mapM_ (assertProtocolTerminalStatus statusOnly marker) cases
      (_, values) <- protocolUnaryPlan
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      mapM_ (assertProtocolTerminalStatus values marker)
        [ ("unsat", Observation.SolverUnsatisfiable)
        , ("unknown", Observation.SolverUnknown)
        ]
      (_, zeroInput) <- protocolZeroInputPlan
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      SMTLibProtocol.lengthSMTLibProtocolInputValueWriteBytes zeroInput @?=
        Nothing
      zeroReceiver <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInitialQueryWrite
        (SMTLibProtocol.lengthSMTLibProtocolInitialWriteBytes zeroInput)
        $ SMTLibProtocol.startLengthSMTLibProtocol zeroInput
      zeroAction <- expectRight $ SMTLibProtocol.feedLengthSMTLibProtocol
        zeroReceiver $ asciiBytes "sat\n" ++ marker ++ asciiBytes "\n"
      zeroDecoded <- expectProtocolComplete zeroAction
      SMTLibProtocol.lengthSMTLibProtocolDecodedObservation zeroDecoded @?=
        Observation.SatisfiableObservation (Just [])
      (_, zeroStatusOnly) <- protocolZeroInputPlan
        InternalSMTLibExecution.LengthSMTLibStatusOnly
      assertProtocolTerminalStatus zeroStatusOnly marker
        ("sat", Observation.SolverSatisfiable)
  , testCase "reject absent, surplus, malformed, and repeated barrier nonces" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      values <- protocolExecutionConfig
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      statusOnly <- protocolExecutionConfig
        InternalSMTLibExecution.LengthSMTLibStatusOnly
      let seal execution check value =
            SMTLibProtocol.sealLengthSMTLibProtocolPlan
              SMTLibProtocol.defaultLengthSMTLibProtocolLimits
              execution query check value
      assertLeft SMTLibProtocol.LengthSMTLibProtocolMissingInputValueBarrierNonce
        $ seal values protocolCheckNonce Nothing
      assertLeft SMTLibProtocol.LengthSMTLibProtocolUnexpectedInputValueBarrierNonce
        $ seal statusOnly protocolCheckNonce $ Just protocolValueNonce
      assertLeft SMTLibProtocol.LengthSMTLibProtocolRepeatedBarrierNonce
        $ seal values protocolCheckNonce $ Just protocolCheckNonce
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolBarrierNonceError
          SMTLibProtocol.LengthSMTLibProtocolCheckBarrier
          $ SMTLibStream.SMTLibEchoSentinelNonceLengthMismatch 32 31)
        $ seal values (replicate 31 0) $ Just protocolValueNonce
      let cyclicNonce = 0 : cyclicNonce
      cyclic <- evaluateWithin $ seal values cyclicNonce $ Just protocolValueNonce
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolBarrierNonceError
          SMTLibProtocol.LengthSMTLibProtocolCheckBarrier
          $ SMTLibStream.SMTLibEchoSentinelNonceLengthMismatch 32 33)
        cyclic
  , testCase "fail closed at decoder, framing, barrier, and EOF boundaries" $ do
      (query, plan) <- protocolUnaryPlan
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      checkBarrier <- protocolSentinel protocolCheckNonce
      wrongBarrier <- protocolSentinel protocolValueNonce
      initial <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInitialQueryWrite
        (SMTLibProtocol.lengthSMTLibProtocolInitialWriteBytes plan)
        $ SMTLibProtocol.startLengthSMTLibProtocol plan
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolResponseFailure
          SMTLibProtocol.LengthSMTLibProtocolCheckStatusPhase
          SMTLibResponse.LengthSMTLibSuccessWhereStatusExpected)
        $ SMTLibProtocol.feedLengthSMTLibProtocol initial
        $ asciiBytes "success\n"
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolResponseFailure
          SMTLibProtocol.LengthSMTLibProtocolCheckStatusPhase
          SMTLibResponse.LengthSMTLibSuccessWhereStatusExpected)
        $ SMTLibProtocol.feedLengthSMTLibProtocol initial
        $ asciiBytes "success\n" ++
            error "protocol decoder rejection forced its completed-frame tail"
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolFramingFailure
          SMTLibProtocol.LengthSMTLibProtocolCheckStatusPhase
          $ SMTLibStream.SMTLibStreamUnexpectedClosingParenthesis 0)
        $ SMTLibProtocol.feedLengthSMTLibProtocol initial [41]
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolUnexpectedEOF
          SMTLibProtocol.LengthSMTLibProtocolCheckStatusPhase)
        $ SMTLibProtocol.finishLengthSMTLibProtocol initial
      partial <- expectProtocolAwait =<< expectRight
        (SMTLibProtocol.feedLengthSMTLibProtocol initial $ asciiBytes "sa")
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolFramingFailure
          SMTLibProtocol.LengthSMTLibProtocolCheckStatusPhase
          $ SMTLibStream.SMTLibStreamMissingWhitespaceAfterAtom 2)
        $ SMTLibProtocol.finishLengthSMTLibProtocol partial
      checkPhase <- expectProtocolAwait =<< expectRight
        (SMTLibProtocol.feedLengthSMTLibProtocol initial $ asciiBytes "sat\n")
      SMTLibProtocol.lengthSMTLibProtocolReceiverPhase checkPhase @?=
        SMTLibProtocol.LengthSMTLibProtocolCheckBarrierPhase
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolBarrierMismatch
          SMTLibProtocol.LengthSMTLibProtocolCheckBarrier)
        $ SMTLibProtocol.feedLengthSMTLibProtocol checkPhase
        $ SMTLibStream.smtLibEchoSentinelResponseBytes wrongBarrier ++
          asciiBytes "\n"
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolBarrierMismatch
          SMTLibProtocol.LengthSMTLibProtocolCheckBarrier)
        $ SMTLibProtocol.feedLengthSMTLibProtocol checkPhase
        $ SMTLibStream.smtLibEchoSentinelResponseBytes wrongBarrier ++
            asciiBytes "\n" ++
            error "protocol barrier mismatch forced its completed-frame tail"
      let staleValues = protocolValueFrame query [3]
      case SMTLibProtocol.feedLengthSMTLibProtocol initial $
          asciiBytes "sat\n" ++
          SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier ++
          asciiBytes "\n" ++ staleValues of
        Left (SMTLibProtocol.LengthSMTLibProtocolUnexpectedPostBarrierByte
            _ 40) -> pure ()
        Left other -> assertFailure $ "unexpected stale-frame rejection: " ++
          show other
        Right _ -> assertFailure
          "a valuation buffered before its write capability was accepted"
  , testCase "retain the exact admitted response policy after sealing" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      responseLimits <- expectRight $ SMTLibResponse.mkLengthSMTLibResponseLimits
        SMTLibResponse.defaultLengthSMTLibResponseLimitSource
          { SMTLibResponse.lengthSMTLibResponseLimitSourceTokenBytes = 19 }
      execution <- protocolExecutionConfigWithResponse
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
        responseLimits
      plan <- expectRight $ SMTLibProtocol.sealLengthSMTLibProtocolPlan
        SMTLibProtocol.defaultLengthSMTLibProtocolLimits
        execution query protocolCheckNonce $ Just protocolValueNonce
      checkBarrier <- protocolSentinel protocolCheckNonce
      initial <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInitialQueryWrite
        (SMTLibProtocol.lengthSMTLibProtocolInitialWriteBytes plan)
        $ SMTLibProtocol.startLengthSMTLibProtocol plan
      valueAction <- expectRight $ SMTLibProtocol.feedLengthSMTLibProtocol
        initial $ asciiBytes "sat\n" ++
          SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier ++
          asciiBytes "\n"
      valueReceiver <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInputValueWrite
        (fromMaybe [] $ SMTLibProtocol.lengthSMTLibProtocolInputValueWriteBytes
          plan)
        valueAction
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolResponseFailure
          SMTLibProtocol.LengthSMTLibProtocolInputValuePhase
          $ SMTLibResponse.LengthSMTLibResponseSyntaxError
          $ SMTLibResponse.SMTLibTokenByteLimitExceeded
              SMTLibResponse.SMTLibBareToken 19 20)
        $ SMTLibProtocol.feedLengthSMTLibProtocol valueReceiver
        $ asciiBytes
            "((djex_length_input_0 12345678901234567890))\n"
  , testCase "bind semantic plan inputs but exclude fingerprint admission" $ do
      problem <- adversarialConstantZeroProblem identityLengthContract
      query <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits problem
      binaryProblem <- adversarialBinaryConstantZeroProblem
        identityLengthContract
      binaryQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
        SMTLib.defaultLengthSMTLibLimits binaryProblem
      execution <- protocolExecutionConfig
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      changedExecutionConfig <- expectRight
        $ InternalSMTLibExecution.mkLengthSMTLibExecutionConfig
            InternalSMTLibExecution.defaultLengthSMTLibExecutionLimits
        $ (InternalSMTLibExecution.defaultLengthSMTLibExecutionConfigSource
            absoluteFixtureExecutable Nothing)
            { InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
                1001 }
      let changedExecution =
            InternalSMTLibExecution.retainLengthSMTLibPostLaunchExecutionPolicy
              changedExecutionConfig
      let defaults = SMTLibProtocol.defaultLengthSMTLibProtocolLimits
          source = SMTLibProtocol.defaultLengthSMTLibProtocolLimitSource
          alteredStream = SMTLibProtocol.mkLengthSMTLibProtocolLimits
            $ source
              { SMTLibProtocol.lengthSMTLibProtocolLimitSourceStreamLimits =
                  SMTLibStream.defaultSMTLibStreamLimitSource
                    { SMTLibStream.smtLibStreamLimitSourceTotalBytes = 131071 }
              }
          alteredCumulative = SMTLibProtocol.mkLengthSMTLibProtocolLimits
            $ source
              { SMTLibProtocol.lengthSMTLibProtocolLimitSourceCumulativeStdoutBytes =
                  524287 }
          widerAdmission = SMTLibProtocol.mkLengthSMTLibProtocolLimits
            $ source
              { SMTLibProtocol.lengthSMTLibProtocolLimitSourcePlanFingerprintBytes =
                  524288 }
          seal limits configured selected checkNonce valueNonce = expectRight
            $ SMTLibProtocol.sealLengthSMTLibProtocolPlan limits configured
                selected checkNonce $ Just valueNonce
      baseline <- seal defaults execution query
        protocolCheckNonce protocolValueNonce
      resealed <- seal widerAdmission execution query
        protocolCheckNonce protocolValueNonce
      SMTLibProtocol.lengthSMTLibProtocolPlanFingerprint resealed @?=
        SMTLibProtocol.lengthSMTLibProtocolPlanFingerprint baseline
      changed <- sequence
        [ seal alteredStream execution query
            protocolCheckNonce protocolValueNonce
        , seal alteredCumulative execution query
            protocolCheckNonce protocolValueNonce
        , seal defaults changedExecution query
            protocolCheckNonce protocolValueNonce
        , seal defaults execution binaryQuery
            protocolCheckNonce protocolValueNonce
        , seal defaults execution query [1 .. 32] protocolValueNonce
        , seal defaults execution query protocolCheckNonce [64 .. 95]
        ]
      let baselineFingerprint =
            SMTLibProtocol.lengthSMTLibProtocolPlanFingerprint baseline
          changedFingerprints =
            map SMTLibProtocol.lengthSMTLibProtocolPlanFingerprint changed
          fingerprints = baselineFingerprint : changedFingerprints
      assertBool "a semantic protocol-plan input was absent from identity"
        $ notElem baselineFingerprint changedFingerprints
      assertBool "distinct protocol plans shared a private complete key"
        $ length (nub fingerprints) == length fingerprints
  , testCase "enforce exact cumulative accounting and value-phase barriers" $ do
      (query, defaultPlan) <- protocolUnaryPlan
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      execution <- protocolExecutionConfig
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable
      let exactLimits = SMTLibProtocol.mkLengthSMTLibProtocolLimits
            $ SMTLibProtocol.defaultLengthSMTLibProtocolLimitSource
                { SMTLibProtocol.lengthSMTLibProtocolLimitSourceCumulativeStdoutBytes =
                    205 }
      exactPlan <- expectRight $ SMTLibProtocol.sealLengthSMTLibProtocolPlan
        exactLimits execution query protocolCheckNonce $ Just protocolValueNonce
      checkBarrier <- protocolSentinel protocolCheckNonce
      valueBarrier <- protocolSentinel protocolValueNonce
      let checkTranscript = asciiBytes "sat\n" ++
            SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier ++
            asciiBytes "\n"
          rawValues = protocolValueFrame query [0]
          valueTranscript = rawValues ++
            SMTLibStream.smtLibEchoSentinelResponseBytes valueBarrier ++
            asciiBytes "\n"
          begin plan = expectProtocolWrite
            SMTLibProtocol.LengthSMTLibProtocolInitialQueryWrite
            (SMTLibProtocol.lengthSMTLibProtocolInitialWriteBytes plan)
            $ SMTLibProtocol.startLengthSMTLibProtocol plan
      exactInitial <- begin exactPlan
      exactValueAction <- expectRight
        $ SMTLibProtocol.feedLengthSMTLibProtocol exactInitial checkTranscript
      exactValue <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInputValueWrite
        (fromMaybe [] $ SMTLibProtocol.lengthSMTLibProtocolInputValueWriteBytes
          exactPlan)
        exactValueAction
      exactDecoded <- expectProtocolComplete =<< expectRight
        (SMTLibProtocol.feedLengthSMTLibProtocol exactValue valueTranscript)
      SMTLibProtocol.lengthSMTLibProtocolDecodedObservation exactDecoded @?=
        Observation.SatisfiableObservation
          (Just [smtIntegerBinding (asciiBytes "djex_length_input_0") 0])

      cappedInitial <- begin exactPlan
      cappedPending <- expectProtocolAwait =<< expectRight
        (SMTLibProtocol.feedLengthSMTLibProtocol cappedInitial
          $ replicate 205 32)
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolCumulativeStdoutByteLimitExceeded
          205 206)
        $ SMTLibProtocol.feedLengthSMTLibProtocol cappedPending [32]

      overflowingInitial <- begin exactPlan
      overflowingAction <- expectRight
        $ SMTLibProtocol.feedLengthSMTLibProtocol
            overflowingInitial checkTranscript
      overflowingValue <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInputValueWrite
        (fromMaybe [] $ SMTLibProtocol.lengthSMTLibProtocolInputValueWriteBytes
          exactPlan)
        overflowingAction
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolCumulativeStdoutByteLimitExceeded
          205 206)
        $ SMTLibProtocol.feedLengthSMTLibProtocol overflowingValue
        $ valueTranscript ++ asciiBytes " "
      cyclicInitial <- begin exactPlan
      cyclicAction <- expectRight
        $ SMTLibProtocol.feedLengthSMTLibProtocol cyclicInitial checkTranscript
      cyclicValue <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInputValueWrite
        (fromMaybe [] $ SMTLibProtocol.lengthSMTLibProtocolInputValueWriteBytes
          exactPlan)
        cyclicAction
      let cyclicWhitespace = 32 : cyclicWhitespace
      cyclicOverflow <- evaluateWithin
        $ SMTLibProtocol.feedLengthSMTLibProtocol cyclicValue
        $ rawValues ++
          SMTLibStream.smtLibEchoSentinelResponseBytes valueBarrier ++
          cyclicWhitespace
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolCumulativeStdoutByteLimitExceeded
          205 206)
        cyclicOverflow

      statusExecution <- protocolExecutionConfig
        InternalSMTLibExecution.LengthSMTLibStatusOnly
      let equalCapLimits = SMTLibProtocol.mkLengthSMTLibProtocolLimits
            $ SMTLibProtocol.defaultLengthSMTLibProtocolLimitSource
                { SMTLibProtocol.lengthSMTLibProtocolLimitSourceStreamLimits =
                    SMTLibStream.defaultSMTLibStreamLimitSource
                      { SMTLibStream.smtLibStreamLimitSourceTotalBytes = 87 }
                , SMTLibProtocol.lengthSMTLibProtocolLimitSourceCumulativeStdoutBytes =
                    96
                }
      equalCapPlan <- expectRight $ SMTLibProtocol.sealLengthSMTLibProtocolPlan
        equalCapLimits statusExecution query protocolCheckNonce Nothing
      equalCapInitial <- begin equalCapPlan
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolFramingFailure
          SMTLibProtocol.LengthSMTLibProtocolCheckBarrierPhase
          $ SMTLibStream.SMTLibStreamTotalByteLimitExceeded 87 88)
        $ SMTLibProtocol.feedLengthSMTLibProtocol equalCapInitial
        $ asciiBytes "  unknown\n" ++
          SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier ++
          asciiBytes "\n"

      defaultInitial <- begin defaultPlan
      defaultValueAction <- expectRight
        $ SMTLibProtocol.feedLengthSMTLibProtocol defaultInitial checkTranscript
      defaultValue <- expectProtocolWrite
        SMTLibProtocol.LengthSMTLibProtocolInputValueWrite
        (fromMaybe [] $ SMTLibProtocol.lengthSMTLibProtocolInputValueWriteBytes
          defaultPlan)
        defaultValueAction
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolUnexpectedEOF
          SMTLibProtocol.LengthSMTLibProtocolInputValuePhase)
        $ SMTLibProtocol.finishLengthSMTLibProtocol defaultValue
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolResponseFailure
          SMTLibProtocol.LengthSMTLibProtocolInputValuePhase
          SMTLibResponse.LengthSMTLibUnexpectedInputValueResponse)
        $ SMTLibProtocol.feedLengthSMTLibProtocol defaultValue
        $ asciiBytes "success\n"
      valueBarrierPhase <- expectProtocolAwait =<< expectRight
        (SMTLibProtocol.feedLengthSMTLibProtocol defaultValue
          $ rawValues ++ asciiBytes "\n")
      SMTLibProtocol.lengthSMTLibProtocolReceiverPhase valueBarrierPhase @?=
        SMTLibProtocol.LengthSMTLibProtocolInputValueBarrierPhase
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolUnexpectedEOF
          SMTLibProtocol.LengthSMTLibProtocolInputValueBarrierPhase)
        $ SMTLibProtocol.finishLengthSMTLibProtocol valueBarrierPhase
      assertLeft
        (SMTLibProtocol.LengthSMTLibProtocolBarrierMismatch
          SMTLibProtocol.LengthSMTLibProtocolInputValueBarrier)
        $ SMTLibProtocol.feedLengthSMTLibProtocol valueBarrierPhase
        $ SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier ++
          asciiBytes "\n"

      (_, statusOnly) <- protocolUnaryPlan
        InternalSMTLibExecution.LengthSMTLibStatusOnly
      statusInitial <- begin statusOnly
      statusDecoded <- expectProtocolComplete =<< expectRight
        (SMTLibProtocol.feedLengthSMTLibProtocol statusInitial
          $ asciiBytes "unknown\n" ++
            SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier ++
            [9, 10, 13, 32])
      SMTLibProtocol.lengthSMTLibProtocolDecodedObservation statusDecoded @?=
        Observation.UnknownObservation ()
      commentInitial <- begin statusOnly
      case SMTLibProtocol.feedLengthSMTLibProtocol commentInitial $
          asciiBytes "unknown\n" ++
          SMTLibStream.smtLibEchoSentinelResponseBytes checkBarrier ++
          asciiBytes "; not transport whitespace" of
        Left (SMTLibProtocol.LengthSMTLibProtocolUnexpectedPostBarrierByte
            _ 59) -> pure ()
        Left other -> assertFailure $ "unexpected post-barrier rejection: " ++
          show other
        Right _ -> assertFailure "a post-barrier comment was accepted as trivia"
  ]

protocolCheckNonce, protocolValueNonce :: [Word8]
protocolCheckNonce = [0 .. 31]
protocolValueNonce = [32 .. 63]

protocolSentinel :: [Word8] -> IO SMTLibStream.SMTLibEchoSentinel
protocolSentinel = expectRight . SMTLibStream.mkSMTLibEchoSentinel

protocolExecutionConfig
  :: InternalSMTLibExecution.LengthSMTLibArtifactPolicy
  -> IO InternalSMTLibExecution.LengthSMTLibPostLaunchExecutionPolicy
protocolExecutionConfig policy = fmap
  InternalSMTLibExecution.retainLengthSMTLibPostLaunchExecutionPolicy
  $ expectRight
  $ protocolExecutionConfigWithResponseEither policy
      SMTLibResponse.defaultLengthSMTLibResponseLimits

protocolExecutionConfigWithResponse
  :: InternalSMTLibExecution.LengthSMTLibArtifactPolicy
  -> SMTLibResponse.LengthSMTLibResponseLimits
  -> IO InternalSMTLibExecution.LengthSMTLibPostLaunchExecutionPolicy
protocolExecutionConfigWithResponse policy response = fmap
  InternalSMTLibExecution.retainLengthSMTLibPostLaunchExecutionPolicy
  $ expectRight
  $ protocolExecutionConfigWithResponseEither policy response

protocolExecutionConfigWithResponseEither
  :: InternalSMTLibExecution.LengthSMTLibArtifactPolicy
  -> SMTLibResponse.LengthSMTLibResponseLimits
  -> Either
      InternalSMTLibExecution.LengthSMTLibExecutionConfigError
      InternalSMTLibExecution.LengthSMTLibExecutionConfig
protocolExecutionConfigWithResponseEither policy response =
  InternalSMTLibExecution.mkLengthSMTLibExecutionConfig
    InternalSMTLibExecution.defaultLengthSMTLibExecutionLimits
  $ (InternalSMTLibExecution.defaultLengthSMTLibExecutionConfigSource
      absoluteFixtureExecutable Nothing)
      { InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
          policy
      , InternalSMTLibExecution.lengthSMTLibExecutionConfigSourceResponseLimits =
          response
      }

protocolUnaryPlan
  :: InternalSMTLibExecution.LengthSMTLibArtifactPolicy
  -> IO
      ( SMTLib.LengthSMTLibQuery AdversarialIdentity AdversarialLocal
      , SMTLibProtocol.LengthSMTLibProtocolPlan
          AdversarialIdentity AdversarialLocal
      )
protocolUnaryPlan policy = do
  problem <- adversarialConstantZeroProblem identityLengthContract
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  execution <- protocolExecutionConfig policy
  let valueNonce = case policy of
        InternalSMTLibExecution.LengthSMTLibStatusOnly -> Nothing
        InternalSMTLibExecution.LengthSMTLibInputValuesAfterSatisfiable ->
          Just protocolValueNonce
  plan <- expectRight $ SMTLibProtocol.sealLengthSMTLibProtocolPlan
    SMTLibProtocol.defaultLengthSMTLibProtocolLimits
    execution query protocolCheckNonce valueNonce
  pure (query, plan)

protocolZeroInputPlan
  :: InternalSMTLibExecution.LengthSMTLibArtifactPolicy
  -> IO
      ( SMTLib.LengthSMTLibQuery AdversarialIdentity AdversarialLocal
      , SMTLibProtocol.LengthSMTLibProtocolPlan
          AdversarialIdentity AdversarialLocal
      )
protocolZeroInputPlan policy = do
  let result = Length.LengthVariable Length.LengthResult
      source = contractWith (Length.LengthTruth True)
        $ Length.LengthEqual result $ Length.LengthLiteral 1
  problem <- adversarialZeroInputProblem source
  query <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits problem
  execution <- protocolExecutionConfig policy
  plan <- expectRight $ SMTLibProtocol.sealLengthSMTLibProtocolPlan
    SMTLibProtocol.defaultLengthSMTLibProtocolLimits
    execution query protocolCheckNonce Nothing
  pure (query, plan)

protocolValueFrame
  :: SMTLib.LengthSMTLibQuery identity local
  -> [Integer]
  -> [Word8]
protocolValueFrame query values =
  [40] ++ intercalate [32]
    [ [40] ++ symbol ++ [32] ++ asciiBytes (show value) ++ [41]
    | (symbol, value) <-
        zip (SMTLib.lengthSMTLibQueryInputSymbols query) values
    ] ++ [41]

protocolSpinePairValueFrame
  :: SMTLib.LengthSpinePairSMTLibQuery identity local
  -> [Integer]
  -> [Word8]
protocolSpinePairValueFrame query values =
  [40] ++ intercalate [32]
    [ [40] ++ symbol ++ [32] ++ asciiBytes (show value) ++ [41]
    | (symbol, value) <-
        zip (SMTLib.lengthSpinePairSMTLibQueryInputSymbols query) values
    ] ++ [41]

expectProtocolWrite
  :: SMTLibProtocol.LengthSMTLibProtocolWriteKind
  -> [Word8]
  -> SMTLibProtocol.LengthSMTLibProtocolAction identity local
  -> IO (SMTLibProtocol.LengthSMTLibProtocolReceiver identity local)
expectProtocolWrite expectedKind expectedBytes action = case action of
  SMTLibCausal.SMTLibCausalWrite kind bytes receiver -> do
    kind @?= expectedKind
    bytes @?= expectedBytes
    pure receiver
  SMTLibCausal.SMTLibCausalAwait{} ->
    assertFailure "expected a protocol write action, observed await"
  SMTLibCausal.SMTLibCausalComplete{} ->
    assertFailure "expected a protocol write action, observed completion"

expectProtocolAwait
  :: SMTLibProtocol.LengthSMTLibProtocolAction identity local
  -> IO (SMTLibProtocol.LengthSMTLibProtocolReceiver identity local)
expectProtocolAwait action = case action of
  SMTLibCausal.SMTLibCausalAwait receiver -> pure receiver
  SMTLibCausal.SMTLibCausalWrite{} ->
    assertFailure "expected a protocol await action, observed write"
  SMTLibCausal.SMTLibCausalComplete{} ->
    assertFailure "expected a protocol await action, observed completion"

expectProtocolComplete
  :: SMTLibProtocol.LengthSMTLibProtocolAction identity local
  -> IO (SMTLibProtocol.LengthSMTLibProtocolDecoded identity local)
expectProtocolComplete action = case action of
  SMTLibCausal.SMTLibCausalComplete decoded -> pure decoded
  SMTLibCausal.SMTLibCausalWrite{} ->
    assertFailure "expected protocol completion, observed write"
  SMTLibCausal.SMTLibCausalAwait{} ->
    assertFailure "expected protocol completion, observed await"

expectSpinePairProtocolWrite
  :: SMTLibSpinePairProtocol.LengthSpinePairSMTLibProtocolWriteKind
  -> [Word8]
  -> SMTLibSpinePairProtocol.LengthSpinePairSMTLibProtocolAction identity local
  -> IO
      (SMTLibSpinePairProtocol.LengthSpinePairSMTLibProtocolReceiver
        identity local)
expectSpinePairProtocolWrite expectedKind expectedBytes action = case action of
  SMTLibCausal.SMTLibCausalWrite kind bytes receiver -> do
    kind @?= expectedKind
    bytes @?= expectedBytes
    pure receiver
  SMTLibCausal.SMTLibCausalAwait{} ->
    assertFailure "expected a pair protocol write action, observed await"
  SMTLibCausal.SMTLibCausalComplete{} ->
    assertFailure "expected a pair protocol write action, observed completion"

expectSpinePairProtocolComplete
  :: SMTLibSpinePairProtocol.LengthSpinePairSMTLibProtocolAction identity local
  -> IO
      (SMTLibSpinePairProtocol.LengthSpinePairSMTLibProtocolDecoded
        identity local)
expectSpinePairProtocolComplete action = case action of
  SMTLibCausal.SMTLibCausalComplete decoded -> pure decoded
  SMTLibCausal.SMTLibCausalWrite{} ->
    assertFailure "expected pair protocol completion, observed write"
  SMTLibCausal.SMTLibCausalAwait{} ->
    assertFailure "expected pair protocol completion, observed await"

feedProtocolChunks
  :: SMTLibProtocol.LengthSMTLibProtocolReceiver identity local
  -> [[Word8]]
  -> IO (SMTLibProtocol.LengthSMTLibProtocolAction identity local)
feedProtocolChunks receiver chunks = case chunks of
  [] -> pure $ SMTLibCausal.SMTLibCausalAwait receiver
  chunk : remaining -> do
    action <- expectRight
      $ SMTLibProtocol.feedLengthSMTLibProtocol receiver chunk
    case action of
      SMTLibCausal.SMTLibCausalAwait next ->
        feedProtocolChunks next remaining
      _
        | null remaining -> pure action
        | otherwise -> assertFailure
            "the protocol produced an action before all response chunks"

assertProtocolTerminalStatus
  :: SMTLibProtocol.LengthSMTLibProtocolPlan identity local
  -> [Word8]
  -> (String, Observation.SolverStatus)
  -> IO ()
assertProtocolTerminalStatus plan marker (rawStatus, expectedStatus) = do
  receiver <- expectProtocolWrite
    SMTLibProtocol.LengthSMTLibProtocolInitialQueryWrite
    (SMTLibProtocol.lengthSMTLibProtocolInitialWriteBytes plan)
    $ SMTLibProtocol.startLengthSMTLibProtocol plan
  action <- expectRight $ SMTLibProtocol.feedLengthSMTLibProtocol receiver
    $ asciiBytes (rawStatus ++ "\n") ++ marker ++ asciiBytes "\n"
  decoded <- expectProtocolComplete action
  SMTLibProtocol.lengthSMTLibProtocolDecodedObservation decoded @?=
    case expectedStatus of
      Observation.SolverSatisfiable ->
        Observation.SatisfiableObservation Nothing
      Observation.SolverUnsatisfiable ->
        Observation.UnsatisfiableObservation ()
      Observation.SolverUnknown -> Observation.UnknownObservation ()

constantZeroSMTLibCheck :: String
constantZeroSMTLibCheck = unlines
  [ "(set-option :produce-models true)"
  , "(set-option :random-seed 1)"
  , "(set-logic QF_LIA)"
  , "(define-fun djex_nat_monus ((x Int) (y Int)) Int (ite (<= y x) (- x y) 0))"
  , "(define-fun djex_nat_min ((x Int) (y Int)) Int (ite (<= x y) x y))"
  , "(define-fun djex_nat_max ((x Int) (y Int)) Int (ite (<= x y) y x))"
  , "(declare-const djex_length_input_0 Int)"
  , "(assert (<= 0 djex_length_input_0))"
  , "(assert (not (= djex_length_input_0 0)))"
  , "(check-sat)"
  ]

spinePairRelationalSMTLibCheck :: String
spinePairRelationalSMTLibCheck = unlines
  [ "(set-option :produce-models true)"
  , "(set-option :random-seed 1)"
  , "(set-logic QF_LIA)"
  , "(define-fun djex_nat_monus ((x Int) (y Int)) Int (ite (<= y x) (- x y) 0))"
  , "(define-fun djex_nat_min ((x Int) (y Int)) Int (ite (<= x y) x y))"
  , "(define-fun djex_nat_max ((x Int) (y Int)) Int (ite (<= x y) y x))"
  , "(declare-const djex_length_input_0 Int)"
  , "(assert (<= 0 djex_length_input_0))"
  , "(assert (not (and (= djex_length_input_0 0) (= djex_length_input_0 (+ djex_length_input_0 1)))))"
  , "(check-sat)"
  ]

limitTests :: TestTree
limitTests = testGroup "limits"
  [ testCase "publish the exact versioned domain tag" $
      Length.finiteListSpineLengthDomainTag @?=
        map (fromIntegral . fromEnum)
          ("finite-list-spine-length/v1" :: String)
  , testCase "publish the intended conservative defaults" $ do
      Length.mkLengthLimits Length.defaultLengthLimitSource @?=
        Right Length.defaultLengthLimits
      let limits = Length.defaultLengthLimits
      Length.lengthTypeNodeLimit limits @?= 4096
      Length.lengthContractInputLimit limits @?= 8
      Length.lengthSyntaxNodeLimit limits @?= 1024
      Length.lengthFormulaClauseLimit limits @?= 32
      Length.lengthCollectionWidthLimit limits @?= 64
      Length.lengthProviderSummaryLimit limits @?= 256
      Length.lengthProviderArgumentLimit limits @?= 16
      Length.lengthLiteralBitLimit limits @?= 256
      Length.lengthFingerprintByteLimit limits @?= 65536
  , testCase "reject every negative field in declaration order" $
      mapM_ assertNegativeLimit negativeLimitCases
  , testCase "admit zero for every bound" $ do
      limits <- expectRight $ Length.mkLengthLimits zeroLengthLimitSource
      map ($ limits)
        [ Length.lengthTypeNodeLimit
        , Length.lengthContractInputLimit
        , Length.lengthSyntaxNodeLimit
        , Length.lengthFormulaClauseLimit
        , Length.lengthCollectionWidthLimit
        , Length.lengthProviderSummaryLimit
        , Length.lengthProviderArgumentLimit
        , Length.lengthLiteralBitLimit
        , Length.lengthFingerprintByteLimit
        ] @?= replicate 9 0
  ]

contextTests :: TestTree
contextTests = testGroup "checked semantic contexts"
  [ testCase "retain the exact inventory and builtin structural-list model" $ do
      context <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits fixtureInventory Length.BuiltinListSpine
      Length.lengthContextInventory context @?= fixtureInventory
      let model = Length.lengthContextSpineModel context
      Length.checkedLengthSpineTypeName model @?= listName
      Length.checkedLengthSpineZeroConstructor model @?= listName
      Length.checkedLengthSpineStepConstructor model @?= consName
      Length.checkedLengthSpineRecursiveField model @?= 1
      Length.checkedLengthSpineModelTrust model @?=
        Length.BuiltinStructuralListSpine
  , testCase "derive both legal recursive-field orders from declarations" $ do
      typeName <- expectName "Fixture.Sequence"
      zeroName <- expectName "Fixture.Empty"
      stepName <- expectName "Fixture.Link"
      let source = Length.DeclaredListSpine typeName zeroName stepName
          payloadFirstInventory = fixtureInventoryFromDeclarations
            [listLikeDeclaration typeName zeroName stepName False]
          recursiveFirstInventory = fixtureInventoryFromDeclarations
            [listLikeDeclaration typeName zeroName stepName True]
      payloadFirst <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits payloadFirstInventory source
      recursiveFirst <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits recursiveFirstInventory source
      let payloadFirstModel = Length.lengthContextSpineModel payloadFirst
          recursiveFirstModel = Length.lengthContextSpineModel recursiveFirst
      map Length.checkedLengthSpineTypeName
          [payloadFirstModel, recursiveFirstModel] @?=
        [typeName, typeName]
      map Length.checkedLengthSpineZeroConstructor
          [payloadFirstModel, recursiveFirstModel] @?=
        [zeroName, zeroName]
      map Length.checkedLengthSpineStepConstructor
          [payloadFirstModel, recursiveFirstModel] @?=
        [stepName, stepName]
      map Length.checkedLengthSpineRecursiveField
          [payloadFirstModel, recursiveFirstModel] @?=
        [1, 0]
      map Length.checkedLengthSpineModelTrust
          [payloadFirstModel, recursiveFirstModel] @?=
        replicate 2 Length.DerivedFromListLikeDataDeclaration
  , testCase "reject absent, non-data, ambiguous, and malformed schemas" $ do
      typeName <- expectName "Fixture.Sequence"
      zeroName <- expectName "Fixture.Empty"
      stepName <- expectName "Fixture.Link"
      otherName <- expectName "Fixture.Other"
      let source = Length.DeclaredListSpine typeName zeroName stepName
          parameter = TypeParameter "element" Nothing
          payload = TypeVariable "element"
          recursive = TypeApplication (TypeConstructor typeName) payload
          nonDataInventory = fixtureInventoryFromDeclarations
            [AbstractTypeDeclaration () typeName ProperTypeKind]
          noParameterInventory = fixtureInventoryFromDeclarations
            [DataTypeDeclaration () typeName []
              [DataConstructor () zeroName [], DataConstructor () stepName []]]
          oneConstructorInventory = fixtureInventoryFromDeclarations
            [DataTypeDeclaration () typeName [parameter]
              [DataConstructor () zeroName []]]
          malformedFieldsInventory = fixtureInventoryFromDeclarations
            [DataTypeDeclaration () typeName [parameter]
              [ DataConstructor () zeroName []
              , DataConstructor () stepName [payload, payload]
              ]]
          nonemptyZeroInventory = fixtureInventoryFromDeclarations
            [DataTypeDeclaration () typeName [parameter]
              [ DataConstructor () zeroName [payload]
              , DataConstructor () stepName [payload, recursive]
              ]]
          unaryStepInventory = fixtureInventoryFromDeclarations
            [DataTypeDeclaration () typeName [parameter]
              [ DataConstructor () zeroName []
              , DataConstructor () stepName [recursive]
              ]]
          validInventory = fixtureInventoryFromDeclarations
            [DataTypeDeclaration () typeName [parameter]
              [ DataConstructor () zeroName []
              , DataConstructor () stepName [payload, recursive]
              ]]
      assertLeft (Length.LengthSpineTypeDeclarationMissing typeName)
        $ Length.sealLengthContext
            Length.defaultLengthLimits fixtureInventory source
      assertLeft (Length.LengthSpineTypeIsNotData typeName)
        $ Length.sealLengthContext
            Length.defaultLengthLimits nonDataInventory source
      assertLeft (Length.LengthSpineParameterArityMismatch typeName 0)
        $ Length.sealLengthContext
            Length.defaultLengthLimits noParameterInventory source
      assertLeft (Length.LengthSpineConstructorArityMismatch typeName 1)
        $ Length.sealLengthContext
            Length.defaultLengthLimits oneConstructorInventory source
      assertLeft (Length.LengthSpineConstructorsMustDiffer zeroName)
        $ Length.sealLengthContext Length.defaultLengthLimits validInventory
            (Length.DeclaredListSpine typeName zeroName zeroName)
      assertLeft (Length.LengthSpineZeroConstructorMissing otherName)
        $ Length.sealLengthContext Length.defaultLengthLimits validInventory
            (Length.DeclaredListSpine typeName otherName stepName)
      assertLeft (Length.LengthSpineStepConstructorMissing otherName)
        $ Length.sealLengthContext Length.defaultLengthLimits validInventory
            (Length.DeclaredListSpine typeName zeroName otherName)
      assertLeft (Length.LengthSpineZeroFieldArityMismatch zeroName 1)
        $ Length.sealLengthContext
            Length.defaultLengthLimits nonemptyZeroInventory source
      assertLeft (Length.LengthSpineStepFieldArityMismatch stepName 1)
        $ Length.sealLengthContext
            Length.defaultLengthLimits unaryStepInventory source
      assertLeft
        (Length.LengthSpineStepFieldsDoNotMatch
          stepName payload payload)
        $ Length.sealLengthContext
            Length.defaultLengthLimits malformedFieldsInventory source
  , testCase "keep builtin and declared spine families disjoint" $ do
      typeName <- expectName "Fixture.DisjointSequence"
      zeroName <- expectName "Fixture.DisjointEmpty"
      stepName <- expectName "Fixture.DisjointLink"
      let inventory = fixtureInventoryFromDeclarations
            [listLikeDeclaration typeName zeroName stepName False]
          modeled payload = TypeApplication
            (TypeConstructor typeName) payload
          builtinTarget = FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
          declaredTarget = FunctionType
            (modeled closedPayloadType) (modeled closedPayloadType)
      builtinContext <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits inventory Length.BuiltinListSpine
      declaredContext <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits inventory
        $ Length.DeclaredListSpine typeName zeroName stepName
      assertLeft
        (Length.LengthContractInputIsNotList 0
          $ modeled closedPayloadType)
        $ Length.sealLengthContractInContext
            Length.defaultLengthLimits builtinContext
            declaredTarget identityLengthContract
      assertLeft
        (Length.LengthContractInputIsNotList 0
          $ listOf closedPayloadType)
        $ Length.sealLengthContractInContext
            Length.defaultLengthLimits declaredContext
            builtinTarget identityLengthContract
  ]

contractTests :: TestTree
contractTests = testGroup "checked contracts"
  [ testCase "admit opaque impredicative list payloads" $ do
      let payload = polymorphicIdentityType
          target = FunctionType (listOf payload) (listOf payload)
      checked <- expectRight $ sealContract
        Length.defaultLengthLimits target identityLengthContract
      Length.checkedLengthContractTarget checked @?= target
      Length.checkedLengthContractInputCount checked @?= 1
      Length.checkedLengthContractPrecondition checked @?=
        Length.LengthTruth True
      Length.checkedLengthContractPostcondition checked @?=
        Length.LengthEqual
          (Length.LengthVariable $ Length.LengthInput 0)
          (Length.LengthVariable Length.LengthResult)
  , testCase
      "admit one higher-order target argument without assigning it a length" $ do
      let inputPayload = closedPayloadType
          outputPayload = FunctionType closedPayloadType closedPayloadType
          target = FunctionType
            (FunctionType inputPayload outputPayload)
            $ FunctionType (listOf inputPayload) (listOf outputPayload)
          roles =
            [ Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
      checked <- expectRight $ Length.sealRoleAwareLengthContract
        Length.defaultLengthLimits fixtureInventory roles target
        identityLengthContract
      Length.checkedLengthContractTarget checked @?= target
      Length.checkedLengthContractTargetArgumentRoles checked @?= roles
      Length.checkedLengthContractInputCount checked @?= 1
      case Length.sealLengthContract Length.defaultLengthLimits
          fixtureInventory target identityLengthContract of
        Left (Length.LengthContractInputIsNotList 0 rejected) ->
          rejected @?= FunctionType inputPayload outputPayload
        Left other -> assertFailure $ "unexpected legacy rejection: " ++ show other
        Right _ -> assertFailure
          "legacy all-observed sealing admitted a higher-order argument"
  , testCase
      "canonicalize explicit all-observed roles to the legacy contract" $ do
      let target = FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
          roles = [Length.LengthObservedSpine]
      legacy <- expectRight $ sealContract
        Length.defaultLengthLimits target identityLengthContract
      explicit <- expectRight $ Length.sealRoleAwareLengthContract
        Length.defaultLengthLimits fixtureInventory roles target
        identityLengthContract
      Length.checkedLengthContractTargetArgumentRoles legacy @?= roles
      Length.checkedLengthContractTargetArgumentRoles explicit @?= roles
      Length.lengthContractFingerprint explicit @?=
        Length.lengthContractFingerprint legacy
      Fingerprint.fingerprintCanonicalBytes
          (Length.lengthContractFingerprint explicit) @?=
        Fingerprint.fingerprintCanonicalBytes
          (Length.lengthContractFingerprint legacy)
  , testCase
      "bound and match the complete target-role vector before formulas" $ do
      let target = FunctionType
            (listOf closedPayloadType)
            $ FunctionType
                (listOf closedPayloadType) (listOf closedPayloadType)
          poisonFormula = error "target roles demanded a contract formula"
          poisonContract = Length.LengthContractSource
            poisonFormula poisonFormula
          oneRole = [Length.LengthObservedSpine]
          threeRoles =
            [ Length.LengthObservedSpine
            , Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
          twoRoleLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceContractInputs = 2 }
      assertLeft
        (Length.LengthContractTargetArgumentRoleArityMismatch 2 1)
        $ Length.sealRoleAwareLengthContract
            Length.defaultLengthLimits fixtureInventory oneRole target
            poisonContract
      assertLeft
        (Length.LengthContractTargetArgumentRoleLimitExceeded 2 3)
        $ Length.sealRoleAwareLengthContract
            twoRoleLimits fixtureInventory threeRoles target poisonContract
      let compactOutOfRange = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (Length.LengthVariable $ Length.LengthInput 1)
                (Length.LengthVariable Length.LengthResult)
      assertLeft
        (Length.LengthContractPostconditionError
          $ Length.LengthInputReferenceOutOfRange 1 1)
        $ Length.sealRoleAwareLengthContract
            Length.defaultLengthLimits fixtureInventory
            [ Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
            target compactOutOfRange
  , testCase "reject a direct higher-rank term input" $ do
      let rankNInput = polymorphicIdentityType
          target = FunctionType rankNInput (listOf rankNInput)
      case sealContract
          Length.defaultLengthLimits target identityLengthContract of
        Left (Length.LengthContractInputIsNotList 0 rejected) ->
          rejected @?= rankNInput
        Left other -> assertFailure $ "unexpected rejection: " ++ show other
        Right _ -> assertFailure "direct higher-rank input was admitted as a list"
  , testCase "require proper-kind authority for opaque list payloads" $ do
      let illKindedTarget =
            listOf (TypeConstructor listName) :: Type String
      case sealContract Length.defaultLengthLimits
          illKindedTarget trivialLengthContract of
        Left Length.LengthContractTargetKindError{} -> pure ()
        Left other -> assertFailure $ "unexpected rejection: " ++ show other
        Right _ -> assertFailure "an ill-kinded list payload was admitted"
  , testCase "reject a proper-kinded leading contract context" $ do
      className <- expectName "Fixture.ContractConstraint"
      let classDeclaration :: Declaration String () ()
          classDeclaration = ClassDeclaration () className [] [] []
          target = ForallType [] [Constraint className []]
            $ listOf closedPayloadType
      inventory <- expectRight $ mkInventory
        ClosedKindInventory [classDeclaration]
      assertLeft Length.LengthContractConstrainedTarget
        $ Length.sealLengthContract Length.defaultLengthLimits
            inventory target trivialLengthContract
  , testCase "reject result references in a precondition" $ do
      let source = Length.LengthContractSource
            { Length.lengthContractPrecondition = Length.LengthEqual
                (Length.LengthVariable Length.LengthResult)
                (Length.LengthLiteral 0)
            , Length.lengthContractPostcondition = Length.LengthTruth True
            }
      assertLeft
        (Length.LengthContractPreconditionError
          Length.LengthResultNotAvailableInPrecondition)
        $ sealContract Length.defaultLengthLimits
            (listOf closedPayloadType) source
  , testCase "reject input references outside the target function spine" $ do
      let source = Length.LengthContractSource
            { Length.lengthContractPrecondition = Length.LengthTruth True
            , Length.lengthContractPostcondition = Length.LengthEqual
                (Length.LengthVariable $ Length.LengthInput 1)
                (Length.LengthVariable Length.LengthResult)
            }
      assertLeft
        (Length.LengthContractPostconditionError
          $ Length.LengthInputReferenceOutOfRange 1 1)
        $ sealContract Length.defaultLengthLimits
            (FunctionType
              (listOf closedPayloadType)
              (listOf closedPayloadType)) source
  , testCase "report the first input beyond an exact zero bound" $ do
      let limits = limitsWith $ \source -> source
            { Length.lengthLimitSourceContractInputs = 0 }
      assertLeft (Length.LengthContractInputLimitExceeded 0 1)
        $ sealContract limits
            (FunctionType
              (listOf closedPayloadType)
              (listOf closedPayloadType)) identityLengthContract
  , testCase "bound raw syntax, conjunctions, widths, and literals" $ do
      let target = FunctionType
            (listOf closedPayloadType)
            (listOf closedPayloadType)
          syntaxLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceSyntaxNodes = 1 }
          syntaxSource = contractWith
            (Length.LengthNot $ Length.LengthTruth True)
            (Length.LengthTruth True)
          clauseLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceFormulaClauses = 1 }
          clauses = Length.LengthAll
            [Length.LengthTruth True, Length.LengthTruth False]
          widthLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceCollectionWidth = 1 }
          literalLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceLiteralBits = 3 }
          literalSource = contractWith
            (Length.LengthEqual
              (Length.LengthVariable $ Length.LengthInput 0)
              (Length.LengthLiteral 8))
            (Length.LengthTruth True)
          foldedSumSource = contractWith
            (Length.LengthEqual
              (Length.LengthSum
                [Length.LengthLiteral 7, Length.LengthLiteral 1])
              (Length.LengthLiteral 0))
            (Length.LengthTruth True)
          foldedScaleSource = contractWith
            (Length.LengthEqual
              (Length.LengthScale 2 $ Length.LengthLiteral 4)
              (Length.LengthLiteral 0))
            (Length.LengthTruth True)
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthSyntaxNodeLimitExceeded 1 2)
        $ sealContract syntaxLimits target syntaxSource
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthFormulaClauseLimitExceeded 1 2)
        $ sealContract clauseLimits target
            (contractWith clauses $ Length.LengthTruth True)
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthSyntaxCollectionLimitExceeded
              Length.LengthConjunctionClauses 1 2)
        $ sealContract widthLimits target
            (contractWith clauses $ Length.LengthTruth True)
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthLiteralBitLimitExceeded 3 4)
        $ sealContract literalLimits target literalSource
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthLiteralBitLimitExceeded 3 4)
        $ sealContract literalLimits target foldedSumSource
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthLiteralBitLimitExceeded 3 4)
        $ sealContract literalLimits target foldedScaleSource
  , testCase "validate and normalize positive-literal natural modulo" $ do
      let target = FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
          input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          literalSource divisor value = contractWith
            (Length.LengthTruth True)
            $ Length.LengthEqual result
                $ Length.LengthModulo divisor $ Length.LengthLiteral value
          directLiteral value = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral value
          moduloOneSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthModulo 1 input
          zeroSource = contractWith
            (Length.LengthEqual
              (Length.LengthModulo 0 $ error "zero-modulo-child-demand")
              $ Length.LengthLiteral 0)
            $ Length.LengthTruth True
          literalLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceLiteralBits = 3 }
          oversizedSource = contractWith
            (Length.LengthEqual
              (Length.LengthModulo 8 $ error "modulo-divisor-child-demand")
              $ Length.LengthLiteral 0)
            $ Length.LengthTruth True
          oversizedOperandSource = contractWith
            (Length.LengthEqual
              (Length.LengthModulo 3 $ Length.LengthLiteral 8)
              $ Length.LengthLiteral 0)
            $ Length.LengthTruth True
      folded <- expectRight $ sealContract
        Length.defaultLengthLimits target $ literalSource 3 8
      directFolded <- expectRight $ sealContract
        Length.defaultLengthLimits target $ directLiteral 2
      moduloOne <- expectRight $ sealContract
        Length.defaultLengthLimits target moduloOneSource
      directZero <- expectRight $ sealContract
        Length.defaultLengthLimits target $ directLiteral 0
      Length.checkedLengthContractPostcondition folded @?=
        Length.LengthEqual result (Length.LengthLiteral 2)
      Length.checkedLengthContractPostcondition moduloOne @?=
        Length.LengthEqual result (Length.LengthLiteral 0)
      Length.lengthContractFingerprint folded @?=
        Length.lengthContractFingerprint directFolded
      Length.lengthContractFingerprint moduloOne @?=
        Length.lengthContractFingerprint directZero
      zeroResult <- evaluateWithin
        $ sealContract Length.defaultLengthLimits target zeroSource
      assertLeft
        (Length.LengthContractPreconditionError Length.LengthModuloDivisorZero)
        zeroResult
      oversizedResult <- evaluateWithin
        $ sealContract literalLimits target oversizedSource
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthLiteralBitLimitExceeded 3 4)
        oversizedResult
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthLiteralBitLimitExceeded 3 4)
        $ sealContract literalLimits target oversizedOperandSource

      let syntaxLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceSyntaxNodes = 3 }
          cyclic = Length.LengthScale 1 cyclic
          moduloOneCyclic = contractWith
            (Length.LengthEqual
              (Length.LengthModulo 1 cyclic) $ Length.LengthLiteral 0)
            $ Length.LengthTruth True
      cyclicResult <- evaluateWithin
        $ sealContract syntaxLimits target moduloOneCyclic
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthSyntaxNodeLimitExceeded 3 4)
        cyclicResult
  , testCase
      "validate and normalize positive-literal natural quotient lazily" $ do
      let target = FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
          input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          literalSource divisor value = contractWith
            (Length.LengthTruth True)
            $ Length.LengthEqual result
                $ Length.LengthQuotient divisor $ Length.LengthLiteral value
          directLiteral value = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthLiteral value
          quotientOneSource = contractWith (Length.LengthTruth True)
            $ Length.LengthEqual result $ Length.LengthQuotient 1 input
          zeroSource = contractWith
            (Length.LengthEqual
              (Length.LengthQuotient 0
                $ error "zero-quotient-child-demand")
              $ Length.LengthLiteral 0)
            $ Length.LengthTruth True
          literalLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceLiteralBits = 3 }
          oversizedSource = contractWith
            (Length.LengthEqual
              (Length.LengthQuotient 8
                $ error "quotient-divisor-child-demand")
              $ Length.LengthLiteral 0)
            $ Length.LengthTruth True
          oversizedOperandSource = contractWith
            (Length.LengthEqual
              (Length.LengthQuotient 3 $ Length.LengthLiteral 8)
              $ Length.LengthLiteral 0)
            $ Length.LengthTruth True
      folded <- expectRight $ sealContract
        Length.defaultLengthLimits target $ literalSource 3 8
      directFolded <- expectRight $ sealContract
        Length.defaultLengthLimits target $ directLiteral 2
      quotientOne <- expectRight $ sealContract
        Length.defaultLengthLimits target quotientOneSource
      directInput <- expectRight $ sealContract
        Length.defaultLengthLimits target identityLengthContract
      Length.checkedLengthContractPostcondition folded @?=
        Length.LengthEqual result (Length.LengthLiteral 2)
      Length.checkedLengthContractPostcondition quotientOne @?=
        Length.LengthEqual input result
      Length.lengthContractFingerprint folded @?=
        Length.lengthContractFingerprint directFolded
      Length.lengthContractFingerprint quotientOne @?=
        Length.lengthContractFingerprint directInput
      zeroResult <- evaluateWithin
        $ sealContract Length.defaultLengthLimits target zeroSource
      assertLeft
        (Length.LengthContractPreconditionError
          Length.LengthQuotientDivisorZero)
        zeroResult
      oversizedResult <- evaluateWithin
        $ sealContract literalLimits target oversizedSource
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthLiteralBitLimitExceeded 3 4)
        oversizedResult
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthLiteralBitLimitExceeded 3 4)
        $ sealContract literalLimits target oversizedOperandSource

      let syntaxLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceSyntaxNodes = 3 }
          cyclic = Length.LengthScale 1 cyclic
          quotientOneCyclic = contractWith
            (Length.LengthEqual
              (Length.LengthQuotient 1 cyclic) $ Length.LengthLiteral 0)
            $ Length.LengthTruth True
      cyclicResult <- evaluateWithin
        $ sealContract syntaxLimits target quotientOneCyclic
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthSyntaxNodeLimitExceeded 3 4)
        cyclicResult
  , testCase "bound target structure and type collections" $ do
      let nodeLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceTypeNodes = 0 }
          widthLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceCollectionWidth = 1 }
          wideTarget = ForallType ["left", "right"] []
            (listOf closedPayloadType)
      assertLeft
        (Length.LengthContractTargetBoundError
          $ Length.LengthTypeNodeLimitExceeded 0 1)
        $ sealContract nodeLimits
            (listOf closedPayloadType) trivialLengthContract
      assertLeft
        (Length.LengthContractTargetBoundError
          $ Length.LengthTypeCollectionLimitExceeded
              Length.LengthForallBinders 1 2)
        $ sealContract widthLimits wideTarget
            trivialLengthContract
  , testCase "surface a bounded fingerprint failure at max plus one" $ do
      let limits = limitsWith $ \source -> source
            { Length.lengthLimitSourceFingerprintBytes = 0 }
      assertLeft (Length.LengthContractFingerprintLimitExceeded 0 1)
        $ sealContract limits
            (listOf closedPayloadType) trivialLengthContract
  ]

spinePairContractTests :: TestTree
spinePairContractTests = testGroup
  "checked binary product-of-spines contracts"
  [ testCase "publish one distinct nominal domain and ordered pair carrier" $ do
      Length.finiteBinaryProductSpineLengthsDomainTag @?=
        asciiBytes "finite-binary-product-spine-lengths/v1"
      assertBool "the product domain reused the scalar runtime tag" $
        Length.finiteBinaryProductSpineLengthsDomainTag /=
          Length.finiteListSpineLengthDomainTag
      let pair = Length.LengthSpinePair (3 :: Natural) 5
      Length.lengthSpinePairFirst pair @?= 3
      Length.lengthSpinePairSecond pair @?= 5
      force pair `seq` pure ()
      [ Length.LengthSpinePairFirst
        , Length.LengthSpinePairSecond
        ] @?= [minBound .. maxBound]
  , testCase
      "seal exactly two boxed modeled spines and retain both result laws" $ do
      let firstPayload = closedPayloadType
          secondPayload = polymorphicIdentityType
          firstInput = listOf firstPayload
          secondInput = listOf secondPayload
          firstResultType = listOf secondPayload
          secondResultType = listOf firstPayload
          target = FunctionType firstInput $ FunctionType secondInput
            $ TupleType Boxed [firstResultType, secondResultType]
          first = Length.LengthVariable
            $ Length.LengthSpinePairResult Length.LengthSpinePairFirst
          second = Length.LengthVariable
            $ Length.LengthSpinePairResult Length.LengthSpinePairSecond
          input0 = Length.LengthVariable $ Length.LengthSpinePairInput 0
          input1 = Length.LengthVariable $ Length.LengthSpinePairInput 1
          postcondition = Length.LengthAll
            [ Length.LengthEqual first input1
            , Length.LengthEqual second $ Length.LengthSum [input0, input1]
            ]
          normalizedPostcondition = Length.LengthAll
            [ Length.LengthEqual input1 first
            , Length.LengthEqual second $ Length.LengthSum [input0, input1]
            ]
          source = spinePairContractWith
            (Length.LengthAtMost input0 input1) postcondition
      checked <- expectRight $ sealSpinePairContract
        Length.defaultLengthLimits target source
      Length.checkedLengthSpinePairContractTarget checked @?= target
      Length.checkedLengthSpinePairContractTargetArgumentRoles checked @?=
        [Length.LengthObservedSpine, Length.LengthObservedSpine]
      Length.checkedLengthSpinePairContractInputCount checked @?= 2
      Length.checkedLengthSpinePairContractPrecondition checked @?=
        Length.LengthAtMost input0 input1
      Length.checkedLengthSpinePairContractPostcondition checked @?=
        normalizedPostcondition
      force checked `seq` pure ()
  , testCase
      "reject nonboxed, nonbinary, and nonspine results in source order" $ do
      let spine = listOf closedPayloadType
          sealResult result = sealSpinePairContract
            Length.defaultLengthLimits (FunctionType spine result)
            trivialSpinePairContract
      assertLeft
        (Length.LengthSpinePairContractResultIsNotBoxedTuple spine)
        $ sealResult spine
      let unboxed = TupleType Unboxed [spine, spine]
      assertLeft
        (Length.LengthSpinePairContractResultIsNotBoxedTuple unboxed)
        $ sealResult unboxed
      assertLeft
        (Length.LengthSpinePairContractResultTupleArityMismatch 0)
        $ sealResult $ TupleType Boxed []
      assertLeft
        (Length.LengthSpinePairContractResultTupleArityMismatch 3)
        $ sealResult $ TupleType Boxed [spine, spine, spine]
      let notSpine = closedPayloadType
      assertLeft
        (Length.LengthSpinePairContractResultComponentIsNotList
          Length.LengthSpinePairFirst notSpine)
        $ sealResult $ TupleType Boxed [notSpine, notSpine]
      assertLeft
        (Length.LengthSpinePairContractResultComponentIsNotList
          Length.LengthSpinePairSecond notSpine)
        $ sealResult $ TupleType Boxed [spine, notSpine]
  , testCase
      "check inputs and pair shape before formulas, then precondition first" $ do
      let spine = listOf closedPayloadType
          pairResult = TupleType Boxed [spine, spine]
          poison = error "pair contract demanded a formula too early"
          poisonSource = Length.LengthSpinePairContractSource poison poison
      assertLeft
        (Length.LengthSpinePairContractInputIsNotList 0 closedPayloadType)
        $ Length.sealLengthSpinePairContract Length.defaultLengthLimits
            fixtureInventory
            (FunctionType closedPayloadType spine)
            poisonSource
      assertLeft
        (Length.LengthSpinePairContractResultIsNotBoxedTuple spine)
        $ sealSpinePairContract Length.defaultLengthLimits spine poisonSource

      let badPrecondition = Length.LengthEqual
            (Length.LengthVariable
              $ Length.LengthSpinePairResult Length.LengthSpinePairFirst)
            $ Length.LengthLiteral 0
          preconditionFirst = Length.LengthSpinePairContractSource
            badPrecondition (error "pair postcondition won precedence")
      result <- evaluateWithin $ sealSpinePairContract
        Length.defaultLengthLimits pairResult preconditionFirst
      assertLeft
        (Length.LengthSpinePairContractPreconditionError
          Length.LengthResultNotAvailableInPrecondition)
        result
  , testCase
      "compact role-aware inputs and reject either result in preconditions" $ do
      let spine = listOf closedPayloadType
          opaque = FunctionType closedPayloadType closedPayloadType
          target = FunctionType opaque $ FunctionType spine
            $ TupleType Boxed [spine, spine]
          roles =
            [Length.LengthUnobservedTarget, Length.LengthObservedSpine]
          compactInput = Length.LengthVariable
            $ Length.LengthSpinePairInput 0
          source = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthAll
                [ Length.LengthEqual
                    (pairResultVariable Length.LengthSpinePairFirst)
                    compactInput
                , Length.LengthEqual
                    (pairResultVariable Length.LengthSpinePairSecond)
                    compactInput
                ]
      checked <- expectRight $ Length.sealRoleAwareLengthSpinePairContract
        Length.defaultLengthLimits fixtureInventory roles target source
      Length.checkedLengthSpinePairContractTargetArgumentRoles checked @?= roles
      Length.checkedLengthSpinePairContractInputCount checked @?= 1
      mapM_ (\component ->
          assertLeft
            (Length.LengthSpinePairContractPreconditionError
              Length.LengthResultNotAvailableInPrecondition)
            $ Length.sealRoleAwareLengthSpinePairContract
                Length.defaultLengthLimits fixtureInventory roles target
                $ spinePairContractWith
                    (Length.LengthEqual
                      (pairResultVariable component) $ Length.LengthLiteral 0)
                    (Length.LengthTruth True))
        [Length.LengthSpinePairFirst, Length.LengthSpinePairSecond]
      assertLeft
        (Length.LengthSpinePairContractPostconditionError
          $ Length.LengthInputReferenceOutOfRange 1 1)
        $ Length.sealRoleAwareLengthSpinePairContract
            Length.defaultLengthLimits fixtureInventory roles target
            $ spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthEqual
                (Length.LengthVariable $ Length.LengthSpinePairInput 1)
                (pairResultVariable Length.LengthSpinePairFirst)
  , testCase
      "give pair contracts independent identities without perturbing scalar parity" $ do
      let spine = listOf closedPayloadType
          pairTarget = FunctionType spine $ TupleType Boxed [spine, spine]
          scalarTarget = FunctionType spine spine
          input = Length.LengthVariable $ Length.LengthSpinePairInput 0
          source component = spinePairContractWith (Length.LengthTruth True)
            $ Length.LengthEqual (pairResultVariable component) input
      first <- expectRight $ sealSpinePairContract
        Length.defaultLengthLimits pairTarget
        $ source Length.LengthSpinePairFirst
      second <- expectRight $ sealSpinePairContract
        Length.defaultLengthLimits pairTarget
        $ source Length.LengthSpinePairSecond
      assertBool "pair result component was omitted from contract identity" $
        Length.lengthSpinePairContractFingerprint first /=
          Length.lengthSpinePairContractFingerprint second

      legacy <- expectRight $ sealContract
        Length.defaultLengthLimits scalarTarget identityLengthContract
      explicit <- expectRight $ Length.sealRoleAwareLengthContract
        Length.defaultLengthLimits fixtureInventory
        [Length.LengthObservedSpine] scalarTarget identityLengthContract
      Length.lengthContractFingerprint legacy @?=
        Length.lengthContractFingerprint explicit
      assertBool "pair identity bytes alias the historical scalar contract" $
        Fingerprint.fingerprintCanonicalBytes
            (Length.lengthSpinePairContractFingerprint first) /=
          Fingerprint.fingerprintCanonicalBytes
            (Length.lengthContractFingerprint legacy)
  , testCase "share syntax accounting across phases and bound pair identity" $ do
      let spine = listOf closedPayloadType
          target = TupleType Boxed [spine, spine]
          oneNode = limitsWith $ \source -> source
            { Length.lengthLimitSourceSyntaxNodes = 1 }
          noFingerprint = limitsWith $ \source -> source
            { Length.lengthLimitSourceFingerprintBytes = 0 }
      assertLeft
        (Length.LengthSpinePairContractPostconditionError
          $ Length.LengthSyntaxNodeLimitExceeded 1 2)
        $ sealSpinePairContract oneNode target trivialSpinePairContract
      assertLeft
        (Length.LengthSpinePairContractFingerprintLimitExceeded 0 1)
        $ sealSpinePairContract noFingerprint target
            trivialSpinePairContract
  ]

providerTests :: TestTree
providerTests = testGroup "assumed provider inventory"
  [ testCase "retain closed schemes, roles, transfers, and assumed trust" $ do
      providerName <- expectName "Fixture.preserve"
      let source = unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      inventory <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [source]
      case Length.lookupCheckedLengthProviderSummary providerName inventory of
        Nothing -> assertFailure "checked provider disappeared from inventory"
        Just checked -> do
          Length.checkedLengthProviderName checked @?= providerName
          Length.checkedLengthProviderScheme checked @?=
            Length.lengthProviderScheme source
          Length.checkedLengthProviderArgumentRoles checked @?=
            [Length.LengthSpineArgument]
          Length.checkedLengthProviderTransfer checked @?=
            Length.LengthVariable (Length.LengthProviderArgument 0)
          Length.checkedLengthProviderTrust checked @?=
            Length.AssumedProviderLaw
  , testCase "admit non-list arguments only when their spines are unobserved" $ do
      providerName <- expectName "Fixture.constant"
      let scheme = FunctionType closedPayloadType
            (listOf closedPayloadType)
          source = providerSource providerName scheme
            [Length.LengthUnobservedArgument]
            (Length.LengthLiteral 0)
      inventory <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [source]
      let summaries = Length.checkedLengthProviderSummaries inventory
      map Length.checkedLengthProviderArgumentRoles summaries @?=
        [[Length.LengthUnobservedArgument]]
  , testCase "admit rank-N unobserved arguments and impredicative list payloads" $ do
      unobservedName <- expectName "Fixture.rankNUnobserved"
      spineName <- expectName "Fixture.impredicativeSpine"
      let unobserved = providerSource unobservedName
            (FunctionType polymorphicIdentityType
              $ listOf closedPayloadType)
            [Length.LengthUnobservedArgument]
            (Length.LengthLiteral 0)
          impredicative = providerSource spineName
            (FunctionType
              (listOf polymorphicIdentityType)
              (listOf polymorphicIdentityType))
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      inventory <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [unobserved, impredicative]
      map Length.checkedLengthProviderName
          (Length.checkedLengthProviderSummaries inventory) @?=
        sort [unobservedName, spineName]
  , testCase "resolve names before inspecting poisoned summary fields" $ do
      providerName <- expectName "Fixture.missing"
      let cyclicScheme = FunctionType cyclicScheme cyclicScheme
          cyclicRoles = Length.LengthSpineArgument : cyclicRoles
          cyclicTransfer = Length.LengthScale 1 cyclicTransfer
          source = providerSource providerName cyclicScheme
            cyclicRoles cyclicTransfer
      observed <- evaluateWithin $ Length.sealLengthProviderInventory
        Length.defaultLengthLimits fixtureInventory [source]
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderNotInSourceInventory providerName)
        observed
  , testCase "reject source-scheme mismatch before semantic shape errors" $ do
      providerName <- expectName "Fixture.mismatch"
      let sourceScheme = ForallType ["source"] [] $ FunctionType
            (listOf $ TypeVariable "source")
            (listOf $ TypeVariable "source")
          claimedScheme = ForallType ["claimed"] [] $ FunctionType
            closedPayloadType (listOf $ TypeVariable "claimed")
          source = providerSource providerName claimedScheme []
            (Length.LengthVariable $ Length.LengthProviderArgument 99)
          inventory = fixtureInventoryFromDeclarations
            [ValueDeclaration $ ValueSignature () providerName sourceScheme]
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderSourceSchemeMismatch
              sourceScheme claimedScheme)
        $ Length.sealLengthProviderInventory
            Length.defaultLengthLimits inventory [source]
  , testCase "accept alpha-equivalent claims and retain the source scheme" $ do
      providerName <- expectName "Fixture.alphaClaim"
      let sourceScheme = ForallType ["source"] [] $ FunctionType
            (listOf $ TypeVariable "source")
            (listOf $ TypeVariable "source")
          claimedScheme = ForallType ["claimed"] [] $ FunctionType
            (listOf $ TypeVariable "claimed")
            (listOf $ TypeVariable "claimed")
          source = providerSource providerName claimedScheme
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          inventory = fixtureInventoryFromDeclarations
            [ValueDeclaration $ ValueSignature () providerName sourceScheme]
      checkedInventory <- expectRight $ Length.sealLengthProviderInventory
        Length.defaultLengthLimits inventory [source]
      checked <- case Length.lookupCheckedLengthProviderSummary
          providerName checkedInventory of
        Nothing -> assertFailure "alpha-equivalent provider disappeared"
        Just summary -> pure summary
      Length.checkedLengthProviderScheme checked @?= sourceScheme
  , testCase "close implicit source variables before exact comparison" $ do
      providerName <- expectName "Fixture.implicit"
      let openSourceScheme = FunctionType
            (listOf $ TypeVariable "free")
            (listOf $ TypeVariable "free")
          closedClaim = ForallType ["renamed"] [] $ FunctionType
            (listOf $ TypeVariable "renamed")
            (listOf $ TypeVariable "renamed")
          source = providerSource providerName closedClaim
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          inventory = fixtureInventoryFromDeclarations
            [ValueDeclaration $ ValueSignature () providerName openSourceScheme]
      checkedInventory <- expectRight $ Length.sealLengthProviderInventory
        Length.defaultLengthLimits inventory [source]
      case Length.lookupCheckedLengthProviderSummary
          providerName checkedInventory of
        Nothing -> assertFailure "implicitly closed provider disappeared"
        Just checked -> Length.checkedLengthProviderScheme checked @?=
          ForallType ["free"] [] openSourceScheme
  , testCase "bound only the exact provider scheme, not unrelated terms" $ do
      providerName <- expectName "Fixture.localScheme"
      unrelatedName <- expectName "Fixture.unrelatedWideScheme"
      let provider = unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          unrelatedScheme = ForallType ["wide"] []
            $ foldr FunctionType (TypeVariable "wide")
            $ replicate 128 $ TypeVariable "wide"
          inventory = fixtureInventoryFromDeclarations
            [ ValueDeclaration
                $ ValueSignature () unrelatedName unrelatedScheme
            , ValueDeclaration
                $ ValueSignature () providerName
                $ Length.lengthProviderScheme provider
            ]
          exactSchemeLimit = limitsWith $ \limits -> limits
            { Length.lengthLimitSourceTypeNodes = 8 }
      checked <- expectRight $ Length.sealLengthProviderInventory
        exactSchemeLimit inventory [provider]
      map Length.checkedLengthProviderName
          (Length.checkedLengthProviderSummaries checked) @?= [providerName]
  , testCase "reject a proper-kinded leading provider context" $ do
      className <- expectName "Fixture.ProviderConstraint"
      providerName <- expectName "Fixture.constrained"
      let classDeclaration :: Declaration String () ()
          classDeclaration = ClassDeclaration () className [] [] []
          scheme = ForallType [] [Constraint className []]
            $ FunctionType
                (listOf closedPayloadType)
                (listOf closedPayloadType)
          source = providerSource providerName scheme
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      inventory <- expectRight $ mkInventory
        ClosedKindInventory
          [ classDeclaration
          , ValueDeclaration $ ValueSignature () providerName scheme
          ]
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          Length.LengthProviderConstrainedScheme)
        $ Length.sealLengthProviderInventory
            Length.defaultLengthLimits inventory [source]
  , testCase "require constraints on an explicitly conditional provider" $ do
      providerName <- expectName "Fixture.emptyConditionalContext"
      let scheme = ForallType ["element"] [] $ FunctionType
            (listOf $ TypeVariable "element")
            (listOf $ TypeVariable "element")
          source = conditionalProviderSource providerName scheme
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          Length.LengthProviderConditionalSchemeHasNoConstraints)
        $ sealProviderInventory Length.defaultLengthLimits [source]
  , testCase
      "retain conditional source schemes, roles, transfers, and trust" $ do
      className <- expectName "Fixture.ConditionalProviderConstraint"
      providerName <- expectName "Fixture.conditionalProvider"
      let sourceBinder = "source-element"
          claimedBinder = "claimed-element"
          classBinder = "class-element"
          classDeclaration :: Declaration String () ()
          classDeclaration = ClassDeclaration () className
            [TypeParameter classBinder (Just ProperTypeKind)] [] []
          sourceScheme = ForallType [sourceBinder]
            [Constraint className [TypeVariable sourceBinder]]
            $ FunctionType
                (listOf $ TypeVariable sourceBinder)
                (listOf $ TypeVariable sourceBinder)
          claimedScheme = ForallType [claimedBinder]
            [Constraint className [TypeVariable claimedBinder]]
            $ FunctionType
                (listOf $ TypeVariable claimedBinder)
                (listOf $ TypeVariable claimedBinder)
          roles = [Length.LengthSpineArgument]
          transfer = Length.LengthVariable $ Length.LengthProviderArgument 0
          source = conditionalProviderSource providerName claimedScheme
            roles transfer
      inventory <- expectRight $ mkInventory ClosedKindInventory
        [ classDeclaration
        , ValueDeclaration $ ValueSignature () providerName sourceScheme
        ]
      checkedInventory <- expectRight $ Length.sealLengthProviderInventory
        Length.defaultLengthLimits inventory [source]
      checked <- case Length.lookupCheckedLengthProviderSummary
          providerName checkedInventory of
        Nothing -> assertFailure "conditional provider disappeared"
        Just summary -> pure summary
      Length.checkedLengthProviderName checked @?= providerName
      Length.checkedLengthProviderScheme checked @?= sourceScheme
      Length.checkedLengthProviderArgumentRoles checked @?= roles
      Length.checkedLengthProviderTransfer checked @?= transfer
      Length.checkedLengthProviderTrust checked @?=
        Length.AssumedProviderLawConditionalOnConstraintDischarge
  , testCase "reject direct rank-N spines and observed non-list arguments" $ do
      rankNName <- expectName "Fixture.rankN"
      nonListName <- expectName "Fixture.nonList"
      let rankNScheme = FunctionType polymorphicIdentityType
            (listOf closedPayloadType)
          rankNSource = providerSource rankNName rankNScheme
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          nonListScheme = FunctionType closedPayloadType
            (listOf closedPayloadType)
          nonListSource = providerSource nonListName nonListScheme
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      case sealProviderInventory
          Length.defaultLengthLimits [rankNSource] of
        Left (Length.LengthProviderSummaryRejected 0 name
            (Length.LengthProviderSpineArgumentIsNotList 0 _)) ->
          name @?= rankNName
        Left other -> assertFailure $ "unexpected rejection: " ++ show other
        Right _ -> assertFailure "direct higher-rank provider input was admitted"
      assertLeft
        (Length.LengthProviderSummaryRejected 0 nonListName
          $ Length.LengthProviderSpineArgumentIsNotList 0 closedPayloadType)
        $ sealProviderInventory
            Length.defaultLengthLimits [nonListSource]
  , testCase "reject transfer references to absent or unobserved arguments" $ do
      providerName <- expectName "Fixture.badTransfer"
      let scheme = FunctionType closedPayloadType
            (listOf closedPayloadType)
          outOfRange = providerSource providerName scheme
            [Length.LengthUnobservedArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 1)
          unobserved = providerSource providerName scheme
            [Length.LengthUnobservedArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderTransferError
          $ Length.LengthProviderReferenceOutOfRange 1 1)
        $ sealProviderInventory
            Length.defaultLengthLimits [outOfRange]
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderTransferError
          $ Length.LengthProviderReferenceIsUnobserved 0)
        $ sealProviderInventory
            Length.defaultLengthLimits [unobserved]
  , testCase "reject role arity mismatches and duplicate names" $ do
      providerName <- expectName "Fixture.duplicate"
      let source = unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          missingRole = source { Length.lengthProviderArgumentRoles = [] }
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderRoleArityMismatch 1 0)
        $ sealProviderInventory
            Length.defaultLengthLimits [missingRole]
      assertLeft (Length.DuplicateLengthProvider providerName)
        $ sealProviderInventory
            Length.defaultLengthLimits [source, source]
      assertLeft (Length.DuplicateLengthProvider providerName)
        $ sealProviderInventory Length.defaultLengthLimits
            [ source
            , source { Length.lengthProviderArgumentRoles = [] }
            ]
  , testCase "canonicalize source order without losing deterministic name order" $ do
      alpha <- expectName "Fixture.alpha"
      beta <- expectName "Fixture.beta"
      let first = unaryListProvider alpha Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          second = unaryListProvider beta Length.LengthSpineArgument
            (Length.LengthScale 2
              $ Length.LengthVariable $ Length.LengthProviderArgument 0)
      forward <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [first, second]
      reverseOrder <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [second, first]
      Length.lengthProviderInventoryFingerprint forward @?=
        Length.lengthProviderInventoryFingerprint reverseOrder
      map Length.checkedLengthProviderName
          (Length.checkedLengthProviderSummaries forward) @?=
        sort [alpha, beta]
      map Length.checkedLengthProviderName
          (Length.checkedLengthProviderSummaries reverseOrder) @?=
        sort [alpha, beta]
  , testCase "enforce provider count, argument count, and fingerprint bounds" $ do
      providerName <- expectName "Fixture.bounded"
      let source = unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          noSummaries = limitsWith $ \limits -> limits
            { Length.lengthLimitSourceProviderSummaries = 0 }
          noArguments = limitsWith $ \limits -> limits
            { Length.lengthLimitSourceProviderArguments = 0 }
          noFingerprint = limitsWith $ \limits -> limits
            { Length.lengthLimitSourceFingerprintBytes = 0 }
      assertLeft (Length.LengthProviderSummaryLimitExceeded 0 1)
        $ sealProviderInventory noSummaries [source]
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderArgumentLimitExceeded 0 1)
        $ sealProviderInventory noArguments [source]
      assertLeft
        (Length.LengthProviderInventoryFingerprintLimitExceeded 0 1)
        $ sealProviderInventory noFingerprint
            ([] :: [Length.LengthProviderSummarySource String])
  ]

evaluationTests :: TestTree
evaluationTests = testGroup "solver-neutral concrete replay"
  [ testCase "validate evaluation limits in declaration order" $ do
      Evaluate.mkLengthEvaluationLimits
          Evaluate.defaultLengthEvaluationLimitSource @?=
        Right Evaluate.defaultLengthEvaluationLimits
      Evaluate.lengthAssignmentValueBitLimit
          Evaluate.defaultLengthEvaluationLimits @?= 4096
      Evaluate.lengthIntermediateValueBitLimit
          Evaluate.defaultLengthEvaluationLimits @?= 4096
      let bothNegative = Evaluate.LengthEvaluationLimitSource
            { Evaluate.lengthEvaluationLimitSourceAssignmentValueBits = -1
            , Evaluate.lengthEvaluationLimitSourceIntermediateValueBits = -2
            }
          secondNegative = bothNegative
            { Evaluate.lengthEvaluationLimitSourceAssignmentValueBits = 0 }
          allZero = secondNegative
            { Evaluate.lengthEvaluationLimitSourceIntermediateValueBits = 0 }
      Evaluate.mkLengthEvaluationLimits bothNegative @?= Left
        (Evaluate.NegativeLengthEvaluationLimit
          Evaluate.LengthAssignmentValueBits (-1))
      Evaluate.mkLengthEvaluationLimits secondNegative @?= Left
        (Evaluate.NegativeLengthEvaluationLimit
          Evaluate.LengthIntermediateValueBits (-2))
      limits <- expectRight $ Evaluate.mkLengthEvaluationLimits allZero
      map ($ limits)
          [ Evaluate.lengthAssignmentValueBitLimit
          , Evaluate.lengthIntermediateValueBitLimit
          ] @?= [0, 0]
  , testCase "classify the three contract outcomes exactly" $ do
      let input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          source = contractWith
            (Length.LengthAtMost input $ Length.LengthLiteral 2)
            (Length.LengthEqual result
              $ Length.LengthSum [input, Length.LengthLiteral 1])
          target = FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
      contract <- expectRight $ sealContract
        Length.defaultLengthLimits target source
      let replay inputs observedResult =
            Evaluate.evaluateLengthContractAssignment
              Evaluate.defaultLengthEvaluationLimits contract
              $ Evaluate.LengthContractAssignment inputs observedResult
      replay [3] 99 @?= Right Evaluate.LengthPreconditionNotMet
      replay [1] 2 @?= Right Evaluate.LengthPostconditionSatisfied
      replay [1] 3 @?= Right Evaluate.LengthPostconditionViolated
      [ Evaluate.LengthPreconditionNotMet
        , Evaluate.LengthPostconditionSatisfied
        , Evaluate.LengthPostconditionViolated
        ] @?= [minBound .. maxBound]
  , testCase "reject contract assignment arity before inspecting values" $ do
      let target = FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
      contract <- expectRight $ sealContract
        Length.defaultLengthLimits target identityLengthContract
      let replay inputs = Evaluate.evaluateLengthContractAssignment
            Evaluate.defaultLengthEvaluationLimits contract
            $ Evaluate.LengthContractAssignment inputs 0
      replay [] @?= Left
        (Evaluate.LengthContractAssignmentArityMismatch 1 0)
      replay [0, 2 ^ (5000 :: Int)] @?= Left
        (Evaluate.LengthContractAssignmentArityMismatch 1 2)
  , testCase "reject cyclic assignments at the first excess cell" $ do
      providerName <- expectName "Fixture.cyclicReplay"
      let target = FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
          cyclicInputs = 0 : cyclicInputs
          cyclicArguments =
            Evaluate.ObservedSpineLength 0 : cyclicArguments
          provider = unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      contract <- expectRight $ sealContract
        Length.defaultLengthLimits target identityLengthContract
      checkedProvider <- expectCheckedProvider provider
      contractResult <- evaluateWithin
        $ Evaluate.evaluateLengthContractAssignment
            Evaluate.defaultLengthEvaluationLimits contract
            $ Evaluate.LengthContractAssignment cyclicInputs 0
      providerResult <- evaluateWithin
        $ Evaluate.evaluateLengthProviderApplication
            Evaluate.defaultLengthEvaluationLimits checkedProvider
            cyclicArguments
      contractResult @?= Left
        (Evaluate.LengthContractAssignmentArityMismatch 1 2)
      providerResult @?= Left
        (Evaluate.LengthProviderAssignmentArityMismatch 1 2)
  , testCase
      "require conditional discharge before demanding provider arguments" $ do
      className <- expectName "Fixture.EvaluationConditionalConstraint"
      providerName <- expectName "Fixture.evaluationConditionalProvider"
      let scheme = ForallType [] [Constraint className []] $ FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
          source = conditionalProviderSource providerName scheme
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          classDeclaration :: Declaration String () ()
          classDeclaration = ClassDeclaration () className [] [] []
          poisonArguments :: [Evaluate.LengthProviderArgumentValue]
          poisonArguments = error "conditional replay demanded arguments"
      inventory <- expectRight $ mkInventory ClosedKindInventory
        [ classDeclaration
        , ValueDeclaration $ ValueSignature () providerName scheme
        ]
      checkedInventory <- expectRight $ Length.sealLengthProviderInventory
        Length.defaultLengthLimits inventory [source]
      checked <- case Length.lookupCheckedLengthProviderSummary
          providerName checkedInventory of
        Nothing -> assertFailure "conditional replay provider disappeared"
        Just summary -> pure summary
      observed <- evaluateWithin $ Evaluate.evaluateLengthProviderApplication
        Evaluate.defaultLengthEvaluationLimits checked poisonArguments
      assertLeft
        Evaluate.LengthEvaluationConditionalProviderRequiresDischarge observed
  , testCase "enforce assignment and intermediate bit bounds by site" $ do
      let target = FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
          four = 4
          inputLimits = evaluationLimitsWith 2 8
      contract <- expectRight $ sealContract
        Length.defaultLengthLimits target identityLengthContract
      Evaluate.evaluateLengthContractAssignment inputLimits contract
          (Evaluate.LengthContractAssignment [four] 0) @?= Left
        (Evaluate.LengthEvaluationValueBitLimitExceeded
          (Evaluate.LengthContractInputValue 0) 2 3)
      Evaluate.evaluateLengthContractAssignment inputLimits contract
          (Evaluate.LengthContractAssignment [0] four) @?= Left
        (Evaluate.LengthEvaluationValueBitLimitExceeded
          Evaluate.LengthContractResultValue 2 3)

      providerName <- expectName "Fixture.bitBounded"
      let transfer = Length.LengthScale 2
            $ Length.LengthVariable $ Length.LengthProviderArgument 0
          provider = unaryListProvider providerName
            Length.LengthSpineArgument transfer
      checked <- expectCheckedProvider provider
      Evaluate.evaluateLengthProviderApplication inputLimits checked
          [Evaluate.ObservedSpineLength four] @?= Left
        (Evaluate.LengthEvaluationValueBitLimitExceeded
          (Evaluate.LengthProviderSpineValue 0) 2 3)
      let intermediateLimits = evaluationLimitsWith 3 3
      Evaluate.evaluateLengthProviderApplication intermediateLimits checked
          [Evaluate.ObservedSpineLength four] @?= Left
        (Evaluate.LengthEvaluationValueBitLimitExceeded
          Evaluate.LengthIntermediateValue 3 4)
  , testCase "report multi-input assignment bounds from left to right" $ do
      let target = FunctionType
            (listOf closedPayloadType)
            $ FunctionType
                (listOf closedPayloadType) (listOf closedPayloadType)
          limits = evaluationLimitsWith 2 8
      contract <- expectRight $ sealContract
        Length.defaultLengthLimits target trivialLengthContract
      let replay inputs result = Evaluate.evaluateLengthContractAssignment
            limits contract $ Evaluate.LengthContractAssignment inputs result
      replay [4, 8] 16 @?= Left
        (Evaluate.LengthEvaluationValueBitLimitExceeded
          (Evaluate.LengthContractInputValue 0) 2 3)
      replay [0, 4] 8 @?= Left
        (Evaluate.LengthEvaluationValueBitLimitExceeded
          (Evaluate.LengthContractInputValue 1) 2 3)
      replay [0, 0] 4 @?= Left
        (Evaluate.LengthEvaluationValueBitLimitExceeded
          Evaluate.LengthContractResultValue 2 3)
  , testCase "enforce exact provider arity and observed-role boundaries" $ do
      providerName <- expectName "Fixture.rolesReplay"
      let scheme = FunctionType
            (listOf closedPayloadType)
            $ FunctionType closedPayloadType (listOf closedPayloadType)
          provider = providerSource providerName scheme
            [ Length.LengthSpineArgument
            , Length.LengthUnobservedArgument
            ]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      checked <- expectCheckedProvider provider
      let replay = Evaluate.evaluateLengthProviderApplication
            Evaluate.defaultLengthEvaluationLimits checked
      replay [] @?= Left
        (Evaluate.LengthProviderAssignmentArityMismatch 2 0)
      replay
          [ Evaluate.ObservedSpineLength 1
          , Evaluate.UnobservedLengthArgument
          , Evaluate.UnobservedLengthArgument
          ] @?= Left
        (Evaluate.LengthProviderAssignmentArityMismatch 2 3)
      replay
          [ Evaluate.UnobservedLengthArgument
          , Evaluate.UnobservedLengthArgument
          ] @?= Left
        (Evaluate.LengthProviderArgumentRoleMismatch 0
          Length.LengthSpineArgument Evaluate.UnobservedLengthArgument)
      replay
          [Evaluate.ObservedSpineLength 1, Evaluate.ObservedSpineLength 2] @?=
        Left (Evaluate.LengthProviderArgumentRoleMismatch 1
          Length.LengthUnobservedArgument
          $ Evaluate.ObservedSpineLength 2)
      replay
          [Evaluate.ObservedSpineLength 7, Evaluate.UnobservedLengthArgument]
        @?= Right 7
  , testCase "evaluate natural quotient and operators without integers" $ do
      providerName <- expectName "Fixture.operatorReplay"
      let input = Length.LengthVariable $ Length.LengthProviderArgument 0
          transfer = Length.LengthSum
            [ Length.LengthScale 2 input
            , Length.LengthQuotient 3 input
            , Length.LengthModulo 3 input
            , Length.LengthMonus (Length.LengthLiteral 3)
                (Length.LengthLiteral 5)
            , Length.LengthMinimum
                (Length.LengthLiteral 7) (Length.LengthLiteral 2)
            , Length.LengthMaximum
                (Length.LengthLiteral 1) (Length.LengthLiteral 6)
            ]
          provider = unaryListProvider providerName
            Length.LengthSpineArgument transfer
      checked <- expectCheckedProvider provider
      Evaluate.evaluateLengthProviderApplication
          Evaluate.defaultLengthEvaluationLimits checked
          [Evaluate.ObservedSpineLength 4] @?= Right 18
  , testCase "agree with direct Natural quot across small inputs" $ do
      providerName <- expectName "Fixture.smallNaturalDifferential"
      let input = Length.LengthVariable $ Length.LengthProviderArgument 0
          condition = Length.LengthAll
            [ Length.LengthAtMost input $ Length.LengthLiteral 4
            , Length.LengthNot
                $ Length.LengthEqual input $ Length.LengthLiteral 2
            ]
          transfer = Length.LengthIf condition
            (Length.LengthSum
              [ Length.LengthScale 2 input
              , Length.LengthQuotient 3 input
              , Length.LengthModulo 3 input
              , Length.LengthMonus
                  (Length.LengthLiteral 5) input
              , Length.LengthMinimum input $ Length.LengthLiteral 3
              ])
            (Length.LengthMaximum input $ Length.LengthLiteral 4)
          expected value
            | value <= 4 && value /= 2 =
                2 * value
                  + value `quot` 3
                  + value `mod` 3
                  + (if value <= 5 then 5 - value else 0)
                  + min value 3
            | otherwise = max value 4
          provider = unaryListProvider providerName
            Length.LengthSpineArgument transfer
      checked <- expectCheckedProvider provider
      mapM_ (\value ->
        Evaluate.evaluateLengthProviderApplication
            Evaluate.defaultLengthEvaluationLimits checked
            [Evaluate.ObservedSpineLength value] @?= Right (expected value))
        [0 .. 12]
  , testCase "skip dead if branches and short-circuit conjunctions" $ do
      providerName <- expectName "Fixture.shortCircuit"
      let input = Length.LengthVariable $ Length.LengthProviderArgument 0
          dangerous = Length.LengthScale 8
            $ Length.LengthMaximum input $ Length.LengthLiteral 1
          firstClause = Length.LengthEqual input $ Length.LengthLiteral 1
          dangerousClause = Length.LengthEqual dangerous
            $ Length.LengthLiteral 0
          transfer = Length.LengthIf
            (Length.LengthAll [firstClause, dangerousClause])
            (Length.LengthLiteral 8)
            (Length.LengthLiteral 1)
          provider = unaryListProvider providerName
            Length.LengthSpineArgument transfer
          tightLimits = evaluationLimitsWith 4 1
      checked <- expectCheckedProvider provider
      Evaluate.evaluateLengthProviderApplication tightLimits checked
          [Evaluate.ObservedSpineLength 0] @?= Right 1
      Evaluate.evaluateLengthProviderApplication tightLimits checked
          [Evaluate.ObservedSpineLength 1] @?= Left
        (Evaluate.LengthEvaluationValueBitLimitExceeded
          Evaluate.LengthIntermediateValue 1 2)
  ]

normalizationTests :: TestTree
normalizationTests = testGroup "normalization"
  [ testCase "make conjunction and additive permutations idempotent" $ do
      let target = FunctionType
            (listOf closedPayloadType)
            (listOf closedPayloadType)
          input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          lowerBound = Length.LengthAtMost (Length.LengthLiteral 1) input
          fixedPoint = Length.LengthEqual input input
          leftSource = contractWith
            (Length.LengthAll
              [ fixedPoint
              , lowerBound
              , fixedPoint
              , Length.LengthTruth True
              ])
            (Length.LengthEqual result
              $ Length.LengthSum
                  [input, Length.LengthLiteral 0, Length.LengthLiteral 1])
          rightSource = contractWith
            (Length.LengthAll
              [ Length.LengthAll [lowerBound, fixedPoint]
              , fixedPoint
              ])
            (Length.LengthEqual
              (Length.LengthSum
                [Length.LengthLiteral 1, input, Length.LengthLiteral 0])
              result)
      left <- expectRight $ sealContract
        Length.defaultLengthLimits target leftSource
      right <- expectRight $ sealContract
        Length.defaultLengthLimits target rightSource
      Length.checkedLengthContractPrecondition left @?=
        Length.checkedLengthContractPrecondition right
      Length.checkedLengthContractPostcondition left @?=
        Length.checkedLengthContractPostcondition right
      Length.lengthContractFingerprint left @?=
        Length.lengthContractFingerprint right
      resealed <- expectRight $ sealContract
        Length.defaultLengthLimits
        (Length.checkedLengthContractTarget left)
        Length.LengthContractSource
          { Length.lengthContractPrecondition =
              Length.checkedLengthContractPrecondition left
          , Length.lengthContractPostcondition =
              Length.checkedLengthContractPostcondition left
          }
      Length.checkedLengthContractPrecondition resealed @?=
        Length.checkedLengthContractPrecondition left
      Length.checkedLengthContractPostcondition resealed @?=
        Length.checkedLengthContractPostcondition left
      Length.lengthContractFingerprint resealed @?=
        Length.lengthContractFingerprint left
  , testCase "keep alpha-renamed impredicative payloads opaque" $ do
      let firstPayload = ForallType ["a"] [] $ FunctionType
            (TypeVariable "a") (TypeVariable "a")
          secondPayload = ForallType ["renamed"] [] $ FunctionType
            (TypeVariable "renamed") (TypeVariable "renamed")
      first <- expectRight $ sealContract
        Length.defaultLengthLimits
        (listOf firstPayload) trivialLengthContract
      second <- expectRight $ sealContract
        Length.defaultLengthLimits
        (listOf secondPayload) trivialLengthContract
      Length.lengthContractFingerprint first @?=
        Length.lengthContractFingerprint second
  , testCase "canonicalize minimum and maximum association and order" $ do
      let target = FunctionType
            (listOf closedPayloadType)
            (listOf closedPayloadType)
          input = Length.LengthVariable $ Length.LengthInput 0
          result = Length.LengthVariable Length.LengthResult
          firstSource = contractWith (Length.LengthTruth True)
            (Length.LengthAll
              [ Length.LengthEqual result
                  (Length.LengthMinimum input
                    $ Length.LengthMinimum
                        (Length.LengthLiteral 3) result)
              , Length.LengthEqual input
                  (Length.LengthMaximum result
                    $ Length.LengthMaximum
                        (Length.LengthLiteral 2) input)
              ])
          reassociated = contractWith (Length.LengthTruth True)
            (Length.LengthAll
              [ Length.LengthEqual input
                  (Length.LengthMaximum
                    (Length.LengthMaximum input
                      $ Length.LengthLiteral 2)
                    result)
              , Length.LengthEqual result
                  (Length.LengthMinimum
                    (Length.LengthMinimum result input)
                    $ Length.LengthLiteral 3)
              ])
      first <- expectRight $ sealContract
        Length.defaultLengthLimits target firstSource
      second <- expectRight $ sealContract
        Length.defaultLengthLimits target reassociated
      Length.checkedLengthContractPostcondition first @?=
        Length.checkedLengthContractPostcondition second
      Length.lengthContractFingerprint first @?=
        Length.lengthContractFingerprint second
  ]

productiveBoundTests :: TestTree
productiveBoundTests = testGroup "productive bounded traversal"
  [ testCase "stop on a cyclic target at the first type node past the bound" $ do
      let limits = limitsWith $ \source -> source
            { Length.lengthLimitSourceTypeNodes = 4 }
          cyclicTarget = FunctionType
            (listOf closedPayloadType) cyclicTarget
      observed <- evaluateWithin $ sealContract
        limits cyclicTarget trivialLengthContract
      assertLeft
        (Length.LengthContractTargetBoundError
          $ Length.LengthTypeNodeLimitExceeded 4 5)
        observed
  , testCase "stop on a cyclic formula AST at the first node past the bound" $ do
      let limits = limitsWith $ \limitSource -> limitSource
            { Length.lengthLimitSourceSyntaxNodes = 3 }
          cyclicFormula = Length.LengthNot cyclicFormula
          source = contractWith cyclicFormula (Length.LengthTruth True)
      observed <- evaluateWithin $ sealContract
        limits (listOf closedPayloadType) source
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthSyntaxNodeLimitExceeded 3 4)
        observed
  , testCase "stop on cyclic sum terms at collection width plus one" $ do
      let limits = limitsWith $ \limitSource -> limitSource
            { Length.lengthLimitSourceCollectionWidth = 1 }
          cyclicTerms = Length.LengthLiteral 0 : cyclicTerms
          source = contractWith
            (Length.LengthEqual
              (Length.LengthSum cyclicTerms)
              (Length.LengthLiteral 0))
            (Length.LengthTruth True)
      observed <- evaluateWithin $ sealContract
        limits (listOf closedPayloadType) source
      assertLeft
        (Length.LengthContractPreconditionError
          $ Length.LengthSyntaxCollectionLimitExceeded
              Length.LengthSumTerms 1 2)
        observed
  , testCase "stop on a cyclic provider source list at max plus one" $ do
      providerName <- expectName "Fixture.cyclic"
      let limits = limitsWith $ \source -> source
            { Length.lengthLimitSourceProviderSummaries = 1 }
          provider = unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          cyclicProviders = provider : cyclicProviders
          inventory = providerFixtureInventory [provider]
      observed <- evaluateWithin $ Length.sealLengthProviderInventory
        limits inventory cyclicProviders
      assertLeft (Length.LengthProviderSummaryLimitExceeded 1 2) observed
  , testCase "stop on a cyclic role list at the argument bound" $ do
      providerName <- expectName "Fixture.cyclicRoles"
      let roles = Length.LengthSpineArgument : roles
          provider = (unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0))
              { Length.lengthProviderArgumentRoles = roles }
      observed <- evaluateWithin $ sealProviderInventory
        Length.defaultLengthLimits [provider]
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderArgumentLimitExceeded 16 17)
        observed
  , testCase "stop on cyclic target roles at the contract bound" $ do
      let roles = Length.LengthObservedSpine : roles
          target = FunctionType
            (listOf closedPayloadType) (listOf closedPayloadType)
      observed <- evaluateWithin $ Length.sealRoleAwareLengthContract
        Length.defaultLengthLimits fixtureInventory roles target
        trivialLengthContract
      assertLeft
        (Length.LengthContractTargetArgumentRoleLimitExceeded 8 9)
        observed
      sessionObserved <- evaluateWithin
        $ LengthProblem.sealRoleAwareLengthSession
            Length.defaultLengthLimits roles
            (sessionInventory () []) Length.BuiltinListSpine []
      assertLeft
        (LengthProblem.LengthSessionTargetArgumentRoleLimitExceeded 8 9)
        sessionObserved
  , testCase "stop on a cyclic provider transfer at the syntax bound" $ do
      providerName <- expectName "Fixture.cyclicTransfer"
      let limits = limitsWith $ \source -> source
            { Length.lengthLimitSourceSyntaxNodes = 3 }
          transfer = Length.LengthScale 1 transfer
          provider = unaryListProvider providerName
            Length.LengthSpineArgument transfer
      observed <- evaluateWithin $ sealProviderInventory limits [provider]
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderTransferError
          $ Length.LengthSyntaxNodeLimitExceeded 3 4)
        observed
  , testCase "validate semantically discarded provider subtrees" $ do
      providerName <- expectName "Fixture.discardedTransfer"
      let limits = limitsWith $ \source -> source
            { Length.lengthLimitSourceSyntaxNodes = 4 }
          cyclic = Length.LengthScale 1 cyclic
          conditional = unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthIf
              (Length.LengthTruth True)
              (Length.LengthLiteral 0)
              cyclic)
          scaledAway = unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthScale 0 cyclic)
      conditionalResult <- evaluateWithin
        $ sealProviderInventory limits [conditional]
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderTransferError
          $ Length.LengthSyntaxNodeLimitExceeded 4 5)
        conditionalResult
      scaledResult <- evaluateWithin
        $ sealProviderInventory limits [scaledAway]
      assertLeft
        (Length.LengthProviderSummaryRejected 0 providerName
          $ Length.LengthProviderTransferError
          $ Length.LengthSyntaxNodeLimitExceeded 4 5)
        scaledResult
  ]

fingerprintTests :: TestTree
fingerprintTests = testGroup "identity sensitivity"
  [ testCase "abstract opaque payloads but distinguish behavioral formulas" $ do
      let firstTarget = listOf closedPayloadType
          secondTarget = listOf
            (FunctionType closedPayloadType closedPayloadType)
          stronger = contractWith (Length.LengthTruth True)
            (Length.LengthEqual
              (Length.LengthVariable Length.LengthResult)
              (Length.LengthLiteral 1))
      baseline <- expectRight $ sealContract
        Length.defaultLengthLimits firstTarget trivialLengthContract
      differentPayload <- expectRight $ sealContract
        Length.defaultLengthLimits secondTarget trivialLengthContract
      differentFormula <- expectRight $ sealContract
        Length.defaultLengthLimits firstTarget stronger
      assertBool "opaque payload leaked into length-contract identity" $
        Length.lengthContractFingerprint baseline ==
          Length.lengthContractFingerprint differentPayload
      assertBool "behavioral formula was omitted from contract identity" $
        Length.lengthContractFingerprint baseline /=
          Length.lengthContractFingerprint differentFormula
  , testCase "distinguish the ordered contract input spine" $ do
      nullary <- expectRight $ sealContract
        Length.defaultLengthLimits
        (listOf closedPayloadType) trivialLengthContract
      unary <- expectRight $ sealContract
        Length.defaultLengthLimits
        (FunctionType
          (listOf closedPayloadType)
          (listOf closedPayloadType))
        trivialLengthContract
      assertBool "contract input arity was omitted from identity" $
        Length.lengthContractFingerprint nullary /=
          Length.lengthContractFingerprint unary
  , testCase
      "bind every mixed target role while compacting observed inputs" $ do
      let spine = listOf closedPayloadType
          target = FunctionType spine $ FunctionType spine spine
          firstRoles =
            [ Length.LengthUnobservedTarget
            , Length.LengthObservedSpine
            ]
          secondRoles = reverse firstRoles
      first <- expectRight $ Length.sealRoleAwareLengthContract
        Length.defaultLengthLimits fixtureInventory firstRoles target
        identityLengthContract
      second <- expectRight $ Length.sealRoleAwareLengthContract
        Length.defaultLengthLimits fixtureInventory secondRoles target
        identityLengthContract
      Length.checkedLengthContractInputCount first @?= 1
      Length.checkedLengthContractInputCount second @?= 1
      assertBool "target-role order was omitted from contract identity" $
        Length.lengthContractFingerprint first /=
          Length.lengthContractFingerprint second
  , testCase "exclude admission limits from contract and inventory identity" $ do
      providerName <- expectName "Fixture.limitIndependent"
      let tightLimits = limitsWith $ \source -> source
            { Length.lengthLimitSourceTypeNodes = 32
            , Length.lengthLimitSourceContractInputs = 1
            , Length.lengthLimitSourceSyntaxNodes = 16
            , Length.lengthLimitSourceFormulaClauses = 8
            , Length.lengthLimitSourceCollectionWidth = 8
            , Length.lengthLimitSourceProviderSummaries = 1
            , Length.lengthLimitSourceProviderArguments = 1
            , Length.lengthLimitSourceLiteralBits = 8
            , Length.lengthLimitSourceFingerprintBytes = 65535
            }
          target = FunctionType
            (listOf closedPayloadType)
            (listOf closedPayloadType)
          provider = unaryListProvider providerName
            Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      defaultContract <- expectRight $ sealContract
        Length.defaultLengthLimits target identityLengthContract
      tightContract <- expectRight $ sealContract
        tightLimits target identityLengthContract
      defaultInventory <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [provider]
      tightInventory <- expectRight $ sealProviderInventory
        tightLimits [provider]
      Length.lengthContractFingerprint defaultContract @?=
        Length.lengthContractFingerprint tightContract
      Length.lengthProviderInventoryFingerprint defaultInventory @?=
        Length.lengthProviderInventoryFingerprint tightInventory
  , testCase "identify alpha-equivalent closed provider schemes" $ do
      providerName <- expectName "Fixture.alphaEquivalent"
      let scheme binder = ForallType [binder] [] $ FunctionType
            (listOf $ TypeVariable binder)
            (listOf $ TypeVariable binder)
          source binder = providerSource providerName (scheme binder)
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      first <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [source "element"]
      renamed <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [source "renamed"]
      Length.lengthProviderInventoryFingerprint first @?=
        Length.lengthProviderInventoryFingerprint renamed
  , testCase "retain ordered provider argument roles in identity" $ do
      providerName <- expectName "Fixture.roles"
      let scheme = FunctionType
            (listOf closedPayloadType)
            (FunctionType
              (listOf closedPayloadType)
              (listOf closedPayloadType))
          source roles = providerSource providerName scheme roles
            (Length.LengthLiteral 0)
      first <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits
        [source
          [ Length.LengthSpineArgument
          , Length.LengthUnobservedArgument
          ]]
      swapped <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits
        [source
          [ Length.LengthUnobservedArgument
          , Length.LengthSpineArgument
          ]]
      assertBool "ordered provider roles were omitted from identity" $
        Length.lengthProviderInventoryFingerprint first /=
          Length.lengthProviderInventoryFingerprint swapped
  , testCase "distinguish provider name, scheme, and assumed transfer" $ do
      firstName <- expectName "Fixture.first"
      secondName <- expectName "Fixture.second"
      let identitySource = unaryListProvider firstName
            Length.LengthSpineArgument
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          renamedSource = identitySource
            { Length.lengthProviderName = secondName }
          scaledSource = identitySource
            { Length.lengthProviderTransfer = Length.LengthScale 2
                $ Length.LengthVariable $ Length.LengthProviderArgument 0 }
          changedScheme = providerSource firstName
            (FunctionType
              (listOf closedPayloadType)
              (listOf $ FunctionType
                closedPayloadType closedPayloadType))
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
      baseline <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [identitySource]
      renamed <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [renamedSource]
      scaled <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [scaledSource]
      changed <- expectRight $ sealProviderInventory
        Length.defaultLengthLimits [changedScheme]
      let baselineFingerprint =
            Length.lengthProviderInventoryFingerprint baseline
      assertBool "provider name was omitted from inventory identity" $
        baselineFingerprint /= Length.lengthProviderInventoryFingerprint renamed
      assertBool "provider transfer was omitted from inventory identity" $
        baselineFingerprint /= Length.lengthProviderInventoryFingerprint scaled
      assertBool "provider scheme was omitted from inventory identity" $
        baselineFingerprint /= Length.lengthProviderInventoryFingerprint changed
  , testCase "bind contract and provider identity to recursive-field order" $ do
      typeName <- expectName "Fixture.ModelSensitive"
      zeroName <- expectName "Fixture.ModelZero"
      stepName <- expectName "Fixture.ModelStep"
      providerName <- expectName "Fixture.modelProvider"
      let payload = TypeVariable "element"
          modeled = TypeApplication (TypeConstructor typeName) payload
          providerScheme = ForallType ["element"] []
            $ FunctionType modeled modeled
          provider = providerSource providerName providerScheme
            [Length.LengthSpineArgument]
            (Length.LengthVariable $ Length.LengthProviderArgument 0)
          declarations recursiveFirst =
            [ listLikeDeclaration
                typeName zeroName stepName recursiveFirst
            , ValueDeclaration
                $ ValueSignature () providerName providerScheme
            ]
          source = Length.DeclaredListSpine typeName zeroName stepName
          target = FunctionType
            (TypeApplication (TypeConstructor typeName) closedPayloadType)
            (TypeApplication (TypeConstructor typeName) closedPayloadType)
      payloadFirstContext <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits
        (fixtureInventoryFromDeclarations $ declarations False) source
      recursiveFirstContext <- expectRight $ Length.sealLengthContext
        Length.defaultLengthLimits
        (fixtureInventoryFromDeclarations $ declarations True) source
      payloadFirstContract <- expectRight $ Length.sealLengthContractInContext
        Length.defaultLengthLimits payloadFirstContext target identityLengthContract
      recursiveFirstContract <- expectRight $ Length.sealLengthContractInContext
        Length.defaultLengthLimits recursiveFirstContext target identityLengthContract
      payloadFirstProviders <- expectRight
        $ Length.sealLengthProviderInventoryInContext
            Length.defaultLengthLimits payloadFirstContext [provider]
      recursiveFirstProviders <- expectRight
        $ Length.sealLengthProviderInventoryInContext
            Length.defaultLengthLimits recursiveFirstContext [provider]
      assertBool "spine-field order was omitted from contract identity" $
        Length.lengthContractFingerprint payloadFirstContract /=
          Length.lengthContractFingerprint recursiveFirstContract
      assertBool "spine-field order was omitted from provider identity" $
        Length.lengthProviderInventoryFingerprint payloadFirstProviders /=
          Length.lengthProviderInventoryFingerprint recursiveFirstProviders
  ]

negativeLimitCases
  :: [(String, Length.LengthLimitField, Length.LengthLimitSource)]
negativeLimitCases =
  [ ("type nodes", Length.LengthTypeNodes, defaults
      { Length.lengthLimitSourceTypeNodes = -1 })
  , ("contract inputs", Length.LengthContractInputs, defaults
      { Length.lengthLimitSourceContractInputs = -1 })
  , ("syntax nodes", Length.LengthSyntaxNodes, defaults
      { Length.lengthLimitSourceSyntaxNodes = -1 })
  , ("formula clauses", Length.LengthFormulaClauses, defaults
      { Length.lengthLimitSourceFormulaClauses = -1 })
  , ("collection width", Length.LengthCollectionWidth, defaults
      { Length.lengthLimitSourceCollectionWidth = -1 })
  , ("provider summaries", Length.LengthProviderSummaries, defaults
      { Length.lengthLimitSourceProviderSummaries = -1 })
  , ("provider arguments", Length.LengthProviderArguments, defaults
      { Length.lengthLimitSourceProviderArguments = -1 })
  , ("literal bits", Length.LengthLiteralBits, defaults
      { Length.lengthLimitSourceLiteralBits = -1 })
  , ("fingerprint bytes", Length.LengthFingerprintBytes, defaults
      { Length.lengthLimitSourceFingerprintBytes = -1 })
  ]
 where
  defaults = Length.defaultLengthLimitSource

assertNegativeLimit
  :: (String, Length.LengthLimitField, Length.LengthLimitSource)
  -> IO ()
assertNegativeLimit (label, field, source) =
  case Length.mkLengthLimits source of
    Left failure -> failure @?= Length.NegativeLengthLimit field (-1)
    Right _ -> assertFailure $ "negative " ++ label ++ " limit was accepted"

zeroLengthLimitSource :: Length.LengthLimitSource
zeroLengthLimitSource = Length.LengthLimitSource
  { Length.lengthLimitSourceTypeNodes = 0
  , Length.lengthLimitSourceContractInputs = 0
  , Length.lengthLimitSourceSyntaxNodes = 0
  , Length.lengthLimitSourceFormulaClauses = 0
  , Length.lengthLimitSourceCollectionWidth = 0
  , Length.lengthLimitSourceProviderSummaries = 0
  , Length.lengthLimitSourceProviderArguments = 0
  , Length.lengthLimitSourceLiteralBits = 0
  , Length.lengthLimitSourceFingerprintBytes = 0
  }

limitsWith
  :: (Length.LengthLimitSource -> Length.LengthLimitSource)
  -> Length.LengthLimits
limitsWith transform = case Length.mkLengthLimits
    $ transform Length.defaultLengthLimitSource of
  Left failure -> error $ "invalid test limits: " ++ show failure
  Right limits -> limits

closedPayloadType :: Type String
closedPayloadType = TupleType Boxed []

polymorphicIdentityType :: Type String
polymorphicIdentityType = ForallType ["element"] [] $ FunctionType
  (TypeVariable "element") (TypeVariable "element")

listOf :: Type variable -> Type variable
listOf = TypeApplication $ TypeConstructor listName

identityLengthContract :: Length.LengthContractSource
identityLengthContract = contractWith
  (Length.LengthTruth True)
  (Length.LengthEqual
    (Length.LengthVariable Length.LengthResult)
    (Length.LengthVariable $ Length.LengthInput 0))

successorLengthContract :: Length.LengthContractSource
successorLengthContract = contractWith
  (Length.LengthTruth True)
  (Length.LengthEqual
    (Length.LengthVariable Length.LengthResult)
    (Length.LengthSum
      [ Length.LengthVariable $ Length.LengthInput 0
      , Length.LengthLiteral 1
      ]))

trivialLengthContract :: Length.LengthContractSource
trivialLengthContract = contractWith
  (Length.LengthTruth True) (Length.LengthTruth True)

contractWith
  :: Length.LengthFormula Length.LengthContractVariable
  -> Length.LengthFormula Length.LengthContractVariable
  -> Length.LengthContractSource
contractWith precondition postcondition = Length.LengthContractSource
  { Length.lengthContractPrecondition = precondition
  , Length.lengthContractPostcondition = postcondition
  }

trivialSpinePairContract :: Length.LengthSpinePairContractSource
trivialSpinePairContract = spinePairContractWith
  (Length.LengthTruth True) (Length.LengthTruth True)

firstIdentitySpinePairContract :: Length.LengthSpinePairContractSource
firstIdentitySpinePairContract = spinePairContractWith
  (Length.LengthTruth True)
  (Length.LengthEqual
    (pairResultVariable Length.LengthSpinePairFirst)
    (Length.LengthVariable $ Length.LengthSpinePairInput 0))

firstSuccessorSpinePairContract :: Length.LengthSpinePairContractSource
firstSuccessorSpinePairContract = spinePairContractWith
  (Length.LengthTruth True)
  (Length.LengthEqual
    (pairResultVariable Length.LengthSpinePairFirst)
    (Length.LengthSum
      [ Length.LengthVariable $ Length.LengthSpinePairInput 0
      , Length.LengthLiteral 1
      ]))

spinePairContractWith
  :: Length.LengthFormula Length.LengthSpinePairContractVariable
  -> Length.LengthFormula Length.LengthSpinePairContractVariable
  -> Length.LengthSpinePairContractSource
spinePairContractWith precondition postcondition =
  Length.LengthSpinePairContractSource
    { Length.lengthSpinePairContractPrecondition = precondition
    , Length.lengthSpinePairContractPostcondition = postcondition
    }

pairResultVariable
  :: Length.LengthSpinePairComponent
  -> Length.LengthExpression Length.LengthSpinePairContractVariable
pairResultVariable = Length.LengthVariable . Length.LengthSpinePairResult

fixtureInventory :: Inventory String ()
fixtureInventory = fixtureInventoryFromDeclarations []

fixtureInventoryFromDeclarations
  :: [Declaration String () ()]
  -> Inventory String ()
fixtureInventoryFromDeclarations declarations = case mkInventory
    ClosedKindInventory declarations of
  Left failure -> error $ "invalid fixture inventory: " ++ show failure
  Right inventory -> inventory

providerFixtureInventory
  :: [Length.LengthProviderSummarySource String]
  -> Inventory String ()
providerFixtureInventory = fixtureInventoryFromDeclarations
  . uniqueProviderDeclarations []
 where
  uniqueProviderDeclarations _ [] = []
  uniqueProviderDeclarations seen (source : remaining)
    | providerName `elem` seen =
        uniqueProviderDeclarations seen remaining
    | otherwise =
        ValueDeclaration
          (ValueSignature () providerName $ Length.lengthProviderScheme source)
          : uniqueProviderDeclarations (providerName : seen) remaining
   where
    providerName = Length.lengthProviderName source

listLikeDeclaration
  :: Name
  -> Name
  -> Name
  -> Bool
  -> Declaration String () ()
listLikeDeclaration typeName zeroName stepName recursiveFirst =
  DataTypeDeclaration () typeName [TypeParameter "element" Nothing]
    [ DataConstructor () zeroName []
    , DataConstructor () stepName fields
    ]
 where
  payload = TypeVariable "element"
  recursive = TypeApplication (TypeConstructor typeName) payload
  fields
    | recursiveFirst = [recursive, payload]
    | otherwise = [payload, recursive]

sessionInventory
  :: annotation
  -> [Declaration (Variable String) () annotation]
  -> Inventory (Variable String) annotation
sessionInventory _ declarations = case mkInventory
    ClosedKindInventory declarations of
  Left failure -> error $ "invalid session fixture inventory: " ++ show failure
  Right inventory -> inventory

sessionProviderDeclaration
  :: annotation
  -> Length.LengthProviderSummarySource (Variable String)
  -> Declaration (Variable String) () annotation
sessionProviderDeclaration annotation source = ValueDeclaration
  $ ValueSignature annotation
      (Length.lengthProviderName source)
      (Length.lengthProviderScheme source)

sessionUnaryProvider
  :: Name
  -> String
  -> Length.LengthProviderSummarySource (Variable String)
sessionUnaryProvider providerName identity = Length.AssumedProviderSummary
  { Length.lengthProviderName = providerName
  , Length.lengthProviderScheme = ForallType [variable] []
      $ FunctionType
          (sessionListOf $ TypeVariable variable)
          (sessionListOf $ TypeVariable variable)
  , Length.lengthProviderArgumentRoles = [Length.LengthSpineArgument]
  , Length.lengthProviderTransfer = Length.LengthVariable
      $ Length.LengthProviderArgument 0
  }
 where
  variable = FlexibleVariable identity

sessionPayloadType :: Type (Variable String)
sessionPayloadType = TupleType Boxed []

sessionListOf
  :: Type (Variable String)
  -> Type (Variable String)
sessionListOf = TypeApplication $ TypeConstructor listName

type AdversarialIdentity = String
type AdversarialLocal = Int
type AdversarialType = Type (Variable AdversarialIdentity)
type AdversarialGraph = Djex.TermGraph AdversarialType AdversarialLocal
type AdversarialCandidate = Djex.TypedCandidate
  String
  AdversarialType
  AdversarialLocal
  (Djex.Candidate AdversarialType () ())

type AdversarialCertificateGraph =
  InternalCertificateAssociation.CheckedTypeApplicationCertificateGraph
    (Variable AdversarialIdentity)
    AdversarialLocal

associatedProviderScheme :: AdversarialIdentity -> AdversarialType
associatedProviderScheme identity =
  let binder = FlexibleVariable identity
  in ForallType [binder] [] $ adversarialListOf $ TypeVariable binder

associatedProviderSummary
  :: Name
  -> AdversarialType
  -> Length.LengthProviderSummarySource (Variable AdversarialIdentity)
associatedProviderSummary name scheme = Length.AssumedProviderSummary
  { Length.lengthProviderName = name
  , Length.lengthProviderScheme = scheme
  , Length.lengthProviderArgumentRoles = []
  , Length.lengthProviderTransfer = Length.LengthLiteral 0
  }

associatedConditionalProviderSummary
  :: Name
  -> AdversarialType
  -> Length.LengthProviderSummarySource (Variable AdversarialIdentity)
associatedConditionalProviderSummary name scheme =
  Length.AssumedConstraintConditionalProviderSummary
    { Length.lengthProviderName = name
    , Length.lengthProviderScheme = scheme
    , Length.lengthProviderArgumentRoles = []
    , Length.lengthProviderTransfer = Length.LengthLiteral 0
    }

associatedProviderCertificateGraph
  :: Name
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> [Constraint AdversarialType]
  -> Natural
  -> Natural
  -> Natural
  -> Natural
  -> Natural
  -> IO AdversarialCertificateGraph
associatedProviderCertificateGraph owner scheme selected result obligations
    certificateCoordinate baseNode visibleNode baseOccurrence
    visibleOccurrence = do
  argument <- expectRight $ Djex.specifiedVisibleTypeArgument selected
  let certificate = Djex.certificateId certificateCoordinate
      source = Djex.TermGraphSource (Djex.termNodeId visibleNode)
        [ ( Djex.termNodeId baseNode
          , Djex.TermNode scheme
              $ Djex.TypedGlobal (Djex.occurrenceId baseOccurrence) owner
          )
        , ( Djex.termNodeId visibleNode
          , Djex.TermNode result
              $ Djex.TypedVisibleTypeApplication
                  (Djex.occurrenceId visibleOccurrence)
                  (Djex.termNodeId baseNode)
                  argument
                  (Djex.TypeApplicationWitness
                    scheme selected result $ Just (certificate, 0))
          )
        ]
      origin =
        InternalCertificateAssociation.TypeApplicationCertificateOrigin
          certificate owner scheme
          [ InternalCertificate.TypeApplicationCertificateObservation
              0 scheme selected result obligations
          ]
  expectRight $
    InternalCertificateAssociation.sealCheckedTypeApplicationCertificateGraph
      InternalCertificate.defaultTypeApplicationCertificateLimits
      Djex.sharedTypeStructure Djex.defaultTermGraphLimits source [origin]

associatedProviderLetLocalCertificateGraph
  :: Name
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> [Constraint AdversarialType]
  -> IO AdversarialCertificateGraph
associatedProviderLetLocalCertificateGraph owner scheme selected result
    obligations = do
  argument <- expectRight $ Djex.specifiedVisibleTypeArgument selected
  let certificate = Djex.certificateId 7
      source = Djex.TermGraphSource (Djex.termNodeId 3)
        [ ( Djex.termNodeId 0
          , Djex.TermNode scheme
              $ Djex.TypedGlobal (Djex.occurrenceId 0) owner
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode result
              $ Djex.TypedVisibleTypeApplication
                  (Djex.occurrenceId 1)
                  (Djex.termNodeId 0)
                  argument
                  (Djex.TypeApplicationWitness
                    scheme selected result $ Just (certificate, 0))
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode result
              $ Djex.TypedLocal (Djex.occurrenceId 3) 0
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode result
              $ Djex.TypedLet
                  (Djex.TypedPattern
                    (Djex.occurrenceId 2) result $ Djex.TypedBind 0)
                  (Djex.termNodeId 1)
                  (Djex.termNodeId 2)
          )
        ]
      origin = InternalCertificateAssociation.TypeApplicationCertificateOrigin
        certificate owner scheme
        [ InternalCertificate.TypeApplicationCertificateObservation
            0 scheme selected result obligations
        ]
  expectRight $
    InternalCertificateAssociation.sealCheckedTypeApplicationCertificateGraph
      InternalCertificate.defaultTypeApplicationCertificateLimits
      Djex.sharedTypeStructure Djex.defaultTermGraphLimits source [origin]

associatedConditionalGraphWithDirectOwner
  :: Name
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> [Constraint AdversarialType]
  -> IO AdversarialCertificateGraph
associatedConditionalGraphWithDirectOwner owner scheme selected result
    obligations = do
  argument <- expectRight $ Djex.specifiedVisibleTypeArgument selected
  let certificate = Djex.certificateId 7
      source = Djex.TermGraphSource (Djex.termNodeId 3)
        [ ( Djex.termNodeId 0
          , Djex.TermNode scheme
              $ Djex.TypedGlobal (Djex.occurrenceId 0) owner
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode result
              $ Djex.TypedVisibleTypeApplication
                  (Djex.occurrenceId 1)
                  (Djex.termNodeId 0)
                  argument
                  (Djex.TypeApplicationWitness
                    scheme selected result $ Just (certificate, 0))
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode scheme
              $ Djex.TypedGlobal (Djex.occurrenceId 2) owner
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode result
              $ Djex.TypedLet
                  (Djex.TypedPattern
                    (Djex.occurrenceId 3) scheme Djex.TypedWildcard)
                  (Djex.termNodeId 2)
                  (Djex.termNodeId 1)
          )
        ]
      origin = InternalCertificateAssociation.TypeApplicationCertificateOrigin
        certificate owner scheme
        [ InternalCertificate.TypeApplicationCertificateObservation
            0 scheme selected result obligations
        ]
  expectRight $
    InternalCertificateAssociation.sealCheckedTypeApplicationCertificateGraph
      InternalCertificate.defaultTypeApplicationCertificateLimits
      Djex.sharedTypeStructure Djex.defaultTermGraphLimits source [origin]

twoStepAssociatedProviderCertificateGraph
  :: Name
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> [Constraint AdversarialType]
  -> IO AdversarialCertificateGraph
twoStepAssociatedProviderCertificateGraph owner scheme firstSelected
    firstResult secondSelected result obligations = do
  firstArgument <- expectRight $
    Djex.specifiedVisibleTypeArgument firstSelected
  secondArgument <- expectRight $
    Djex.specifiedVisibleTypeArgument secondSelected
  let certificate = Djex.certificateId 7
      source = Djex.TermGraphSource (Djex.termNodeId 2)
        [ ( Djex.termNodeId 0
          , Djex.TermNode scheme
              $ Djex.TypedGlobal (Djex.occurrenceId 0) owner
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode firstResult
              $ Djex.TypedVisibleTypeApplication
                  (Djex.occurrenceId 1)
                  (Djex.termNodeId 0)
                  firstArgument
                  (Djex.TypeApplicationWitness
                    scheme firstSelected firstResult $ Just (certificate, 0))
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode result
              $ Djex.TypedVisibleTypeApplication
                  (Djex.occurrenceId 2)
                  (Djex.termNodeId 1)
                  secondArgument
                  (Djex.TypeApplicationWitness
                    firstResult secondSelected result
                    $ Just (certificate, 1))
          )
        ]
      origin = InternalCertificateAssociation.TypeApplicationCertificateOrigin
        certificate owner scheme
        [ InternalCertificate.TypeApplicationCertificateObservation
            0 scheme firstSelected firstResult []
        , InternalCertificate.TypeApplicationCertificateObservation
            1 firstResult secondSelected result obligations
        ]
  expectRight $
    InternalCertificateAssociation.sealCheckedTypeApplicationCertificateGraph
      InternalCertificate.defaultTypeApplicationCertificateLimits
      Djex.sharedTypeStructure Djex.defaultTermGraphLimits source [origin]

associatedGraphWithDirectConditionalProvider
  :: Name
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> Name
  -> AdversarialType
  -> IO AdversarialCertificateGraph
associatedGraphWithDirectConditionalProvider owner scheme selected result
    conditionalOwner conditionalScheme = do
  argument <- expectRight $ Djex.specifiedVisibleTypeArgument selected
  let certificate = Djex.certificateId 7
      source = Djex.TermGraphSource (Djex.termNodeId 3)
        [ ( Djex.termNodeId 0
          , Djex.TermNode scheme
              $ Djex.TypedGlobal (Djex.occurrenceId 0) owner
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode result
              $ Djex.TypedVisibleTypeApplication
                  (Djex.occurrenceId 1)
                  (Djex.termNodeId 0)
                  argument
                  (Djex.TypeApplicationWitness
                    scheme selected result $ Just (certificate, 0))
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode conditionalScheme
              $ Djex.TypedGlobal (Djex.occurrenceId 2) conditionalOwner
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode result
              $ Djex.TypedLet
                  (Djex.TypedPattern
                    (Djex.occurrenceId 3) conditionalScheme Djex.TypedWildcard)
                  (Djex.termNodeId 2)
                  (Djex.termNodeId 1)
          )
        ]
      origin = InternalCertificateAssociation.TypeApplicationCertificateOrigin
        certificate owner scheme
        [ InternalCertificate.TypeApplicationCertificateObservation
            0 scheme selected result []
        ]
  expectRight $
    InternalCertificateAssociation.sealCheckedTypeApplicationCertificateGraph
      InternalCertificate.defaultTypeApplicationCertificateLimits
      Djex.sharedTypeStructure Djex.defaultTermGraphLimits source [origin]

associatedAdversarialTypedCandidate
  :: Djex.Candidate AdversarialType () ()
  -> AdversarialCertificateGraph
  -> AdversarialCandidate
associatedAdversarialTypedCandidate compatibility checked = unsafeCoerce $
  InternalTypedCandidate.mkCertificateAssociatedTypedCandidate compatibility
    (Right checked :: Either String AdversarialCertificateGraph)

twoRowAssociatedLetCertificateGraph
  :: Name
  -> Name
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> IO AdversarialCertificateGraph
twoRowAssociatedLetCertificateGraph firstOwner secondOwner scheme selected
    result = do
  argument <- expectRight $ Djex.specifiedVisibleTypeArgument selected
  let firstCertificate = Djex.certificateId 7
      secondCertificate = Djex.certificateId 19
      visible node occurrence function certificate =
        ( Djex.termNodeId node
        , Djex.TermNode result
            $ Djex.TypedVisibleTypeApplication
                (Djex.occurrenceId occurrence)
                (Djex.termNodeId function)
                argument
                (Djex.TypeApplicationWitness scheme selected result
                  $ Just (certificate, 0))
        )
      source = Djex.TermGraphSource (Djex.termNodeId 4)
        [ ( Djex.termNodeId 0
          , Djex.TermNode scheme
              $ Djex.TypedGlobal (Djex.occurrenceId 10) firstOwner
          )
        , visible 1 11 0 firstCertificate
        , ( Djex.termNodeId 2
          , Djex.TermNode scheme
              $ Djex.TypedGlobal (Djex.occurrenceId 12) secondOwner
          )
        , visible 3 13 2 secondCertificate
        , ( Djex.termNodeId 4
          , Djex.TermNode result
              $ Djex.TypedLet
                  (Djex.TypedPattern (Djex.occurrenceId 14) result
                    Djex.TypedWildcard)
                  (Djex.termNodeId 1)
                  (Djex.termNodeId 3)
          )
        ]
      origin certificate owner =
        InternalCertificateAssociation.TypeApplicationCertificateOrigin
          certificate owner scheme
          [ InternalCertificate.TypeApplicationCertificateObservation
              0 scheme selected result []
          ]
      -- Deliberately reverse the raw row list.  The sealed carrier must expose
      -- the first let child before its body in rooted structural preorder.
      origins =
        [ origin secondCertificate secondOwner
        , origin firstCertificate firstOwner
        ]
  expectRight $
    InternalCertificateAssociation.sealCheckedTypeApplicationCertificateGraph
      InternalCertificate.defaultTypeApplicationCertificateLimits
      Djex.sharedTypeStructure Djex.defaultTermGraphLimits source origins

certifiedVisibleApplication
  :: (Djex.TermNodeId, Djex.TermNode ty local)
  -> Bool
certifiedVisibleApplication (_, Djex.TermNode _ form) = case form of
  Djex.TypedVisibleTypeApplication _ _ _ witness -> case
      Djex.typeApplicationCertificate witness of
    Just _ -> True
    Nothing -> False
  Djex.TypedLocal{} -> False
  Djex.TypedGlobal{} -> False
  Djex.TypedLambda{} -> False
  Djex.TypedApply{} -> False
  Djex.TypedForallIntroduction{} -> False
  Djex.TypedContextIntroduction{} -> False
  Djex.TypedContextApplication{} -> False
  Djex.TypedImplicitTypeApplication{} -> False
  Djex.TypedTuple{} -> False
  Djex.TypedHole{} -> False
  Djex.TypedLet{} -> False
  Djex.TypedCase{} -> False

exactCaseAssociatedProviderGraph
  :: Name
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> IO (AdversarialCertificateGraph, AdversarialType)
exactCaseAssociatedProviderGraph owner scheme payload spine = do
  selectedArgument <- expectRight $ Djex.specifiedVisibleTypeArgument payload
  let certificate = Djex.certificateId 7
      target = FunctionType spine spine
      zeroPattern = Djex.TypedPattern (Djex.occurrenceId 2) spine
        $ Djex.TypedConstructor listName []
      stepPattern = Djex.TypedPattern (Djex.occurrenceId 5) spine
        $ Djex.TypedConstructor consName
          [ Djex.TypedPattern (Djex.occurrenceId 6) payload
              Djex.TypedWildcard
          , Djex.TypedPattern (Djex.occurrenceId 7) spine
              $ Djex.TypedBind 1
          ]
      source = Djex.TermGraphSource (Djex.termNodeId 5)
        [ ( Djex.termNodeId 0
          , Djex.TermNode spine
              $ Djex.TypedLocal (Djex.occurrenceId 1) 0
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode scheme
              $ Djex.TypedGlobal (Djex.occurrenceId 3) owner
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode spine
              $ Djex.TypedVisibleTypeApplication
                  (Djex.occurrenceId 4) (Djex.termNodeId 1)
                  selectedArgument
                  (Djex.TypeApplicationWitness
                    scheme payload spine $ Just (certificate, 0))
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode spine
              $ Djex.TypedLocal (Djex.occurrenceId 8) 1
          )
        , ( Djex.termNodeId 4
          , Djex.TermNode spine
              $ Djex.TypedCase (Djex.termNodeId 0)
                  [ (zeroPattern, Djex.termNodeId 2)
                  , (stepPattern, Djex.termNodeId 3)
                  ]
          )
        , ( Djex.termNodeId 5
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern (Djex.occurrenceId 0) spine
                      $ Djex.TypedBind 0
                  ]
                  (Djex.termNodeId 4)
          )
        ]
      structure = Djex.sharedTypeStructure
        { Djex.constructorPatternFieldTypes = \name patternType ->
            if patternType /= spine
              then Nothing
              else if name == listName
                then Just []
                else if name == consName
                  then Just [payload, spine]
                  else Nothing
        }
      origin =
        InternalCertificateAssociation.TypeApplicationCertificateOrigin
          certificate owner scheme
          [ InternalCertificate.TypeApplicationCertificateObservation
              0 scheme payload spine []
          ]
  checked <- expectRight $
    InternalCertificateAssociation.sealCheckedTypeApplicationCertificateGraph
      InternalCertificate.defaultTypeApplicationCertificateLimits
      structure Djex.defaultTermGraphLimits source [origin]
  pure (checked, target)

adversarialLengthSession
  :: [Declaration (Variable AdversarialIdentity) () ()]
  -> [Length.LengthProviderSummarySource
        (Variable AdversarialIdentity)]
  -> IO (LengthProblem.CheckedLengthSession AdversarialIdentity ())
adversarialLengthSession declarations providers = expectRight
  $ LengthProblem.sealLengthSession
      Length.defaultLengthLimits
      (sessionInventory () declarations)
      Length.BuiltinListSpine
      providers

adversarialRoleAwareLengthSession
  :: [Length.LengthTargetArgumentRole]
  -> [Declaration (Variable AdversarialIdentity) () ()]
  -> [Length.LengthProviderSummarySource
        (Variable AdversarialIdentity)]
  -> IO (LengthProblem.CheckedLengthSession AdversarialIdentity ())
adversarialRoleAwareLengthSession roles declarations providers = expectRight
  $ LengthProblem.sealRoleAwareLengthSession
      Length.defaultLengthLimits
      roles
      (sessionInventory () declarations)
      Length.BuiltinListSpine
      providers

adversarialExactCaseLengthSession
  :: [Length.LengthTargetArgumentRole]
  -> [Declaration (Variable AdversarialIdentity) () ()]
  -> [Length.LengthProviderSummarySource
        (Variable AdversarialIdentity)]
  -> IO (LengthProblem.CheckedLengthSession AdversarialIdentity ())
adversarialExactCaseLengthSession roles declarations providers = expectRight
  $ LengthProblem.sealExactSpineCaseLengthSession
      Length.defaultLengthLimits
      roles
      (sessionInventory () declarations)
      Length.BuiltinListSpine
      providers

adversarialLengthContract
  :: LengthProblem.CheckedLengthSession AdversarialIdentity ()
  -> AdversarialType
  -> Length.LengthContractSource
  -> IO (Length.CheckedLengthContract
      (Variable AdversarialIdentity))
adversarialLengthContract session target source = expectRight
  $ Length.sealLengthContractInContext
      Length.defaultLengthLimits
      (LengthProblem.checkedLengthSessionContext session)
      target
      source

adversarialRoleAwareLengthContract
  :: LengthProblem.CheckedLengthSession AdversarialIdentity ()
  -> [Length.LengthTargetArgumentRole]
  -> AdversarialType
  -> Length.LengthContractSource
  -> IO (Length.CheckedLengthContract
      (Variable AdversarialIdentity))
adversarialRoleAwareLengthContract session roles target source = expectRight
  $ Length.sealRoleAwareLengthContractInContext
      Length.defaultLengthLimits
      (LengthProblem.checkedLengthSessionContext session)
      roles
      target
      source

adversarialLengthSpinePairContract
  :: LengthProblem.CheckedLengthSession AdversarialIdentity ()
  -> AdversarialType
  -> Length.LengthSpinePairContractSource
  -> IO (Length.CheckedLengthSpinePairContract
      (Variable AdversarialIdentity))
adversarialLengthSpinePairContract session target source = expectRight
  $ Length.sealLengthSpinePairContractInContext
      Length.defaultLengthLimits
      (LengthProblem.checkedLengthSessionContext session)
      target
      source

adversarialRoleAwareLengthSpinePairContract
  :: LengthProblem.CheckedLengthSession AdversarialIdentity ()
  -> [Length.LengthTargetArgumentRole]
  -> AdversarialType
  -> Length.LengthSpinePairContractSource
  -> IO (Length.CheckedLengthSpinePairContract
      (Variable AdversarialIdentity))
adversarialRoleAwareLengthSpinePairContract session roles target source =
  expectRight $ Length.sealRoleAwareLengthSpinePairContractInContext
    Length.defaultLengthLimits
    (LengthProblem.checkedLengthSessionContext session)
    roles
    target
    source

adversarialListOf :: AdversarialType -> AdversarialType
adversarialListOf = TypeApplication $ TypeConstructor listName

adversarialClosedList :: AdversarialType
adversarialClosedList = adversarialListOf $ TupleType Boxed []

adversarialConstantZeroGraph :: IO AdversarialGraph
adversarialConstantZeroGraph = sealAdversarialGraph
  $ Djex.TermGraphSource (Djex.termNodeId 1)
      [ ( Djex.termNodeId 0
        , Djex.TermNode adversarialClosedList
            $ Djex.TypedGlobal (Djex.occurrenceId 1) listName
        )
      , ( Djex.termNodeId 1
        , Djex.TermNode
            (FunctionType adversarialClosedList adversarialClosedList)
            $ Djex.TypedLambda
                [ Djex.TypedPattern
                    (Djex.occurrenceId 0)
                    adversarialClosedList
                    Djex.TypedWildcard
                ]
                (Djex.termNodeId 0)
        )
      ]

adversarialBinaryConstantZeroTarget :: AdversarialType
adversarialBinaryConstantZeroTarget = FunctionType adversarialClosedList
  $ FunctionType adversarialClosedList adversarialClosedList

adversarialBinaryConstantZeroGraph :: IO AdversarialGraph
adversarialBinaryConstantZeroGraph = sealAdversarialGraph
  $ Djex.TermGraphSource (Djex.termNodeId 1)
      [ ( Djex.termNodeId 0
        , Djex.TermNode adversarialClosedList
            $ Djex.TypedGlobal (Djex.occurrenceId 2) listName
        )
      , ( Djex.termNodeId 1
        , Djex.TermNode adversarialBinaryConstantZeroTarget
            $ Djex.TypedLambda
                [ Djex.TypedPattern
                    (Djex.occurrenceId 0)
                    adversarialClosedList
                    Djex.TypedWildcard
                , Djex.TypedPattern
                    (Djex.occurrenceId 1)
                    adversarialClosedList
                    Djex.TypedWildcard
                ]
                (Djex.termNodeId 0)
        )
      ]

adversarialInputSpinePairTarget :: AdversarialType
adversarialInputSpinePairTarget = adversarialInputSpinePairTargetFor
  adversarialClosedList

adversarialInputSpinePairTargetFor :: AdversarialType -> AdversarialType
adversarialInputSpinePairTargetFor spine = FunctionType spine
  $ TupleType Boxed [spine, spine]

adversarialInputAndZeroSpinePairGraph :: IO AdversarialGraph
adversarialInputAndZeroSpinePairGraph =
  adversarialInputAndZeroSpinePairGraphFor adversarialClosedList

adversarialInputAndZeroSpinePairGraphFor
  :: AdversarialType -> IO AdversarialGraph
adversarialInputAndZeroSpinePairGraphFor spine = sealAdversarialGraph
  $ Djex.TermGraphSource (Djex.termNodeId 3)
      [ ( Djex.termNodeId 0
        , Djex.TermNode spine
            $ Djex.TypedLocal (Djex.occurrenceId 1) 0
        )
      , ( Djex.termNodeId 1
        , Djex.TermNode spine
            $ Djex.TypedGlobal (Djex.occurrenceId 2) listName
        )
      , ( Djex.termNodeId 2
        , Djex.TermNode
            (TupleType Boxed
              [spine, spine])
            $ Djex.TypedTuple [Djex.termNodeId 0, Djex.termNodeId 1]
        )
      , ( Djex.termNodeId 3
        , Djex.TermNode (adversarialInputSpinePairTargetFor spine)
            $ Djex.TypedLambda
                [ Djex.TypedPattern
                    (Djex.occurrenceId 0)
                    spine
                    (Djex.TypedBind 0)
                ]
                (Djex.termNodeId 2)
        )
      ]

adversarialZeroAndInputSpinePairGraph :: IO AdversarialGraph
adversarialZeroAndInputSpinePairGraph = sealAdversarialGraph
  $ Djex.TermGraphSource (Djex.termNodeId 3)
      [ ( Djex.termNodeId 0
        , Djex.TermNode adversarialClosedList
            $ Djex.TypedLocal (Djex.occurrenceId 1) 0
        )
      , ( Djex.termNodeId 1
        , Djex.TermNode adversarialClosedList
            $ Djex.TypedGlobal (Djex.occurrenceId 2) listName
        )
      , ( Djex.termNodeId 2
        , Djex.TermNode
            (TupleType Boxed
              [adversarialClosedList, adversarialClosedList])
            $ Djex.TypedTuple [Djex.termNodeId 1, Djex.termNodeId 0]
        )
      , ( Djex.termNodeId 3
        , Djex.TermNode adversarialInputSpinePairTarget
            $ Djex.TypedLambda
                [ Djex.TypedPattern
                    (Djex.occurrenceId 0)
                    adversarialClosedList
                    (Djex.TypedBind 0)
                ]
                (Djex.termNodeId 2)
        )
      ]

type AdversarialCheckedLengthProblem =
  LengthProblem.CheckedLengthProblem AdversarialIdentity AdversarialLocal

type AdversarialLengthSMTLibQuery =
  SMTLib.LengthSMTLibQuery AdversarialIdentity AdversarialLocal

type AdversarialCheckedLengthSpinePairProblem =
  LengthProblem.CheckedLengthSpinePairProblem
    AdversarialIdentity AdversarialLocal

type AdversarialLengthSpinePairSMTLibQuery =
  SMTLib.LengthSpinePairSMTLibQuery AdversarialIdentity AdversarialLocal

scalarCounterexampleBankBridgeFixture
  :: Length.LengthContractSource
  -> IO
      ( (AdversarialCheckedLengthProblem, AdversarialLengthSMTLibQuery)
      , (AdversarialCheckedLengthProblem, AdversarialLengthSMTLibQuery)
      )
scalarCounterexampleBankBridgeFixture contractSource = do
  session <- adversarialLengthSession [] []
  contract <- adversarialLengthContract session
    (FunctionType adversarialClosedList adversarialClosedList)
    contractSource
  zeroGraph <- adversarialConstantZeroGraph
  identityGraph <- sealAdversarialGraph
    $ adversarialIdentityGraphSource adversarialClosedList
  zeroProblem <- sealAdversarialLengthProblem session contract zeroGraph
  identityProblem <- sealAdversarialLengthProblem session contract identityGraph
  zeroQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits zeroProblem
  identityQuery <- expectRight $ SMTLib.sealLengthSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits identityProblem
  pure ((zeroProblem, zeroQuery), (identityProblem, identityQuery))

pairCounterexampleBankBridgeFixture
  :: Length.LengthSpinePairContractSource
  -> IO
      ( ( AdversarialCheckedLengthSpinePairProblem
        , AdversarialLengthSpinePairSMTLibQuery
        )
      , ( AdversarialCheckedLengthSpinePairProblem
        , AdversarialLengthSpinePairSMTLibQuery
        )
      )
pairCounterexampleBankBridgeFixture contractSource = do
  session <- adversarialLengthSession [] []
  contract <- adversarialLengthSpinePairContract session
    adversarialInputSpinePairTarget contractSource
  zeroInputGraph <- adversarialZeroAndInputSpinePairGraph
  inputZeroGraph <- adversarialInputAndZeroSpinePairGraph
  zeroInputProblem <- sealAdversarialLengthSpinePairProblem
    session contract zeroInputGraph
  inputZeroProblem <- sealAdversarialLengthSpinePairProblem
    session contract inputZeroGraph
  zeroInputQuery <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits zeroInputProblem
  inputZeroQuery <- expectRight $ SMTLib.sealLengthSpinePairSMTLibQuery
    SMTLib.defaultLengthSMTLibLimits inputZeroProblem
  pure
    ( (zeroInputProblem, zeroInputQuery)
    , (inputZeroProblem, inputZeroQuery)
    )

sealAdversarialLengthProblem
  :: LengthProblem.CheckedLengthSession AdversarialIdentity ()
  -> Length.CheckedLengthContract (Variable AdversarialIdentity)
  -> AdversarialGraph
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
sealAdversarialLengthProblem session contract graph = expectRight
  $ LengthProblem.sealLengthTypedCandidateProblem
      LengthProblem.defaultLengthProblemLimits session contract
      $ adversarialTypedCandidate $ Right graph

sealAdversarialLengthSpinePairProblem
  :: LengthProblem.CheckedLengthSession AdversarialIdentity ()
  -> Length.CheckedLengthSpinePairContract (Variable AdversarialIdentity)
  -> AdversarialGraph
  -> IO
      (LengthProblem.CheckedLengthSpinePairProblem
        AdversarialIdentity AdversarialLocal)
sealAdversarialLengthSpinePairProblem session contract graph = expectRight
  $ LengthProblem.sealLengthSpinePairTypedCandidateProblem
      LengthProblem.defaultLengthProblemLimits session contract
      $ adversarialTypedCandidate $ Right graph

adversarialBinaryZeroSpinePairTarget :: AdversarialType
adversarialBinaryZeroSpinePairTarget = FunctionType adversarialClosedList
  $ FunctionType adversarialClosedList
  $ TupleType Boxed [adversarialClosedList, adversarialClosedList]

adversarialBinaryZeroSpinePairGraph :: IO AdversarialGraph
adversarialBinaryZeroSpinePairGraph = sealAdversarialGraph
  $ Djex.TermGraphSource (Djex.termNodeId 3)
      [ ( Djex.termNodeId 0
        , Djex.TermNode adversarialClosedList
            $ Djex.TypedGlobal (Djex.occurrenceId 2) listName
        )
      , ( Djex.termNodeId 1
        , Djex.TermNode adversarialClosedList
            $ Djex.TypedGlobal (Djex.occurrenceId 3) listName
        )
      , ( Djex.termNodeId 2
        , Djex.TermNode
            (TupleType Boxed
              [adversarialClosedList, adversarialClosedList])
            $ Djex.TypedTuple [Djex.termNodeId 0, Djex.termNodeId 1]
        )
      , ( Djex.termNodeId 3
        , Djex.TermNode adversarialBinaryZeroSpinePairTarget
            $ Djex.TypedLambda
                [ Djex.TypedPattern
                    (Djex.occurrenceId 0)
                    adversarialClosedList
                    Djex.TypedWildcard
                , Djex.TypedPattern
                    (Djex.occurrenceId 1)
                    adversarialClosedList
                    Djex.TypedWildcard
                ]
                (Djex.termNodeId 2)
        )
      ]

-- The first seal deliberately uses fixture-owned constructor schemas.  The
-- production exact-case sealer does not trust this structure: it freshly
-- re-seals the raw graph from the checked Length session's opaque spine model.
adversarialExactSpineCaseFixture
  :: Name
  -> Name
  -> Bool
  -> IO
      ( LengthProblem.CheckedLengthSession AdversarialIdentity ()
      , Length.CheckedLengthContract (Variable AdversarialIdentity)
      , AdversarialGraph
      )
adversarialExactSpineCaseFixture zeroName stepName reversed = do
  adversarialExactSpineCaseFixtureWithSchema
    zeroName stepName reversed False

adversarialExactSpineCaseFixtureWithSchema
  :: Name
  -> Name
  -> Bool
  -> Bool
  -> IO
      ( LengthProblem.CheckedLengthSession AdversarialIdentity ()
      , Length.CheckedLengthContract (Variable AdversarialIdentity)
      , AdversarialGraph
      )
adversarialExactSpineCaseFixtureWithSchema zeroName stepName reversed
    recursiveFirst = do
  let roles = [Length.LengthObservedSpine]
      payload = TupleType Boxed []
      spine = adversarialListOf payload
      target = FunctionType spine spine
      zeroPattern = Djex.TypedPattern (Djex.occurrenceId 2) spine
        $ Djex.TypedConstructor zeroName []
      stepPattern = Djex.TypedPattern (Djex.occurrenceId 4) spine
        $ Djex.TypedConstructor stepName
          $ if recursiveFirst
            then [tailField, payloadField]
            else [payloadField, tailField]
      payloadField = Djex.TypedPattern (Djex.occurrenceId 5) payload
        Djex.TypedWildcard
      tailField = Djex.TypedPattern (Djex.occurrenceId 6) spine
        $ Djex.TypedBind 1
      alternatives
        | reversed = [(stepPattern, Djex.termNodeId 2),
            (zeroPattern, Djex.termNodeId 1)]
        | otherwise = [(zeroPattern, Djex.termNodeId 1),
            (stepPattern, Djex.termNodeId 2)]
      source = Djex.TermGraphSource (Djex.termNodeId 4)
        [ ( Djex.termNodeId 0
          , Djex.TermNode spine
              $ Djex.TypedLocal (Djex.occurrenceId 1) 0
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode spine
              $ Djex.TypedGlobal (Djex.occurrenceId 3) zeroName
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode spine
              $ Djex.TypedLocal (Djex.occurrenceId 7) 1
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode spine
              $ Djex.TypedCase (Djex.termNodeId 0) alternatives
          )
        , ( Djex.termNodeId 4
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern (Djex.occurrenceId 0) spine
                      $ Djex.TypedBind 0
                  ]
                  (Djex.termNodeId 3)
          )
        ]
      typeStructure = Djex.sharedTypeStructure
        { Djex.constructorPatternFieldTypes = \name patternType ->
            if patternType /= spine
              then Nothing
              else if name == zeroName
                then Just []
                else if name == stepName
                  then Just $ if recursiveFirst
                    then [spine, payload]
                    else [payload, spine]
                  else Nothing
        }
  session <- adversarialExactCaseLengthSession roles [] []
  contract <- adversarialRoleAwareLengthContract
    session roles target identityLengthContract
  graph <- expectRight $ Djex.sealTermGraph
    typeStructure Djex.defaultTermGraphLimits source
  pure (session, contract, graph)

adversarialExactCasePayloadDemandFixture
  :: IO
      ( LengthProblem.CheckedLengthSession AdversarialIdentity ()
      , Length.CheckedLengthContract (Variable AdversarialIdentity)
      , AdversarialGraph
      , Djex.OccurrenceId
      , Djex.TermNodeId
      )
adversarialExactCasePayloadDemandFixture = do
  let roles = [Length.LengthObservedSpine]
      payload = adversarialClosedList
      spine = adversarialListOf payload
      target = FunctionType spine payload
      payloadOccurrence = Djex.occurrenceId 5
      caseNode = Djex.termNodeId 3
      zeroPattern = Djex.TypedPattern (Djex.occurrenceId 2) spine
        $ Djex.TypedConstructor listName []
      stepPattern = Djex.TypedPattern (Djex.occurrenceId 4) spine
        $ Djex.TypedConstructor consName
          [ Djex.TypedPattern payloadOccurrence payload $ Djex.TypedBind 1
          , Djex.TypedPattern (Djex.occurrenceId 6) spine
              Djex.TypedWildcard
          ]
      source = Djex.TermGraphSource (Djex.termNodeId 4)
        [ ( Djex.termNodeId 0
          , Djex.TermNode spine
              $ Djex.TypedLocal (Djex.occurrenceId 1) 0
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode payload
              $ Djex.TypedGlobal (Djex.occurrenceId 3) listName
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode payload
              $ Djex.TypedLocal (Djex.occurrenceId 7) 1
          )
        , ( caseNode
          , Djex.TermNode payload
              $ Djex.TypedCase (Djex.termNodeId 0)
                  [ (zeroPattern, Djex.termNodeId 1)
                  , (stepPattern, Djex.termNodeId 2)
                  ]
          )
        , ( Djex.termNodeId 4
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern (Djex.occurrenceId 0) spine
                      $ Djex.TypedBind 0
                  ]
                  caseNode
          )
        ]
      typeStructure = Djex.sharedTypeStructure
        { Djex.constructorPatternFieldTypes = \name patternType ->
            if patternType /= spine
              then Nothing
              else if name == listName
                then Just []
                else if name == consName
                  then Just [payload, spine]
                  else Nothing
        }
  session <- adversarialExactCaseLengthSession roles [] []
  contract <- adversarialRoleAwareLengthContract
    session roles target trivialLengthContract
  graph <- expectRight $ Djex.sealTermGraph
    typeStructure Djex.defaultTermGraphLimits source
  pure (session, contract, graph, payloadOccurrence, caseNode)

adversarialExactCaseProviderUnionFixture
  :: IO
      ( [Name]
      , LengthProblem.CheckedLengthSession AdversarialIdentity ()
      , Length.CheckedLengthContract (Variable AdversarialIdentity)
      , AdversarialGraph
      )
adversarialExactCaseProviderUnionFixture = do
  firstName <- expectName "Fixture.caseZeroProvider"
  secondName <- expectName "Fixture.caseStepProvider"
  let roles = [Length.LengthObservedSpine]
      payload = TupleType Boxed []
      spine = adversarialListOf payload
      target = FunctionType spine spine
      provider name = Length.AssumedProviderSummary
        { Length.lengthProviderName = name
        , Length.lengthProviderScheme = spine
        , Length.lengthProviderArgumentRoles = []
        , Length.lengthProviderTransfer = Length.LengthLiteral 7
        }
      providers = [provider firstName, provider secondName]
      declarations =
        [ ValueDeclaration $ ValueSignature () name spine
        | name <- [firstName, secondName]
        ]
      zeroPattern = Djex.TypedPattern (Djex.occurrenceId 2) spine
        $ Djex.TypedConstructor listName []
      stepPattern = Djex.TypedPattern (Djex.occurrenceId 4) spine
        $ Djex.TypedConstructor consName
          [ Djex.TypedPattern (Djex.occurrenceId 5) payload
              Djex.TypedWildcard
          , Djex.TypedPattern (Djex.occurrenceId 6) spine
              Djex.TypedWildcard
          ]
      source = Djex.TermGraphSource (Djex.termNodeId 4)
        [ ( Djex.termNodeId 0
          , Djex.TermNode spine
              $ Djex.TypedLocal (Djex.occurrenceId 1) 0
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode spine
              $ Djex.TypedGlobal (Djex.occurrenceId 3) firstName
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode spine
              $ Djex.TypedGlobal (Djex.occurrenceId 7) secondName
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode spine
              $ Djex.TypedCase (Djex.termNodeId 0)
                  [ (zeroPattern, Djex.termNodeId 1)
                  , (stepPattern, Djex.termNodeId 2)
                  ]
          )
        , ( Djex.termNodeId 4
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern (Djex.occurrenceId 0) spine
                      $ Djex.TypedBind 0
                  ]
                  (Djex.termNodeId 3)
          )
        ]
      typeStructure = Djex.sharedTypeStructure
        { Djex.constructorPatternFieldTypes = \name patternType ->
            if patternType /= spine
              then Nothing
              else if name == listName
                then Just []
                else if name == consName
                  then Just [payload, spine]
                  else Nothing
        }
      contractSource = contractWith (Length.LengthTruth True)
        $ Length.LengthEqual
            (Length.LengthVariable Length.LengthResult)
            $ Length.LengthLiteral 7
  session <- adversarialExactCaseLengthSession
    roles declarations providers
  contract <- adversarialRoleAwareLengthContract
    session roles target contractSource
  graph <- expectRight $ Djex.sealTermGraph
    typeStructure Djex.defaultTermGraphLimits source
  pure (sort [firstName, secondName], session, contract, graph)

adversarialVisibleProviderProblem
  :: Name
  -> AdversarialType
  -> AdversarialType
  -> AdversarialType
  -> Maybe (Djex.CertificateId, Natural)
  -> IO
      (Either
        (LengthProblem.LengthProblemError
          String AdversarialIdentity AdversarialLocal)
        (LengthProblem.CheckedLengthProblem
          AdversarialIdentity AdversarialLocal))
adversarialVisibleProviderProblem providerName providerScheme selected result
    certificate = do
  let provider = Length.AssumedProviderSummary
        { Length.lengthProviderName = providerName
        , Length.lengthProviderScheme = providerScheme
        , Length.lengthProviderArgumentRoles = []
        , Length.lengthProviderTransfer = Length.LengthLiteral 0
        }
      declaration = ValueDeclaration
        $ ValueSignature () providerName providerScheme
      witness = Djex.TypeApplicationWitness
        providerScheme selected result certificate
      source = Djex.TermGraphSource (Djex.termNodeId 1)
        [ ( Djex.termNodeId 0
          , Djex.TermNode providerScheme
              $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode result
              $ Djex.TypedVisibleTypeApplication
                  (Djex.occurrenceId 1)
                  (Djex.termNodeId 0)
                  Djex.inferredVisibleTypeArgument
                  witness
          )
        ]
  session <- adversarialLengthSession [declaration] [provider]
  contract <- adversarialLengthContract session result trivialLengthContract
  graph <- sealAdversarialGraph source
  pure $ LengthProblem.sealLengthTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

-- The canonical source order is a,b, while occurrences are b,a,b. Both
-- forall witnesses retain their exact bodies; the shared sealer checks the
-- selected rigids and scope before the production Length consumer sees them.
adversarialCanonicalFirstGraphs :: IO (AdversarialGraph, AdversarialGraph)
adversarialCanonicalFirstGraphs = do
  let a = FlexibleVariable "canonical-a"
      b = FlexibleVariable "canonical-b"
      selectedA = TypeVariable $ RigidVariable "canonical-open-a"
      selectedB = TypeVariable $ RigidVariable "canonical-open-b"
      sourceA = adversarialListOf $ TypeVariable a
      sourceB = adversarialListOf $ TypeVariable b
      openedA = adversarialListOf selectedA
      openedB = adversarialListOf selectedB
      sourceBody = FunctionType sourceB $ FunctionType sourceA sourceB
      source = ForallType [a, b] [] sourceBody
      afterFirst = ForallType [b] [] $
        FunctionType sourceB $ FunctionType openedA sourceB
      openedBody = FunctionType openedB $ FunctionType openedA openedB
      bodyNodes =
        [ (Djex.termNodeId 0, Djex.TermNode openedB $
            Djex.TypedLocal (Djex.occurrenceId 0) 0)
        , (Djex.termNodeId 1, Djex.TermNode openedBody $
            Djex.TypedLambda
              [ Djex.TypedPattern (Djex.occurrenceId 1) openedB $ Djex.TypedBind 0
              , Djex.TypedPattern (Djex.occurrenceId 2) openedA Djex.TypedWildcard
              ] (Djex.termNodeId 0))
        ]
      sourceNodes = bodyNodes ++
        [ (Djex.termNodeId 2, Djex.TermNode afterFirst $
            Djex.TypedForallIntroduction (Djex.occurrenceId 3) (Djex.termNodeId 1) $
              Djex.ForallIntroductionWitness afterFirst selectedB openedBody)
        , (Djex.termNodeId 3, Djex.TermNode source $
            Djex.TypedForallIntroduction (Djex.occurrenceId 4) (Djex.termNodeId 2) $
              Djex.ForallIntroductionWitness source selectedA afterFirst)
        ]
  opened <- sealAdversarialGraph $ Djex.TermGraphSource (Djex.termNodeId 1) bodyNodes
  closed <- expectRight $ Djex.sealTermGraph
    (Djex.sharedTypeStructure
      { Djex.forallTypeStructure = Just Djex.sharedForallTypeStructure })
    Djex.defaultTermGraphLimits $ Djex.TermGraphSource (Djex.termNodeId 3) sourceNodes
  pure (opened, closed)


-- A complete independently sealed graph, including the source forall and its
-- exact opened body. This does not bypass the production root-opening matcher.
adversarialQuantifiedIdentityGraph :: IO AdversarialGraph
adversarialQuantifiedIdentityGraph = do
  let binder = FlexibleVariable "closed-root-source"
      selected = RigidVariable "closed-root-selected"
      sourceElement = TypeVariable binder
      selectedElement = TypeVariable selected
      sourceSpine = adversarialListOf sourceElement
      selectedSpine = adversarialListOf selectedElement
      sourceBody = FunctionType sourceSpine sourceSpine
      selectedBody = FunctionType selectedSpine selectedSpine
      source = ForallType [binder] [] sourceBody
      bodyNodes = Djex.termGraphSourceNodes
        $ adversarialIdentityGraphSource selectedSpine
      graphSource = Djex.TermGraphSource (Djex.termNodeId 2)
        $ bodyNodes ++
          [(Djex.termNodeId 2, Djex.TermNode source
            $ Djex.TypedForallIntroduction (Djex.occurrenceId 2) (Djex.termNodeId 1)
                (Djex.ForallIntroductionWitness source selectedElement selectedBody))]
  expectRight $ Djex.sealTermGraph
    (Djex.sharedTypeStructure
      { Djex.forallTypeStructure = Just Djex.sharedForallTypeStructure })
    Djex.defaultTermGraphLimits graphSource
adversarialIdentityGraphSource
  :: AdversarialType
  -> Djex.TermGraphSource AdversarialType AdversarialLocal
adversarialIdentityGraphSource spine = Djex.TermGraphSource
  (Djex.termNodeId 1)
  [ ( Djex.termNodeId 0
    , Djex.TermNode spine
        $ Djex.TypedLocal (Djex.occurrenceId 1) 0
    )
  , ( Djex.termNodeId 1
    , Djex.TermNode (FunctionType spine spine)
        $ Djex.TypedLambda
            [ Djex.TypedPattern
                (Djex.occurrenceId 0) spine (Djex.TypedBind 0)
            ]
            (Djex.termNodeId 0)
    )
  ]

roleAwareMapFixture
  :: IO
      ( Name
      , LengthProblem.CheckedLengthSession AdversarialIdentity ()
      , Length.CheckedLengthContract (Variable AdversarialIdentity)
      , AdversarialCandidate
      )
roleAwareMapFixture = roleAwareMapFixtureWithContract identityLengthContract

roleAwareMapFixtureWithContract
  :: Length.LengthContractSource
  -> IO
      ( Name
      , LengthProblem.CheckedLengthSession AdversarialIdentity ()
      , Length.CheckedLengthContract (Variable AdversarialIdentity)
      , AdversarialCandidate
      )
roleAwareMapFixtureWithContract contractSource = do
  providerName <- expectName "Fixture.roleAwareMap"
  let inputPayload = TupleType Boxed []
      outputPayload = FunctionType inputPayload inputPayload
      functionArgument = FunctionType inputPayload outputPayload
      inputSpine = adversarialListOf inputPayload
      outputSpine = adversarialListOf outputPayload
      providerResult = FunctionType inputSpine outputSpine
      target = FunctionType functionArgument providerResult
      roles =
        [ Length.LengthUnobservedTarget
        , Length.LengthObservedSpine
        ]
      provider = Length.AssumedProviderSummary
        { Length.lengthProviderName = providerName
        , Length.lengthProviderScheme = target
        , Length.lengthProviderArgumentRoles =
            [ Length.LengthUnobservedArgument
            , Length.LengthSpineArgument
            ]
        , Length.lengthProviderTransfer = Length.LengthVariable
            $ Length.LengthProviderArgument 1
        }
      declaration = ValueDeclaration
        $ ValueSignature () providerName target
      source = Djex.TermGraphSource (Djex.termNodeId 5)
        [ ( Djex.termNodeId 0
          , Djex.TermNode target
              $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode functionArgument
              $ Djex.TypedLocal (Djex.occurrenceId 1) 0
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode providerResult
              $ Djex.TypedApply
                  (Djex.termNodeId 0)
                  (Djex.termNodeId 1)
                  (Djex.ApplicationWitness functionArgument providerResult)
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode inputSpine
              $ Djex.TypedLocal (Djex.occurrenceId 2) 1
          )
        , ( Djex.termNodeId 4
          , Djex.TermNode outputSpine
              $ Djex.TypedApply
                  (Djex.termNodeId 2)
                  (Djex.termNodeId 3)
                  (Djex.ApplicationWitness inputSpine outputSpine)
          )
        , ( Djex.termNodeId 5
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern (Djex.occurrenceId 3)
                      functionArgument (Djex.TypedBind 0)
                  , Djex.TypedPattern (Djex.occurrenceId 4)
                      inputSpine (Djex.TypedBind 1)
                  ]
                  (Djex.termNodeId 4)
          )
        ]
  session <- adversarialRoleAwareLengthSession roles
    [declaration] [provider]
  contract <- adversarialRoleAwareLengthContract
    session roles target contractSource
  graph <- sealAdversarialGraph source
  pure
    ( providerName
    , session
    , contract
    , adversarialTypedCandidate $ Right graph
    )

sealRoleAwareAdversarialProblem
  :: [Length.LengthTargetArgumentRole]
  -> AdversarialType
  -> Length.LengthContractSource
  -> Djex.TermGraphSource AdversarialType AdversarialLocal
  -> IO
      (Either
        (LengthProblem.LengthProblemError
          String AdversarialIdentity AdversarialLocal)
        (LengthProblem.CheckedLengthProblem
          AdversarialIdentity AdversarialLocal))
sealRoleAwareAdversarialProblem roles target contractSource graphSource = do
  session <- adversarialRoleAwareLengthSession roles [] []
  contract <- adversarialRoleAwareLengthContract
    session roles target contractSource
  graph <- sealAdversarialGraph graphSource
  pure $ LengthProblem.sealRoleAwareLengthTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

assertOpaqueTargetDemandFailures :: IO ()
assertOpaqueTargetDemandFailures = do
  let spine = adversarialClosedList
      spineIdentityTarget = FunctionType spine spine
  spineResult <- sealRoleAwareAdversarialProblem
    [Length.LengthUnobservedTarget]
    spineIdentityTarget
    trivialLengthContract
    $ adversarialIdentityGraphSource spine
  assertLeft
    (LengthProblem.LengthProblemUnobservedTargetArgumentDemanded 0
      $ LengthProblem.LengthUnobservedTargetSpineDemand
      $ Djex.termNodeId 1)
    spineResult

  let callable = FunctionType spine spine
      callableTarget = FunctionType callable
        $ FunctionType spine spine
      callableSource = Djex.TermGraphSource (Djex.termNodeId 3)
        [ ( Djex.termNodeId 0
          , Djex.TermNode callable
              $ Djex.TypedLocal (Djex.occurrenceId 0) 0
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode spine
              $ Djex.TypedLocal (Djex.occurrenceId 1) 1
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode spine
              $ Djex.TypedApply
                  (Djex.termNodeId 0)
                  (Djex.termNodeId 1)
                  (Djex.ApplicationWitness spine spine)
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode callableTarget
              $ Djex.TypedLambda
                  [ Djex.TypedPattern (Djex.occurrenceId 2)
                      callable (Djex.TypedBind 0)
                  , Djex.TypedPattern (Djex.occurrenceId 3)
                      spine (Djex.TypedBind 1)
                  ]
                  (Djex.termNodeId 2)
          )
        ]
  callableResult <- sealRoleAwareAdversarialProblem
    [ Length.LengthUnobservedTarget
    , Length.LengthObservedSpine
    ]
    callableTarget
    identityLengthContract
    callableSource
  assertLeft
    (LengthProblem.LengthProblemUnobservedTargetArgumentDemanded 0
      $ LengthProblem.LengthUnobservedTargetCallableDemand
      $ Djex.termNodeId 2)
    callableResult

  let tuple = TupleType Boxed [spine, spine]
      tupleTarget = FunctionType tuple spine
      tupleOccurrence = Djex.occurrenceId 4
      tupleSource = Djex.TermGraphSource (Djex.termNodeId 1)
        [ ( Djex.termNodeId 0
          , Djex.TermNode spine
              $ Djex.TypedLocal (Djex.occurrenceId 5) 0
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode tupleTarget
              $ Djex.TypedLambda
                  [ Djex.TypedPattern tupleOccurrence tuple
                      $ Djex.TypedTuplePattern
                        [ Djex.TypedPattern (Djex.occurrenceId 6)
                            spine (Djex.TypedBind 0)
                        , Djex.TypedPattern (Djex.occurrenceId 7)
                            spine Djex.TypedWildcard
                        ]
                  ]
                  (Djex.termNodeId 0)
          )
        ]
  tupleResult <- sealRoleAwareAdversarialProblem
    [Length.LengthUnobservedTarget]
    tupleTarget
    trivialLengthContract
    tupleSource
  assertLeft
    (LengthProblem.LengthProblemUnobservedTargetArgumentDemanded 0
      $ LengthProblem.LengthUnobservedTargetTupleDemand tupleOccurrence)
    tupleResult

roleAwareOpaqueStepPayloadProblem
  :: IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
roleAwareOpaqueStepPayloadProblem = do
  let payload = TupleType Boxed []
      spine = adversarialListOf payload
      stepResult = FunctionType spine spine
      target = FunctionType payload stepResult
      roles =
        [ Length.LengthUnobservedTarget
        , Length.LengthObservedSpine
        ]
      expected = Length.LengthSum
        [ Length.LengthVariable $ Length.LengthInput 0
        , Length.LengthLiteral 1
        ]
      contractSource = contractWith (Length.LengthTruth True)
        $ Length.LengthEqual
            (Length.LengthVariable Length.LengthResult) expected
      source = Djex.TermGraphSource (Djex.termNodeId 5)
        [ ( Djex.termNodeId 0
          , Djex.TermNode target
              $ Djex.TypedGlobal (Djex.occurrenceId 0) consName
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode payload
              $ Djex.TypedLocal (Djex.occurrenceId 1) 0
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode stepResult
              $ Djex.TypedApply
                  (Djex.termNodeId 0)
                  (Djex.termNodeId 1)
                  (Djex.ApplicationWitness payload stepResult)
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode spine
              $ Djex.TypedLocal (Djex.occurrenceId 2) 1
          )
        , ( Djex.termNodeId 4
          , Djex.TermNode spine
              $ Djex.TypedApply
                  (Djex.termNodeId 2)
                  (Djex.termNodeId 3)
                  (Djex.ApplicationWitness spine spine)
          )
        , ( Djex.termNodeId 5
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern (Djex.occurrenceId 3)
                      payload (Djex.TypedBind 0)
                  , Djex.TypedPattern (Djex.occurrenceId 4)
                      spine (Djex.TypedBind 1)
                  ]
                  (Djex.termNodeId 4)
          )
        ]
  result <- sealRoleAwareAdversarialProblem
    roles target contractSource source
  expectRight result

adversarialConstantZeroProblem
  :: Length.LengthContractSource
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialConstantZeroProblem contractSource = do
  session <- adversarialLengthSession [] []
  let target = FunctionType adversarialClosedList adversarialClosedList
      source = Djex.TermGraphSource (Djex.termNodeId 1)
        [ ( Djex.termNodeId 0
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedGlobal (Djex.occurrenceId 1) listName
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern
                      (Djex.occurrenceId 0)
                      adversarialClosedList
                      Djex.TypedWildcard
                  ]
                  (Djex.termNodeId 0)
          )
        ]
  contract <- adversarialLengthContract session target contractSource
  graph <- sealAdversarialGraph source
  expectRight $ LengthProblem.sealLengthTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialZeroInputProblem
  :: Length.LengthContractSource
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialZeroInputProblem contractSource = do
  session <- adversarialLengthSession [] []
  let source = Djex.TermGraphSource (Djex.termNodeId 0)
        [ ( Djex.termNodeId 0
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedGlobal (Djex.occurrenceId 0) listName
          )
        ]
  contract <- adversarialLengthContract
    session adversarialClosedList contractSource
  graph <- sealAdversarialGraph source
  expectRight $ LengthProblem.sealLengthTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialBinaryConstantZeroProblem
  :: Length.LengthContractSource
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialBinaryConstantZeroProblem contractSource = do
  session <- adversarialLengthSession [] []
  contract <- adversarialLengthContract
    session adversarialBinaryConstantZeroTarget contractSource
  graph <- adversarialBinaryConstantZeroGraph
  expectRight $ LengthProblem.sealLengthTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialInputAndZeroSpinePairProblem
  :: Length.LengthSpinePairContractSource
  -> IO
      (LengthProblem.CheckedLengthSpinePairProblem
        AdversarialIdentity AdversarialLocal)
adversarialInputAndZeroSpinePairProblem contractSource = do
  session <- adversarialLengthSession [] []
  contract <- adversarialLengthSpinePairContract
    session adversarialInputSpinePairTarget contractSource
  graph <- adversarialInputAndZeroSpinePairGraph
  expectRight $ LengthProblem.sealLengthSpinePairTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialBinaryZeroSpinePairProblem
  :: Length.LengthSpinePairContractSource
  -> IO
      (LengthProblem.CheckedLengthSpinePairProblem
        AdversarialIdentity AdversarialLocal)
adversarialBinaryZeroSpinePairProblem contractSource = do
  session <- adversarialLengthSession [] []
  contract <- adversarialLengthSpinePairContract
    session adversarialBinaryZeroSpinePairTarget contractSource
  graph <- adversarialBinaryZeroSpinePairGraph
  expectRight $ LengthProblem.sealLengthSpinePairTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialNullaryZeroSpinePairProblem
  :: Length.LengthSpinePairContractSource
  -> IO
      (LengthProblem.CheckedLengthSpinePairProblem
        AdversarialIdentity AdversarialLocal)
adversarialNullaryZeroSpinePairProblem contractSource = do
  let resultType = TupleType Boxed
        [adversarialClosedList, adversarialClosedList]
      source = Djex.TermGraphSource (Djex.termNodeId 2)
        [ ( Djex.termNodeId 0
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedGlobal (Djex.occurrenceId 0) listName
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedGlobal (Djex.occurrenceId 1) listName
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode resultType
              $ Djex.TypedTuple [Djex.termNodeId 0, Djex.termNodeId 1]
          )
        ]
  session <- adversarialLengthSession [] []
  contract <- adversarialLengthSpinePairContract
    session resultType contractSource
  graph <- sealAdversarialGraph source
  expectRight $ LengthProblem.sealLengthSpinePairTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialProviderSpinePairProblem
  :: IO
      ( [Name]
      , LengthProblem.CheckedLengthSpinePairProblem
          AdversarialIdentity AdversarialLocal
      )
adversarialProviderSpinePairProblem = do
  firstName <- expectName "Fixture.spinePairFirstProvider"
  secondName <- expectName "Fixture.spinePairSecondProvider"
  let resultType = TupleType Boxed
        [adversarialClosedList, adversarialClosedList]
      provider name value = Length.AssumedProviderSummary
        { Length.lengthProviderName = name
        , Length.lengthProviderScheme = adversarialClosedList
        , Length.lengthProviderArgumentRoles = []
        , Length.lengthProviderTransfer = Length.LengthLiteral value
        }
      providers = [provider firstName 11, provider secondName 22]
      declarations =
        [ ValueDeclaration $ ValueSignature () name adversarialClosedList
        | name <- [firstName, secondName]
        ]
      source = Djex.TermGraphSource (Djex.termNodeId 2)
        [ ( Djex.termNodeId 0
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedGlobal (Djex.occurrenceId 0) firstName
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedGlobal (Djex.occurrenceId 1) secondName
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode resultType
              $ Djex.TypedTuple [Djex.termNodeId 0, Djex.termNodeId 1]
          )
        ]
      firstResult = pairResultVariable Length.LengthSpinePairFirst
      secondResult = pairResultVariable Length.LengthSpinePairSecond
      contractSource = spinePairContractWith (Length.LengthTruth True)
        $ Length.LengthAll
            [ Length.LengthEqual firstResult $ Length.LengthLiteral 0
            , Length.LengthEqual secondResult $ Length.LengthLiteral 0
            ]
  session <- adversarialLengthSession declarations providers
  contract <- adversarialLengthSpinePairContract
    session resultType contractSource
  graph <- sealAdversarialGraph source
  problem <- expectRight
    $ LengthProblem.sealLengthSpinePairTypedCandidateProblem
        LengthProblem.defaultLengthProblemLimits session contract
        $ adversarialTypedCandidate $ Right graph
  pure (sort [firstName, secondName], problem)

adversarialOpaqueComponentsSpinePairProblem
  :: IO
      (Either
        (LengthProblem.LengthSpinePairProblemError
          String AdversarialIdentity AdversarialLocal)
        (LengthProblem.CheckedLengthSpinePairProblem
          AdversarialIdentity AdversarialLocal))
adversarialOpaqueComponentsSpinePairProblem = do
  let resultType = TupleType Boxed
        [adversarialClosedList, adversarialClosedList]
      target = FunctionType adversarialClosedList
        $ FunctionType adversarialClosedList resultType
      roles =
        [Length.LengthUnobservedTarget, Length.LengthUnobservedTarget]
      source = Djex.TermGraphSource (Djex.termNodeId 3)
        [ ( Djex.termNodeId 0
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedLocal (Djex.occurrenceId 2) 0
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedLocal (Djex.occurrenceId 3) 1
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode resultType
              $ Djex.TypedTuple [Djex.termNodeId 0, Djex.termNodeId 1]
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern (Djex.occurrenceId 0)
                      adversarialClosedList $ Djex.TypedBind 0
                  , Djex.TypedPattern (Djex.occurrenceId 1)
                      adversarialClosedList $ Djex.TypedBind 1
                  ]
                  (Djex.termNodeId 2)
          )
        ]
  session <- adversarialRoleAwareLengthSession roles [] []
  contract <- adversarialRoleAwareLengthSpinePairContract
    session roles target trivialSpinePairContract
  graph <- sealAdversarialGraph source
  pure $ LengthProblem.sealRoleAwareLengthSpinePairTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialWideConstantZeroProblem
  :: Int
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialWideConstantZeroProblem inputCount =
  adversarialWideConstantZeroProblemWithContract
    inputCount trivialLengthContract

adversarialWideConstantZeroProblemWithContract
  :: Int
  -> Length.LengthContractSource
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialWideConstantZeroProblemWithContract inputCount contractSource = do
  let limits = limitsWith $ \limitSource -> limitSource
        { Length.lengthLimitSourceContractInputs = inputCount }
      target = foldr FunctionType adversarialClosedList
        $ replicate inputCount adversarialClosedList
      patterns =
        [ Djex.TypedPattern
            (Djex.occurrenceId $ fromIntegral index)
            adversarialClosedList
            Djex.TypedWildcard
        | index <- [0 .. inputCount - 1]
        ]
      source = Djex.TermGraphSource (Djex.termNodeId 1)
        [ ( Djex.termNodeId 0
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedGlobal
                  (Djex.occurrenceId $ fromIntegral inputCount) listName
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode target
              $ Djex.TypedLambda patterns (Djex.termNodeId 0)
          )
        ]
  session <- expectRight $ LengthProblem.sealLengthSession limits
    (sessionInventory () []) Length.BuiltinListSpine []
  contract <- expectRight $ Length.sealLengthContractInContext limits
    (LengthProblem.checkedLengthSessionContext session)
    target contractSource
  graph <- sealAdversarialGraph source
  expectRight $ LengthProblem.sealLengthTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialConstantProviderProblem
  :: Natural
  -> Length.LengthContractSource
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialConstantProviderProblem result contractSource = do
  providerName <- expectName "Fixture.problemReplayConstant"
  let target = FunctionType adversarialClosedList adversarialClosedList
      provider = Length.AssumedProviderSummary
        { Length.lengthProviderName = providerName
        , Length.lengthProviderScheme = adversarialClosedList
        , Length.lengthProviderArgumentRoles = []
        , Length.lengthProviderTransfer = Length.LengthLiteral result
        }
      declaration = ValueDeclaration
        $ ValueSignature () providerName adversarialClosedList
      source = Djex.TermGraphSource (Djex.termNodeId 1)
        [ ( Djex.termNodeId 0
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedGlobal (Djex.occurrenceId 1) providerName
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern
                      (Djex.occurrenceId 0)
                      adversarialClosedList
                      Djex.TypedWildcard
                  ]
                  (Djex.termNodeId 0)
          )
        ]
  session <- adversarialLengthSession [declaration] [provider]
  contract <- adversarialLengthContract session target contractSource
  graph <- sealAdversarialGraph source
  expectRight $ LengthProblem.sealLengthTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialScaledProviderProblem
  :: Natural
  -> Length.LengthContractSource
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialScaledProviderProblem factor = adversarialTransferredProviderProblem
  (Length.LengthScale factor
    $ Length.LengthVariable $ Length.LengthProviderArgument 0)

adversarialModuloProviderProblem
  :: Natural
  -> Length.LengthContractSource
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialModuloProviderProblem divisor = adversarialTransferredProviderProblem
  (Length.LengthModulo divisor
    $ Length.LengthVariable $ Length.LengthProviderArgument 0)

adversarialQuotientProviderProblem
  :: Natural
  -> Length.LengthContractSource
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialQuotientProviderProblem divisor = adversarialTransferredProviderProblem
  (Length.LengthQuotient divisor
    $ Length.LengthVariable $ Length.LengthProviderArgument 0)

adversarialTransferredProviderProblem
  :: Length.LengthExpression Length.LengthProviderVariable
  -> Length.LengthContractSource
  -> IO
      (LengthProblem.CheckedLengthProblem
        AdversarialIdentity AdversarialLocal)
adversarialTransferredProviderProblem transfer contractSource = do
  providerName <- expectName "Fixture.problemReplayTransfer"
  let target = FunctionType adversarialClosedList adversarialClosedList
      provider = Length.AssumedProviderSummary
        { Length.lengthProviderName = providerName
        , Length.lengthProviderScheme = target
        , Length.lengthProviderArgumentRoles = [Length.LengthSpineArgument]
        , Length.lengthProviderTransfer = transfer
        }
      declaration = ValueDeclaration
        $ ValueSignature () providerName target
      source = Djex.TermGraphSource (Djex.termNodeId 3)
        [ ( Djex.termNodeId 0
          , Djex.TermNode target
              $ Djex.TypedGlobal (Djex.occurrenceId 0) providerName
          )
        , ( Djex.termNodeId 1
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedLocal (Djex.occurrenceId 1) 0
          )
        , ( Djex.termNodeId 2
          , Djex.TermNode adversarialClosedList
              $ Djex.TypedApply
                  (Djex.termNodeId 0)
                  (Djex.termNodeId 1)
                  (Djex.ApplicationWitness
                    adversarialClosedList adversarialClosedList)
          )
        , ( Djex.termNodeId 3
          , Djex.TermNode target
              $ Djex.TypedLambda
                  [ Djex.TypedPattern
                      (Djex.occurrenceId 2)
                      adversarialClosedList
                      (Djex.TypedBind 0)
                  ]
                  (Djex.termNodeId 2)
          )
        ]
  session <- adversarialLengthSession [declaration] [provider]
  contract <- adversarialLengthContract session target contractSource
  graph <- sealAdversarialGraph source
  expectRight $ LengthProblem.sealLengthTypedCandidateProblem
    LengthProblem.defaultLengthProblemLimits session contract
    $ adversarialTypedCandidate $ Right graph

adversarialLetIdentityGraphSource
  :: AdversarialType
  -> Djex.TermGraphSource AdversarialType AdversarialLocal
adversarialLetIdentityGraphSource spine = Djex.TermGraphSource
  (Djex.termNodeId 3)
  [ ( Djex.termNodeId 0
    , Djex.TermNode spine
        $ Djex.TypedLocal (Djex.occurrenceId 1) 0
    )
  , ( Djex.termNodeId 1
    , Djex.TermNode spine
        $ Djex.TypedLocal (Djex.occurrenceId 3) 0
    )
  , ( Djex.termNodeId 2
    , Djex.TermNode spine
        $ Djex.TypedLet
            (Djex.TypedPattern
              (Djex.occurrenceId 2) spine Djex.TypedWildcard)
            (Djex.termNodeId 0)
            (Djex.termNodeId 1)
    )
  , ( Djex.termNodeId 3
    , Djex.TermNode (FunctionType spine spine)
        $ Djex.TypedLambda
            [ Djex.TypedPattern
                (Djex.occurrenceId 0) spine (Djex.TypedBind 0)
            ]
            (Djex.termNodeId 2)
    )
  ]

sealAdversarialGraph
  :: Djex.TermGraphSource AdversarialType AdversarialLocal
  -> IO AdversarialGraph
sealAdversarialGraph = expectRight
  . Djex.sealTermGraph Djex.sharedTypeStructure Djex.defaultTermGraphLimits

-- IMPORTANT: this coercion is confined to the adversarial same-package test
-- component.
-- Cabal compiles the exact private representation as a home module, whose unit
-- identity is deliberately distinct from the library's opaque public type even
-- though both definitions and all field types are identical.  Production code
-- never receives this constructor or coercion; downstream opacity remains
-- covered independently by the negative API tests.
adversarialTypedCandidate
  :: Either String AdversarialGraph
  -> AdversarialCandidate
adversarialTypedCandidate graph = unsafeCoerce
  $ InternalTypedCandidate.mkTypedCandidate adversarialCompatibility graph

adversarialCompatibility :: Djex.Candidate AdversarialType () ()
adversarialCompatibility = Djex.Candidate
  { Djex.candidateOutput = ()
  , Djex.candidateResidualConstraints = []
  , Djex.candidateDetails = ()
  }

realListIdentityFixture
  :: Type (Variable Int)
  -> IO
      ( LengthProblem.CheckedLengthSession Int ()
      , Length.CheckedLengthContract (Variable Int)
      , Djex.ExferenceTypedCandidate
      )
realListIdentityFixture payload = do
  environment <- expectRight
    (Djex.mkEnvironment [] ::
      Either (Djex.EnvironmentError Djex.ExferenceTypeVariable)
        Djex.ExferenceEnvironment)
  exferenceSession <- expectRight $ Djex.mkExferenceSession environment
  lengthSession <- expectRight $ LengthProblem.sealLengthSession
    Length.defaultLengthLimits
    (Djex.exferenceSessionInventory exferenceSession)
    Length.BuiltinListSpine []
  targetName <- expectName "lengthIdentityCandidate"
  target <- expectRight $ Djex.mkDefinitionName targetName
  let spine = TypeApplication (TypeConstructor listName) payload
      goal = FunctionType spine spine
      query = Djex.QueryRequest
        { Djex.requestTarget = target
        , Djex.requestGoal = goal
        , Djex.requestContexts = []
        , Djex.requestOptions = Djex.defaultExferenceOptions
            { Djex.exferenceMaximumSteps = 8 }
        }
  request <- expectRight $ Djex.mkExferenceRequest query
  contract <- expectRight $ Length.sealLengthContractInContext
    Length.defaultLengthLimits
    (LengthProblem.checkedLengthSessionContext lengthSession)
    goal identityLengthContract
  results <- expectRight $ Djex.runExferenceTypedQuery exferenceSession request
  candidate <- case
      [ value
      | result <- results
      , value <- Djex.batchCandidates $ Djex.resultSearch result
      ] of
    [] -> assertFailure "the list identity query returned no candidate"
    value : _ -> pure value
  pure (lengthSession, contract, candidate)

isNamedGlobal :: Name -> Djex.TermNode ty local -> Bool
isNamedGlobal expected (Djex.TermNode _ form) = case form of
  Djex.TypedGlobal _ actual -> actual == expected
  _ -> False

sealContract
  :: Length.LengthLimits
  -> Type String
  -> Length.LengthContractSource
  -> Either
      (Length.LengthContractError String)
      (Length.CheckedLengthContract String)
sealContract limits = Length.sealLengthContract limits fixtureInventory

sealSpinePairContract
  :: Length.LengthLimits
  -> Type String
  -> Length.LengthSpinePairContractSource
  -> Either
      (Length.LengthSpinePairContractError String)
      (Length.CheckedLengthSpinePairContract String)
sealSpinePairContract limits =
  Length.sealLengthSpinePairContract limits fixtureInventory

sealProviderInventory
  :: Length.LengthLimits
  -> [Length.LengthProviderSummarySource String]
  -> Either
      (Length.LengthProviderInventoryError String)
      (Length.CheckedLengthProviderInventory String)
sealProviderInventory limits =
  \sources -> Length.sealLengthProviderInventory
    limits (providerFixtureInventory sources) sources

providerSource
  :: Name
  -> Type String
  -> [Length.LengthProviderArgumentRole]
  -> Length.LengthExpression Length.LengthProviderVariable
  -> Length.LengthProviderSummarySource String
providerSource providerName scheme roles transfer =
  Length.AssumedProviderSummary
    { Length.lengthProviderName = providerName
    , Length.lengthProviderScheme = scheme
    , Length.lengthProviderArgumentRoles = roles
    , Length.lengthProviderTransfer = transfer
    }

conditionalProviderSource
  :: Name
  -> Type String
  -> [Length.LengthProviderArgumentRole]
  -> Length.LengthExpression Length.LengthProviderVariable
  -> Length.LengthProviderSummarySource String
conditionalProviderSource providerName scheme roles transfer =
  Length.AssumedConstraintConditionalProviderSummary
    { Length.lengthProviderName = providerName
    , Length.lengthProviderScheme = scheme
    , Length.lengthProviderArgumentRoles = roles
    , Length.lengthProviderTransfer = transfer
    }

unaryListProvider
  :: Name
  -> Length.LengthProviderArgumentRole
  -> Length.LengthExpression Length.LengthProviderVariable
  -> Length.LengthProviderSummarySource String
unaryListProvider providerName role transfer = providerSource providerName
  (ForallType ["element"] [] $ FunctionType
    (listOf $ TypeVariable "element")
    (listOf $ TypeVariable "element"))
  [role]
  transfer

expectCheckedProvider
  :: Length.LengthProviderSummarySource String
  -> IO (Length.CheckedLengthProviderSummary String)
expectCheckedProvider source = do
  inventory <- expectRight $ sealProviderInventory
    Length.defaultLengthLimits [source]
  case Length.lookupCheckedLengthProviderSummary
      (Length.lengthProviderName source) inventory of
    Nothing -> assertFailure "checked provider disappeared from its inventory"
    Just summary -> pure summary

evaluationLimitsWith :: Int -> Int -> Evaluate.LengthEvaluationLimits
evaluationLimitsWith assignmentBits intermediateBits = case
    Evaluate.mkLengthEvaluationLimits Evaluate.LengthEvaluationLimitSource
      { Evaluate.lengthEvaluationLimitSourceAssignmentValueBits = assignmentBits
      , Evaluate.lengthEvaluationLimitSourceIntermediateValueBits =
          intermediateBits
      } of
  Left failure -> error $ "invalid evaluation test limits: " ++ show failure
  Right limits -> limits

asciiBytes :: String -> [Word8]
asciiBytes = map $ fromIntegral . fromEnum

fingerprintVersionPrefix :: Word8 -> [Word8]
fingerprintVersionPrefix version =
  [ 0x44, 0x4a, 0x45, 0x58, 0x46, 0x50
  , 0x01, 0x01, 0x01, version
  ]

absoluteFixtureExecutable :: FilePath
absoluteFixtureExecutable
  | SystemInfo.os == "mingw32" = "C:\\djex\\z3.exe"
  | otherwise = "/usr/bin/z3"

absoluteFixturePrefix :: FilePath
absoluteFixturePrefix
  | SystemInfo.os == "mingw32" = "C:\\"
  | otherwise = "/z3"

smtIntegerBinding
  :: [Word8]
  -> Integer
  -> SMTLib.LengthSMTLibIntegerBinding
smtIntegerBinding symbol value = SMTLib.LengthSMTLibIntegerBinding
  { SMTLib.lengthSMTLibIntegerBindingSymbol = symbol
  , SMTLib.lengthSMTLibIntegerBindingValue = value
  }

smtRawArtifact
  :: [Word8]
  -> [Word8]
  -> IO (SemanticProblem.BoundedRawArtifact ())
smtRawArtifact format bytes = expectRight
  $ SemanticProblem.mkBoundedRawArtifact
      SemanticProblem.defaultRawArtifactLimits format bytes

expectName :: String -> IO Name
expectName = expectRight . parseName

expectRight :: Show error => Either error value -> IO value
expectRight result = case result of
  Left failure -> assertFailure $ "unexpected rejection: " ++ show failure
  Right value -> pure value

canonicalFingerprintSHA256
  :: Fingerprint.Fingerprint subject
  -> String
canonicalFingerprintSHA256 = concatMap hexadecimalByte . BS.unpack
  . SHA256.hash . BS.pack . Fingerprint.fingerprintCanonicalBytes

hexadecimalByte :: Word8 -> String
hexadecimalByte byte = [digit $ byte `quot` 16, digit $ byte `mod` 16]
 where
  digit value
    | value < 10 = toEnum $ fromEnum '0' + fromIntegral value
    | otherwise = toEnum $ fromEnum 'a' + fromIntegral value - 10

expectNoCounterexample
  :: Show error
  => Either error (Maybe evidence)
  -> IO ()
expectNoCounterexample result = case result of
  Left failure -> assertFailure $ "unexpected replay rejection: " ++ show failure
  Right Nothing -> pure ()
  Right Just{} -> assertFailure "an assignment unexpectedly refuted the problem"

expectCounterexample
  :: Show error
  => Either error (Maybe evidence)
  -> IO evidence
expectCounterexample result = case result of
  Left failure -> assertFailure $ "unexpected replay rejection: " ++ show failure
  Right Nothing -> assertFailure "the violating assignment produced no evidence"
  Right (Just evidence) -> pure evidence

assertLeft
  :: (Eq error, Show error)
  => error
  -> Either error value
  -> IO ()
assertLeft expected result = case result of
  Left failure -> failure @?= expected
  Right _ -> assertFailure $ "expected rejection: " ++ show expected

evaluateWithin :: value -> IO value
evaluateWithin value = do
  observed <- timeout 2000000 $ evaluate value
  case observed of
    Nothing -> fail "bounded validation did not terminate within two seconds"
    Just result -> pure result
