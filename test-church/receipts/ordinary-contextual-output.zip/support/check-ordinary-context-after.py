"""Check all nine new public cases, preserving the separately timed-out baseline."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys

ROOT = Path('C:/Djex')
sys.path.insert(0, str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT = ROOT/'dist-newstyle/ordinary-context-focused-v2'
OUT.mkdir(exist_ok=False)
BASE = ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17'
TEST = BASE/'t/djex-cli-tests/build/djex-cli-tests/djex-cli-tests.exe'
EXE = BASE/'x/djex/build/djex/djex.exe'
baseline = ROOT/'dist-newstyle/ordinary-context-focused-v1/results.json'
prior = json.loads(baseline.read_text(encoding='utf-8'))
assert prior['unchanged'] and prior['processes'][-1]['status'] == 'timed_out'
baseline_stdout = baseline.parent/'before.stdout.txt'
text = baseline_stdout.read_text(encoding='utf-8')
assert all(re.search(r'^    '+name+r':\s+FAIL$', text, re.M) for name in
           ['djinn first','djinn best','djinn all','exference first'])
paths = [ROOT/'src/Language/Haskell/Djex/Command.hs', ROOT/'src/Language/Haskell/Djex/REPL.hs',
         ROOT/'test-cli/Spec.hs', ROOT/'djex.cabal', TEST, EXE, Path(__file__), baseline, baseline_stdout]
snapshot = lambda: {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
report = dict(status='running', before=snapshot(), baseline=dict(status='incomplete_timeout',
    completed_failure_cases=4, total_inventory=9, receipt=str(baseline),
    note='The four completed baseline cases fail exact GHC replay; the next compiler replay stalled. No complete baseline matrix is claimed.'))
processes = runtime.Processes(OUT,1200)
receipt = OUT/'results.json'
pattern = 'ordinary contextual presentation retains typed choices'
try:
    env = dict(os.environ, djex_datadir=str(ROOT))
    env['PATH'] = os.pathsep.join([str(EXE.parent),
        str(BASE/'x/djex-fake-cabal/build/djex-fake-cabal'),
        str(BASE/'x/djex-fake-z3/build/djex-fake-z3'),env.get('PATH','')])
    inventory = processes.run('after-inventory',[str(TEST),'--list-tests','-p',pattern],cwd=ROOT,env=env)
    names = [line for line in inventory.stdout.splitlines() if pattern in line]
    assert inventory.returncode == 0 and len(names) == len(set(names)) == 9
    report['inventory'] = names
    runtime.write_json(receipt,report)
    run = processes.run('after',[str(TEST),'-j1','--color=never','--timeout=180s','-p',pattern],cwd=ROOT,env=env)
    report['exit_code'] = run.returncode
    report['status'] = 'passed' if run.returncode == 0 and re.search(r'All 9 tests passed',run.stdout+run.stderr) else 'failed'
finally:
    report['after'] = snapshot()
    report['unchanged'] = report['before'] == report['after']
    report['processes'] = processes.rows
    if not report['unchanged'] or report['status'] == 'running': report['status'] = 'failed'
    runtime.write_json(receipt,report)
    print(report['status'],flush=True)
sys.exit(0 if report['status']=='passed' else 1)
