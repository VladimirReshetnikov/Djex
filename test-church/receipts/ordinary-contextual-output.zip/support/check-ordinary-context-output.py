"""Run the same new public tests against preserved old and rebuilt executables."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys

ROOT = Path('C:/Djex')
sys.path.insert(0, str(ROOT/'test-church'))
import behavior_runtime as runtime

OUT = ROOT/'dist-newstyle/ordinary-context-focused-v1'
OUT.mkdir(exist_ok=False)
BASE = ROOT/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17'
TEST = BASE/'t/djex-cli-tests/build/djex-cli-tests/djex-cli-tests.exe'
AFTER = BASE/'x/djex/build/djex/djex.exe'
BEFORE = ROOT/'dist-newstyle/ordinary-context-before-bin/djex.exe'
paths = [ROOT/'src/Language/Haskell/Djex/Command.hs', ROOT/'src/Language/Haskell/Djex/REPL.hs',
         ROOT/'test-cli/Spec.hs', ROOT/'djex.cabal', TEST, BEFORE, AFTER, Path(__file__)]
snapshot = lambda: {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
report = {'status':'running','before':snapshot(),'runs':[]}
processes = runtime.Processes(OUT,1200)
receipt = OUT/'results.json'
pattern = 'ordinary contextual presentation retains typed choices'
try:
    for label, exe in [('before',BEFORE),('after',AFTER)]:
        env = dict(os.environ, djex_datadir=str(ROOT))
        env['PATH'] = os.pathsep.join([str(exe.parent),
            str(BASE/'x/djex-fake-cabal/build/djex-fake-cabal'),
            str(BASE/'x/djex-fake-z3/build/djex-fake-z3'),env.get('PATH','')])
        inventory = processes.run(label+'-inventory',[str(TEST),'--list-tests','-p',pattern],cwd=ROOT,env=env)
        names = [line for line in inventory.stdout.splitlines() if pattern in line]
        assert inventory.returncode == 0 and len(names) == len(set(names)) == 9
        run = processes.run(label,[str(TEST),'-j1','--color=never','--timeout=180s','-p',pattern],cwd=ROOT,env=env)
        text = run.stdout + run.stderr
        passed = run.returncode == 0 and re.search(r'All 9 tests passed',text) is not None
        report['runs'].append(dict(label=label,executable=str(exe),tests=names,
                                   exit_code=run.returncode,status='passed' if passed else 'failed'))
        runtime.write_json(receipt,report)
        print(label,report['runs'][-1]['status'],flush=True)
finally:
    report['after'] = snapshot()
    report['unchanged'] = report['before'] == report['after']
    report['processes'] = processes.rows
    report['status'] = 'passed' if (report['unchanged'] and len(report['runs'])==2
        and report['runs'][0]['status']=='failed' and report['runs'][1]['status']=='passed') else 'failed'
    runtime.write_json(receipt,report)
    print(report['status'],flush=True)
sys.exit(0 if report['status']=='passed' else 1)
