"""Package accepted ordinary presentation evidence and update both roadmaps."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('C:/Djex')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
focused = read(ROOT/'dist-newstyle/ordinary-context-focused-v3/results.json')
full = read(ROOT/'dist-newstyle/ordinary-context-regression-v1/regression/results.json')
final = read(ROOT/'dist-newstyle/ordinary-context-cli-final-v1/regression/results.json')
assert focused['status']=='passed' and focused['unchanged']
assert [row['status'] for row in focused['runs']]==['failed','passed']
assert len(focused['runs'][1]['tests'])==9
assert full['sources_unchanged'] and full['helpers_unchanged']
assert [row['suite'] for row in full['rows'] if row['status']!='passed']==['djex-cli-tests']
assert final['status']=='passed' and final['sources_unchanged'] and final['helpers_unchanged']
assert len(final['rows'])==1 and final['rows'][0]['suite']=='djex-cli-tests'
changed = [p for p,h in full['source_hashes_after'].items() if final['source_hashes_before'].get(p)!=h]
assert changed==[str(ROOT/'test-cli/Spec.hs')]
previous_test = ROOT/'dist-newstyle/ordinary-context-before-scheduler-assertion.hs'
assert sha(previous_test.read_bytes())==full['source_hashes_after'][str(ROOT/'test-cli/Spec.hs')]
for relative in ['src/Language/Haskell/Djex/Command.hs','src/Language/Haskell/Djex/REPL.hs']:
    path = ROOT/relative
    assert sha(path.read_bytes())==focused['after'][str(path)]==full['source_hashes_after'][str(path)]==final['source_hashes_after'][str(path)]
accepted = [row for row in full['rows'] if row['status']=='passed']+final['rows']
assert len(accepted)==4 and sum(row['passed_count'] for row in accepted)==330
for result in [focused,full,final]:
    for row in result['processes']:
        for stream in ['stdout','stderr']:
            assert sha(Path(row[stream+'_path']).read_bytes())==row[stream+'_sha256']

files = {}
for name in ['ordinary-context-focused-v1','ordinary-context-focused-v2','ordinary-context-focused-v3',
             'ordinary-context-regression-v1','ordinary-context-cli-final-v1',
             'ordinary-context-output-diagnostics-v1']:
    directory = ROOT/'dist-newstyle'/name
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            assert path.suffix not in ['.exe','.dll','.o','.hi']
            files[name+'/'+path.relative_to(directory).as_posix()] = path.read_bytes()
for relative in ['src/Language/Haskell/Djex/Command.hs','src/Language/Haskell/Djex/REPL.hs','test-cli/Spec.hs']:
    files['source/'+relative] = (ROOT/relative).read_bytes()
files['source/change.patch'] = subprocess.check_output(['git','diff','--',
    'src/Language/Haskell/Djex/Command.hs','src/Language/Haskell/Djex/REPL.hs','test-cli/Spec.hs'],cwd=ROOT)
for name in ['ordinary-context-build-v1.log','ordinary-context-build-v2.log','ordinary-context-build-v3.log',
             'ordinary-context-before-scheduler-assertion.hs','check-ordinary-context-output.py',
             'check-ordinary-context-after.py','check-ordinary-context-bounded.py',
             'validate-ordinary-context-regression.py','validate-ordinary-context-cli-final.py',
             'run-loaded-provider-regression.py']:
    files['support/'+name] = (ROOT/'dist-newstyle'/name).read_bytes()
files['support/publish-ordinary-context-artifacts.py'] = Path(__file__).read_bytes()
manifest = [{'path':name,'sha256':sha(raw),'bytes':len(raw)} for name,raw in sorted(files.items())]
archive = ROOT/'test-church/receipts/ordinary-contextual-output.zip'
receipt = archive.with_suffix('.json')
assert not archive.exists() and not receipt.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,raw in sorted(files.items()): z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(row['path']))==row['sha256'] for row in manifest)
summary = dict(status='accepted_bounded_ordinary_contextual_repl_output',
    base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    source_hashes={relative:sha((ROOT/relative).read_bytes()) for relative in
        ['src/Language/Haskell/Djex/Command.hs','src/Language/Haskell/Djex/REPL.hs','test-cli/Spec.hs']},
    focused=dict(cases=9,public_queries=36,max_steps=256,choice_budget=20000,
        engines=['djinn','exference','both'],selection=['first','best','all'],
        render=['definition','expression'],signatures=['forall a. C a => Token','forall a. C a => (forall b. b -> b) -> Token'],
        payloads={'Int':37,'Bool':91},status='passed',seconds=50.86),
    regressions=dict(suites=[{k:row[k] for k in ['suite','passed_count','seconds']} for row in accepted],tests=330,
        qualification='Three complete suites passed in the original run; the complete 113-test CLI suite passed after correcting two stale source-assertion callback lines. Production source is identical across those runs.'),
    prior_attempts=dict(baseline_20000='Four confirmed GHC failures followed by a compiler replay stall and the 1200-second outer deadline.',
        rebuilt_20000='Seven of nine cases passed; Exference best and Both best reached their 180-second case deadlines.',
        baseline_256='All nine test cases failed. Some legacy all-output failures are fixture line-extraction parse errors; they do not establish compiler rejection of the complete legacy output.',
        duplicate_diagnostic='The preserved baseline best compiler input contains 7475 identical compatibility expressions. This does not establish equal typed evidence.'),
    boundaries=['The test-only search bound was reduced from 20000 to 256; production limits, candidate ordering and tie retention are unchanged.',
        'This milestone establishes ordinary explicit-forall contextual REPL output; implicit roots, one-shot contextual commands and typed list rendering remain separate work.',
        'No native dependency update or native integration acceptance is claimed.',
        'The full 13 extended and 19 explicit-default operations across all five language/engine combinations remain required.'],
    archive=dict(path=archive.name,sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,artifacts=len(files)),artifacts=manifest)
receipt.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
table = '\n'.join('| '+row['suite']+' | '+str(row['passed_count'])+' | '+str(row['seconds'])+' |' for row in accepted)
report = '''# Ordinary contextual Haskell output retains its selected type choices

Ordinary Djex REPL queries now retain each selected candidate's own typed graph
through presentation. For explicit-forall contextual signatures, the renderer
uses that graph's type selections and scoped dictionary evidence. Expressions
and definitions no longer depend on a behavioral predicate worker to repair an
erased method application. Missing or unsupported evidence produces a rendering
diagnostic; another candidate's evidence is never substituted.

The [receipt](https://github.com/VladimirReshetnikov/Djex/blob/main/test-church/receipts/ordinary-contextual-output.json)
and [archive](https://github.com/VladimirReshetnikov/Djex/blob/main/test-church/receipts/ordinary-contextual-output.zip)
preserve source hashes, complete inventories, commands, compiler/test captures,
the implementation patch, and earlier failed attempts.

## Accepted public coverage

All **9 cases / 36 public queries pass**: Djinn, Exference and Both; first, best
and all selection; expression and definition output; and both signatures:

```haskell
forall a. C a => Token
forall a. C a => (forall b. b -> b) -> Token
```

The loaded method's type variable occurs only in its class constraint. Independent
GHC execution checks every displayed candidate verbatim under its original full
signature and distinguishes the Int payload 37 from the Bool payload 91. The
higher-rank argument is also supplied at replay. Both mode must emit a candidate
from each labeled engine section. These are ordinary queries without a `where`
predicate. The focused matrix passes in **50.86 seconds**.

Selection continues to rank the candidate's compatibility projection with the
existing selector rules, retaining the original typed handle for rendering.
Legacy Exference all-selection still streams, and best still retains tied
candidates. Prepared parallel paths receive the parsed signature. Production
search limits, provider inventories, ranking and tie retention are unchanged.

## Complete affected regressions

Strict builds pass. All **330 tests in four complete affected suites pass**
across the following recorded runs:

| Suite | Tests | Seconds |
| --- | --- | --- |
''' + table + '''

The first aggregate run passed three complete suites and 112/113 CLI tests. Its
only failure was a source assertion still expecting preparation callbacks without
the parsed signature argument. After correcting those two expected lines, the
complete CLI suite passed. Production source remained identical; the archive
retains the original fixture and failure. The other project suites were not
rerun for this frontend-only milestone.

## Fixture bounds and retained failures

The initial new fixture used 20,000 Exference steps. Its preserved baseline best
compiler input contains 7,475 copies of the same compatibility expression; equal
printed expressions do not establish interchangeable typed evidence. The baseline
run recorded four GHC failures, then a compiler replay stalled until the owned
outer guard terminated it. The rebuilt run passed seven cases but timed out in
Exference best and Both best at 180 seconds per case.

The accepted presentation fixture uses **256 search steps**, retaining all 36
queries, every displayed alternative, the 20,000 Djinn choice budget and the same
signatures/payloads. Its GHC replay uses a process job for owned child cleanup.
The paired baseline still fails all nine cases, although some legacy all-output
failures come from line extraction and are not claims about complete legacy
renderings. This is bounded presentation acceptance, not a performance repair or
acceptance of the earlier 20,000-step best queries.

## Remaining work

Implicit-root binder order/scope, one-shot contextual commands, typed list
rendering, derived Haskell methods, mixed Lean inventories, selected equal-predicate
dictionaries and richer evidence remain separate deliveries. Leant's committed
dependency is unchanged; the native recursor timeouts and remaining integration
gates stay open. The [current roadmap](2026-09-07-synthesis-retriage.md) preserves
all priorities 1–4 and all 13 extended plus 19 explicit-default Church operations
across Haskell Djinn/Exference and Lean Djinn/Exference/Both.
'''
for root in [ROOT,Path('C:/Leant')]:
    p = root/'docs/reports/2026-09-08-ordinary-contextual-output.md'
    assert not p.exists()
    p.write_text(report,encoding='utf-8')
    p = root/'docs/reports/2026-09-07-synthesis-retriage.md'
    s = p.read_text(encoding='utf-8')
    start = s.index('| **First implementation delivery')
    end = s.index('\n',start)
    s = s[:start]+s[end+1:]
    start = s.index('The changed order favors')
    end = s.index('\nThe full supplied-default worklist',start)
    s = s[:start]+'''The [ordinary contextual REPL delivery](2026-09-08-ordinary-contextual-output.md)
now passes all 36 public queries and 330 tests across four complete affected
suites, with the documented test-only assertion correction and 256-step fixture.
It leaves the implementation queue. The earlier 20,000-step best timeouts remain
recorded; this delivery does not repair their performance. Implicit-root scope,
one-shot contextual commands and typed list rendering remain open.

Native integration remains a release gate for the dependency. Execute heavy
checks serially with frozen inputs, and rerun accepted aggregate suites when
relevant production inputs change.
''' + s[end:]
    s = s.replace('**Handle implicit-root binder scope and typed list rendering as separate increments.**',
        '**Handle implicit-root binder scope, one-shot contextual commands and typed list rendering as separate increments.**',1)
    p.write_text(s,encoding='utf-8')

p=ROOT/'README.md'
s=p.read_text(encoding='utf-8')
old='''[current delivery order](docs/reports/2026-09-07-synthesis-retriage.md) prioritizes
exact ordinary Haskell contextual output, whose prototype builds but still needs
replay acceptance, followed by a focused native timeout diagnosis and the Lean
tree check at unchanged bounds. Native integration remains a dependency-release
gate. The earlier layered-provider failure now passes in the complete unit suite.'''
new='''[ordinary contextual REPL output](docs/reports/2026-09-08-ordinary-contextual-output.md)
now retains selected type and dictionary choices through first/best/all rendering:
all 36 explicit-forall public queries and 330 tests across four complete affected
suites pass at the documented fixture bounds. Implicit-root scope, one-shot
contextual commands and typed list rendering remain open. The
[current delivery order](docs/reports/2026-09-07-synthesis-retriage.md) returns to
native timeout diagnosis and the Lean tree check at unchanged bounds; native
integration remains a dependency-release gate.'''
assert old in s
p.write_text(s.replace(old,new,1),encoding='utf-8')
p=Path('C:/Leant/README.md')
s=p.read_text(encoding='utf-8')
old='''  puts exact ordinary Haskell contextual output first (prototype builds; replay
  acceptance pending), then a focused native timeout diagnosis and the native
  tree check. Broader search estimates were rejected after losing Church composition.'''
new='''  returns to native timeout diagnosis and the native tree check after the
  [ordinary Haskell contextual REPL delivery](docs/reports/2026-09-08-ordinary-contextual-output.md):
  36 explicit-forall public queries and 330 tests across four complete affected
  suites pass at the documented fixture bounds. Implicit-root scope, one-shot
  contextual commands and typed list rendering remain open. Broader search
  estimates were rejected after losing Church composition.'''
assert old in s
p.write_text(s.replace(old,new,1),encoding='utf-8')
p=ROOT/'docs/reports/2026-09-07-synthesis-priorities-1-4.md'
s=p.read_text(encoding='utf-8')
old='''also pass explicit-forall behavioral queries in both engines. Implicit-root
scoping, ordinary contextual presentation, derived method schemes, mixed Lean'''
new='''also pass explicit-forall behavioral queries in both engines. The
[ordinary contextual REPL delivery](2026-09-08-ordinary-contextual-output.md) now
passes 36 public queries and 330 tests across four complete affected suites at
its documented bounds. Implicit-root scoping, one-shot contextual commands,
typed list rendering, derived method schemes, mixed Lean'''
assert old in s
p.write_text(s.replace(old,new,1),encoding='utf-8')
print(json.dumps({'status':summary['status'],'tests':330,'archive':summary['archive']}),flush=True)
