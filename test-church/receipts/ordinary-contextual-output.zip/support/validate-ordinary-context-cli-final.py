"""Complete affected frontend suites after focused ordinary-output acceptance."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path('C:/Djex')
spec = importlib.util.spec_from_file_location('regression', ROOT/'dist-newstyle/run-loaded-provider-regression.py')
regression = importlib.util.module_from_spec(spec)
spec.loader.exec_module(regression)
regression.SUITES = ['djex-cli-tests']
regression.REQUIRED['djex-cli-tests'] += [
    'ordinary contextual presentation retains typed choices.' + backend + ' ' + selection
    for backend in ['djinn', 'exference', 'both'] for selection in ['first', 'best', 'all']]
OUT = ROOT/'dist-newstyle/ordinary-context-cli-final-v1'
OUT.mkdir(exist_ok=False)
own_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
build = ['cabal','build', 'exe:djex', 'exe:djex-fake-cabal', 'exe:djex-fake-z3',
         *['test:'+suite for suite in regression.SUITES], '-j1', '--ghc-options=-Werror']
with (OUT/'strict-build.log').open('wb') as capture:
    result = subprocess.run(build, cwd=ROOT, stdout=capture, stderr=subprocess.STDOUT, timeout=1200)
if result.returncode:
    raise SystemExit(result.returncode)
print('Strict build passed; running the complete CLI suite after the source-assertion correction.', flush=True)
sys.argv = [str(ROOT/'dist-newstyle/run-loaded-provider-regression.py'), str(OUT/'regression')]
code = regression.main()
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == own_hash
(OUT/'driver.json').write_text(json.dumps(dict(driver_sha256=own_hash,build=build,
    suite_count=len(regression.SUITES),status='passed' if code == 0 else 'failed'),indent=2)+'\n')
raise SystemExit(code)
