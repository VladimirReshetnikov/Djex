{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, AllowAmbiguousTypes, FlexibleContexts, KindSignatures #-}
module Main where
import Data.Kind (Type)
data Token = Token Int
class C (a :: Type) where payload :: Int
instance C Int where payload = 37
instance C Bool where payload = 91
provider :: forall a. C a => Token
provider = Token (payload @a)
observe (Token n) = n
candidate :: forall a b. (C a, C b) => Token
candidate = (((provider @(b)) :: (C b) => Token) :: Token)
main :: IO ()
main = print (observe (candidate @Int @Bool), observe (candidate @Bool @Int))
