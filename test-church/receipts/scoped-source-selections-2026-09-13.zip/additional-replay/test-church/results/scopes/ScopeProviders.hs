{-# LANGUAGE RankNTypes, ImpredicativeTypes, NoImplicitPrelude, NoPolyKinds, EmptyDataDecls #-}
module ScopeProviders (F, H, G, G3, Seed, Token, delayedProvider, delayedValue, alternatingProvider, unitSeed, seedProvider, layeredBinaryProvider, layeredTernaryProvider) where
data F a = F
data H a
data G a b = G
data G3 a b c = G3
data Seed = Seed
data Token = Token
delayedProvider :: forall a. F (forall b. b -> a) -> Token
delayedProvider _ = Token
delayedValue :: F (forall c. c -> (forall d. d -> d))
delayedValue = F
alternatingProvider :: forall a. a -> () -> (forall b. b -> G a b)
alternatingProvider _ _ _ = G
unitSeed :: ()
unitSeed = ()
seedProvider :: Seed
seedProvider = Seed
layeredBinaryProvider :: Seed -> forall a. a -> Seed -> forall b. b -> G a b
layeredBinaryProvider _ _ _ _ = G
layeredTernaryProvider :: Seed -> forall a b. a -> b -> Seed -> forall c. c -> G3 a b c
layeredTernaryProvider _ _ _ _ _ = G3
