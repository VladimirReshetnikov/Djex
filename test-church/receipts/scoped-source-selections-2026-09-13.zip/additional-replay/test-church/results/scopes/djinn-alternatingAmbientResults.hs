{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_alternatingAmbientResults where
import ScopeProviders (F, H, G, G3, Seed, Token)
alternatingAmbientResults :: forall seed x. seed -> (seed -> forall a. a -> seed -> forall b. b -> G a b) -> G (forall c. x -> c -> c) (forall d. d -> d)
alternatingAmbientResults a b = b a (\_ c -> c) a (\d -> d)
