{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_alternatingGlobalResults where
import ScopeProviders (F, H, G, G3, Seed, Token, alternatingProvider, unitSeed)
alternatingGlobalResults :: G (forall c. c -> c) (forall d. d -> d)
alternatingGlobalResults =
  alternatingProvider (\a -> a) unitSeed (\b -> b)
