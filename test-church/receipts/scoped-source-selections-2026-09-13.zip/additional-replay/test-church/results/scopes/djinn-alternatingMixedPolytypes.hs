{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_alternatingMixedPolytypes where
import ScopeProviders (F, H, G, G3, Seed, Token)
alternatingMixedPolytypes :: forall seed f. seed -> (seed -> forall a b. a -> b -> seed -> forall c. c -> f a b c) -> f (forall a. a -> a) (forall a. a -> a -> a) (forall a. a -> a)
alternatingMixedPolytypes a b =
  b a (\c -> c) (\_ d -> d) a (\e -> e)
