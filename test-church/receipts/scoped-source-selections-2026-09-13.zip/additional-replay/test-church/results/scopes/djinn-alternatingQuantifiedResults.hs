{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_alternatingQuantifiedResults where
import ScopeProviders (F, H, G, G3, Seed, Token)
alternatingQuantifiedResults :: forall seed. seed -> (seed -> forall a. a -> seed -> forall b. b -> G a b) -> G (forall c. c -> c) (forall d. d -> d)
alternatingQuantifiedResults a b = b a (\c -> c) a (\d -> d)
