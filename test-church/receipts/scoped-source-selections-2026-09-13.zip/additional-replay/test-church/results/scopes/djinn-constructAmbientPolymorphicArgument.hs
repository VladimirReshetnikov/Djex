{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructAmbientPolymorphicArgument where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructAmbientPolymorphicArgument :: forall x. (forall a. a -> F a) -> F (forall b. x -> b -> x)
constructAmbientPolymorphicArgument a = a (\b _ -> b)
