{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructNestedDependentArgument where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructNestedDependentArgument :: (forall a. a -> F a) -> F (forall b. b -> F (forall c. b -> c -> b))
constructNestedDependentArgument a = a (\b -> a (\_ _ -> b))
