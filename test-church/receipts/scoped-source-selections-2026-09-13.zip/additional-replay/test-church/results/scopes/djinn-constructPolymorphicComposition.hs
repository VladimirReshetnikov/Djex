{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructPolymorphicComposition where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructPolymorphicComposition :: forall f g h k. (forall a. a -> f a) -> (forall a. g a -> h a) -> (forall a. h a -> k a) -> f (forall a. g a -> k a)
constructPolymorphicComposition a b c = a (\d -> c (b d))
