{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructRepeatedBinderPolytypes where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructRepeatedBinderPolytypes :: (forall a b. a -> b -> G a b) -> G (forall a. a -> a) (forall a. a -> a -> a)
constructRepeatedBinderPolytypes a = a (\b -> b) (\_ c -> c)
