{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_correlatedAlpha where
import ScopeProviders (F, H, G, G3, Seed, Token)
correlatedAlpha :: (forall a. G a (F a)) -> G (forall q. q -> q) (F (forall z. z -> z))
correlatedAlpha a = a
