{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_delayedAmbientArgument where
import ScopeProviders (F, H, G, G3, Seed, Token)
delayedAmbientArgument :: forall x. (forall a. F (forall b. b -> a) -> Token) -> F (forall c. c -> (forall d. x -> d -> d)) -> Token
delayedAmbientArgument a = a @(forall a0_0. _ -> a0_0 -> a0_0)
