{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_delayedArgumentInstantiation where
import ScopeProviders (F, H, G, G3, Seed, Token)
delayedArgumentInstantiation :: (forall a. F (forall b. b -> a) -> Token) -> F (forall c. c -> (forall d. d -> d)) -> Token
delayedArgumentInstantiation a = a @(forall a0_0. a0_0 -> a0_0)
