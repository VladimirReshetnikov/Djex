{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_delayedGlobalAmbientArgument where
import ScopeProviders (F, H, G, G3, Seed, Token, delayedProvider)
delayedGlobalAmbientArgument :: forall x. F (forall c. c -> (forall d. x -> d -> d)) -> Token
delayedGlobalAmbientArgument =
  delayedProvider @(forall a0_0. _ -> a0_0 -> a0_0)
