{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_delayedGlobalArgument where
import ScopeProviders (F, H, G, G3, Seed, Token, delayedProvider, delayedValue)
delayedGlobalArgument :: Token
delayedGlobalArgument =
  delayedProvider @(forall a0_0. a0_0 -> a0_0) delayedValue
