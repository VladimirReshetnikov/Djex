{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_higherKindedCorrelation where
import ScopeProviders (F, H, G, G3, Seed, Token)
higherKindedCorrelation :: forall f x. (forall a b. G (f a) (f b)) -> G (f x) (f (forall z. z -> z))
higherKindedCorrelation a = a
