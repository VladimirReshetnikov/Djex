{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_nestedAbstractConstructor where
import ScopeProviders (F, H, G, G3, Seed, Token)
nestedAbstractConstructor :: forall f. (forall a. f (forall b. b -> a)) -> f (forall c. c -> (forall d. d -> d))
nestedAbstractConstructor a = a @(forall a0_0. a0_0 -> a0_0)
