{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_nestedAmbientShadowing where
import ScopeProviders (F, H, G, G3, Seed, Token)
nestedAmbientShadowing :: forall a. (forall b. F (forall a. a -> b)) -> F (forall b. b -> (forall c. a -> c -> a))
nestedAmbientShadowing a = a @(forall a0_0. _ -> a0_0 -> _)
