{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_nestedCorrelatedAmbient where
import ScopeProviders (F, H, G, G3, Seed, Token)
nestedCorrelatedAmbient :: forall x y. (forall a. G (forall b. b -> a) a) -> G (forall c. c -> (forall d. x -> y -> d -> x)) (forall e. x -> y -> e -> x)
nestedCorrelatedAmbient a = a
