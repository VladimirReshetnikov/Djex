{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_nestedHigherKindedAmbient where
import ScopeProviders (F, H, G, G3, Seed, Token)
nestedHigherKindedAmbient :: forall f. (forall a. F (forall b. b -> a)) -> F (forall c. c -> (forall d. f d -> d -> f d))
nestedHigherKindedAmbient a =
  a @(forall a0_0. _ a0_0 -> a0_0 -> _ a0_0)
