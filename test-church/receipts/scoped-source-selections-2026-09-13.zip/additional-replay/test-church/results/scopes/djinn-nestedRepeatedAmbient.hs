{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_nestedRepeatedAmbient where
import ScopeProviders (F, H, G, G3, Seed, Token)
nestedRepeatedAmbient :: forall x y. (forall a. F (forall b. b -> a)) -> F (forall c. c -> (forall d. x -> y -> x -> d -> d))
nestedRepeatedAmbient a =
  a @(forall a0_0. _ -> _ -> _ -> a0_0 -> a0_0)
