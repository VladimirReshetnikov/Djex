{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_polymorphicResultAfterArgument where
import ScopeProviders (F, H, G, G3, Seed, Token)
polymorphicResultAfterArgument :: forall seed. seed -> (seed -> (forall a. a -> F a)) -> F (forall b. b -> b)
polymorphicResultAfterArgument a b = b a (\c -> c)
