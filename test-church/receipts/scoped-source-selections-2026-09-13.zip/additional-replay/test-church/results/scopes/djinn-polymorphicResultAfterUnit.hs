{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_polymorphicResultAfterUnit where
import ScopeProviders (F, H, G, G3, Seed, Token, unitSeed)
polymorphicResultAfterUnit :: (() -> (forall a. a -> F a)) -> F (forall b. b -> b)
polymorphicResultAfterUnit a = a unitSeed (\b -> b)
