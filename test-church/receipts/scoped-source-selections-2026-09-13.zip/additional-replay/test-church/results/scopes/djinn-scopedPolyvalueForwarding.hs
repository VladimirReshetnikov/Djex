{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_scopedPolyvalueForwarding where
import ScopeProviders (F, H, G, G3, Seed, Token)
scopedPolyvalueForwarding :: (forall a. a -> a) -> ((forall x. x -> x) -> Token) -> Token
scopedPolyvalueForwarding _ a = a (\b -> b)
