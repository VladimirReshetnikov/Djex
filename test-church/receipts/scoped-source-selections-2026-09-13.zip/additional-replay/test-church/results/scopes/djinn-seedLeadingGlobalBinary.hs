{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_seedLeadingGlobalBinary where
import ScopeProviders (F, H, G, G3, Seed, Token, seedProvider, layeredBinaryProvider)
seedLeadingGlobalBinary :: G (forall a. a -> a) (forall a. a -> a -> a)
seedLeadingGlobalBinary =
  layeredBinaryProvider
  seedProvider
  (\a -> a)
  seedProvider
  (\_ b -> b)
