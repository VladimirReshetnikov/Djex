{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_seedLeadingGlobalTernary where
import ScopeProviders (F, H, G, G3, Seed, Token, seedProvider, layeredTernaryProvider)
seedLeadingGlobalTernary :: G3 (forall a. a -> a) (forall a. a -> a -> a) (forall a. a -> a)
seedLeadingGlobalTernary =
  layeredTernaryProvider
  seedProvider
  (\a -> a)
  (\_ b -> b)
  seedProvider
  (\c -> c)
