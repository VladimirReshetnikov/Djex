{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_shadowedResult where
import ScopeProviders (F, H, G, G3, Seed, Token)
shadowedResult :: forall a. (forall b. G a b) -> G a (forall a. a -> a)
shadowedResult a = a
