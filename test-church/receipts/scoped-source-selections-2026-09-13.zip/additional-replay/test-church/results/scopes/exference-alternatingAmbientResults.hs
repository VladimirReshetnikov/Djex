{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_alternatingAmbientResults where
import ScopeProviders (F, H, G, G3, Seed, Token)
alternatingAmbientResults :: forall seed x. seed -> (seed -> forall a. a -> seed -> forall b. b -> G a b) -> G (forall c. x -> c -> c) (forall d. d -> d)
alternatingAmbientResults a f2 =
  let f6 = f2 a @(forall a0_0. _ -> a0_0 -> a0_0) (\_ -> \i -> i)
  in let f11 = f6 a in f11 (\n -> n)
