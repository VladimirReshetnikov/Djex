{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_alternatingGlobalResults where
import ScopeProviders (F, H, G, G3, Seed, Token, alternatingProvider, unitSeed)
alternatingGlobalResults :: G (forall c. c -> c) (forall d. d -> d)
alternatingGlobalResults =
  let f1 = alternatingProvider @(forall a0_0. a0_0 -> a0_0) (\c -> c)
  in let f5 = f1 unitSeed in f5 (\h -> h)
