{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_alternatingMixedPolytypes where
import ScopeProviders (F, H, G, G3, Seed, Token)
alternatingMixedPolytypes :: forall seed f. seed -> (seed -> forall a b. a -> b -> seed -> forall c. c -> f a b c) -> f (forall a. a -> a) (forall a. a -> a -> a) (forall a. a -> a)
alternatingMixedPolytypes a f2 =
  let f6 = f2
           a @(forall a0_0. a0_0 -> a0_0) @(forall a0_0. a0_0 -> a0_0 -> a0_0)
           (\h -> h)
  in let f10 = f6 (\l -> \_ -> l) in let f15 = f10 a in f15 (\r -> r)
