{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_alternatingQuantifiedResults where
import ScopeProviders (F, H, G, G3, Seed, Token)
alternatingQuantifiedResults :: forall seed. seed -> (seed -> forall a. a -> seed -> forall b. b -> G a b) -> G (forall c. c -> c) (forall d. d -> d)
alternatingQuantifiedResults a f2 =
  let f6 = f2 a @(forall a0_0. a0_0 -> a0_0) (\h -> h)
  in let f10 = f6 a in f10 (\m -> m)
