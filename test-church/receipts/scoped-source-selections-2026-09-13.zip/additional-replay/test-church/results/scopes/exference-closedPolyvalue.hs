{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_closedPolyvalue where
import ScopeProviders (F, H, G, G3, Seed, Token)
closedPolyvalue :: (forall a. F a) -> F (forall b. b -> b)
closedPolyvalue f1 = f1
