{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_compoundAlpha where
import ScopeProviders (F, H, G, G3, Seed, Token)
compoundAlpha :: (forall a. G (F a) (H a)) -> G (F (forall b. b -> b)) (H (forall c. c -> c))
compoundAlpha g1 = g1
