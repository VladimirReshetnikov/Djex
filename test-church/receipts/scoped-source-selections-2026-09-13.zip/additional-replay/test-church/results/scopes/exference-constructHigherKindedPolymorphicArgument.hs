{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructHigherKindedPolymorphicArgument where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructHigherKindedPolymorphicArgument :: forall g. (forall a. a -> F a) -> F (forall b. g b -> g b)
constructHigherKindedPolymorphicArgument f1 = f1 (\d -> d)
