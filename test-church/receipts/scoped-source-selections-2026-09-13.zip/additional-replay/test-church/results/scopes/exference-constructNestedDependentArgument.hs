{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructNestedDependentArgument where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructNestedDependentArgument :: (forall a. a -> F a) -> F (forall b. b -> F (forall c. b -> c -> b))
constructNestedDependentArgument f1 = f1 (\d -> f1 (\_ -> \_ -> d))
