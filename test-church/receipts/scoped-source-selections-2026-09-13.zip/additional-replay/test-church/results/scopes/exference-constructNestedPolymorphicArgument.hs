{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructNestedPolymorphicArgument where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructNestedPolymorphicArgument :: (forall a. a -> F a) -> F (forall b. b -> F (forall c. c -> c))
constructNestedPolymorphicArgument f1 = f1 (\_ -> f1 (\g -> g))
