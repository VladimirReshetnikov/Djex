{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructPolymorphicArgument where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructPolymorphicArgument :: (forall a. a -> F a) -> F (forall b. b -> b)
constructPolymorphicArgument f1 = f1 (\d -> d)
