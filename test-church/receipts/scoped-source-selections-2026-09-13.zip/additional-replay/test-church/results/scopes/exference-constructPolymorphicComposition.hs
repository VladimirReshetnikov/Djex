{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructPolymorphicComposition where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructPolymorphicComposition :: forall f g h k. (forall a. a -> f a) -> (forall a. g a -> h a) -> (forall a. h a -> k a) -> f (forall a. g a -> k a)
constructPolymorphicComposition f1 f2 f3 = f1 (\f -> f3 (f2 f))
