{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_constructTwoPolymorphicArguments where
import ScopeProviders (F, H, G, G3, Seed, Token)
constructTwoPolymorphicArguments :: (forall a b. a -> b -> G a b) -> G (forall c. c -> c) (forall d e. d -> e -> d)
constructTwoPolymorphicArguments f1 = f1 (\e -> e) (\g -> \_ -> g)
