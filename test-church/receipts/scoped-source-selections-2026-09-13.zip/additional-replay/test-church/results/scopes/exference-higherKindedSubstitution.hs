{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_higherKindedSubstitution where
import ScopeProviders (F, H, G, G3, Seed, Token)
higherKindedSubstitution :: (forall f a. G (f a) a) -> G (F (forall z. z -> z)) (forall y. y -> y)
higherKindedSubstitution g1 = g1
