{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_nestedAmbientResult where
import ScopeProviders (F, H, G, G3, Seed, Token)
nestedAmbientResult :: forall x. (forall a. F (forall b. b -> a)) -> F (forall c. c -> (forall d. x -> d -> d))
nestedAmbientResult f1 = f1 @(forall a0_0. _ -> a0_0 -> a0_0)
