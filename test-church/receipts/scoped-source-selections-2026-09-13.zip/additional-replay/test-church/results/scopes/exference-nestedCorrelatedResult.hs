{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_nestedCorrelatedResult where
import ScopeProviders (F, H, G, G3, Seed, Token)
nestedCorrelatedResult :: (forall a. G (forall b. b -> a) a) -> G (forall x. x -> (forall y. y -> y)) (forall z. z -> z)
nestedCorrelatedResult g1 = g1
