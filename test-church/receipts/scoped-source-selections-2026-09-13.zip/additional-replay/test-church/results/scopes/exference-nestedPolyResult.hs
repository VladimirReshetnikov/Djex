{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_nestedPolyResult where
import ScopeProviders (F, H, G, G3, Seed, Token)
nestedPolyResult :: (forall a. F (forall b. b -> a)) -> F (forall c. c -> (forall d. d -> d))
nestedPolyResult f1 = f1 @(forall a0_0. a0_0 -> a0_0)
