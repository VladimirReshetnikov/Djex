{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_outerRigidCapture where
import ScopeProviders (F, H, G, G3, Seed, Token)
outerRigidCapture :: forall a. ((forall b. a -> b -> b) -> F a) -> F a
outerRigidCapture f1 = f1 (\_ -> \e -> e)
