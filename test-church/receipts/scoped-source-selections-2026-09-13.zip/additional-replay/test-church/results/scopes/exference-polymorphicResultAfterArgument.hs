{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_polymorphicResultAfterArgument where
import ScopeProviders (F, H, G, G3, Seed, Token)
polymorphicResultAfterArgument :: forall seed. seed -> (seed -> (forall a. a -> F a)) -> F (forall b. b -> b)
polymorphicResultAfterArgument a f2 = let f4 = f2 a in f4 (\g -> g)
