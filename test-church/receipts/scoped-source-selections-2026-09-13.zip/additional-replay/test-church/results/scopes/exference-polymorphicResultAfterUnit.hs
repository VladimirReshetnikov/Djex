{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_polymorphicResultAfterUnit where
import ScopeProviders (F, H, G, G3, Seed, Token, unitSeed)
polymorphicResultAfterUnit :: (() -> (forall a. a -> F a)) -> F (forall b. b -> b)
polymorphicResultAfterUnit f1 =
  let f3 = f1 unitSeed in f3 (\f -> f)
