{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_seedLeadingGlobalBinary where
import ScopeProviders (F, H, G, G3, Seed, Token, seedProvider, layeredBinaryProvider)
seedLeadingGlobalBinary :: G (forall a. a -> a) (forall a. a -> a -> a)
seedLeadingGlobalBinary =
  let f3 = layeredBinaryProvider
           seedProvider @(forall a0_0. a0_0 -> a0_0)
           (\e -> e)
  in let f7 = f3 seedProvider in f7 (\j -> \_ -> j)
