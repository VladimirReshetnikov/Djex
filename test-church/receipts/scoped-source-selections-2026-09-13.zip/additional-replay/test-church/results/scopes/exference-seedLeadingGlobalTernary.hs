{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_seedLeadingGlobalTernary where
import ScopeProviders (F, H, G, G3, Seed, Token, seedProvider, layeredTernaryProvider)
seedLeadingGlobalTernary :: G3 (forall a. a -> a) (forall a. a -> a -> a) (forall a. a -> a)
seedLeadingGlobalTernary =
  let f3 = layeredTernaryProvider
           seedProvider @(forall a0_0. a0_0 -> a0_0) @(forall a0_0. a0_0 -> a0_0 -> a0_0)
           (\e -> e)
  in let f7 = f3 (\i -> \_ -> i)
     in let f12 = f7 seedProvider in f12 (\o -> o)
