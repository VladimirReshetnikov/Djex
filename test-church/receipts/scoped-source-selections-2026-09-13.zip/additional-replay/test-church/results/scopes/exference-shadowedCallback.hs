{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_shadowedCallback where
import ScopeProviders (F, H, G, G3, Seed, Token)
shadowedCallback :: forall a. a -> ((forall a. a -> a) -> F a) -> F a
shadowedCallback _ f2 = f2 (\e -> e)
