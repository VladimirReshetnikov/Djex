{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables #-}
{-# LANGUAGE NoImplicitPrelude, TypeApplications, NoPolyKinds #-}
module Scope_successiveQuantifiers where
import ScopeProviders (F, H, G, G3, Seed, Token)
successiveQuantifiers :: (forall a. (forall b. G a b)) -> G (forall x. x -> x) (forall y. y -> y)
successiveQuantifiers g1 = g1
