import Control.Monad (forM, forM_, unless)
import Data.List (sort)
import System.Directory (createDirectory)
import System.Exit (ExitCode(ExitSuccess))
import System.Process (readProcessWithExitCode)
import System.Timeout (timeout)
import Data.Void (Void)
import Language.Haskell.Djex
import qualified Language.Haskell.Synthesis.TypedGenerated.Haskell as H

right :: Show e => Either e a -> IO a
right = either (fail . show) pure
main :: IO ()
main = do
  c <- right $ parseName "C"
  token <- right $ parseName "Token"
  provider <- right $ parseName "provider"
  target <- right $ mkIdentifier "selectedCandidate"
  let v = TypeVariable
      ctx x = Constraint c [v x]
      ty = TypeConstructor token
      scheme = ForallType ["p"] [ctx "p"] ty
      signature = ForallType ["a", "b"] [ctx "a", ctx "b"] ty
      declarations :: [Declaration String Void ()]
      declarations = [ClassDeclaration () c [TypeParameter "p" (Just ProperTypeKind)] [] [],
        AbstractTypeDeclaration () token ProperTypeKind,
        ValueDeclaration $ ValueSignature () provider scheme]
  environment <- right $ mkEnvironment declarations
  session <- right $ mkDjinnSession environment
  request <- right $ parseDjinnRequest session defaultQueryOptions
    {optionCutoff=32,optionBudget=Just 20000,optionAlternatives=True,optionSorted=False,optionStrategy=Interleave}
    target "scoped-selection-query" "forall a b. (C a, C b) => Token"
  result <- right $ runDjinnTypedQuery session request
  stream <- right $ runDjinnTypedQueryStream session request
  observations <- mapM right stream
  createDirectory "dist-newstyle/source-selection-ghc-replay-v1"
  forM_ [("batch", batchCandidates $ resultSearch result),
         ("stream", concatMap (batchCandidates . resultSearch) observations)] $ \(mode, candidates) -> do
    unless (length candidates <= 32) $ fail "candidate bound changed"
    observed <- forM (zip [0 :: Int ..] candidates) $ \(index, candidate) -> do
      graph <- right $ typedCandidateTermGraph candidate
      rendered <- right $ H.renderHaskellTermGraphAtSignatureWithMetavariables (defaultRenderOptions id) signature graph
      let path = "dist-newstyle/source-selection-ghc-replay-v1/" ++ mode ++ "-" ++ show index ++ ".hs"
          fixture = unlines
            [ "{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, AllowAmbiguousTypes, FlexibleContexts, KindSignatures #-}"
            , "module Main where"
            , "import Data.Kind (Type)"
            , "data Token = Token Int"
            , "class C (a :: Type) where payload :: Int"
            , "instance C Int where payload = 37"
            , "instance C Bool where payload = 91"
            , "provider :: forall a. C a => Token"
            , "provider = Token (payload @a)"
            , "observe (Token n) = n"
            , "candidate :: forall a b. (C a, C b) => Token"
            , "candidate = " ++ rendered
            , "main :: IO ()"
            , "main = print (observe (candidate @Int @Bool), observe (candidate @Bool @Int))"
            ]
      writeFile path fixture
      outcome <- timeout 60000000 $ readProcessWithExitCode "runghc" [path] ""
      case outcome of
        Just (ExitSuccess, output, errors) -> do
          writeFile (path ++ ".stdout.txt") output
          writeFile (path ++ ".stderr.txt") errors
          putStrLn $ mode ++ " " ++ show index ++ " " ++ rendered ++ " => " ++ output
          pure $ filter (`notElem` "\r\n") output
        other -> fail $ "independent replay failed: " ++ show other ++ "\n" ++ fixture
    unless (sort observed == ["(37,91)", "(91,37)"]) $ fail $ "lost a selected dictionary: " ++ show observed
  putStrLn "Both public modes preserve both distinct dictionary selections; all four GHC replays passed."
