{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes, FlexibleContexts, KindSignatures #-}
module Main where
import Data.Kind (Type)
data Token = Token Int
class C (a :: Type) where payload :: Int
instance C Int where payload = 37
instance C Bool where payload = 91
provider :: forall p. C p => Token
provider = Token (payload @p)
observe (Token n) = n
candidate :: forall a b. (C a, C b) => (forall p. C p => Token) -> Token
candidate = (\a -> (((a @(a)) :: (C a) => Token) :: Token))
main :: IO ()
main = print (observe (candidate @Int @Bool (\ @p -> provider @p)), observe (candidate @Bool @Int (\ @p -> provider @p)))
