from pathlib import Path
import hashlib, json, re, subprocess, zipfile
root=Path.cwd()
def sha(data): return hashlib.sha256(data).hexdigest()
items={}
for version in (1,2,3):
    folder=root/f'dist-newstyle/scoped-selections-validation-v{version}'
    result=json.loads((folder/'results.json').read_text())
    assert result['status'] in ('passed','failed')
    assert all(result[k] for k in ['sources_unchanged','binaries_unchanged','controller_unchanged'])
    patch=(folder/'source.patch').read_bytes()
    changed=set(re.findall(r'^diff --git a/(.*?) b/',patch.decode(),re.M))
    changed.update(['djinn/src-internal/Djinn/Internal/SourceAnnotation.hs','djinn/test-source-graph-private/SourceSelectionSpec.hs'])
    for file in folder.rglob('*'):
        if not file.is_file(): continue
        rel=file.relative_to(folder)
        if rel.parts[0]=='source' and str(Path(*rel.parts[1:])).replace('\\','/') not in changed: continue
        items[f'validation-v{version}/{rel.as_posix()}']=file.read_bytes()
    controller=root/f'dist-newstyle/run-scoped-selections-validation-v{version}.py'
    assert sha(controller.read_bytes())==result['controller_sha256']
    items[f'validation-v{version}/controller.py']=controller.read_bytes()
for file in (root/'dist-newstyle').glob('scoped-selections-*.log'):
    if file.name=='scoped-selections-cli-v1.log': continue
    items['diagnostics/'+file.name]=file.read_bytes()
for name in ['replay-scoped-query.hs','replay-scoped-query-v1.log','retriage-local-callback-replay.hs','retriage-local-callback-replay.log']:
    items['diagnostics/'+name]=(root/'dist-newstyle'/name).read_bytes()
for folder in ['test-church/results/scopes','dist-newstyle/source-selection-ghc-replay-v1']:
    for file in (root/folder).rglob('*'):
        if file.is_file() and file.suffix not in ('.exe','.o','.hi'):
            items['additional-replay/'+file.relative_to(root).as_posix()]=file.read_bytes()
# Only invoke once the CLI process is terminal, so its output is complete.
cli=(root/'dist-newstyle/scoped-selections-cli-v1.log').read_bytes()
assert b'Test suite djex-cli-tests: PASS' in cli
items['cli/scoped-selections-cli-v1.log']=cli
items['packaging-controller.py']=Path(__file__).read_bytes()
items['README.txt']=('Each validation directory retains the original controller, results, source manifest, diff, and changed source files.\n'
 'Reconstruct a run from its results.json head commit, then overlay its source directory. Unchanged files are identified by the complete source_sha256 map and remain available in that commit.\n'
 'The final run is validation-v3. Build with GHC 9.12.4 on Windows and cabal build exe:djex test:djex-tests test:djinn-tests test:synthesis-tests test:djinn-source-graph-private-tests test:djinn-source-graph-tests test:djex-church-tests test:djex-rank-n-scope-tests --ghc-options=-Werror -j1.\n'
 'Run the archived validation-v3 controller from the reconstructed checkout. Its output directory must not already exist. Run the CLI gate separately with cabal test djex-cli-tests --ghc-options=-Werror -j1 --test-show-details=direct --test-options=-j1.\n'
 'Signature synthesis/typechecking, scope probes, finite dictionary observations, and CLI tests are separate claims. No native Lean integration or additional Church behavior cell is claimed.\n').encode()
manifest=[{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(items.items())]
items['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=root/'test-church/receipts/scoped-source-selections-2026-09-13.zip'
assert not out.exists()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(items.items()): z.writestr(name,data)
with zipfile.ZipFile(out) as z:
    for row in manifest:
        data=z.read(row['path'])
        assert len(data)==row['bytes'] and sha(data)==row['sha256']
receipt={'schema':'scoped-source-selections-v1','status':'canonical_haskell_acceptance','base_commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'implementation_identity':'validation-v3/results.json source_sha256 and source.patch; changed source files retained','gates':{'strict_build':'scoped-selections-build-v7.log plus final private test rebuild scoped-selections-build-v9.log','budgets':10,'public_dictionary_selections':2,'private_graph':120,'shared_synthesis':514,'djinn_unit':133,'integration':154,'public_source_graph':59,'church_signatures_per_engine':350,'scope_probes_per_engine':50,'cli':int(re.search(rb'All (\d+) tests passed',cli).group(1))},'prior_failed_runs':['validation-v1 integration: 2 of 154 failed duplicate controls','validation-v2 private graph: new rewrite fixture assumed implicit beta cleanup','diagnostics/scoped-selections-private-v8.log: eta cleanup does not promise beta reduction'],'native_lean_integration':'pending','church_behavior_cells_added':0,'archive':{'path':out.name,'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'artifacts':len(manifest),'all_members_rehashed':True}}
(root/'test-church/receipts/scoped-source-selections-2026-09-13.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt['archive'],indent=2))
