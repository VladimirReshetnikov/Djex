from pathlib import Path
import hashlib, json, subprocess, time, datetime
root = Path.cwd()
out = root/'dist-newstyle/scoped-selections-validation-v3'
out.mkdir(exist_ok=False)
base = root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17'
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
paths = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'], cwd=root).decode().split('\0')
inputs = {p: digest(root/p) for p in paths if p and (root/p).is_file()}
suites = [('budgets', 'djex-tests', ['-p', 'Conditional Given production budgets']), ('public', 'djex-tests', ['-p', 'Proof-selected dictionaries survive public synthesis']), ('private', 'djinn-source-graph-private-tests', []), ('synthesis', 'synthesis-tests', []), ('djinn', 'djinn-tests', []), ('integration', 'djex-tests', []), ('source_graph', 'djinn-source-graph-tests', []), ('church', 'djex-church-tests', ['--report-dir', str(out/'church')]), ('scopes', 'djex-rank-n-scope-tests', [])]
binaries = {name: base/'t'/name/'build'/name/(name+'.exe') for _,name,_ in suites}
state = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(), 'source_sha256': inputs, 'binary_sha256': {k:digest(v) for k,v in binaries.items()}, 'controller_sha256': digest(Path(__file__)), 'cases': [], 'status': 'running'}
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary']))
for p in paths:
    if p and (root/p).is_file():
        dest = out/'source'/p
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((root/p).read_bytes())
def save():
    (out/'results.json').write_text(json.dumps(state,indent=2)+'\n')
save()
for label,name,args in suites:
    cmd = [str(binaries[name]),'-j1']+args
    row = {'label':label, 'command':cmd, 'status':'running'}
    state['cases'].append(row)
    save()
    print('START',label,flush=True)
    start=time.monotonic()
    with (out/(label+'.stdout.txt')).open('w',encoding='utf-8') as stdout, (out/(label+'.stderr.txt')).open('w',encoding='utf-8') as stderr:
        proc=subprocess.Popen(cmd,cwd=root,stdout=stdout,stderr=stderr)
        row['pid']=proc.pid
        save()
        row['exit_code']=proc.wait()
    row['seconds']=round(time.monotonic()-start,2)
    row['status']='passed' if row['exit_code']==0 else 'failed'
    save()
    print('END',label,row['status'],row['seconds'],flush=True)
    if row['exit_code']:
        break
state['sources_unchanged']=all((root/p).is_file() and digest(root/p)==h for p,h in inputs.items())
state['binaries_unchanged']=all(digest(binaries[k])==h for k,h in state['binary_sha256'].items())
state['controller_unchanged']=digest(Path(__file__))==state['controller_sha256']
state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
state['status']='passed' if len(state['cases'])==len(suites) and all(x['status']=='passed' for x in state['cases']) and all(state[k] for k in ['sources_unchanged','binaries_unchanged','controller_unchanged']) else 'failed'
save()
print('FINAL',state['status'],flush=True)
raise SystemExit(0 if state['status']=='passed' else 1)
