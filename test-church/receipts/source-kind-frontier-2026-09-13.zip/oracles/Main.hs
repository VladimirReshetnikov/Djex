{-# LANGUAGE RankNTypes, KindSignatures, ImpredicativeTypes #-}
module Main where
import qualified Prelude
kinded_identity_djinn_one_shot :: forall (f :: * -> *) a. f a -> f a
kinded_identity_djinn_one_shot = \x -> x
kinded_callback_djinn_one_shot :: forall b. ((forall (f :: * -> *) a. f a -> f a) -> b) -> b
kinded_callback_djinn_one_shot = \k -> k (\x -> x)
main = Prelude.print [(kinded_identity_djinn_one_shot [1, 2 :: Prelude.Int] Prelude.== [1, 2] Prelude.&& kinded_identity_djinn_one_shot (Prelude.Just Prelude.True) Prelude.== Prelude.Just Prelude.True), (kinded_callback_djinn_one_shot (\h -> Prelude.length (h [1, 2, 3 :: Prelude.Int])) Prelude.== 3 Prelude.&& kinded_callback_djinn_one_shot (\h -> if h (Prelude.Just Prelude.True) Prelude.== Prelude.Just Prelude.True then 7 else 0) Prelude.== 7)]
