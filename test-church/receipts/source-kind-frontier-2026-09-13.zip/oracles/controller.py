from pathlib import Path
import json, os, shutil, sys
ROOT=Path('C:/Djex')
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT=runtime.prepare_output_directory(ROOT/'dist-newstyle/public-kinded-oracles-v1')
probe_path=ROOT/'dist-newstyle/public-kinded-source-v1/results.json'
probe=json.loads(probe_path.read_text())
ghc=Path(shutil.which('ghc')).resolve()
assert runtime.sha256(ghc)==probe['runtime_sha256'][str(ghc)]
chosen=[row for row in probe['results'] if row['engine']=='djinn' and row['entrance']=='one-shot']
source=OUT/'Main.hs'
text='{-# LANGUAGE RankNTypes, KindSignatures, ImpredicativeTypes #-}\nmodule Main where\nimport qualified Prelude\n'
for row in chosen:
    body='\\x -> x' if row['name'].startswith('kinded_identity') else '\\k -> k (\\x -> x)'
    text+=row['name']+' :: '+row['type']+'\n'+row['name']+' = '+body+'\n'
text+='main = Prelude.print ['+', '.join('('+row['predicate']+')' for row in chosen)+']\n'
source.write_text(text,encoding='utf-8')
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,180)
result=dict(status='running',probe_receipt_sha256=runtime.sha256(probe_path),source_sha256=runtime.sha256(source),compiler_sha256=runtime.sha256(ghc))
try:
    exe=OUT/'oracle.exe'
    p=runner.run('oracle-compile',[str(ghc),'-v0','-fforce-recomp',str(source),'-o',str(exe)],cwd=OUT,env=os.environ)
    assert p.returncode==0,'source oracle failed compilation'
    p=runner.run('oracle-execute',[str(exe)],cwd=OUT,env=os.environ)
    assert p.returncode==0 and p.stdout.strip()=='[True,True]','oracle observations failed'
    result['status']='passed'
except BaseException as failure:
    result.update(status='failed',failure=repr(failure))
finally:
    result['processes']=runner.rows
    result['sources_unchanged']=runtime.sha256(source)==result['source_sha256']
    result['compiler_unchanged']=runtime.sha256(ghc)==result['compiler_sha256']
    if not result['sources_unchanged'] or not result['compiler_unchanged']:result['status']='failed'
    runtime.write_json(OUT/'results.json',result)
print(result['status'],result.get('failure',''))
raise SystemExit(0 if result['status']=='passed' else 1)
