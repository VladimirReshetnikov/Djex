from pathlib import Path
import hashlib, json, os, re, shutil, sys

ROOT = Path('C:/Djex')
OLD = Path('C:/Djex-validation/scoped-source-selections')
sys.path.insert(0, str(ROOT / 'test-church'))
import behavior_runtime as runtime
from quality_cli import emitted_definition
accepted_path = OLD / 'dist-newstyle/acyclic-head-release-v1/results.json'
accepted = json.loads(accepted_path.read_text())
assert accepted['status'] == 'passed'
assert all(runtime.sha256(OLD / p) == h for p, h in accepted['source_sha256'].items())
metadata_changes = {'test-church/behavior-ledger-catalog.json', 'test-church/behavior-ledger.json'}
for p in accepted['source_sha256']:
    if p not in metadata_changes:
        assert (ROOT / p).read_text(encoding='utf-8') == (OLD / p).read_text(encoding='utf-8'), p
exe = next(Path(p) for p in accepted['runtime_sha256'] if Path(p).name == 'djex.exe')
assert runtime.sha256(exe) == accepted['runtime_sha256'][str(exe)]
ghc = Path(shutil.which('ghc')).resolve()
OUT = runtime.prepare_output_directory(ROOT / 'dist-newstyle/public-kinded-source-v1')
environment = OUT / 'empty-environment'
environment.mkdir()
report = dict(status='running', scope='Public one-shot and named-where higher-kinded source probes; no claim beyond the recorded cases.',
    accepted_baseline=str(accepted_path), accepted_baseline_sha256=runtime.sha256(accepted_path),
    runtime_sha256={str(p): runtime.sha256(p) for p in (exe, ghc)}, results=[],
    publication_metadata_changes={p: dict(validation_sha256=runtime.sha256(OLD/p), root_sha256=runtime.sha256(ROOT/p)) for p in sorted(metadata_changes)})
runner = runtime.Processes(OUT, 180)
env = dict(os.environ, djex_datadir=str(OLD), PYTHONDONTWRITEBYTECODE='1')
cases = [
    ('kinded_identity', 'forall (f :: * -> *) a. f a -> f a',
     '{f} [1, 2 :: Prelude.Int] Prelude.== [1, 2] Prelude.&& {f} (Prelude.Just Prelude.True) Prelude.== Prelude.Just Prelude.True'),
    ('kinded_callback', 'forall b. ((forall (f :: * -> *) a. f a -> f a) -> b) -> b',
     '{f} (\\h -> Prelude.length (h [1, 2, 3 :: Prelude.Int])) Prelude.== 3 Prelude.&& {f} (\\h -> if h (Prelude.Just Prelude.True) Prelude.== Prelude.Just Prelude.True then 7 else 0) Prelude.== 7')]
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())

def save():
    report['processes'] = runner.rows
    runtime.write_json(OUT / 'results.json', report)

def replay(label, name, target, expression, predicate):
    source = OUT / (label + '.hs')
    source.write_text('{-# LANGUAGE RankNTypes, KindSignatures, ImpredicativeTypes #-}\nmodule Main where\nimport qualified Prelude\n'
        + name + ' :: ' + target + '\n' + name + ' = ' + expression + '\nmain = Prelude.print (' + predicate + ')\n', encoding='utf-8')
    binary = OUT / (label + '.exe')
    compiled = runner.run(label + '-ghc', [str(ghc), '-v0', '-fforce-recomp', str(source), '-o', str(binary)], cwd=OUT, env=env)
    if compiled.returncode: return dict(status='compile-failed', source_sha256=runtime.sha256(source))
    evaluated = runner.run(label + '-execute', [str(binary)], cwd=OUT, env=env)
    return dict(status='passed' if evaluated.returncode == 0 and evaluated.stdout.strip() == 'True' else 'behavior-failed',
        source_sha256=runtime.sha256(source), executable_sha256=runtime.sha256(binary))

try:
    save()
    for engine in ('djinn', 'exference'):
        for operation, target, template in cases:
            for entrance in ('one-shot', 'named-where'):
                name = operation + '_' + engine + '_' + entrance.replace('-', '_')
                predicate = template.replace('{f}', name)
                row = dict(name=name, engine=engine, entrance=entrance, type=target, predicate=predicate)
                report['results'].append(row)
                try:
                    if entrance == 'one-shot':
                        limits = ['--choice-budget', '20000', '--candidate-limit', '32'] if engine == 'djinn' else ['--max-steps', '20000', '--allow-unused']
                        process = runner.run(name, [str(exe), engine, '--environment', str(environment), '--render', 'expression',
                            '--select', 'first', '--quality-window', '32', *limits, target], cwd=ROOT, env=env)
                        expression = process.stdout.strip()
                    else:
                        lines = [':set prompt ""', ':backend ' + engine, ':set select first', ':set render definition',
                            ':set allow-unused on', ':set djinn-axioms off', ':set djinn-strategy interleave',
                            ':set candidate-limit 32', ':set quality-window 32', ':set choice-budget 20000', ':set max-steps 20000',
                            ':browse', ':show settings', ':synth ' + name + ' :: ' + target + ' where ' + predicate, ':quit', '']
                        process = runner.run(name, [str(exe), 'repl', '--ignore-startup', '--environment', str(environment)],
                            source='\n'.join(lines), cwd=ROOT, env=env)
                        expression = emitted_definition(process.stdout, name)
                    assert process.returncode == 0 and expression, 'public command failed'
                    row['expression'] = expression
                    row['replay'] = replay(name + '-replay', name, target, expression, predicate)
                    row['status'] = row['replay']['status']
                except Exception as failure:
                    row.update(status='failed', failure=repr(failure))
                save()
                print(json.dumps(dict(name=name, status=row['status'])), flush=True)
finally:
    report['runtimes_unchanged'] = all(runtime.sha256(Path(p)) == h for p,h in report['runtime_sha256'].items())
    report['controller_unchanged'] = (OUT / 'controller.py').read_bytes() == Path(__file__).read_bytes()
    report['status'] = 'passed' if len(report['results']) == 8 and all(r['status'] == 'passed' for r in report['results']) and report['runtimes_unchanged'] and report['controller_unchanged'] else 'failed'
    save()
print(report['status'], flush=True)
raise SystemExit(0 if report['status'] == 'passed' else 1)
