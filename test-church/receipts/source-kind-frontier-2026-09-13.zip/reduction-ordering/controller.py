from pathlib import Path
import json,os,subprocess,sys

ROOT=Path.cwd()
assert ROOT==Path('C:/Djex-validation/reduction-head-construction')
OUT=ROOT/'dist-newstyle/reduction-head-construction-v4'
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime

OUT.mkdir(exist_ok=False)
paths=[ROOT/p for p in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    if p and (ROOT/p).is_file() and (Path(p).suffix in ['.hs','.lhs','.cabal'] or p=='cabal.project')]
report=dict(status='running',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    source_sha256={p.relative_to(ROOT).as_posix():runtime.sha256(p) for p in paths},gates=[],
    scope='Applied-head ordering experiment. Stop after a failed fixed-carrier gate; original query runs only after fixed-carrier and cursor contracts pass. Not a release or compiler-replay acceptance.',
    original_bounds=dict(raw_candidates=65536,choices=500000))
for p in paths:
    dest=OUT/'source'/p.relative_to(ROOT)
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(p.read_bytes())
(OUT/'change.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT/'prepare.py').write_bytes((ROOT/'dist-newstyle/prepare.py').read_bytes())
runner=runtime.Processes(OUT,1200)
env=dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1')

def save():
    report['processes']=runner.rows
    runtime.write_json(OUT/'results.json',report)

save()
try:
    report['active_gate']='strict-build';save()
    result=runner.run('strict-build',['cabal','build','djex:test:djinn-tests','--ghc-options=-Werror','-j1'],cwd=ROOT,env=env)
    report['build_exit_code']=result.returncode
    assert result.returncode==0,'strict build failed'
    executables={name:Path(subprocess.check_output(['cabal','list-bin','djex:test:'+name],cwd=ROOT).decode().strip())
        for name in ['djinn-tests']}
    report['runtime_sha256']={str(p):runtime.sha256(p) for p in executables.values()}
    runner.timeout=180
    for label,suite,pattern in [
        ('cursor-contracts','djinn-tests','path-sensitive'),
        ('fixed-carrier-construction','djinn-tests','construct both reduction orders at an admitted continuation carrier'),
        ('original-reductions','djinn-tests','synthesize supplied-default reductions with nonassociative order')]:
        report['active_gate']=label;save()
        result=runner.run(label,[str(executables[suite]),'-p',pattern,'--timeout','120s'],cwd=ROOT,env=env)
        report['gates'].append(dict(name=label,exit_code=result.returncode))
        save()
        assert result.returncode == 0, label + ' failed; stop dependent gates'
except BaseException as failure:
    report['failure']=repr(failure)
finally:
    report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report.get('runtime_sha256',{}).items())
    report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['status']='passed' if report.get('build_exit_code')==0 and len(report['gates'])==3 and \
        all(g['exit_code']==0 for g in report['gates']) and \
        all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
    save()
print(report['status'],report.get('failure',''),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
