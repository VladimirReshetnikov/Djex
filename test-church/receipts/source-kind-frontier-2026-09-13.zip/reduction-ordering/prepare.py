from pathlib import Path
import hashlib,json,subprocess

BASE=Path('C:/Djex-validation/scoped-source-selections')
ROOT=Path('C:/Djex-validation/reduction-head-construction')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()
gate=json.loads((BASE/'dist-newstyle/acyclic-head-release-v1/results.json').read_text())
assert gate['status']=='passed' and gate['sources_unchanged'] and gate['runtimes_unchanged']
overlay=['djinn/src-core/Djinn/Core.hs','djinn/src-core/Djinn/Internal/LJT.hs','djinn/test-unit/Spec.hs']
for name in overlay:
    raw=(BASE/name).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==gate['source_sha256'][name]
    (ROOT/name).write_bytes(raw)

p=ROOT/'djinn/src-internal/Djinn/Internal/Instantiation.hs'
s=p.read_text()
before='''    carriers = formulaFunctionCarriers translator variableSpellings
        (goalFormulas ++ premiseFormulas)
    carrierKeys'''
after='''    -- Keep the existing residual prefix. An already scoped monomorphic
    -- function can itself be the state of an endomorphism, supporting a
    -- continuation accumulator without inventing a new ambient variable.
    -- These proposals share the existing family/tuple limits and pass the
    -- same kind-checked instantiation path as every other carrier.
    residuals = formulaFunctionCarriers translator variableSpellings
        (goalFormulas ++ premiseFormulas)
    carriers = take maxInstantiationAttempts $ distinctOn SharedTypeAtom.alphaTypeKey $
        residuals ++ [SharedType.FunctionType source source | source <- residuals]
    carrierKeys'''
assert s.count(before)==1
p.write_text(s.replace(before,after),encoding='utf-8')

p=ROOT/'djinn/src-core/Djinn/Core.hs'
s=p.read_text()
before='functionCarrierSearchPlans = focusedPlansWithPrefix "$djinn$carrier-focused$"'
assert s.count(before)==1
s=s.replace(before,'functionCarrierSearchPlans = focusedPlansWithPrefix "$djinn$carrier-focused$function$"')
before='''            -- Common-result bridges can cooperate across distinct argument
            -- branches. Try paths without repeated heads before unrestricted
            -- recursive compositions; every original continuation remains.
            else if any (isPrefixOf "$djinn$carrier-focused$common$" . symbolSpelling) $
                    Set.toList symbols'''
after='''            -- Common-result bridges and residual function carriers can
            -- compose independent branches without repeating one head along
            -- a path. Keep the complete original continuation and accounting.
            else if any (\\symbol -> any (`isPrefixOf` symbolSpelling symbol)
                    ["$djinn$carrier-focused$common$", "$djinn$carrier-focused$function$"]) $
                    Set.toList symbols'''
assert s.count(before)==1
p.write_text(s.replace(before,after),encoding='utf-8')

p=ROOT/'djinn/test-unit/Spec.hs'
s=p.read_text()
before='    , ("synthesize nested Church maybeEither within the original raw bounds", testMaybeEitherConstruction)'
# Use the exact existing registration independent of its displayed title.
registration=next(line for line in s.splitlines() if 'testMaybeEitherConstruction)' in line)
s=s.replace(registration,registration+'\n    , ("synthesize supplied-default reductions with nonassociative order", testReductionCarriers)\n    , ("construct both reduction orders at an admitted continuation carrier", testReductionHeadConstruction)',1)
old=(BASE/'dist-newstyle/reduction-published-baseline-v1/source/djinn/test-unit/Spec.hs').read_text()
start=old.index('testReductionCarriers :: IO ()')
end=old.index('testCarrierFirstResult :: IO ()',start)
reduction=old[start:end]
reduction=reduction.replace('    assertBool diagnostic $ left /= Nothing && right /= Nothing',
    '    putStrLn diagnostic\n    assertBool diagnostic $ left /= Nothing && right /= Nothing')
control=r'''-- This direct-cursor diagnostic fixes only the admitted carrier. It does
-- not supply a reduction body and is separate from original-query acceptance.
testReductionHeadConstruction :: IO ()
testReductionHeadConstruction = do
    let a = PVar $ Symbol "reductionElement"
        state = (a :-> a) :-> a :-> a
        foldType = (a :-> state :-> state) :-> state :-> state
        initial = Symbol "reductionDefault"
        operation = Symbol "reductionOperation"
        input = Symbol "reductionInput"
        context = [(initial, a), (operation, a :-> a :-> a), (input, foldType)]
        mode = (defaultSearchMode True)
            {searchTermAlternatives = True, searchStrategy = Interleave}
    cursor <- expectRight $ startProofSearchWithAcyclicHeadsChecked mode context a
    let (proofs, charged) = consume 65536 500000 cursor
        expressions = map toExpression proofs
        matches reduction expression = all
            (\(zero, step, values) -> observe expression zero step values ==
                Right (if null values then zero else reduction step values))
            [(zero, step, values)
            | zero <- [37, 91]
            , step <- [(-), (\x y -> 10 * x + y), const, (\_ y -> y)]
            , values <- [[], [8], [8, 3], [8, 3, 1], [2, 7, 4, 9]]]
        left = findIndex (matches foldl1) expressions
        right = findIndex (matches foldr1) expressions
        diagnostic = "fixed-carrier reduction construction; left=" ++ show left ++
            "; right=" ++ show right ++ "; proofs=" ++ show (length proofs) ++
            "; choices=" ++ show charged
    putStrLn diagnostic
    mapM_ (expectRight . checkProof context a) proofs
    assertBool diagnostic $ left /= Nothing && right /= Nothing
  where
    consume :: Int -> Integer -> ProofSearchCursor -> ([Proof], Integer)
    consume raw allowance _ | raw <= 0 || allowance <= 0 = ([], 0)
    consume raw allowance cursor = case observeProofSearch cursor of
        ProofSearchFinished -> ([], 0)
        ProofSearchChoice continuation ->
            let (proofs, charged) = consume raw (allowance - 1) continuation
            in (proofs, charged + 1)
        ProofSearchResult proof continuation ->
            let (proofs, charged) = consume (raw - 1) allowance continuation
            in (proof : proofs, charged)
    toExpression (Var symbol) = SharedGenerated.Local $ symbolSpelling symbol
    toExpression (Lam binder body) = SharedGenerated.Lambda
        [SharedGenerated.Bind $ symbolSpelling binder] $ toExpression body
    toExpression (Apply function argument) =
        SharedGenerated.Apply (toExpression function) (toExpression argument)
    toExpression _ = error "non-arrow proof in fixed-carrier construction control"
    observe expression initial operation values = do
        result <- evaluateCarrierExpression 10000 (Map.fromList
            [("reductionDefault", CarrierTestElement initial)
            ,("reductionInput", carrierListEncode values)
            ,("reductionOperation", CarrierTestFunction $ \left ->
                Right $ CarrierTestFunction $ \right -> case (left, right) of
                    (CarrierTestElement x, CarrierTestElement y) ->
                        Right $ CarrierTestElement $ operation x y
                    _ -> Left "fixed-carrier step received a non-element")]) expression
        case result of
            CarrierTestElement value -> Right value
            _ -> Left "fixed-carrier control returned a non-element"

'''
s=s.replace('testMaybeEitherConstruction :: IO ()',reduction+control+'testMaybeEitherConstruction :: IO ()',1)
p.write_text(s,encoding='utf-8')

p=ROOT/'djinn/test-source-graph-private/Spec.hs'
s=p.read_text()
s=s.replace('import Djinn.Internal.Environment (prepareGroundSynthesisEnvironment)',
    'import Djinn.Internal.Environment (prepareGroundSynthesisEnvironment, preparedEnvironmentSynthesisFormulaTranslator)\nimport qualified Djinn.Internal.Instantiation as Instantiation\nimport Djinn.Internal.LJTFormula (Formula((:->)))')
s=s.replace('  [ sharingTests, lexicalTests, constructorTests, specializationTests',
    '  [ carrierAdmissionTests, sharingTests, lexicalTests, constructorTests, specializationTests')
s += '''
-- A production-family admission test, independent of proof search and the
-- behavior interpreter. The second control exercises lexical ownership.
carrierAdmissionTests :: TestTree
carrierAdmissionTests = testGroup "continuation carrier admission"
  [ testCase "admit a scoped continuation instance of the original Church fold" $ do
      environment <- right $ E.mkEnvironment ([] :: [DeclarationSource])
      prepared <- right $ prepareGroundSynthesisEnvironment environment
      let a = variable "a"
          r = variable "r"
          church = forallType ["r"] $ arrow (arrow a $ arrow r r) $ arrow r r
          source = arrow a $ arrow (arrow a $ arrow a a) $ arrow church a
          state = arrow (arrow a a) $ arrow a a
          instanceType = arrow (arrow a $ arrow state state) $ arrow state state
          translate = preparedEnvironmentSynthesisFormulaTranslator prepared
      formula <- right $ translate source
      opaque <- right $ translate church
      instanceFormula <- right $ translate instanceType
      let admitted owned = Instantiation.instantiationAxiomPremises $
            Instantiation.queryCarrierInstantiationAxioms translate (const Nothing)
              owned [formula] []
      assertBool "the continuation carrier was not admitted at the original fold scheme" $
        (opaque :-> instanceFormula) `elem` map snd (admitted ["a"])
      assertEqual "an unowned query variable entered a continuation carrier" [] $ admitted ["b"]
  ]
'''
p.write_text(s,encoding='utf-8')

out=ROOT/'dist-newstyle'
out.mkdir(exist_ok=True)
(out/'prepare.py').write_bytes(Path(__file__).read_bytes())
print('Prepared isolated carrier admission + head construction experiment; no builds or synthesis run.')
