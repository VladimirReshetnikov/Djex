-- | Checked Djinn sessions behind Djex's backend-neutral query envelope.
--
-- A session seals the exact Djinn environment once and retains one prepared
-- shared inventory together with every private search index derived from it.
-- Queries use the shared source-type vocabulary while retaining Djinn's
-- proof-search options and backend-specific evidence.
--
-- The curated session is immutable, matching the Exference adapter: change a
-- declaration by constructing a replacement neutral 'DjinnEnvironment' and
-- sealing it with 'mkDjinnSession'. Raw declaration edits, declaration-table
-- snapshots, and instance-method projection remain compatibility frontend
-- implementation details and do not cross this module.
module Language.Haskell.Djex.Djinn
  ( -- * Sessions
    DjinnSession
  , DjinnEnvironment
  , DjinnInventory
  , mkDjinnSession
  , standardDjinnSession
  , djinnSessionEnvironment
  , djinnSessionInventory
  , djinnSessionSourceInventory

    -- * Requests
  , DjinnTypeVariable
  , DjinnLocal
  , DjinnType
  , QueryOptions (..)
  , Strategy (..)
  , defaultQueryOptions
  , DjinnRequest
  , mkDjinnRequest
  , djinnRequestQuery
  , parseDjinnRequest
  , parseDjinnRequestWithCheckedTarget
  , validateDjinnTarget

    -- * Results
  , DjinnCandidate
  , DjinnTypedCandidate
  , DjinnLengthTypedCandidate
  , djinnTypedCandidateForLength
  , DjinnTermGraphTypeVariable
  , DjinnTermGraphType
  , DjinnTermGraphAbsence (..)
  , DjinnCandidateDetails (..)
  , Qualification (..)
  , RenderError (..)
  , DjinnQueryMetadata (..)
  , DjinnResult
  , DjinnTypedResult
  , runDjinnTypedQuery
  , runDjinnTypedQueryWithInstantiationCandidates
  , runDjinnTypedQueryWithInstantiationAssignments
  , runDjinnTypedQueryWithKindedInstantiationAssignments
  , runDjinnTypedQueryStream
  , runDjinnTypedQueryStreamWithInstantiationCandidates
  , runDjinnTypedQueryStreamWithInstantiationAssignments
  , runDjinnTypedQueryStreamWithKindedInstantiationAssignments
  , runDjinnQuery
  , runDjinnQueryWithInstantiationCandidates
  , runDjinnQueryWithInstantiationAssignments
  , runDjinnQueryWithKindedInstantiationAssignments
  , renderDjinnCandidateExpression
  , renderDjinnCandidateDefinition
  ) where

import Djinn.Core
  ( DjinnCandidateDetails (..)
  , DjinnCandidate
  , DjinnTermGraphAbsence (..)
  , DjinnTermGraphType
  , DjinnTermGraphTypeVariable
  , DjinnTypedCandidate
  , DjinnQueryError (..)
  , DjinnQueryMetadata (..)
  , DjinnResult
  , DjinnTypedResult
  )
import qualified Djinn.Core as Core
import Language.Haskell.Djex.Djinn.Internal.Request
  ( DjinnLocal
  , DjinnRequest
  , DjinnType
  , DjinnTypeVariable
  , QueryOptions (..)
  , Strategy (..)
  , defaultQueryOptions
  , djinnRequestQuery
  , mkDjinnRequest
  , validateDjinnTarget
  )
import qualified Language.Haskell.Djex.Djinn.Internal.Request as Request
import Language.Haskell.Djex.Djinn.Internal.Session
  ( DjinnEnvironment
  , DjinnInventory
  , DjinnSession
  , djinnSessionEnvironment
  , djinnSessionInventory
  , djinnSessionSourceInventory
  , mkDjinnSession
  , standardDjinnSession
  )
import qualified Language.Haskell.Djex.Djinn.Internal.Session as Session
import Language.Haskell.Synthesis.Candidate
  ( Candidate (..)
  , renderCandidateDefinition
  , renderCandidateExpression
  )
import Language.Haskell.Synthesis.Diagnostic
  ( Diagnostic
  , Severity (Error)
  , contextualDiagnostic
  , shownErrorDiagnostic
  , sourceTextLocation
  )
import Language.Haskell.Synthesis.Generated
  ( DefinitionName
  , Qualification (..)
  , RenderError (..)
  , RenderOptions (renderQualification)
  , defaultRenderOptions
  )
import Language.Haskell.Synthesis.Name (Name)
import Language.Haskell.Synthesis.Query
  ( KindedProviderInstantiationAssignment
  , ProviderInstantiationAssignment
  , ProviderInstantiationCandidate
  , QueryEvidence (..)
  , QueryRequest (..)
  , RequestProvenance (..)
  , mkQueryResult
  , requestContextualType
  , resultEvidence
  , resultSearch
  , withRequestProvenance
  )
import Language.Haskell.Synthesis.TypedCandidate
  ( typedQueryResultCompatibility )
import qualified Language.Haskell.Synthesis.Internal.TypedCandidate as TypedCandidate
import qualified Language.Haskell.Synthesis.Generated as Generated

-- | Djinn's exact candidate association with the compatibility residual
-- vocabulary aligned to its graph source types. Djinn proves closed
-- obligations; its residual list is invariantly empty in both views.
type DjinnLengthTypedCandidate =
  TypedCandidate.TypedCandidate DjinnTermGraphAbsence DjinnTermGraphType String
    (Candidate DjinnTermGraphType DjinnCandidateDetails (Generated.FunctionClause String))

-- | The only conversion is the invariant-empty residual-constraint slot.
-- Clause, details, graph availability, and private certificate carrier remain
-- part of the original candidate; the graph is not demanded or rebuilt.
djinnTypedCandidateForLength :: DjinnTypedCandidate -> DjinnLengthTypedCandidate
djinnTypedCandidateForLength = TypedCandidate.mapTypedCandidateCompatibility $ \candidate ->
  Candidate (candidateOutput candidate) [] (candidateDetails candidate)

-- | Parse the type portion of a Djinn query.  The accepted context grammar is
-- exactly the historical one: either one constraint or a comma-separated
-- parenthesized list, followed by @=>@ and the goal.  The session argument
-- keeps this boundary parallel with Exference's request parser; Djinn's parser
-- itself is environment-independent, while kind and class lookup remain part
-- of 'runDjinnQuery'.
parseDjinnRequest
  :: DjinnSession
  -> QueryOptions
  -> Name
  -> FilePath
  -> String
  -> Either Diagnostic DjinnRequest
parseDjinnRequest session options target sourceName source = do
  -- Preserve command-boundary precedence: an invalid output name is a usage
  -- error even when the source text is also malformed.
  checkedTarget <- validateDjinnTarget target
  parseDjinnRequestWithCheckedTarget
    session options checkedTarget sourceName source

-- | Parse a Djinn query for a target already checked at an outer command
-- boundary. This avoids repeating target validation while retaining the same
-- source parser and opaque request construction as 'parseDjinnRequest'.
parseDjinnRequestWithCheckedTarget
  :: DjinnSession
  -> QueryOptions
  -> DefinitionName
  -> FilePath
  -> String
  -> Either Diagnostic DjinnRequest
parseDjinnRequestWithCheckedTarget _session options checkedTarget
    sourceName source = do
  let provenance = SourceRequest $ sourceTextLocation sourceName source
  (rawContexts, rawGoal) <- case Core.parseContextualHType source of
    Right parsed -> Right parsed
    Left failure -> Left $ withRequestProvenance provenance
      $ contextualDiagnostic Error "DJEX_DJINN_PARSE"
          "cannot parse the Djinn query type" failure
  goal <- Request.validateDjinnQueryTypeWithProvenance
    provenance "goal" rawGoal
  contexts <- traverse
    (traverse $ Request.validateDjinnQueryTypeWithProvenance
      provenance "context")
    rawContexts
  let query = QueryRequest
        { requestTarget = checkedTarget
        , requestGoal = goal
        , requestContexts = contexts
        , requestOptions = options
        }
  Request.mkDjinnRequestWithProvenance provenance query

-- | Run one complete configured Djinn search while retaining the canonical
-- typed-candidate association.  Logical evidence stays independent of
-- operational completion and graph availability.
runDjinnTypedQuery
  :: DjinnSession
  -> DjinnRequest
  -> Either Diagnostic DjinnTypedResult
runDjinnTypedQuery session =
  runDjinnTypedQueryWithInstantiationCandidates session []

-- | Run one checked Djinn search with externally established type choices for
-- exact named providers. Ordinary request validation retains precedence; the
-- evidence list is then bounded, elaborated, kind-checked, and kept
-- provider-local against this exact session before it can add a separate
-- proof-producing search tail.
runDjinnTypedQueryWithInstantiationCandidates
  :: DjinnSession
  -> [ProviderInstantiationCandidate DjinnTypeVariable]
  -> DjinnRequest
  -> Either Diagnostic DjinnTypedResult
runDjinnTypedQueryWithInstantiationCandidates session candidates =
  runDjinnTypedQueryWithProviderEvidence session $
    CandidateEvidence candidates

-- | Run one checked Djinn search with complete ordered leading-forall
-- assignments established for exact named providers.  Each assignment vector
-- is bounded, elaborated, and checked against its provider's exact arity, then
-- supplied directly to proof search without Cartesian reconstruction.
runDjinnTypedQueryWithInstantiationAssignments
  :: DjinnSession
  -> [ProviderInstantiationAssignment DjinnTypeVariable]
  -> DjinnRequest
  -> Either Diagnostic DjinnTypedResult
runDjinnTypedQueryWithInstantiationAssignments session assignments =
  runDjinnTypedQueryWithProviderEvidence session $
    AssignmentEvidence assignments

-- | Run one checked Djinn search with complete ordered assignments and the
-- exact ground kind of every leading provider binder. The supplied kind vector
-- is validated against the retained provider body, so it can refine a vacuous
-- binder without weakening any inferred non-vacuous constraint.
runDjinnTypedQueryWithKindedInstantiationAssignments
  :: DjinnSession
  -> [KindedProviderInstantiationAssignment DjinnTypeVariable]
  -> DjinnRequest
  -> Either Diagnostic DjinnTypedResult
runDjinnTypedQueryWithKindedInstantiationAssignments session assignments =
  runDjinnTypedQueryWithProviderEvidence session $
    KindedAssignmentEvidence assignments

-- | Observe one configured search incrementally, in deterministic discovery
-- order. Request validation precedes the stream; each observed result retains
-- its own checked typed candidates and cumulative search progress. The final
-- observation carries completion evidence. Stopping at a successful prefix
-- does not inspect the remaining search or establish its final verdict.
--
-- Unlike 'runDjinnTypedQuery', this route does not collect and globally rank
-- the complete candidate pool. Candidate and choice limits belong to the one
-- search, not to individual observations. A late query failure occurs at its
-- position in the stream and does not invalidate earlier checked candidates.
runDjinnTypedQueryStream
  :: DjinnSession
  -> DjinnRequest
  -> Either Diagnostic [Either Diagnostic DjinnTypedResult]
runDjinnTypedQueryStream session =
  runDjinnTypedQueryStreamWithInstantiationCandidates session []

-- | Incremental counterpart of 'runDjinnTypedQueryWithInstantiationCandidates'.
-- Exact provider evidence is checked once before the search can yield results.
runDjinnTypedQueryStreamWithInstantiationCandidates
  :: DjinnSession
  -> [ProviderInstantiationCandidate DjinnTypeVariable]
  -> DjinnRequest
  -> Either Diagnostic [Either Diagnostic DjinnTypedResult]
runDjinnTypedQueryStreamWithInstantiationCandidates session candidates =
  runDjinnTypedQueryStreamWithProviderEvidence session $ CandidateEvidence candidates

-- | Incremental counterpart of 'runDjinnTypedQueryWithInstantiationAssignments'.
runDjinnTypedQueryStreamWithInstantiationAssignments
  :: DjinnSession
  -> [ProviderInstantiationAssignment DjinnTypeVariable]
  -> DjinnRequest
  -> Either Diagnostic [Either Diagnostic DjinnTypedResult]
runDjinnTypedQueryStreamWithInstantiationAssignments session assignments =
  runDjinnTypedQueryStreamWithProviderEvidence session $ AssignmentEvidence assignments

-- | Incremental counterpart of
-- 'runDjinnTypedQueryWithKindedInstantiationAssignments'. The ordered provider
-- and kind vectors remain attached to the exact source request and session.
runDjinnTypedQueryStreamWithKindedInstantiationAssignments
  :: DjinnSession
  -> [KindedProviderInstantiationAssignment DjinnTypeVariable]
  -> DjinnRequest
  -> Either Diagnostic [Either Diagnostic DjinnTypedResult]
runDjinnTypedQueryStreamWithKindedInstantiationAssignments session assignments =
  runDjinnTypedQueryStreamWithProviderEvidence session $ KindedAssignmentEvidence assignments

-- | Compatibility projection of 'runDjinnTypedQuery'.  Mapping does not
-- inspect typed-graph availability or checked proof evidence.
runDjinnQuery
  :: DjinnSession
  -> DjinnRequest
  -> Either Diagnostic DjinnResult
runDjinnQuery session = fmap typedQueryResultCompatibility
  . runDjinnTypedQuery session

-- | Compatibility projection of
-- 'runDjinnTypedQueryWithInstantiationCandidates'.
runDjinnQueryWithInstantiationCandidates
  :: DjinnSession
  -> [ProviderInstantiationCandidate DjinnTypeVariable]
  -> DjinnRequest
  -> Either Diagnostic DjinnResult
runDjinnQueryWithInstantiationCandidates session candidates =
  fmap typedQueryResultCompatibility
    . runDjinnTypedQueryWithInstantiationCandidates session candidates

-- | Compatibility projection of
-- 'runDjinnTypedQueryWithInstantiationAssignments'.
runDjinnQueryWithInstantiationAssignments
  :: DjinnSession
  -> [ProviderInstantiationAssignment DjinnTypeVariable]
  -> DjinnRequest
  -> Either Diagnostic DjinnResult
runDjinnQueryWithInstantiationAssignments session assignments =
  fmap typedQueryResultCompatibility
    . runDjinnTypedQueryWithInstantiationAssignments session assignments

-- | Compatibility projection of
-- 'runDjinnTypedQueryWithKindedInstantiationAssignments'.
runDjinnQueryWithKindedInstantiationAssignments
  :: DjinnSession
  -> [KindedProviderInstantiationAssignment DjinnTypeVariable]
  -> DjinnRequest
  -> Either Diagnostic DjinnResult
runDjinnQueryWithKindedInstantiationAssignments session assignments =
  fmap typedQueryResultCompatibility
    . runDjinnTypedQueryWithKindedInstantiationAssignments session assignments

data DjinnProviderEvidence
  = CandidateEvidence
      [ProviderInstantiationCandidate DjinnTypeVariable]
  | AssignmentEvidence
      [ProviderInstantiationAssignment DjinnTypeVariable]
  | KindedAssignmentEvidence
      [KindedProviderInstantiationAssignment DjinnTypeVariable]

runDjinnTypedQueryWithProviderEvidence
  :: DjinnSession
  -> DjinnProviderEvidence
  -> DjinnRequest
  -> Either Diagnostic DjinnTypedResult
runDjinnTypedQueryWithProviderEvidence session evidence request = do
  let query = djinnRequestQuery request
  (contexts, goal) <- Request.prepareDjinnRequest
    (Session.sessionClassArity session) request
  let execute = Core.inhabitTypedSynthesisResultPreparedWithSourceGoal
        (requestOptions query)
        (Session.sessionPreparedEnvironment session)
        (requestContextualType query)
        contexts
        (djinnSourceEvidence evidence)
        (requestTarget query)
        goal
  adaptDjinnQueryResult session request execute

runDjinnTypedQueryStreamWithProviderEvidence
  :: DjinnSession
  -> DjinnProviderEvidence
  -> DjinnRequest
  -> Either Diagnostic [Either Diagnostic DjinnTypedResult]
runDjinnTypedQueryStreamWithProviderEvidence session evidence request = do
  let query = djinnRequestQuery request
  (contexts, goal) <- Request.prepareDjinnRequest
    (Session.sessionClassArity session) request
  case Core.inhabitTypedSynthesisStreamPreparedWithSourceGoal
      (requestOptions query)
      (Session.sessionPreparedEnvironment session)
      (requestContextualType query)
      contexts
      (djinnSourceEvidence evidence)
      (requestTarget query)
      goal of
    Left failure -> Left $ djinnQueryFailure request failure
    Right results -> Right $ map (adaptDjinnQueryResult session request) results

djinnSourceEvidence :: DjinnProviderEvidence -> Core.DjinnSourceProviderEvidence
djinnSourceEvidence evidence = case evidence of
  CandidateEvidence candidates -> Core.DjinnSourceInstantiationCandidates candidates
  AssignmentEvidence assignments -> Core.DjinnSourceInstantiationAssignments assignments
  KindedAssignmentEvidence assignments -> Core.DjinnSourceKindedInstantiationAssignments assignments

adaptDjinnQueryResult
  :: DjinnSession
  -> DjinnRequest
  -> Either DjinnQueryError DjinnTypedResult
  -> Either Diagnostic DjinnTypedResult
adaptDjinnQueryResult session request execute = case execute of
    Left failure -> Left $
      djinnQueryFailure request failure
    Right result
      | Session.sessionContextualProvidersOmitted session ->
          weakenCandidateFreeEvidence result
      | otherwise -> Right result
 where
  -- A projected contextual provider may require a source instance outside
  -- lexical proof search. Preserve every checked candidate, but make candidate-free
  -- conclusions explicitly inconclusive, including the self-reference-only
  -- diagnostic which an omitted ordinary provider could have avoided.
  weakenCandidateFreeEvidence result = case resultEvidence result of
    ValidatedCandidates -> Right result
    _ -> case mkQueryResult NoEvidence $ resultSearch result of
      Left invariant -> Left $ djinnQueryFailure request
        $ DjinnResultInvariantFailure invariant
      Right weakened -> Right weakened

-- | Render only a Djinn candidate's generated expression.
--
-- Genuine Djinn results are closed and therefore have no residual
-- constraints. Because the compatibility
-- 'Language.Haskell.Synthesis.Candidate.Candidate' constructor is public,
-- this boundary also rejects a caller-built candidate that attaches an
-- obligation. Generated-syntax validation deliberately runs first, preserving
-- the existing scope and lexical error precedence when both parts are forged.
renderDjinnCandidateExpression
  :: Qualification
  -> DjinnCandidate
  -> Either RenderError String
renderDjinnCandidateExpression qualification candidate = do
  rendered <- renderCandidateExpression
    (candidateRenderOptions qualification) candidate
  validateClosedDjinnCandidate candidate
  pure rendered

-- | Render a complete definition using the target retained by the candidate.
-- Scope and lexical failures take precedence over
-- 'UnexpectedResidualConstraints', as in 'renderDjinnCandidateExpression'.
renderDjinnCandidateDefinition
  :: Qualification
  -> DjinnCandidate
  -> Either RenderError String
renderDjinnCandidateDefinition qualification candidate = do
  rendered <- renderCandidateDefinition
    (candidateRenderOptions qualification) candidate
  validateClosedDjinnCandidate candidate
  pure rendered

validateClosedDjinnCandidate :: DjinnCandidate -> Either RenderError ()
validateClosedDjinnCandidate candidate = case
    candidateResidualConstraints candidate of
  [] -> Right ()
  _ : _ -> Left UnexpectedResidualConstraints

candidateRenderOptions :: Qualification -> RenderOptions DjinnLocal
candidateRenderOptions qualification =
  (defaultRenderOptions id) {renderQualification = qualification}

djinnQueryFailure
  :: DjinnRequest
  -> DjinnQueryError
  -> Diagnostic
djinnQueryFailure request failure = case failure of
  DjinnQueryOptionsFailure optionsFailure -> shownErrorDiagnostic
    "DJEX_DJINN_OPTIONS" "invalid Djinn search options" optionsFailure
  DjinnQueryFailure message -> Request.withDjinnRequestProvenance request
    $ contextualDiagnostic Error
        "DJEX_DJINN_QUERY" "Djinn rejected the query" message
  DjinnInstantiationCandidateFailure message -> contextualDiagnostic Error
    "DJEX_DJINN_CANDIDATE"
    "Djinn rejected provider instantiation evidence"
    message
  DjinnInstantiationAssignmentFailure message -> contextualDiagnostic Error
    "DJEX_DJINN_ASSIGNMENT"
    "Djinn rejected a provider instantiation assignment"
    message
  DjinnInternalQueryFailure message -> contextualDiagnostic Error
    "DJEX_DJINN_INTERNAL"
    "Djinn violated an internal query invariant"
    message
  DjinnResultInvariantFailure invariant -> shownErrorDiagnostic
    "DJEX_DJINN_RESULT"
    "Djinn produced inconsistent logical evidence"
    invariant
