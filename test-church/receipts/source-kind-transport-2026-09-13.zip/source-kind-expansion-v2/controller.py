from pathlib import Path
import json, os, re, subprocess, sys
ROOT = Path.cwd()
assert ROOT == Path('C:/Djex-validation/public-kinded-source')
sys.path.insert(0, str(ROOT / 'test-church'))
import behavior_runtime as runtime
OUT = runtime.prepare_output_directory(ROOT / 'dist-newstyle/source-kind-expansion-v2')
paths = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT).decode().split('\0')
sources = sorted({p for p in paths if p and (ROOT/p).is_file() and (Path(p).suffix in {'.hs', '.cabal'} or p == 'cabal.project')})
targets = ['djex:test:synthesis-tests', 'djex:test:djex-tests']
binaries = {target: Path(subprocess.check_output(['cabal', 'list-bin', target], cwd=ROOT).decode().strip()) for target in targets}
report = dict(status='running', source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    source_sha256={p: runtime.sha256(ROOT/p) for p in sources},
    runtime_sha256={str(p): runtime.sha256(p) for p in binaries.values()}, gates=[],
    scope='Ground-kind source conversion and kind-preserving synonym expansion. Public commands and engine kind authority are not yet connected.')
for p in sources:
    target = OUT/'source'/p
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT/p).read_bytes())
for p in sorted((ROOT/'dist-newstyle').glob('source-kind-expansion-build-v*.log')):
    (OUT/p.name).write_bytes(p.read_bytes())
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner = runtime.Processes(OUT, 600)
env = dict(os.environ, djex_datadir=str(ROOT), PYTHONDONTWRITEBYTECODE='1')
def save():
    report['processes'] = runner.rows
    runtime.write_json(OUT/'results.json', report)
try:
    save()
    for label, target, args, count in [
        ('focused-expansion', targets[0], ['-p','source kinds through synonym expansion'], 13),
        ('focused-conversion', targets[1], ['-p','checked kinded source conversion'], 11),
        ('full-foundation', targets[0], [], 539),
        ('full-integration', targets[1], [], 171),
    ]:
        result = runner.run(label, [str(binaries[target]), *args, '--num-threads', '1'], cwd=ROOT, env=env)
        passed = result.returncode == 0 and bool(re.search(fr'All {count} tests passed', result.stdout))
        report['gates'].append(dict(name=label, exit_code=result.returncode, passed=passed, expected_count=count))
        save()
        assert passed, label + ' failed or inventory changed'
except BaseException as failure:
    report['failure'] = repr(failure)
finally:
    report['sources_unchanged'] = all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
    report['runtimes_unchanged'] = all(runtime.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
    report['controller_unchanged'] = (OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
    report['status'] = 'passed' if len(report['gates'])==4 and all(g['passed'] for g in report['gates']) and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
    save()
print(report['status'], report.get('failure',''), flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
