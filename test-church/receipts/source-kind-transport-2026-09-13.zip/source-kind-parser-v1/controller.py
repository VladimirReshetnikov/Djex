from pathlib import Path
import json,os,re,subprocess,sys
ROOT=Path.cwd()
assert ROOT==Path('C:/Djex-validation/public-kinded-source')
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT=runtime.prepare_output_directory(ROOT/'dist-newstyle/source-kind-parser-v1')
source_paths=[p for p in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    if p and (ROOT/p).is_file() and (Path(p).suffix in {'.hs','.cabal'} or p=='cabal.project')]
source_paths+=['synthesis/src/Language/Haskell/Synthesis/SourceKind.hs','synthesis/test/SourceKindSpec.hs','test-integration/SourceKindParserSpec.hs']
exe=Path(subprocess.check_output(['cabal','list-bin','djex:test:djex-tests'],cwd=ROOT).decode().strip())
report=dict(status='running',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
 source_sha256={p:runtime.sha256(ROOT/p) for p in source_paths},runtime_sha256={str(exe):runtime.sha256(exe)},gates=[],
 scope='Parsed-source lexical kind retention and regression gates. Explicit kinded source syntax and engine transport remain disabled.')
for name in ['source-kind-parser-build-v1.log']:
 (OUT/name).write_bytes((ROOT/'dist-newstyle'/name).read_bytes())
for p in ['djex.cabal','synthesis/src/Language/Haskell/Synthesis/KindInference.hs','synthesis/src/Language/Haskell/Synthesis/SourceKind.hs','synthesis/test/Spec.hs','synthesis/test/SourceKindSpec.hs','src/Language/Haskell/Djex/HaskellSrc.hs','test-integration/Spec.hs','test-integration/SourceKindParserSpec.hs']:
 target=OUT/'source'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/p).read_bytes())
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,600)
env=dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
def save():
 report['processes']=runner.rows;runtime.write_json(OUT/'results.json',report)
try:
 save()
 for label,args,count in [('parsed-kinds',['-p','parsed source binder kinds'],4),('full-integration',[],160)]:
  result=runner.run(label,[str(exe),*args,'--num-threads','1'],cwd=ROOT,env=env)
  passed=result.returncode==0 and bool(re.search(fr'All {count} tests passed',result.stdout))
  report['gates'].append(dict(name=label,exit_code=result.returncode,passed=passed,expected_count=count));save()
  assert passed,label+' failed or inventory changed'
except BaseException as failure:
 report['failure']=repr(failure)
finally:
 report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report['runtime_sha256'].items())
 report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
 report['status']='passed' if len(report['gates'])==2 and all(g['passed'] for g in report['gates']) and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
 save()
print(report['status'],report.get('failure',''),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
