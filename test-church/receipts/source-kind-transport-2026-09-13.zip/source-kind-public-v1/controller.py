from pathlib import Path
import json,os,re,subprocess,sys
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'test-church'))
import behavior_runtime as runtime
OUT=runtime.prepare_output_directory(ROOT/'dist-newstyle/source-kind-public-v1')
previous=json.loads((ROOT/'dist-newstyle/source-kind-parser-v1/results.json').read_text())
assert previous['status']=='passed'
assert all(runtime.sha256(ROOT/p)==h for p,h in previous['source_sha256'].items())
report=dict(status='running',source_sha256=previous['source_sha256'],gates=[],
 scope='Command and API regressions after parsed-source kind retention. No explicit kinded-syntax synthesis acceptance.')
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
runner=runtime.Processes(OUT,1800)
env=dict(os.environ,djex_datadir=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
def save():
 report['processes']=runner.rows;runtime.write_json(OUT/'results.json',report)
try:
 save()
 targets=['djex:test:djex-cli-tests','djex:test:djex-api-tests','djex:exe:djex','djex:exe:djex-fake-cabal','djex:exe:djex-fake-z3']
 build=runner.run('strict-build',['cabal','build',*targets,'--ghc-options=-Werror','-j1'],cwd=ROOT,env=env)
 report['build_exit_code']=build.returncode;save()
 assert build.returncode==0,'public strict build failed'
 binaries={target:Path(subprocess.check_output(['cabal','list-bin',target],cwd=ROOT).decode().strip()) for target in targets}
 report['runtime_sha256']={str(p):runtime.sha256(p) for p in binaries.values()}
 env['PATH']=os.pathsep.join(str(p.parent) for target,p in binaries.items() if ':exe:' in target)+os.pathsep+env.get('PATH','')
 for label,target,expected in [('api','djex:test:djex-api-tests',None),('cli','djex:test:djex-cli-tests',138)]:
  result=runner.run(label,[str(binaries[target]),'--num-threads','1'],cwd=ROOT,env=env)
  count=re.search(r'All (\d+) tests passed',result.stdout)
  passed=result.returncode==0 and bool(count) and (expected is None or int(count[1])==expected)
  report['gates'].append(dict(name=label,exit_code=result.returncode,passed=passed,test_count=int(count[1]) if count else None));save()
  assert passed,label+' failed or inventory changed'
except BaseException as failure:
 report['failure']=repr(failure)
finally:
 report['sources_unchanged']=all(runtime.sha256(ROOT/p)==h for p,h in report['source_sha256'].items())
 report['runtimes_unchanged']=all(runtime.sha256(Path(p))==h for p,h in report.get('runtime_sha256',{}).items())
 report['controller_unchanged']=(OUT/'controller.py').read_bytes()==Path(__file__).read_bytes()
 report['status']='passed' if report.get('build_exit_code')==0 and len(report['gates'])==2 and all(g['passed'] for g in report['gates']) and all(report[k] for k in ['sources_unchanged','runtimes_unchanged','controller_unchanged']) else 'failed'
 save()
print(report['status'],report.get('failure',''),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
