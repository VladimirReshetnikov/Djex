from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path('C:/Djex')
OUT = ROOT / 'dist-newstyle/church-last-atkey-haskell-v1'
OUT.mkdir(exist_ok=False)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(report):
    (OUT / 'snapshot.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

pins = {}
for repo, prefix in ((ROOT, ''),):
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).decode().split('\0')
    for name in names:
        path = repo / name
        if not name or not path.is_file() or '/receipts/' in name:
            continue
        if path.suffix not in ('.hs', '.lhs', '.py', '.cabal', '.lean') and name not in ('cabal.project', 'lean-toolchain', 'test-church/manifest.json'):
            continue
        relative = prefix + name
        pins[relative] = digest(path)
        target = OUT / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())

script = Path(__file__)
(OUT / 'controller.py').write_bytes(script.read_bytes())
report = {'status': 'building', 'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
          'production_changes_uncommitted': True, 'source_hashes': pins, 'controller_sha256': digest(script)}
(OUT / 'working.diff').write_bytes(subprocess.check_output(['git', 'diff', 'HEAD'], cwd=ROOT))
build = ['cabal', 'build', 'exe:djex', '--ghc-options=-Werror', '-j1']
report['build_command'] = build
save(report)
print(f'Frozen {len(pins)} Haskell sources; starting strict build.', flush=True)
with (OUT / 'strict-build.log').open('wb') as log:
    result = subprocess.run(build, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
if result.returncode:
    report.update(status='build_failed', exit_code=result.returncode)
    save(report)
    sys.exit(result.returncode)
exe = ROOT / 'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17/x/djex/build/djex/djex.exe'
command = [sys.executable, '-X', 'utf8', '-B', 'test-church/behavior_partial_probe.py',
           '--djex', str(exe), '--output', str(OUT/'run'),
           '--engine', 'djinn', '--engine', 'exference', '--operation', 'last', '--operation', 'atKey',
           '--djinn-window', '65536', '--djinn-budget', '500000', '--djinn-strategy', 'interleave',
           '--exference-window', '256', '--exference-budget', '100000', '--steps', '100000',
           '--queue', '8192', '--process-timeout', '300', '--evaluation-timeout', '2']
report.update(status='running', strict_build='passed', command=command, executable_sha256=digest(exe))
assert all(digest(ROOT/name) == value for name, value in pins.items())
save(report)
print('Strict build passed; starting four Haskell last/atKey cells and independent controls/replays.', flush=True)
with (OUT/'driver.log').open('wb') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
report.update(status='passed' if result.returncode == 0 else 'failed', exit_code=result.returncode,
              sources_unchanged=all(digest(ROOT/name) == value for name, value in pins.items()),
              executable_unchanged=digest(exe) == report['executable_sha256'], controller_unchanged=digest(script) == report['controller_sha256'])
save(report)
print(json.dumps({k: report[k] for k in ('status', 'exit_code', 'sources_unchanged', 'executable_unchanged', 'controller_unchanged')}), flush=True)
sys.exit(result.returncode or (0 if report['sources_unchanged'] and report['executable_unchanged'] and report['controller_unchanged'] else 1))
