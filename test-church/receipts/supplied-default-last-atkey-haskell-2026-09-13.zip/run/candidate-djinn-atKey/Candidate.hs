{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_djinn_atKey) where
import Prelude (Int)
import qualified Prelude (Int)
partial_djinn_atKey :: (forall church0 church1 church2. (church2 -> ((church0 -> (church1 -> (forall church3. (church3 -> (church3 -> church3))))) -> (church1 -> ((forall church5. (((forall church4. ((church0 -> (church2 -> church4)) -> church4)) -> (church5 -> church5)) -> (church5 -> church5))) -> church2)))))
partial_djinn_atKey a b c d = d (\e f -> e (\g h -> b g c h f)) a
