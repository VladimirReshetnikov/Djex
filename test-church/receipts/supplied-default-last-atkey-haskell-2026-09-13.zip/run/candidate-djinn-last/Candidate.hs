{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_djinn_last) where
import Prelude (Int)
import qualified Prelude (Int)
partial_djinn_last :: (forall church0. (church0 -> ((forall church1. ((church0 -> (church1 -> church1)) -> (church1 -> church1))) -> church0)))
partial_djinn_last a b = b (\c d _ -> d c) (\e _ -> e) a b
