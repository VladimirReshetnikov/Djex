{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_exference_atKey) where
import Prelude (Int)
import qualified Prelude (Int)
partial_exference_atKey :: (forall church0 church1 church2. (church2 -> ((church0 -> (church1 -> (forall church3. (church3 -> (church3 -> church3))))) -> (church1 -> ((forall church5. (((forall church4. ((church0 -> (church2 -> church4)) -> church4)) -> (church5 -> church5)) -> (church5 -> church5))) -> church2)))))
partial_exference_atKey a f2 c f4 =
  f4
  (\f8 ->
     \i ->
       f8 (\l -> \m -> let f15 = f2 l in let f17 = f15 c in f17 m i))
  a
