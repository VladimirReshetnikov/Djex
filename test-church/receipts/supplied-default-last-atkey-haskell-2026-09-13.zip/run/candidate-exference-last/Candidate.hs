{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_exference_last) where
import Prelude (Int)
import qualified Prelude (Int)
partial_exference_last :: (forall church0. (church0 -> ((forall church1. ((church0 -> (church1 -> church1)) -> (church1 -> church1))) -> church0)))
partial_exference_last a f2 =
  f2 (\g -> \f8 -> \_ -> f8 g) (\l -> l) a
