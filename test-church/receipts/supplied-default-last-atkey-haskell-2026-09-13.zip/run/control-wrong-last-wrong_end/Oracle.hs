{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Oracle (generated) where
import Prelude
import qualified Prelude
partialOracleHead :: forall a. a -> [a] -> a
partialOracleHead d xs = case xs of { [] -> d; x:_ -> x }
partialOracleLast :: forall a. a -> [a] -> a
partialOracleLast d xs = Prelude.foldl (\_ x -> x) d xs
partialOracleAt :: forall a. a -> Prelude.Int -> [a] -> a
partialOracleAt d n xs = case xs of { [] -> d; x:rest -> if n < 0 then d else if n == 0 then x else partialOracleAt d (n-1) rest }
partialOracleFoldL1 :: forall a. a -> (a -> a -> a) -> [a] -> a
partialOracleFoldL1 d step xs = case xs of { [] -> d; x:rest -> Prelude.foldl step x rest }
partialOracleFoldR1 :: forall a. a -> (a -> a -> a) -> [a] -> a
partialOracleFoldR1 d step xs = Prelude.maybe d Prelude.id (Prelude.foldr (\x rest -> Prelude.Just (Prelude.maybe x (step x) rest)) Prelude.Nothing xs)
partialEnc :: forall a. [a] -> (forall r. (a -> r -> r) -> r -> r)
partialEnc xs step zero = Prelude.foldr step zero xs
partialDec :: forall a. (forall r. (a -> r -> r) -> r -> r) -> [a]
partialDec xs = xs (:) []
partialMaybe :: forall a. Prelude.Maybe a -> (forall r. r -> (a -> r) -> r)
partialMaybe m zero some = Prelude.maybe zero some m
partialEither :: forall a b. Prelude.Either a b -> (forall r. (a -> r) -> (b -> r) -> r)
partialEither e onLeft onRight = Prelude.either onLeft onRight e
partialBool :: Prelude.Bool -> (forall r. r -> r -> r)
partialBool flag yes no = if flag then yes else no
partialPair :: forall a b. (a,b) -> (forall r. (a -> b -> r) -> r)
partialPair (x,y) pair = pair x y
partialDecPair :: forall a b. (forall r. (a -> b -> r) -> r) -> (a,b)
partialDecPair pair = pair (,)
partialDict :: forall a b. [(a,b)] -> (forall r. ((forall r. (a -> b -> r) -> r) -> r -> r) -> r -> r)
partialDict xs step zero = Prelude.foldr (\(k,v) rest -> step (\pair -> pair k v) rest) zero xs
generated :: (forall church0. (church0 -> ((forall church1. ((church0 -> (church1 -> church1)) -> (church1 -> church1))) -> church0)))
generated = \d xs -> partialOracleHead d (partialDec xs)
