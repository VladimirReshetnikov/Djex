{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_djinn_fromJust) where
import Prelude (Int)
import qualified Prelude (Int)
partial_djinn_fromJust :: (forall church0. (church0 -> ((forall church1. (church1 -> ((church0 -> church1) -> church1))) -> church0)))
partial_djinn_fromJust a b = b a (\c -> b a (\_ -> c))
