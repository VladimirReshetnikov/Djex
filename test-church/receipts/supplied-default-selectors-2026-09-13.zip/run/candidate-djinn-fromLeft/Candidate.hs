{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_djinn_fromLeft) where
import Prelude (Int)
import qualified Prelude (Int)
partial_djinn_fromLeft :: (forall church0 church1. (church0 -> ((forall church2. ((church0 -> church2) -> ((church1 -> church2) -> church2))) -> church0)))
partial_djinn_fromLeft a b = b (\c -> c) (\_ -> a)
