{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_djinn_fromRight) where
import Prelude (Int)
import qualified Prelude (Int)
partial_djinn_fromRight :: (forall church0 church1. (church0 -> ((forall church2. ((church1 -> church2) -> ((church0 -> church2) -> church2))) -> church0)))
partial_djinn_fromRight a b =
  b (\_ -> a) (\c -> b (\_ -> a) (\_ -> c))
