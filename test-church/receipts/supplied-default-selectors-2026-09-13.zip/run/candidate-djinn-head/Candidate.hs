{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_djinn_head) where
import Prelude (Int)
import qualified Prelude (Int)
partial_djinn_head :: (forall church0. (church0 -> ((forall church1. ((church0 -> (church1 -> church1)) -> (church1 -> church1))) -> church0)))
partial_djinn_head a b = b (\c _ -> c) a
