{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_exference_fromJust) where
import Prelude (Int)
import qualified Prelude (Int)
partial_exference_fromJust :: (forall church0. (church0 -> ((forall church1. (church1 -> ((church0 -> church1) -> church1))) -> church0)))
partial_exference_fromJust a f2 = f2 a (\f -> f)
