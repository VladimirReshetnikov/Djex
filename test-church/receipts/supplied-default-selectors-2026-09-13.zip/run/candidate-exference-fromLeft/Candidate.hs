{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_exference_fromLeft) where
import Prelude (Int)
import qualified Prelude (Int)
partial_exference_fromLeft :: (forall church0 church1. (church0 -> ((forall church2. ((church0 -> church2) -> ((church1 -> church2) -> church2))) -> church0)))
partial_exference_fromLeft a f2 = f2 (\f -> f) (\_ -> a)
