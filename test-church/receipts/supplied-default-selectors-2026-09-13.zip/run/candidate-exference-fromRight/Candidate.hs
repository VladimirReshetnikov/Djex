{-# LANGUAGE NoImplicitPrelude, RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications #-}
module Candidate (partial_exference_fromRight) where
import Prelude (Int)
import qualified Prelude (Int)
partial_exference_fromRight :: (forall church0 church1. (church0 -> ((forall church2. ((church1 -> church2) -> ((church0 -> church2) -> church2))) -> church0)))
partial_exference_fromRight a f2 = f2 (\_ -> a) (\h -> h)
