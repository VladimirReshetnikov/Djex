-- | Pure command grammar and help inventory for the shared Djex REPL.
--
-- Command names, abbreviations, help, and completion all derive from the same
-- descriptor table. Exact aliases win; otherwise a nonempty unique prefix of
-- a canonical command is accepted, matching GHCi without making parser order
-- decide newly ambiguous abbreviations.
module Language.Haskell.Djex.REPL.Command
  ( ReplBackend (..)
  , replBackendName
  , ReplQueryTarget (..)
  , ReplSynthesisQuery (..)
  , ReplInput (..)
  , ReplCommand (..)
  , ModuleChange (..)
  , KindNormalization (..)
  , TypeDefaulting (..)
  , CompletionDomain (..)
  , ReplSetting (..)
  , replSettingName
  , replSettingIsBoolean
  , parseReplSetting
  , parseReplInput
  , parseReplBackend
  , parseCommandWords
  , resolveCommandToken
  , commandCompletionDomain
  , commandNames
  , helpNames
  , backendNames
  , settingNames
  , booleanSettingNames
  , showNames
  , shortHelp
  , commandHelp
  ) where

import Data.Char (isSpace, toLower)
import Data.List (intercalate, isPrefixOf)
import Text.Read (readMaybe)

import Language.Haskell.Djex (Backend (..))
import Language.Haskell.Djex.Command (heuristicNames)
import Language.Haskell.Djex.Package
  ( PackageInstallMode
  , parsePackageInstall
  , validatePackageTargets
  )
import Language.Haskell.Djex.Text (normalize, stripLineComments, trim)
import Language.Haskell.Synthesis.Behavioral
  ( BehavioralLanguage (HaskellBehavioral), BehavioralQuery (..), parseBehavioralQuery )

-- | Backend selection retained by the interactive frontend.
data ReplBackend
  = OneBackend Backend
  | BothBackends
  deriving (Eq, Show)

-- | The canonical spelling of a backend selection (@djinn@, @exference@,
-- or @both@), as accepted by 'parseReplBackend' and shown in settings.
replBackendName :: ReplBackend -> String
replBackendName (OneBackend DjinnBackend) = "djinn"
replBackendName (OneBackend ExferenceBackend) = "exference"
replBackendName BothBackends = "both"

-- | Whether a query uses the active selection or an explicit backend set.
data ReplQueryTarget
  = ActiveBackends
  | ExplicitBackends ReplBackend
  deriving (Eq, Show)

-- | One synthesis request before the frontend resolves 'ActiveBackends'.
--
-- The optional where clause remains raw bounded input until the runtime has
-- established backend, target, and execution authority.  It is never parsed
-- merely by recognizing the outer REPL command.
data ReplSynthesisQuery = ReplSynthesisQuery
  { replQueryTarget :: ReplQueryTarget
  , replQueryWhereSource :: Maybe String
  , replQueryBehavioral :: Maybe BehavioralQuery
  , replQueryTypeSource :: String
  }
  deriving (Eq, Show)

-- | One complete logical input after explicit multiline collection.
data ReplInput
  = ReplNoInput
  | ReplQuery ReplSynthesisQuery
  | ReplImport String
  | ReplCommand ReplCommand
  deriving (Eq, Show)

-- | A parsed colon command with its already validated arguments. The
-- synthesis commands @:synth@, @:djinn@, @:exference@, and @:compare@ are not
-- included: they parse to 'ReplQuery' instead.
data ReplCommand
  = AddEnvironment [FilePath]
  | Browse (Maybe String)
  | ChangeBackend (Maybe String)
  | ChangeDirectory FilePath
  | ChangeModules ModuleChange [String]
  | DownloadPackages [String]
  | EditFile (Maybe FilePath)
  | Evaluate String
  | Help (Maybe String)
  | History (Maybe String)
  | InspectDeclaration String
  | InspectKind KindNormalization String
  | InspectType TypeDefaulting String
  | InstallPackages PackageInstallMode [String]
  | LoadEnvironment [FilePath]
  | Quit
  | ReloadEnvironment
  | RepeatQuery
  | RunScript FilePath
  | RunShell String
  | SetOption String
  | ShowState (Maybe String)
  | UnaddEnvironment [FilePath]
  | UnsetOption String
  | Version
  deriving (Eq, Show)

-- | How @:module@ changes the modules visible to synthesis queries.
--
-- The leading sign applies to the entire argument list, as it does in GHCi:
-- no sign replaces the context, @+@ extends it, and @-@ subtracts from it.
data ModuleChange
  = ReplaceModules
  | AddModules
  | RemoveModules
  deriving (Eq, Show)

-- | Whether @:kind@ also requests the type's normalized form.
--
-- The mode belongs to the command token: @:kind! T@ normalizes, while
-- @:kind ! T@ inspects the ordinary type text @! T@.
data KindNormalization
  = PreserveTypeSynonyms
  | NormalizeTypeSynonyms
  deriving (Eq, Show)

-- | Whether @:type@ applies its explicit numeric @+d@ defaulting request.
-- Ordinary ambiguity defaulting remains part of inference in either mode;
-- this flag additionally defaults eligible variables that occur in the
-- reported result type.
data TypeDefaulting
  = PreserveTypeVariables
  | DefaultTypeVariables
  deriving (Eq, Show)

-- | The semantic argument vocabulary owned by a colon command.
--
-- Haskeline consumes this metadata, so exact aliases and unique command
-- prefixes receive exactly the same completion behavior as canonical names.
-- Keeping it beside the parser also prevents newly added commands from
-- silently acquiring a different grammar at the completion boundary.
data CompletionDomain
  = NoCompletion
  | BackendCompletion
  | CommandCompletion
  | IdentifierCompletion
  | TypeIdentifierCompletion
  | SynthesisCompletion
  | ModuleCompletion
  | ModuleContextCompletion
  | PathCompletion
  | SettingCompletion
  | ShowCompletion
  deriving (Eq, Show)

-- | Every mutable REPL setting, in stable display and completion order.
data ReplSetting
  = BackendSetting
  | TargetSetting
  | SelectionSetting
  | RankingSetting
  | ProviderCostSetting
  | QualityWindowSetting
  | RenderingSetting
  | QualificationSetting
  | PromptSetting
  | QueryTimeoutSetting
  | SearchJobsSetting
  | LengthZ3Setting
  | CandidateLimitSetting
  | ChoiceBudgetSetting
  | DjinnStrategySetting
  | DjinnAxiomsSetting
  | AllowUnusedSetting
  | AllowConstraintsSetting
  | ConstraintDeferralStepsSetting
  | MultiConstructorPatternsSetting
  | MaximumStepsSetting
  | MaximumQueueSetting
  | MaximumDepthSetting
  | HeuristicSetting
  | FixSetting
  deriving (Bounded, Enum, Eq, Show)

-- | The option name of a setting as written after @:set@ and @:unset@ and
-- accepted by 'parseReplSetting'.
replSettingName :: ReplSetting -> String
replSettingName setting = case setting of
  BackendSetting -> "backend"
  TargetSetting -> "target"
  SelectionSetting -> "select"
  RankingSetting -> "ranking"
  ProviderCostSetting -> "provider-cost"
  QualityWindowSetting -> "quality-window"
  RenderingSetting -> "render"
  QualificationSetting -> "qualification"
  PromptSetting -> "prompt"
  QueryTimeoutSetting -> "timeout"
  SearchJobsSetting -> "jobs"
  LengthZ3Setting -> "length-z3"
  CandidateLimitSetting -> "candidate-limit"
  ChoiceBudgetSetting -> "choice-budget"
  DjinnStrategySetting -> "djinn-strategy"
  DjinnAxiomsSetting -> "djinn-axioms"
  AllowUnusedSetting -> "allow-unused"
  AllowConstraintsSetting -> "allow-constraints"
  ConstraintDeferralStepsSetting -> "constraint-deferral-steps"
  MultiConstructorPatternsSetting -> "multi-constructor-patterns"
  MaximumStepsSetting -> "max-steps"
  MaximumQueueSetting -> "max-queue"
  MaximumDepthSetting -> "max-depth"
  HeuristicSetting -> "heuristic"
  FixSetting -> "fix"

-- | Whether a setting accepts GHCi-style @+NAME@ and @-NAME@ forms.
--
-- This predicate is the semantic owner used by both command execution and
-- completion. Keeping sign eligibility on the setting type prevents a newly
-- added non-boolean option from accidentally accepting @on@ or @off@ merely
-- because the invocation happened to use a sign.
replSettingIsBoolean :: ReplSetting -> Bool
replSettingIsBoolean setting = case setting of
  DjinnAxiomsSetting -> True
  AllowUnusedSetting -> True
  AllowConstraintsSetting -> True
  MultiConstructorPatternsSetting -> True
  FixSetting -> True
  _ -> False

-- | Resolve a setting name case-insensitively and exactly (no prefixes) to
-- its 'ReplSetting'.
parseReplSetting :: String -> Either String ReplSetting
parseReplSetting source = case filter ((== normalize source) . replSettingName)
    [minBound .. maxBound] of
  [setting] -> Right setting
  _ -> Left $ "unknown setting " ++ show source

data CommandDescriptor = CommandDescriptor
  { descriptorName :: String
  , descriptorAliases :: [String]
  , descriptorArguments :: String
  , descriptorSummary :: String
  , descriptorDetails :: [String]
  , descriptorCompletionDomain :: CompletionDomain
  , descriptorParser :: String -> Either String ReplInput
  }

-- | Classify one complete logical REPL input. A bare @:@ repeats the last
-- query, @:!@ runs a shell command, any other leading colon selects a
-- command by exact alias or unique prefix and parses its arguments; after
-- line comments are stripped, blank input is 'ReplNoInput', an @import@
-- keyword is 'ReplImport', and everything else is a query against the
-- active backends.
parseReplInput :: String -> Either String ReplInput
parseReplInput source
  | rawInput == ":" = Right $ ReplCommand RepeatQuery
  | ":!" `isPrefixOf` rawInput = ReplCommand . RunShell
      <$> required "a shell command" (trim $ drop 2 rawInput)
  | ':' : commandSource <- rawInput = parseColon commandSource
  | null input = Right ReplNoInput
  | isImport input = Right $ ReplImport input
  | otherwise = parseSynthesisArguments ActiveBackends input
 where
  -- Colon commands own their argument grammar: shell text, prompts, and paths
  -- may contain a literal @--@. Bare Haskell input instead follows Djinn's
  -- existing line-comment lexer before import/query classification, including
  -- across one explicitly collected multiline input.
  rawInput = trim source
  input = trim $ stripLineComments source
  isImport value = case stripKeyword "import" value of
    Just _ -> True
    Nothing -> False

parseColon :: String -> Either String ReplInput
parseColon source = do
  let (rawToken, rawArguments) = splitHead source
      (token, arguments) = normalizeAttachedModule rawToken rawArguments
      normalized = map toLower token
  case attachedKindBangBase normalized of
    Just _ -> ReplCommand . InspectKind NormalizeTypeSynonyms
      <$> required "a Haskell type" arguments
    Nothing -> do
      descriptor <- resolveCommand normalized
      descriptorParser descriptor arguments

-- GHCi requires whitespace between the command name and its @+@/@-@ mode.
-- Accepting the commonly written attached form costs no ambiguity because
-- neither spelling participates in alias or unique-prefix resolution.
normalizeAttachedModule :: String -> String -> (String, String)
normalizeAttachedModule token arguments = case map toLower token of
  "module+" -> ("module", prependMode '+' arguments)
  "module-" -> ("module", prependMode '-' arguments)
  _ -> (token, arguments)
 where
  prependMode mode "" = [mode]
  prependMode mode rest = mode : ' ' : rest

-- A trailing bang is a mode only when the preceding token already resolves to
-- the sole @kind@ descriptor. This accepts @:k!@ and every unique prefix while
-- keeping @:kind!T@ and bangs on unrelated commands ordinary unknown tokens.
attachedKindBangBase :: String -> Maybe String
attachedKindBangBase token = case reverse token of
  '!' : reversedBase
    | let base = reverse reversedBase
    , not $ null base
    , Right descriptor <- resolveCommand base
    , descriptorName descriptor == "kind" -> Just base
  _ -> Nothing

resolveCommand :: String -> Either String CommandDescriptor
resolveCommand token = case exactMatches of
  [descriptor] -> Right descriptor
  descriptors@(_ : _) -> ambiguous descriptors
  [] -> case prefixMatches of
    [descriptor] -> Right descriptor
    [] -> Left $ "unknown command :" ++ token
    descriptors -> ambiguous descriptors
 where
  exactMatches = filter exact commandDescriptors
  exact descriptor = token == descriptorName descriptor
    || token `elem` descriptorAliases descriptor
  prefixMatches
    | null token = []
    | otherwise = filter (isPrefixOf token . descriptorName)
        commandDescriptors
  ambiguous descriptors = Left $ "ambiguous command :" ++ token
    ++ " (could be "
    ++ intercalate ", " (map ((':' :) . descriptorName) descriptors) ++ ")"

-- | Resolve a colon-command token to its canonical name. The input may retain
-- its leading colon and the attached @module+@, @module-@, or @kind!@ mode.
-- Exact aliases win before unique canonical prefixes, exactly as in
-- 'parseReplInput'.
resolveCommandToken :: String -> Either String String
resolveCommandToken source = descriptorName <$> resolveCommandSyntax source

-- | Look up the completion vocabulary for any spelling accepted by the
-- command parser. Unknown and ambiguous prefixes deliberately have no
-- argument completion until the user supplies enough of the command name.
commandCompletionDomain :: String -> Maybe CompletionDomain
commandCompletionDomain source = case resolveCommandSyntax source of
  Right descriptor -> Just $ descriptorCompletionDomain descriptor
  Left _ -> Nothing

resolveCommandSyntax :: String -> Either String CommandDescriptor
resolveCommandSyntax source = case attachedKindBangBase normalized of
  Just base -> resolveCommand base
  Nothing -> resolveCommand normalized
 where
  withoutColon = case normalize source of
    ':' : token -> token
    token -> token
  (moduleToken, _) = normalizeAttachedModule withoutColon ""
  normalized = map toLower moduleToken

-- | Resolve a backend selection case-insensitively: an exact
-- 'replBackendName' wins, otherwise a nonempty unique prefix of one;
-- unknown and ambiguous spellings are errors listing the candidates.
parseReplBackend :: String -> Either String ReplBackend
parseReplBackend source = case exactMatches of
  [backend] -> Right backend
  [] -> case prefixMatches of
    [backend] -> Right backend
    [] -> Left $ "unknown backend " ++ show source
    matches -> Left $ "ambiguous backend " ++ show source ++ " (could be "
      ++ intercalate ", " (map replBackendName matches) ++ ")"
  matches -> Left $ "ambiguous backend " ++ show source ++ " (could be "
    ++ intercalate ", " (map replBackendName matches) ++ ")"
 where
  token = normalize source
  exactMatches = filter ((== token) . replBackendName) replBackendChoices
  prefixMatches
    | null token = []
    | otherwise = filter (isPrefixOf token . replBackendName)
        replBackendChoices

replBackendChoices :: [ReplBackend]
replBackendChoices =
  [ OneBackend DjinnBackend
  , OneBackend ExferenceBackend
  , BothBackends
  ]

commandDescriptors :: [CommandDescriptor]
commandDescriptors =
  [ commandWith PathCompletion targetDetails "add" [] "[TARGET ...]"
      "add module or file targets and reload their dependencies"
      $ fmap (ReplCommand . AddEnvironment) . commandArguments
  , commandWith BackendCompletion
      ["  choices: " ++ intercalate ", " backendNames]
      "backend" ["b"] "[djinn|exference|both]"
      "show or change the active backend selection"
      $ Right . ReplCommand . ChangeBackend . optionalText
  , commandWith ModuleCompletion
      ["  prefix a loaded module with * to include non-exported declarations"]
      "browse" [] "[[*]MODULE]"
      "list declarations exported by a module or the current scope"
      $ fmap (ReplCommand . Browse)
          . optionalArgument "at most one module name"
  , commandWith PathCompletion []
      "cd" [] "DIR" "change the process working directory"
      $ fmap (ReplCommand . ChangeDirectory) . pathArgument "a directory"
  , commandWith SynthesisCompletion synthesisDetails
      "compare" [] synthesisArguments "synthesize with both backends"
      $ parseSynthesisArguments $ ExplicitBackends BothBackends
  , commandWith SynthesisCompletion synthesisDetails
      "djinn" [] synthesisArguments "synthesize once with Djinn"
      $ parseSynthesisArguments
          $ ExplicitBackends $ OneBackend DjinnBackend
  , commandWith NoCompletion packageDetails
      "download" ["dl"] "CABAL_TARGET ..."
      "ask Cabal to fetch targets and dependencies into its source cache"
      $ fmap (ReplCommand . DownloadPackages) . packageArguments
  , commandWith PathCompletion editDetails "edit" ["e"] "[FILE]"
      "open the configured editor on a file"
      $ fmap (ReplCommand . EditFile) . optionalArgument "at most one file"
  , commandWith IdentifierCompletion evalDetails "eval" [] "EXPRESSION"
      "evaluate a Haskell expression with real GHC"
      $ fmap (ReplCommand . Evaluate) . required "a Haskell expression"
  , commandWith SynthesisCompletion synthesisDetails
      "exference" [] synthesisArguments "synthesize once with Exference"
      $ parseSynthesisArguments
          $ ExplicitBackends $ OneBackend ExferenceBackend
  , commandWith CommandCompletion []
      "help" ["h", "?"] "[COMMAND]" "show command help"
      $ Right . ReplCommand . Help . optionalText
  , command "history" ["hist"] "[N]" "show command history"
      $ Right . ReplCommand . History . optionalText
  , commandWith IdentifierCompletion []
      "info" ["i"] "NAME" "inspect a declaration by exact name"
      $ fmap (ReplCommand . InspectDeclaration) . required "a declaration name"
  , commandWith NoCompletion installDetails
      "install" [] "[--lib] CABAL_TARGET ..."
      "build and install package executables or libraries through Cabal"
      $ fmap (\(mode, targets) -> ReplCommand $ InstallPackages mode targets)
          . installArguments
  , commandWith TypeIdentifierCompletion kindDetails "kind" ["k"] "TYPE"
      "infer the kind of a Haskell type in the current module scope"
      $ fmap (ReplCommand . InspectKind PreserveTypeSynonyms)
          . required "a Haskell type"
  , commandWith PathCompletion loadDetails "load" ["l"] "[TARGET ...]"
      "replace the module or file targets and load their dependencies"
      $ fmap (ReplCommand . LoadEnvironment) . commandArguments
  , commandWith ModuleContextCompletion moduleDetails
      "module" ["m"] "[+|-] [[*]MODULE ...]"
      "set, add to, or remove from the module context"
      $ fmap ReplCommand . parseModuleChange
  , command "pwd" [] "" "show the current working directory"
      $ noArguments $ ReplCommand $ ShowState $ Just "directory"
  , command "quit" ["q"] "" "leave the REPL"
      $ noArguments $ ReplCommand Quit
  , command "reload" ["r"] "" "reload the source workspace"
      $ noArguments $ ReplCommand ReloadEnvironment
  , commandWith PathCompletion []
      "script" [] "FILE" "execute a file of REPL inputs"
      $ fmap (ReplCommand . RunScript) . pathArgument "a script file"
  , commandWith SettingCompletion setDetails
      "set" ["s"] "[OPTION [VALUE]]" "show or change settings"
      $ Right . ReplCommand . SetOption
  , commandWith ShowCompletion
      ["  subjects: " ++ intercalate ", " showNames]
      "show" []
      ("[" ++ intercalate "|" showNames ++ "]")
      "inspect REPL and backend state"
      $ Right . ReplCommand . ShowState . optionalText
  , commandWith SynthesisCompletion synthesisDetails
      "synth" ["sy"] synthesisArguments
      "synthesize with the active backend(s)"
      $ parseSynthesisArguments ActiveBackends
  , commandWith IdentifierCompletion typeDetails "type" ["t"] "[+d] EXPRESSION"
      "infer the type of a Haskell expression in the current module scope"
      $ fmap ReplCommand . parseTypeInspection
  , commandWith PathCompletion targetDetails "unadd" [] "[TARGET ...]"
      "remove module or file targets and reload their dependencies"
      $ fmap (ReplCommand . UnaddEnvironment) . commandArguments
  , commandWith SettingCompletion
      ["  restores a setting to its built-in default"]
      "unset" [] "OPTION" "restore one setting to its default"
      $ fmap (ReplCommand . UnsetOption) . required "a setting name"
  , command "version" ["v"] "" "show the Djex version"
      $ noArguments $ ReplCommand Version
  ]

command
  :: String
  -> [String]
  -> String
  -> String
  -> (String -> Either String ReplInput)
  -> CommandDescriptor
command = commandWith NoCompletion []

commandWith
  :: CompletionDomain
  -> [String]
  -> String
  -> [String]
  -> String
  -> String
  -> (String -> Either String ReplInput)
  -> CommandDescriptor
commandWith completion details name aliases arguments summary parser =
  CommandDescriptor
    { descriptorName = name
    , descriptorAliases = aliases
    , descriptorArguments = arguments
    , descriptorSummary = summary
    , descriptorDetails = details
    , descriptorCompletionDomain = completion
    , descriptorParser = parser
    }

-- | Every colon-prefixed command spelling offered by completion: each
-- canonical name followed by its aliases, in descriptor order, plus the
-- special forms @:kind!@, @:k!@, @:!@, @:{@, and @:}@.
commandNames :: [String]
commandNames = concatMap completionNames commandDescriptors
  ++ [":kind!", ":k!", ":!", ":{", ":}"]
 where
  completionNames descriptor = map (':' :)
    $ descriptorName descriptor : descriptorAliases descriptor

-- | Every subject accepted after @:help@, without an optional leading colon.
-- This is wider than executable colon commands because imports and attached
-- module modes have dedicated grammar at the prompt boundary.
helpNames :: [String]
helpNames = "import" : "module+" : "module-"
  : map (dropWhile (== ':')) commandNames

-- | The backend selection spellings in display order: @djinn@,
-- @exference@, @both@.
backendNames :: [String]
backendNames = map replBackendName replBackendChoices

-- | Every setting name in the stable 'ReplSetting' order, for help and
-- completion.
settingNames :: [String]
settingNames = map replSettingName [minBound .. maxBound]

-- | The names of the settings that accept the @+NAME@ and @-NAME@ sign
-- forms (see 'replSettingIsBoolean'), in 'ReplSetting' order.
booleanSettingNames :: [String]
booleanSettingNames =
  [ replSettingName setting
  | setting <- [minBound .. maxBound]
  , replSettingIsBoolean setting
  ]

-- | The subjects accepted by @:show@, in help and completion order. The
-- parser does not validate the subject; the executing frontend does.
showNames :: [String]
showNames =
  [ "settings"
  , "backends"
  , "environment"
  , "imports"
  , "modules"
  , "targets"
  , "omissions"
  , "diagnostics"
  , "directory"
  ]

-- | The overview printed by a bare @:help@: prompt conventions followed by
-- one aligned usage-and-summary line per command in descriptor order,
-- plus the @import@ and @:!@ forms.
shortHelp :: String
shortHelp = unlines
  $ "Enter a Haskell type to synthesize with the active backend(s)."
  : "Enter import MODULE to extend the modules visible to queries."
  : "Use :{ and :} around multiline input; : repeats the last query."
  : ""
  : "Commands (unique prefixes are accepted):"
  : renderImport
  : map renderDescriptor commandDescriptors
  ++ ["  :! COMMAND" ++ padding ":! COMMAND" ++ "run a shell command"]
 where
  width = maximum $ map (length . descriptorUsage) commandDescriptors
    ++ [length importUsage, length ":! COMMAND"]
  importUsage = "import DECLARATION"
  padding source = replicate (width - length source + 2) ' '
  renderImport = "  " ++ importUsage ++ padding importUsage
    ++ "add a Haskell import to the module context"
  renderDescriptor descriptor = "  " ++ usage ++ padding usage
    ++ descriptorSummary descriptor
   where
    usage = descriptorUsage descriptor

-- | Detailed help for one @:help@ subject: usage, summary, aliases, and
-- details of the command resolved as in 'parseReplInput' (a leading colon
-- and the @module+@, @module-@, or @kind!@ modes are accepted), or the
-- fixed text for @!@, @{@, @}@, and @import@. Unknown or ambiguous
-- subjects yield the parser's error.
commandHelp :: String -> Either String String
commandHelp source = case token of
  "!" -> Right $ unlines
    [ ":! COMMAND"
    , "  run one shell command without changing REPL state"
    ]
  "{" -> Right multilineHelp
  "}" -> Right multilineHelp
  "import" -> Right $ unlines
    [ "import DECLARATION"
    , "  add a Haskell import to the module context"
    , "  qualified, as, hiding, and explicit import lists are accepted"
    ]
  _ -> do
    descriptor <- resolveCommand $ normalizeHelpToken token
    pure $ unlines
      $ [descriptorUsage descriptor, "  " ++ descriptorSummary descriptor]
      ++ aliasLines descriptor
      ++ descriptorDetails descriptor
 where
  token = dropWhile (== ':') $ normalize source
  multilineHelp = unlines
    [ ":{"
    , "INPUT"
    , ":}"
    , "  collect one logical input over multiple lines"
    ]
  normalizeHelpToken value
    | Just base <- attachedKindBangBase value = base
  normalizeHelpToken "module+" = "module"
  normalizeHelpToken "module-" = "module"
  normalizeHelpToken value = value
  aliasLines descriptor = case descriptorAliases descriptor of
    [] -> []
    aliases -> ["  aliases: " ++ intercalate ", " (map (':' :) aliases)]

targetDetails :: [String]
targetDetails =
  [ "  accepts module names, file paths, quoted strings, or [String] syntax"
  ]

packageDetails :: [String]
packageDetails =
  [ "  accepts Cabal targets as words, quoted strings, or [String] syntax"
  , "  target values are passed to Cabal as data, never as command options"
  , "  this does not add compiled package modules to Djex's source workspace"
  ]

editDetails :: [String]
editDetails =
  [ "  uses the VISUAL editor, or EDITOR when VISUAL is unset"
  , "  launches parsed editor argv directly and appends the path as one value"
  , "  with no argument, edits the most recently loaded file target"
  , "  the source workspace is not reloaded; use :reload afterwards"
  ]

evalDetails :: [String]
evalDetails =
  [ "  compiles the loaded file targets into scope when they are"
  , "  real Haskell; otherwise evaluates against Prelude alone"
  , "  each :eval runs a fresh session, so bindings do not persist"
  ]

installDetails :: [String]
installDetails = packageDetails ++
  [ "  defaults to Cabal's executable mode; --lib installs libraries"
  , "  a leading -- makes a following --lib an ordinary package target"
  , "  installation is independent of the surrounding Cabal project"
  ]

kindDetails :: [String]
kindDetails =
  [ "  append ! to the command or any accepted prefix to show normal form"
  , "  uses the loaded module scope independently of backend selection"
  , "  normal form expands saturated type synonyms, not type families"
  ]

loadDetails :: [String]
loadDetails =
  [ "  accepts module names, file paths, quoted strings, or [String] syntax"
  , "  with no targets, unloads the current source workspace"
  ]

moduleDetails :: [String]
moduleDetails =
  [ "  no sign replaces the context; + adds modules; - removes modules"
  , "  canonical examples: :module +Data.List, :module + Data.Maybe"
  , "  prefix a loaded module with * to include non-exported declarations"
  ]

setDetails :: [String]
setDetails =
  [ "  settings: " ++ intercalate ", " settingNames
  , "  booleans also accept :set +NAME and :set -NAME"
  , "  sign forms are rejected for non-boolean settings"
  , "  ranking: legacy, balanced (default), compact, or diverse"
  , "  provider-cost: NAME=COST; :unset provider-cost clears every override"
  , "  quality-window: positive raw-candidate bound for structural Exference all-output"
  , "  Length/Z3 policy: :set length-z3 /absolute/path/to/z3 [SHA256HEX]"
  , "  heuristic weights: " ++ intercalate ", " heuristicNames
  ]

typeDetails :: [String]
typeDetails =
  [ "  +d defaults eligible numeric type variables in the result"
  , "  the obsolete +v mode is no longer accepted"
  ]

synthesisArguments :: String
synthesisArguments = "[--where CLAUSE --] TYPE"

synthesisDetails :: [String]
synthesisDetails =
  [ "  executable predicate: :synth f :: a -> a where f True == True"
  , "  named where queries check a host Bool before displaying a candidate"
  , "  quality-window bounds observations; each GHC check has a 30s deadline"
  , "  Length/Z3: :synth --where length result == length arg0 -- [a] -> [a]"
  , "  pair result: length (fst result) + length (snd result)"
      ++ " == 2 * length arg0"
  , "  --where is recognized only as the first exact option and requires"
      ++ " a standalone --"
  , "  defaults: built-in lists, all list arguments, scalar or boxed-pair result"
  , "  configure with :set length-z3 PATH [SHA256HEX]"
  , "  --where checks each selected engine's own typed candidate through Length/Z3"
  ]

descriptorUsage :: CommandDescriptor -> String
descriptorUsage descriptor = ':' : usageName
  ++ case descriptorArguments descriptor of
    "" -> ""
    arguments -> " " ++ arguments
 where
  usageName
    | descriptorName descriptor == "kind" = "kind[!]"
    | otherwise = descriptorName descriptor

noArguments :: ReplInput -> String -> Either String ReplInput
noArguments result source
  | null $ trim source = Right result
  | otherwise = Left "this command takes no arguments"

required :: String -> String -> Either String String
required description source
  | null value = Left $ "expected " ++ description
  | otherwise = Right value
 where
  value = trim source

parseSynthesisArguments
  :: ReplQueryTarget
  -> String
  -> Either String ReplInput
parseSynthesisArguments target source = case splitHead source of
  ("--where", afterWhere) -> do
    (clause, typeSource) <- splitWhereClause afterWhere
    pure $ ReplQuery ReplSynthesisQuery
      { replQueryTarget = target
      , replQueryWhereSource = Just clause
      , replQueryBehavioral = Nothing
      , replQueryTypeSource = typeSource
      }
  _ -> do
    typeSource <- required "a type" source
    behavioral <- parseBehavioralQuery HaskellBehavioral typeSource
    pure $ ReplQuery ReplSynthesisQuery
      { replQueryTarget = target
      , replQueryWhereSource = Nothing
      , replQueryBehavioral = behavioral
      , replQueryTypeSource = maybe typeSource behavioralType behavioral
      }

splitWhereClause :: String -> Either String (String, String)
splitWhereClause source = case standaloneSeparator source of
  Nothing -> Left "expected a standalone -- after the --where clause"
  Just offset -> do
    clause <- required "a nonempty --where clause" $ take offset source
    typeSource <- required "a type after the --where separator"
      $ drop (offset + 2) source
    pure (clause, typeSource)

standaloneSeparator :: String -> Maybe Int
standaloneSeparator = go 0 True
 where
  go _ _ [] = Nothing
  go offset leftBoundary ('-' : '-' : after)
    | leftBoundary
    , separatorRightBoundary after = Just offset
    | otherwise = go (offset + 1) False $ '-' : after
  go offset _ (character : rest) =
    go (offset + 1) (isSpace character) rest

  separatorRightBoundary [] = True
  separatorRightBoundary (character : _) = isSpace character

optionalText :: String -> Maybe String
optionalText source = case trim source of
  "" -> Nothing
  value -> Just value

pathArgument :: String -> String -> Either String FilePath
pathArgument description source = do
  arguments <- commandArguments source
  case arguments of
    [value] -> Right value
    [] -> Left $ "expected " ++ description
    _ -> Left $ "expected " ++ description ++ " as one argument"

optionalArgument :: String -> String -> Either String (Maybe String)
optionalArgument description source = do
  arguments <- commandArguments source
  case arguments of
    [] -> Right Nothing
    [value] -> Right $ Just value
    _ -> Left $ "expected " ++ description

parseModuleChange :: String -> Either String ReplCommand
parseModuleChange source = do
  let input = dropWhile isSpace source
      (change, argumentsSource) = case input of
        '+' : rest -> (AddModules, rest)
        '-' : rest -> (RemoveModules, rest)
        _ -> (ReplaceModules, input)
  ChangeModules change <$> commandArguments argumentsSource

parseTypeInspection :: String -> Either String ReplCommand
parseTypeInspection source = case stripKeyword "+d" input of
  Just expression -> InspectType DefaultTypeVariables
    <$> required "a Haskell expression" expression
  Nothing -> case stripKeyword "+v" input of
    Just _ -> Left "`:type +v' has gone; use `:type' instead"
    Nothing -> InspectType PreserveTypeVariables
      <$> required "a Haskell expression" input
 where
  input = trim source

packageArguments :: String -> Either String [String]
packageArguments source = do
  arguments <- commandArguments source
  validatePackageTargets arguments

installArguments
  :: String
  -> Either String (PackageInstallMode, [String])
installArguments source = commandArguments source >>= parsePackageInstall

-- | Parse the argument forms accepted by path- and module-oriented commands.
--
-- A whole @[String]@ is convenient in scripts, while ordinary interactive
-- use consists of whitespace-separated bare words or Haskell string literals.
-- Unlike the old single-path parser, malformed quotes are errors rather than
-- silently becoming literal quote characters in a path.
commandArguments :: String -> Either String [String]
commandArguments source = case trim source of
  "" -> Right []
  input@('[' : _) -> case readMaybe input of
    Just arguments -> Right arguments
    Nothing -> Left "malformed [String] command argument list"
  input -> parseCommandWords input

-- | Parse whitespace-separated process-style arguments, with Haskell string
-- literals available for values containing whitespace. Unlike
-- 'commandArguments', a leading bracket has no special meaning. This is the
-- appropriate grammar for command strings supplied through environment
-- variables such as @VISUAL@ and @EDITOR@.
parseCommandWords :: String -> Either String [String]
parseCommandWords source = parseWords $ trim source
 where
  parseWords "" = Right []
  parseWords input = case dropWhile isSpace input of
    "" -> Right []
    quoted@('"' : _) -> do
      (argument, rest) <- readStringArgument quoted
      (argument :) <$> parseWords rest
    unquoted -> do
      let (argument, rest) = break isSpace unquoted
      if '"' `elem` argument
        then Left "malformed string literal in command arguments"
        else (argument :) <$> parseWords rest

  readStringArgument input = case reads input of
    [(argument, "")] -> Right (argument, "")
    [(argument, rest@(first : _))]
      | isSpace first -> Right (argument, rest)
      | otherwise -> Left "expected whitespace after string literal"
    _ -> Left "malformed string literal in command arguments"

splitHead :: String -> (String, String)
splitHead source = (token, trim arguments)
 where
  withoutLeading = dropWhile isSpace source
  (token, arguments) = break isSpace withoutLeading

stripKeyword :: String -> String -> Maybe String
stripKeyword keyword source
  | not $ keyword `isPrefixOf` source = Nothing
  | otherwise = case drop (length keyword) source of
      "" -> Just ""
      rest@(first : _)
        | isSpace first -> Just $ dropWhile isSpace rest
        | otherwise -> Nothing
