{-# LANGUAGE DeriveGeneric #-}

-- | Length-specific sealing around the shared pure Z3 execution profile.
--
-- This module does not resolve, inspect, hash, or launch an executable.  In
-- particular, caller-supplied SHA-256 bytes are an expectation to be checked
-- by a later live session opener, not an attestation or receipt.  That opener
-- must bind the observed digest even when no expectation is configured and
-- must defend the resolution/hash/spawn path against replacement races.
-- The shared profile owns only reusable launch facts; this module retains the
-- Length protocol, artifact, response, fingerprint, and public-error policy.
-- The complete policy fingerprint is kept package-private because its
-- canonical representation is reversible rather than a digest.
module Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Execution
  ( lengthSMTLibExecutionPolicySchemaTag
  , lengthSMTLibExecutionProtocolSchemaTag
  , lengthSMTLibExecutionArgumentPrefix
  , lengthSMTLibExecutionArgumentVector
  , lengthSMTLibExecutionConfiguredArgumentVector
  , lengthSMTLibExecutionStartupCommandBytes
  , lengthSMTLibExecutionQueryResetBytes
  , lengthSMTLibExecutionEnvironmentPolicyTag
  , lengthSMTLibExecutionWorkingDirectoryPolicyTag
  , lengthSMTLibExecutionExpectedDigestSchemaTag
  , lengthSMTLibMinimumHostDeadlineMarginMilliseconds
  , LengthSMTLibArtifactPolicy (..)
  , LengthSMTLibExecutionLimitSource (..)
  , LengthSMTLibExecutionLimits
  , mkLengthSMTLibExecutionLimits
  , defaultLengthSMTLibExecutionLimitSource
  , defaultLengthSMTLibExecutionLimits
  , lengthSMTLibExecutionExecutablePathCharacterLimit
  , lengthSMTLibExecutionPolicyFingerprintByteLimit
  , LengthSMTLibExecutionConfigSource (..)
  , defaultLengthSMTLibExecutionConfigSource
  , LengthSMTLibExecutionConfig
  , LengthSMTLibExecutableLaunchStrategy (..)
  , LengthSMTLibExecutableDigestExpectation (..)
  , lengthSMTLibExecutionExecutableDigestExpectation
  , LengthSMTLibExecutionConfigField (..)
  , LengthSMTLibExecutionPathCharacterError (..)
  , LengthSMTLibExecutionConfigError (..)
  , mkLengthSMTLibExecutionConfig
  , mkLengthSMTLibDescriptorBoundExecutionConfig
  , mkLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessExecutionConfig
  , mkLengthSMTLibDescriptorBoundExecveCheckExecutableAccessExecutionConfig
  , lengthSMTLibExecutionExecutableLaunchStrategy
  , lengthSMTLibExecutionSolverTimeoutMilliseconds
  , lengthSMTLibExecutionSolverResourceLimit
  , lengthSMTLibExecutionHostDeadlineMilliseconds
  , lengthSMTLibExecutionArtifactPolicy
  , lengthSMTLibExecutionResponseLimits
  , LengthSMTLibExecutionPolicyFingerprintSubject
  , lengthSMTLibExecutionPolicyFingerprint
  , LengthSMTLibPostLaunchExecutionPolicy
  , retainLengthSMTLibPostLaunchExecutionPolicy
  , lengthSMTLibPostLaunchHostDeadlineMilliseconds
  , lengthSMTLibPostLaunchArtifactPolicy
  , lengthSMTLibPostLaunchResponseLimits
  , lengthSMTLibPostLaunchExecutionPolicyFingerprint
  , lengthSMTLibPostLaunchExecutableLaunchStrategy
  , lengthSMTLibExecutionZ3Profile
  ) where

import Control.DeepSeq (NFData (rnf))
import Data.Char (ord)
import Data.Word (Word8)
import GHC.Generics (Generic)
import Numeric.Natural (Natural)

import Language.Haskell.Synthesis.Internal.Fingerprint
  ( Fingerprint
  , FingerprintBuilder (..)
  , FingerprintField (..)
  , FingerprintLimitError (..)
  , buildFingerprintWithin
  )
import qualified Language.Haskell.Synthesis.Internal.SMTLib.Z3.Execution
  as Z3
import Language.Haskell.Synthesis.Semantic.Length.SMTLib.Response
  ( LengthSMTLibResponseLimits
  , defaultLengthSMTLibResponseLimits
  , lengthSMTLibResponseByteLimit
  , lengthSMTLibResponseIntegerBitLimit
  , lengthSMTLibResponseNestingDepthLimit
  , lengthSMTLibResponseNodeLimit
  , lengthSMTLibResponseSchemaTag
  , lengthSMTLibResponseTokenByteLimit
  )

-- | Version of the pure policy only.  Live handshake, framing, session, and
-- run identities will use distinct schema tags.
lengthSMTLibExecutionPolicySchemaTag :: [Word8]
lengthSMTLibExecutionPolicySchemaTag =
  ascii "djex-length-z3-smtlib2-execution-policy/v2"

-- | Exact protocol contract whose command bytes and launch spelling are bound
-- into the pure policy.  A live opener must still probe the corresponding Z3
-- behavior before accepting a worker.
lengthSMTLibExecutionProtocolSchemaTag :: [Word8]
lengthSMTLibExecutionProtocolSchemaTag =
  ascii "djex-length-z3-smtlib2-session-protocol/v1"

-- | Fixed argument prefix passed directly to @process@ without a shell.
-- Compliance mode gives @echo@ its standard quoted response spelling.  It
-- also starts with @:print-success true@, which the startup command disables.
lengthSMTLibExecutionArgumentPrefix :: [String]
lengthSMTLibExecutionArgumentPrefix = Z3.z3SMTLibExecutionArgumentPrefix

-- | Legacy compatibility spelling for the fixed prefix.  This is not a
-- complete argv: process launchers must use
-- 'lengthSMTLibExecutionConfiguredArgumentVector' so timeout and resource
-- arguments cannot be omitted silently.
lengthSMTLibExecutionArgumentVector :: [String]
lengthSMTLibExecutionArgumentVector = lengthSMTLibExecutionArgumentPrefix

-- | Complete ordered argv for one sealed policy.  Resource controls are Z3
-- launch parameters rather than input commands so updating them cannot
-- re-enable compliance-mode success responses mid-session.
lengthSMTLibExecutionConfiguredArgumentVector
  :: LengthSMTLibExecutionConfig
  -> [String]
lengthSMTLibExecutionConfiguredArgumentVector =
  Z3.z3SMTLibExecutionConfiguredArgumentVector
    . lengthSMTLibExecutionZ3Profile

-- | Exact startup command.  In required compliance mode the option affects
-- its own response, so a conforming Z3 worker emits no @success@ for it.
lengthSMTLibExecutionStartupCommandBytes :: [Word8]
lengthSMTLibExecutionStartupCommandBytes =
  Z3.z3SMTLibExecutionStartupCommandBytes

-- | Exact reset prefix replayed before every canonical query.  The required
-- Z3 capability retains disabled success printing across @reset@, so reset
-- emits no frame; suppression is then repeated explicitly for the new query.
-- A future capability handshake must establish this response behavior before
-- the worker can enter the query phase.
lengthSMTLibExecutionQueryResetBytes :: [Word8]
lengthSMTLibExecutionQueryResetBytes = Z3.z3SMTLibExecutionQueryResetBytes

-- | V2 launches with @env = Just []@.  It never inherits ambient variables.
-- A later platform-specific allowlist requires a new versioned policy.
lengthSMTLibExecutionEnvironmentPolicyTag :: [Word8]
lengthSMTLibExecutionEnvironmentPolicyTag =
  Z3.z3SMTLibExecutionEnvironmentPolicyTag

-- | V2 requires a fresh empty working directory owned by the live session.
-- Its concrete path belongs to that session identity and must never be an
-- inherited caller directory.
lengthSMTLibExecutionWorkingDirectoryPolicyTag :: [Word8]
lengthSMTLibExecutionWorkingDirectoryPolicyTag =
  Z3.z3SMTLibExecutionWorkingDirectoryPolicyTag

-- | Meaning of optional expected digest bytes.  The digest is a named
-- external digest/pin format, not a collision-free identity for file bytes.
lengthSMTLibExecutionExpectedDigestSchemaTag :: [Word8]
lengthSMTLibExecutionExpectedDigestSchemaTag =
  Z3.z3SMTLibExecutionExpectedDigestSchemaTag

-- | Minimum host-side response and cleanup time beyond the solver timeout.
lengthSMTLibMinimumHostDeadlineMarginMilliseconds :: Natural
lengthSMTLibMinimumHostDeadlineMarginMilliseconds =
  Z3.z3SMTLibMinimumHostDeadlineMarginMilliseconds

-- | Artifacts the future executor may request after a check response.
-- Neither policy grants semantic authority to the returned status or bytes.
data LengthSMTLibArtifactPolicy
  = LengthSMTLibStatusOnly
  | LengthSMTLibInputValuesAfterSatisfiable
  deriving (Bounded, Enum, Eq, Ord, Show, Generic)

instance NFData LengthSMTLibArtifactPolicy

-- | Independent admission bounds.  They do not change execution semantics
-- after a policy has been sealed and therefore are not fingerprint fields.
data LengthSMTLibExecutionLimitSource = LengthSMTLibExecutionLimitSource
  { lengthSMTLibExecutionLimitSourceExecutablePathCharacters :: Natural
  , lengthSMTLibExecutionLimitSourcePolicyFingerprintBytes :: Natural
  }
  deriving (Eq, Ord, Show, Generic)

instance NFData LengthSMTLibExecutionLimitSource

-- | Retained admission bounds for sealing an execution policy: the shared Z3
-- executable-path character bound and the Length policy fingerprint byte
-- bound.  Constructed only through 'mkLengthSMTLibExecutionLimits'.
data LengthSMTLibExecutionLimits = LengthSMTLibExecutionLimits
  !Z3.Z3SMTLibExecutionLimits !Natural
  deriving (Eq, Ord)

instance NFData LengthSMTLibExecutionLimits where
  rnf (LengthSMTLibExecutionLimits z3 fingerprint) =
    rnf z3 `seq` rnf fingerprint

-- | Retain raw admission bounds without validation; the path character bound
-- is handed to the shared Z3 profile limits and the fingerprint bound is kept
-- for Length policy sealing.
mkLengthSMTLibExecutionLimits
  :: LengthSMTLibExecutionLimitSource
  -> LengthSMTLibExecutionLimits
mkLengthSMTLibExecutionLimits source = LengthSMTLibExecutionLimits
  (Z3.mkZ3SMTLibExecutionLimits
    $ lengthSMTLibExecutionLimitSourceExecutablePathCharacters source)
  (lengthSMTLibExecutionLimitSourcePolicyFingerprintBytes source)

-- | Default raw admission bounds: 4096 executable-path characters and a
-- 256 KiB policy fingerprint bound.
defaultLengthSMTLibExecutionLimitSource
  :: LengthSMTLibExecutionLimitSource
defaultLengthSMTLibExecutionLimitSource = LengthSMTLibExecutionLimitSource
  { lengthSMTLibExecutionLimitSourceExecutablePathCharacters = 4096
  , lengthSMTLibExecutionLimitSourcePolicyFingerprintBytes = 262144
  }

-- | 'defaultLengthSMTLibExecutionLimitSource' retained through
-- 'mkLengthSMTLibExecutionLimits'.
defaultLengthSMTLibExecutionLimits :: LengthSMTLibExecutionLimits
defaultLengthSMTLibExecutionLimits =
  mkLengthSMTLibExecutionLimits defaultLengthSMTLibExecutionLimitSource

-- | Maximum number of characters an executable path may have before sealing
-- fails with 'LengthSMTLibExecutionExecutablePathCharacterLimitExceeded'.
-- The count is in 'FilePath' characters, not encoded bytes.
lengthSMTLibExecutionExecutablePathCharacterLimit
  :: LengthSMTLibExecutionLimits
  -> Natural
lengthSMTLibExecutionExecutablePathCharacterLimit
    (LengthSMTLibExecutionLimits value _) =
  Z3.z3SMTLibExecutionExecutablePathCharacterLimit value

-- | Admission-only cap on the canonical byte size of a sealed policy
-- fingerprint; exceeding it fails sealing with
-- 'LengthSMTLibExecutionPolicyFingerprintByteLimitExceeded'.  It is not a
-- fingerprint field.
lengthSMTLibExecutionPolicyFingerprintByteLimit
  :: LengthSMTLibExecutionLimits
  -> Natural
lengthSMTLibExecutionPolicyFingerprintByteLimit
    (LengthSMTLibExecutionLimits _ value) = value

-- | Raw caller policy.  The path is an absolute @process@ 'FilePath'.  Its
-- Unicode code points are fingerprinted exactly, while platform path encoding
-- and resolved file identity remain obligations of the live session opener.
--
-- Timeout and deadline fields are milliseconds.  Z3's timeout and resource
-- limit are required to be finite and nonzero in this deterministic policy.
data LengthSMTLibExecutionConfigSource = LengthSMTLibExecutionConfigSource
  { lengthSMTLibExecutionConfigSourceExecutablePath :: FilePath
  , lengthSMTLibExecutionConfigSourceExpectedExecutableSHA256
      :: Maybe [Word8]
  , lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds :: Int
  , lengthSMTLibExecutionConfigSourceSolverResourceLimit :: Int
  , lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds :: Int
  , lengthSMTLibExecutionConfigSourceArtifactPolicy
      :: LengthSMTLibArtifactPolicy
  , lengthSMTLibExecutionConfigSourceResponseLimits
      :: LengthSMTLibResponseLimits
  }
  deriving (Eq, Ord)

instance NFData LengthSMTLibExecutionConfigSource where
  rnf source =
    rnf (lengthSMTLibExecutionConfigSourceExecutablePath source) `seq`
    rnf (lengthSMTLibExecutionConfigSourceExpectedExecutableSHA256 source) `seq`
    rnf (lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds source) `seq`
    rnf (lengthSMTLibExecutionConfigSourceSolverResourceLimit source) `seq`
    rnf (lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds source) `seq`
    rnf (lengthSMTLibExecutionConfigSourceArtifactPolicy source) `seq`
    rnf (lengthSMTLibExecutionConfigSourceResponseLimits source)

-- | Conservative defaults around a caller-chosen absolute executable and
-- optional expected digest.  The later live boundary must still resolve and
-- inspect the executable, compare any expectation, and probe capabilities.
defaultLengthSMTLibExecutionConfigSource
  :: FilePath
  -> Maybe [Word8]
  -> LengthSMTLibExecutionConfigSource
defaultLengthSMTLibExecutionConfigSource executable expectedDigest =
  LengthSMTLibExecutionConfigSource
    { lengthSMTLibExecutionConfigSourceExecutablePath = executable
    , lengthSMTLibExecutionConfigSourceExpectedExecutableSHA256 = expectedDigest
    , lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds = 1000
    , lengthSMTLibExecutionConfigSourceSolverResourceLimit = 100000
    , lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds = 1500
    , lengthSMTLibExecutionConfigSourceArtifactPolicy =
        LengthSMTLibInputValuesAfterSatisfiable
    , lengthSMTLibExecutionConfigSourceResponseLimits =
        defaultLengthSMTLibResponseLimits
    }

-- | Opaque validated policy.  There is intentionally no 'Show' or 'Generic'
-- instance and no public projection of its reversible canonical fingerprint.
data LengthSMTLibExecutionConfig = LengthSMTLibExecutionConfig
  !Z3.Z3SMTLibExecutionProfile
  !LengthSMTLibExecutableLaunchStrategy
  !LengthSMTLibArtifactPolicy
  !LengthSMTLibResponseLimits
  !(Fingerprint LengthSMTLibExecutionPolicyFingerprintSubject)

-- Equality intentionally means exact sealed-policy equivalence and observes
-- only the private complete key.  V2 contains no inherited environment or
-- caller-supplied secret field.  A future schema must revisit this instance
-- before admitting secret launch material.
instance Eq LengthSMTLibExecutionConfig where
  left == right = lengthSMTLibExecutionPolicyFingerprint left ==
    lengthSMTLibExecutionPolicyFingerprint right

instance NFData LengthSMTLibExecutionConfig where
  rnf (LengthSMTLibExecutionConfig
      z3 strategy artifacts responses fingerprint) =
    rnf z3 `seq` rnf strategy `seq` rnf artifacts `seq`
      rnf responses `seq` rnf fingerprint

-- | Closed executable-launch authority selected by a sealed policy.  The
-- descriptor-bound strategies bind only the opened main executable image.
-- The effective-ID access variant additionally requires the opened source to
-- pass its versioned effective-ID executable-access policy; neither variant
-- grants authority over an interpreter, dynamic loader, shared library,
-- solver behavior, or solver result.
data LengthSMTLibExecutableLaunchStrategy
  = LengthSMTLibPathSnapshotThenDirectSpawn
  | LengthSMTLibDescriptorBoundExecutableLaunch
  | LengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunch
  | LengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunch
  deriving (Bounded, Enum, Eq, Ord, Show, Generic)

instance NFData LengthSMTLibExecutableLaunchStrategy

-- | Whether one sealed policy contains an executable-file digest expectation.
--
-- This classification deliberately reveals neither the expected SHA-256
-- bytes nor whether a later live executable observation matched them.  It is
-- only enough for an outer configuration owner to require that an expectation
-- was explicitly supplied before granting permission to open a live scope.
data LengthSMTLibExecutableDigestExpectation
  = LengthSMTLibExecutableDigestExpectationAbsent
  | LengthSMTLibExecutableDigestExpectationPresent
  deriving (Bounded, Enum, Eq, Ord, Show, Generic)

instance NFData LengthSMTLibExecutableDigestExpectation

-- | Classify the sealed policy without projecting its path or digest bytes.
-- Only the optional field's outer constructor is inspected.
lengthSMTLibExecutionExecutableDigestExpectation
  :: LengthSMTLibExecutionConfig
  -> LengthSMTLibExecutableDigestExpectation
lengthSMTLibExecutionExecutableDigestExpectation config =
  case Z3.z3SMTLibExecutionExpectedExecutableSHA256
      $ lengthSMTLibExecutionZ3Profile config of
    Nothing -> LengthSMTLibExecutableDigestExpectationAbsent
    Just _ -> LengthSMTLibExecutableDigestExpectationPresent

-- | Which numeric source field a negative, zero, or above-maximum rejection
-- refers to.  Validation runs in the order timeout, resource limit, host
-- deadline, so the first offending field is the one reported.
data LengthSMTLibExecutionConfigField
  = LengthSMTLibExecutionSolverTimeoutMilliseconds
  | LengthSMTLibExecutionSolverResourceLimit
  | LengthSMTLibExecutionHostDeadlineMilliseconds
  deriving (Bounded, Enum, Eq, Ord, Show, Generic)

instance NFData LengthSMTLibExecutionConfigField

-- | Why one executable-path character was rejected: it is NUL, or it lies in
-- the UTF-16 surrogate code point range.  Reported with the character's
-- zero-based offset by 'LengthSMTLibExecutionInvalidExecutablePathCharacter'.
data LengthSMTLibExecutionPathCharacterError
  = LengthSMTLibExecutionPathContainsNul
  | LengthSMTLibExecutionPathContainsSurrogate
  deriving (Bounded, Enum, Eq, Ord, Show, Generic)

instance NFData LengthSMTLibExecutionPathCharacterError

-- | Fixed-precedence pure policy rejection.  Errors never retain the path or
-- digest bytes.  Observed collection sizes stop at maximum plus one.
data LengthSMTLibExecutionConfigError
  = NegativeLengthSMTLibExecutionConfigField
      !LengthSMTLibExecutionConfigField !Int
  | ZeroLengthSMTLibExecutionConfigField
      !LengthSMTLibExecutionConfigField
  | LengthSMTLibExecutionConfigFieldAboveMaximum
      !LengthSMTLibExecutionConfigField !Integer !Integer
  | LengthSMTLibExecutionHostDeadlineMarginTooSmall
      !Int !Int !Natural
  | LengthSMTLibExecutionHostDeadlineMicrosecondsOverflow !Int
  | LengthSMTLibExecutionExecutablePathCharacterLimitExceeded
      !Natural !Natural
  | LengthSMTLibExecutionInvalidExecutablePathCharacter
      !Natural !LengthSMTLibExecutionPathCharacterError
  | LengthSMTLibExecutionEmptyExecutablePath
  | LengthSMTLibExecutionExecutablePathNotAbsolute
  | LengthSMTLibExecutionExpectedExecutableSHA256LengthMismatch
      !Natural !Natural
  | LengthSMTLibExecutionPolicyFingerprintByteLimitExceeded
      !Natural !Natural
  deriving (Eq, Ord, Show, Generic)

instance NFData LengthSMTLibExecutionConfigError

-- | Seal one pure launch and response policy.  Successful construction says
-- nothing about the filesystem or a running process.
mkLengthSMTLibExecutionConfig
  :: LengthSMTLibExecutionLimits
  -> LengthSMTLibExecutionConfigSource
  -> Either LengthSMTLibExecutionConfigError LengthSMTLibExecutionConfig
mkLengthSMTLibExecutionConfig limits source = do
  buildExecutionConfig LengthSMTLibPathSnapshotThenDirectSpawn limits source

-- | Seal the additive Linux descriptor-bound launch policy.  Pure admission
-- remains platform-independent; a live opener fails closed when the native
-- descriptor launcher is unavailable.
mkLengthSMTLibDescriptorBoundExecutionConfig
  :: LengthSMTLibExecutionLimits
  -> LengthSMTLibExecutionConfigSource
  -> Either LengthSMTLibExecutionConfigError LengthSMTLibExecutionConfig
mkLengthSMTLibDescriptorBoundExecutionConfig limits source =
  buildExecutionConfig LengthSMTLibDescriptorBoundExecutableLaunch
    limits source

-- | Seal the additive Linux descriptor-bound launch policy that requires the
-- opened source descriptor to pass the versioned effective-ID executable-
-- access check.  Pure admission remains platform-independent; a live opener
-- fails closed when either the native descriptor launcher or that access
-- check is unavailable.
mkLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessExecutionConfig
  :: LengthSMTLibExecutionLimits
  -> LengthSMTLibExecutionConfigSource
  -> Either LengthSMTLibExecutionConfigError LengthSMTLibExecutionConfig
mkLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessExecutionConfig
    limits source =
  buildExecutionConfig
    LengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunch
    limits source

-- | Seal the additive Linux 6.14 descriptor-bound launch policy which adds
-- two source and one staged @AT_EXECVE_CHECK@ observations to the effective-
-- ID access and sealed-image authority.  Pure admission remains platform-
-- independent; a live opener fails closed when any required primitive is
-- unavailable.
mkLengthSMTLibDescriptorBoundExecveCheckExecutableAccessExecutionConfig
  :: LengthSMTLibExecutionLimits
  -> LengthSMTLibExecutionConfigSource
  -> Either LengthSMTLibExecutionConfigError LengthSMTLibExecutionConfig
mkLengthSMTLibDescriptorBoundExecveCheckExecutableAccessExecutionConfig
    limits source =
  buildExecutionConfig
    LengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunch
    limits source

buildExecutionConfig
  :: LengthSMTLibExecutableLaunchStrategy
  -> LengthSMTLibExecutionLimits
  -> LengthSMTLibExecutionConfigSource
  -> Either LengthSMTLibExecutionConfigError LengthSMTLibExecutionConfig
buildExecutionConfig strategy limits source = do
  z3 <- case Z3.mkZ3SMTLibExecutionProfile z3Limits Z3.Z3SMTLibExecutionSource
      { Z3.z3SMTLibExecutionSourceExecutablePath =
          lengthSMTLibExecutionConfigSourceExecutablePath source
      , Z3.z3SMTLibExecutionSourceExpectedExecutableSHA256 =
          lengthSMTLibExecutionConfigSourceExpectedExecutableSHA256 source
      , Z3.z3SMTLibExecutionSourceSolverTimeoutMilliseconds =
          lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds source
      , Z3.z3SMTLibExecutionSourceSolverResourceLimit =
          lengthSMTLibExecutionConfigSourceSolverResourceLimit source
      , Z3.z3SMTLibExecutionSourceHostDeadlineMilliseconds =
          lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds source
      } of
    Left failure -> Left $ mapZ3ExecutionError failure
    Right profile -> Right profile
  let artifacts = lengthSMTLibExecutionConfigSourceArtifactPolicy source
      responses = lengthSMTLibExecutionConfigSourceResponseLimits source
  fingerprint <- case strategy of
    LengthSMTLibPathSnapshotThenDirectSpawn ->
      buildPolicyFingerprint limits z3 artifacts responses
    LengthSMTLibDescriptorBoundExecutableLaunch ->
      buildDescriptorBoundPolicyFingerprint limits z3 artifacts responses
    LengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunch ->
      buildDescriptorBoundEffectiveIDExecutableAccessPolicyFingerprint
        limits z3 artifacts responses
    LengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunch ->
      buildDescriptorBoundExecveCheckExecutableAccessPolicyFingerprint
        limits z3 artifacts responses
  pure $ LengthSMTLibExecutionConfig
    z3 strategy artifacts responses fingerprint
 where
  LengthSMTLibExecutionLimits z3Limits _ = limits

-- | Validated Z3 @timeout=@ launch parameter in milliseconds; sealing
-- guarantees it is positive and below the 32-bit unsigned maximum.
lengthSMTLibExecutionSolverTimeoutMilliseconds
  :: LengthSMTLibExecutionConfig
  -> Int
lengthSMTLibExecutionSolverTimeoutMilliseconds =
  Z3.z3SMTLibExecutionSolverTimeoutMilliseconds
    . lengthSMTLibExecutionZ3Profile

-- | Validated Z3 @rlimit=@ launch parameter; sealing guarantees it is
-- positive and at most the 32-bit unsigned maximum.
lengthSMTLibExecutionSolverResourceLimit
  :: LengthSMTLibExecutionConfig
  -> Int
lengthSMTLibExecutionSolverResourceLimit =
  Z3.z3SMTLibExecutionSolverResourceLimit
    . lengthSMTLibExecutionZ3Profile

-- | Validated host-side deadline in milliseconds.  Sealing guarantees it is
-- positive, exceeds the solver timeout by at least
-- 'lengthSMTLibMinimumHostDeadlineMarginMilliseconds', and converts to
-- microseconds without 'Int' overflow.
lengthSMTLibExecutionHostDeadlineMilliseconds
  :: LengthSMTLibExecutionConfig
  -> Int
lengthSMTLibExecutionHostDeadlineMilliseconds =
  Z3.z3SMTLibExecutionHostDeadlineMilliseconds
    . lengthSMTLibExecutionZ3Profile

-- | Which artifacts a run may request after the @check-sat@ status; retained
-- verbatim from the source and bound into the policy fingerprint.
lengthSMTLibExecutionArtifactPolicy
  :: LengthSMTLibExecutionConfig
  -> LengthSMTLibArtifactPolicy
lengthSMTLibExecutionArtifactPolicy
    (LengthSMTLibExecutionConfig _ _ value _ _) = value

-- | Bounds applied when parsing each @check-sat@ and @get-value@ response
-- frame; retained verbatim from the source and bound into the policy
-- fingerprint.
lengthSMTLibExecutionResponseLimits
  :: LengthSMTLibExecutionConfig
  -> LengthSMTLibResponseLimits
lengthSMTLibExecutionResponseLimits
    (LengthSMTLibExecutionConfig _ _ _ value _) = value

-- | Launch strategy selected by the sealing entry point that built this
-- policy; it determines which fingerprint role and schema the policy key
-- was built under.
lengthSMTLibExecutionExecutableLaunchStrategy
  :: LengthSMTLibExecutionConfig
  -> LengthSMTLibExecutableLaunchStrategy
lengthSMTLibExecutionExecutableLaunchStrategy
    (LengthSMTLibExecutionConfig _ value _ _ _) = value

-- | Uninhabited phantom subject of the complete execution-policy
-- fingerprint, keeping that key distinct from every other 'Fingerprint'.
data LengthSMTLibExecutionPolicyFingerprintSubject

-- | Complete reversible canonical key of the sealed policy, built under a
-- strategy-specific role and schema tag from the protocol tag, every Z3
-- launch fact including the exact path and any expected digest, and the
-- artifact and response policy.  'Eq' on t'LengthSMTLibExecutionConfig'
-- compares only this key.
lengthSMTLibExecutionPolicyFingerprint
  :: LengthSMTLibExecutionConfig
  -> Fingerprint LengthSMTLibExecutionPolicyFingerprintSubject
lengthSMTLibExecutionPolicyFingerprint
    (LengthSMTLibExecutionConfig _ _ _ _ value) = value

-- | Strict post-launch authority intended to be retained only after a worker
-- has passed capability and ready-identity admission.  The structured Z3
-- launch profile is deliberately absent.  The original complete
-- execution-policy key is retained verbatim so every downstream identity
-- remains byte-for-byte compatible with the policy admitted before launch.
data LengthSMTLibPostLaunchExecutionPolicy =
  LengthSMTLibPostLaunchExecutionPolicy
    !Int
    !LengthSMTLibExecutableLaunchStrategy
    !LengthSMTLibArtifactPolicy
    !LengthSMTLibResponseLimits
    !(Fingerprint LengthSMTLibExecutionPolicyFingerprintSubject)

instance NFData LengthSMTLibPostLaunchExecutionPolicy where
  rnf (LengthSMTLibPostLaunchExecutionPolicy
      deadline strategy artifacts responses fingerprint) =
    rnf deadline `seq` rnf strategy `seq` rnf artifacts `seq`
      rnf responses `seq` rnf fingerprint

-- | Narrow a complete execution policy after ready-identity admission.  This
-- copies the already validated host deadline, artifact and response policy,
-- and the original complete fingerprint object; it never rebuilds the key.
retainLengthSMTLibPostLaunchExecutionPolicy
  :: LengthSMTLibExecutionConfig
  -> LengthSMTLibPostLaunchExecutionPolicy
retainLengthSMTLibPostLaunchExecutionPolicy config =
  LengthSMTLibPostLaunchExecutionPolicy
    (lengthSMTLibExecutionHostDeadlineMilliseconds config)
    (lengthSMTLibExecutionExecutableLaunchStrategy config)
    (lengthSMTLibExecutionArtifactPolicy config)
    (lengthSMTLibExecutionResponseLimits config)
    (lengthSMTLibExecutionPolicyFingerprint config)

-- | Host-side deadline in milliseconds copied unchanged from the complete
-- policy at 'retainLengthSMTLibPostLaunchExecutionPolicy'; the live session
-- derives its per-query wait from this value.
lengthSMTLibPostLaunchHostDeadlineMilliseconds
  :: LengthSMTLibPostLaunchExecutionPolicy
  -> Int
lengthSMTLibPostLaunchHostDeadlineMilliseconds
    (LengthSMTLibPostLaunchExecutionPolicy value _ _ _ _) = value

-- | Launch strategy copied unchanged from the complete policy that admitted
-- the worker.
lengthSMTLibPostLaunchExecutableLaunchStrategy
  :: LengthSMTLibPostLaunchExecutionPolicy
  -> LengthSMTLibExecutableLaunchStrategy
lengthSMTLibPostLaunchExecutableLaunchStrategy
    (LengthSMTLibPostLaunchExecutionPolicy _ value _ _ _) = value

-- | Artifact policy copied unchanged from the complete policy; protocol plan
-- sealing consults it to decide whether a @get-value@ write and value
-- barrier are required.
lengthSMTLibPostLaunchArtifactPolicy
  :: LengthSMTLibPostLaunchExecutionPolicy
  -> LengthSMTLibArtifactPolicy
lengthSMTLibPostLaunchArtifactPolicy
    (LengthSMTLibPostLaunchExecutionPolicy _ _ value _ _) = value

-- | Response-parsing bounds copied unchanged from the complete policy;
-- protocol plan sealing validates each required frame against them and the
-- receiver parses status and value frames under them.
lengthSMTLibPostLaunchResponseLimits
  :: LengthSMTLibPostLaunchExecutionPolicy
  -> LengthSMTLibResponseLimits
lengthSMTLibPostLaunchResponseLimits
    (LengthSMTLibPostLaunchExecutionPolicy _ _ _ value _) = value

-- | The original complete execution-policy key, retained verbatim rather
-- than rebuilt, so identities derived after launch (such as the protocol
-- plan fingerprint) bind exactly the policy admitted before launch.
lengthSMTLibPostLaunchExecutionPolicyFingerprint
  :: LengthSMTLibPostLaunchExecutionPolicy
  -> Fingerprint LengthSMTLibExecutionPolicyFingerprintSubject
lengthSMTLibPostLaunchExecutionPolicyFingerprint
    (LengthSMTLibPostLaunchExecutionPolicy _ _ _ _ value) = value

-- | The shared validated Z3 launch profile inside a sealed policy: exact
-- executable path, optional expected digest, and the three numeric launch
-- controls.  Package-private because it exposes the path and digest bytes.
lengthSMTLibExecutionZ3Profile
  :: LengthSMTLibExecutionConfig
  -> Z3.Z3SMTLibExecutionProfile
lengthSMTLibExecutionZ3Profile
    (LengthSMTLibExecutionConfig value _ _ _ _) = value

mapZ3ExecutionError
  :: Z3.Z3SMTLibExecutionError
  -> LengthSMTLibExecutionConfigError
mapZ3ExecutionError failure = case failure of
  Z3.NegativeZ3SMTLibExecutionField field value ->
    NegativeLengthSMTLibExecutionConfigField
      (mapZ3ExecutionField field) value
  Z3.ZeroZ3SMTLibExecutionField field ->
    ZeroLengthSMTLibExecutionConfigField $ mapZ3ExecutionField field
  Z3.Z3SMTLibExecutionFieldAboveMaximum field maximumValue observed ->
    LengthSMTLibExecutionConfigFieldAboveMaximum
      (mapZ3ExecutionField field) maximumValue observed
  Z3.Z3SMTLibExecutionHostDeadlineMarginTooSmall timeout deadline margin ->
    LengthSMTLibExecutionHostDeadlineMarginTooSmall timeout deadline margin
  Z3.Z3SMTLibExecutionHostDeadlineMicrosecondsOverflow deadline ->
    LengthSMTLibExecutionHostDeadlineMicrosecondsOverflow deadline
  Z3.Z3SMTLibExecutionExecutablePathCharacterLimitExceeded
      maximumCharacters observed ->
    LengthSMTLibExecutionExecutablePathCharacterLimitExceeded
      maximumCharacters observed
  Z3.Z3SMTLibExecutionInvalidExecutablePathCharacter offset reason ->
    LengthSMTLibExecutionInvalidExecutablePathCharacter offset
      $ mapZ3PathCharacterError reason
  Z3.Z3SMTLibExecutionEmptyExecutablePath ->
    LengthSMTLibExecutionEmptyExecutablePath
  Z3.Z3SMTLibExecutionExecutablePathNotAbsolute ->
    LengthSMTLibExecutionExecutablePathNotAbsolute
  Z3.Z3SMTLibExecutionExpectedExecutableSHA256LengthMismatch
      expected observed ->
    LengthSMTLibExecutionExpectedExecutableSHA256LengthMismatch
      expected observed

mapZ3ExecutionField
  :: Z3.Z3SMTLibExecutionField
  -> LengthSMTLibExecutionConfigField
mapZ3ExecutionField field = case field of
  Z3.Z3SMTLibExecutionSolverTimeoutMilliseconds ->
    LengthSMTLibExecutionSolverTimeoutMilliseconds
  Z3.Z3SMTLibExecutionSolverResourceLimit ->
    LengthSMTLibExecutionSolverResourceLimit
  Z3.Z3SMTLibExecutionHostDeadlineMilliseconds ->
    LengthSMTLibExecutionHostDeadlineMilliseconds

mapZ3PathCharacterError
  :: Z3.Z3SMTLibExecutionPathCharacterError
  -> LengthSMTLibExecutionPathCharacterError
mapZ3PathCharacterError reason = case reason of
  Z3.Z3SMTLibExecutionPathContainsNul ->
    LengthSMTLibExecutionPathContainsNul
  Z3.Z3SMTLibExecutionPathContainsSurrogate ->
    LengthSMTLibExecutionPathContainsSurrogate

-- | One shared execution-policy fingerprint builder: every launch profile
-- fingerprints the same Z3 profile, artifact policy, and response limits
-- after its own role and header fields (the policy schema literal and, for
-- the descriptor-bound launches, the executable-launch-strategy block).
buildPolicyFingerprintWith
  :: [Word8]
  -> [FingerprintField]
  -> LengthSMTLibExecutionLimits
  -> Z3.Z3SMTLibExecutionProfile
  -> LengthSMTLibArtifactPolicy
  -> LengthSMTLibResponseLimits
  -> Either
      LengthSMTLibExecutionConfigError
      (Fingerprint LengthSMTLibExecutionPolicyFingerprintSubject)
buildPolicyFingerprintWith role headerFields limits z3 artifacts responses =
  case buildFingerprintWithin maximumBytes FingerprintBuilder
      { fingerprintBuilderVersion = 1
      , fingerprintBuilderRole = role
      , fingerprintBuilderFields =
          headerFields ++ Z3.z3SMTLibExecutionFingerprintFields z3 ++
          [ artifactPolicyField artifacts
          , FingerprintBytes lengthSMTLibResponseSchemaTag
          , FingerprintNatural $ lengthSMTLibResponseByteLimit responses
          , FingerprintNatural $ fromIntegral
              $ lengthSMTLibResponseNestingDepthLimit responses
          , FingerprintNatural $ lengthSMTLibResponseNodeLimit responses
          , FingerprintNatural $ lengthSMTLibResponseTokenByteLimit responses
          , FingerprintNatural $ fromIntegral
              $ lengthSMTLibResponseIntegerBitLimit responses
          ]
      } of
    Left FingerprintLimitExceeded
        { fingerprintMaximumBytes = maximumBytesObserved
        , fingerprintObservedBytesAtLeast = observed
        } -> Left $ LengthSMTLibExecutionPolicyFingerprintByteLimitExceeded
          maximumBytesObserved observed
    Right fingerprint -> Right fingerprint
 where
 maximumBytes = lengthSMTLibExecutionPolicyFingerprintByteLimit limits

buildPolicyFingerprint
  :: LengthSMTLibExecutionLimits
  -> Z3.Z3SMTLibExecutionProfile
  -> LengthSMTLibArtifactPolicy
  -> LengthSMTLibResponseLimits
  -> Either
      LengthSMTLibExecutionConfigError
      (Fingerprint LengthSMTLibExecutionPolicyFingerprintSubject)
buildPolicyFingerprint = buildPolicyFingerprintWith
  (ascii "length-z3-execution-policy")
  [ FingerprintBytes lengthSMTLibExecutionPolicySchemaTag
  , FingerprintBytes lengthSMTLibExecutionProtocolSchemaTag
  ]

buildDescriptorBoundPolicyFingerprint
  :: LengthSMTLibExecutionLimits
  -> Z3.Z3SMTLibExecutionProfile
  -> LengthSMTLibArtifactPolicy
  -> LengthSMTLibResponseLimits
  -> Either
      LengthSMTLibExecutionConfigError
      (Fingerprint LengthSMTLibExecutionPolicyFingerprintSubject)
buildDescriptorBoundPolicyFingerprint = buildPolicyFingerprintWith
  (ascii "length-z3-descriptor-bound-execution-policy")
  [ FingerprintBytes $ ascii
      "djex-length-z3-smtlib2-execution-policy/descriptor-bound-main-image/v1"
  , FingerprintBytes lengthSMTLibExecutionProtocolSchemaTag
  , FingerprintTag (ascii "executable-launch-strategy")
      [ FingerprintBytes $ ascii
          "opened-source-hash-copy-sealed-memfd-execveat/main-image-bytes/v1"
      , FingerprintBytes $ ascii
          "sealed-staged-main-image-bytes-only/v1"
      , FingerprintBytes $ ascii
          "no-setuid-file-capability-loader-library-interpreter-or-solver-authority/v1"
      ]
  ]

buildDescriptorBoundEffectiveIDExecutableAccessPolicyFingerprint
  :: LengthSMTLibExecutionLimits
  -> Z3.Z3SMTLibExecutionProfile
  -> LengthSMTLibArtifactPolicy
  -> LengthSMTLibResponseLimits
  -> Either
      LengthSMTLibExecutionConfigError
      (Fingerprint LengthSMTLibExecutionPolicyFingerprintSubject)
buildDescriptorBoundEffectiveIDExecutableAccessPolicyFingerprint =
  buildPolicyFingerprintWith
  (ascii
    "length-z3-descriptor-bound-effective-id-executable-access-execution-policy")
  [ FingerprintBytes $ ascii
      "djex-length-z3-smtlib2-execution-policy/descriptor-bound-effective-id-executable-access/v1"
  , FingerprintBytes lengthSMTLibExecutionProtocolSchemaTag
  , FingerprintTag (ascii "executable-launch-strategy")
      [ FingerprintBytes $ ascii
          "opened-source-two-point-faccessat2-x-ok-at-empty-path-at-eaccess-hash-copy-sealed-memfd-execveat/point-in-time-effective-id-source-vfs-executable-access-and-main-image-bytes/v1"
      , FingerprintBytes $ ascii
          "two-point-point-in-time-effective-id-source-vfs-executable-access-only/v1"
      , FingerprintBytes $ ascii
          "sealed-staged-main-image-bytes-only/v1"
      , FingerprintBytes $ ascii
          "no-setuid-file-capability-loader-library-interpreter-or-solver-authority/v1"
      ]
  ]

buildDescriptorBoundExecveCheckExecutableAccessPolicyFingerprint
  :: LengthSMTLibExecutionLimits
  -> Z3.Z3SMTLibExecutionProfile
  -> LengthSMTLibArtifactPolicy
  -> LengthSMTLibResponseLimits
  -> Either
      LengthSMTLibExecutionConfigError
      (Fingerprint LengthSMTLibExecutionPolicyFingerprintSubject)
buildDescriptorBoundExecveCheckExecutableAccessPolicyFingerprint =
  buildPolicyFingerprintWith
  (ascii
    "length-z3-descriptor-bound-execve-check-executable-access-execution-policy")
  [ FingerprintBytes $ ascii
      "djex-length-z3-smtlib2-execution-policy/descriptor-bound-execve-check-executable-access/v1"
  , FingerprintBytes lengthSMTLibExecutionProtocolSchemaTag
  , FingerprintTag (ascii "executable-launch-strategy")
      [ FingerprintBytes $ ascii $ concat
          [ "opened-source-two-point-faccessat2-x-ok-at-empty-path-at-"
          , "eaccess-plus-execveat-at-empty-path-at-execve-check-hash-"
          , "copy-mfd-exec-fixed-0500-f-seal-exec-sealed-memfd-"
          , "staged-execve-check-then-execveat/point-in-time-source-"
          , "and-staged-kernel-executable-access-and-main-image-"
          , "bytes/v1"
          ]
      , FingerprintBytes $ ascii $ concat
          [ "two-point-source-faccessat2-and-execve-check-plus-one-"
          , "sealed-staged-image-execve-check-point-in-time-only/v1"
          ]
      , FingerprintBytes $ ascii $ concat
          [ "mfd-exec-fixed-0500-seal-write-grow-shrink-future-write-"
          , "exec-seal-main-image-bytes-only/v1"
          ]
      , FingerprintBytes $ ascii $ concat
          [ "no-source-authorization-transfer-format-binfmt-bprm-"
          , "check-credential-transition-interpreter-loader-library-"
          , "solver-or-result-authority/v1"
          ]
      ]
  ]

artifactPolicyField :: LengthSMTLibArtifactPolicy -> FingerprintField
artifactPolicyField policy = FingerprintTag (ascii "artifact-policy")
  [ FingerprintBytes $ case policy of
      LengthSMTLibStatusOnly -> ascii "status-only"
      LengthSMTLibInputValuesAfterSatisfiable ->
        ascii "input-values-after-satisfiable"
  ]

ascii :: String -> [Word8]
ascii = map $ fromIntegral . ord
