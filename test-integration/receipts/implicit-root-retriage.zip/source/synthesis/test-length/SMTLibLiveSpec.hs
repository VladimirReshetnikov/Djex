{-# LANGUAGE CPP #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}

module SMTLibLiveSpec
  ( smtLibLiveTests
  , FakeZ3Event
  , fakeZ3EventTag
  , fakeZ3FieldValues
  , readFakeZ3Events
  , withFakeZ3Mode
  , withDescriptorBoundLiveFacadeSession
  , withDescriptorBoundLiveQueryWorker
  , withEffectiveIDDescriptorBoundLiveFacadeSession
  , withEffectiveIDDescriptorBoundLiveQueryWorker
  , withExecveCheckDescriptorBoundLiveFacadeSession
  , withExecveCheckDescriptorBoundLiveQueryWorker
  , withLiveFacadeSession
  , withLiveQueryWorker
  , withLiveQueryWorkerLimits
  ) where

import Control.Concurrent (forkIO, myThreadId, throwTo)
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
import Control.Concurrent (threadDelay)
#endif
import Control.Concurrent.MVar
  ( newEmptyMVar
  , putMVar
  , takeMVar
  )
import Control.Exception
  ( Exception
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
  , MaskingState (MaskedInterruptible)
#endif
  , bracket
  , finally
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
  , getMaskingState
#endif
  , onException
  , throwIO
  , try
  )
import Control.Monad (forM, forM_)
import qualified Crypto.Hash.SHA256 as SHA256
import Data.Bits ((.&.), shiftR)
import Data.ByteString (ByteString)
import qualified Data.ByteString as BS
import qualified Data.ByteString.Char8 as BSC
import Data.Char (ord)
import Data.IORef
  ( IORef
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
  , modifyIORef'
#endif
  , newIORef
  , readIORef
  , writeIORef
  )
import Data.List (find, isPrefixOf, tails)
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
import Data.Int (Int64)
#endif
import Data.Word (Word8)
import Numeric.Natural (Natural)
import System.Directory
  ( canonicalizePath
  , copyFile
  , createDirectory
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
  , createFileLink
#endif
  , createDirectoryLink
  , doesDirectoryExist
  , doesFileExist
  , doesPathExist
  , findExecutable
  , getPermissions
  , getTemporaryDirectory
  , listDirectory
  , pathIsSymbolicLink
  , removeDirectory
  , removeFile
  , removePathForcibly
  , renameDirectory
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
  , renameFile
#endif
  , setOwnerExecutable
  , setPermissions
  )
import System.FilePath ((</>), takeFileName)
import qualified System.Info as SystemInfo
import System.IO
  ( hClose
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
  , Handle
  , hIsClosed
#endif
  , openTempFile
  )
import System.IO.Error (tryIOError)
import System.Timeout (timeout)

#ifndef mingw32_HOST_OS
import System.Posix.IO
  ( FdOption (CloseOnExec)
  , OpenMode (ReadOnly)
  , closeFd
  , defaultFileFlags
  , openFd
  , setFdOption
  )
import Foreign.C.Types (CInt (..))
import System.Posix.Types (Fd (..))
#endif

import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Execution
  as Execution
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Protocol
  as Protocol
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Session
  as Session
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Session.Capability
  as Capability
import qualified Language.Haskell.Synthesis.Internal.Semantic.Length.SMTLib.Session.Process
  as Process
import qualified Language.Haskell.Synthesis.Internal.Fingerprint
  as Fingerprint
import qualified Language.Haskell.Synthesis.Internal.SMTLib.Causal
  as SMTLibCausal
import qualified Language.Haskell.Synthesis.Internal.SMTLib.Causal.StdoutChunk
  as SMTLibStdoutChunk
import qualified Language.Haskell.Synthesis.Internal.SMTLib.Stream
  as SMTLibStream
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
import qualified Language.Haskell.Synthesis.Internal.SMTLib.Z3.Execution
  as Z3Execution
import qualified Language.Haskell.Synthesis.Internal.SMTLib.Z3.Process
  as Z3Process
#endif
import qualified Language.Haskell.Synthesis.Semantic.Length.SMTLib.Execution
  as PublicExecution
import qualified Language.Haskell.Synthesis.Semantic.Length.SMTLib.Live
  as Live
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.HUnit
  ( assertBool
  , assertFailure
  , testCase
  , (@?=)
  )

smtLibLiveTests :: TestTree
smtLibLiveTests = testGroup "Length SMT-LIB live worker checkpoint"
  [ capabilityTests
  , rawProcessTests
  , liveSessionTests
  ]

capabilityTests :: TestTree
capabilityTests = testGroup "pure capability handshake"
  [ healthyChunkTests
  , testCase "publish exact schemas, defaults, and admission minima"
      assertCapabilitySchemasAndAdmission
  , testCase "reject malformed and every pairwise-reused nonce"
      assertCapabilityNonceAdmission
  , testCase "reject exact-response, barrier, and EOF failures by phase"
      assertCapabilityPhaseFailures
  , testCase "reject model and readiness output before their writes"
      assertCapabilityCausalBoundaries
  , testCase "enforce cumulative maximum and frame/cumulative tie precedence"
      assertCapabilityAccounting
  , testCase "stop at the first bad frame without scanning for recovery"
      assertCapabilityNoScanning
  ]

healthyChunkTests :: TestTree
healthyChunkTests = testGroup "exact four-write transcript across chunking"
  [ testCase name $ do
      fixture <- defaultCapabilityFixture
      assertHealthyCapability fixture chunker
  | (name, chunker) <-
      [ ("whole response groups", wholeChunks)
      , ("selected internal splits", selectedChunks)
      , ("singleton bytes", singletonChunks)
      , ("empty chunks interleaved", emptyInterleavedChunks)
      ]
  ]

rawProcessTests :: TestTree
rawProcessTests = testGroup "raw bounded Process transport"
  [ testCase "reject cancellation before demanding runtime inputs"
      assertRawProcessCancellationPrecedence
  , testCase "reject a relative cwd before demanding limits or launch profile"
      assertRawProcessWorkingDirectoryPrecedence
  , testCase "derive a repeated exact profile-only raw process identity"
      assertRawProcessProfileIdentity
  , testCase "stdout limit preserves prefix before terminal across read chunks"
      assertRawProcessStdoutLimitPrefix
  , descriptorBoundProcessTests
  , effectiveIDDescriptorBoundProcessTests
  , execveCheckDescriptorBoundProcessTests
  ]

descriptorBoundProcessTests :: TestTree
descriptorBoundProcessTests = testGroup
  "sealed descriptor-bound executable launch"
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
  [ testCase "publish exact legacy and sealed-image strengths"
      assertDescriptorBoundStrengths
  , testCase "close the exec-status handle on every read exit"
      assertDescriptorSpawnExecStatusHandleOwnership
  , testCase "rollback a completed spawn interrupted at its masked handoff"
      assertDescriptorSpawnAcquiredHandoffOwnership
  , testCase
      "execute the sealed bytes after replacing the path and source inode"
      assertDescriptorBoundSealedImage
  , testCase "reject a digest mismatch before the hook or child"
      assertDescriptorBoundDigestMismatch
  , testCase "reject open, symlink, nonregular, and nonexecutable sources"
      assertDescriptorBoundSourceFailures
  , testCase "enforce the staged source byte cap at exact and maximum plus one"
      assertDescriptorBoundExecutableByteCap
  , testCase "classify a staged-image exec failure and reap its child"
      assertDescriptorBoundExecFailure
  , testCase "cancel a blocked post-seal hook without allocating a child"
      assertDescriptorBoundHookCancellation
  , testCase "expire a blocked post-seal hook without allocating a child"
      assertDescriptorBoundHookDeadline
  ]
#else
  [ testCase "fail closed before demanding unsupported-platform inputs"
      assertDescriptorBoundUnsupported
  ]
#endif

effectiveIDDescriptorBoundProcessTests :: TestTree
effectiveIDDescriptorBoundProcessTests = testGroup
  "effective-ID executable-access descriptor-bound launch"
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
  [ testCase "publish exact support, strength, and process schema"
      assertEffectiveIDDescriptorBoundStrengths
  , testCase
      "check one borrowed source fd twice around the hook and run sealed bytes"
      assertEffectiveIDDescriptorBoundSealedImage
  , testCase
      "stop pin and source-shape failures before later authority observations"
      assertEffectiveIDDescriptorBoundPrecedence
  , testCase
      "map every closed access result before allocating a child"
      assertEffectiveIDDescriptorBoundAccessFailures
  , testCase "enforce the effective-ID source cap at exact and maximum plus one"
      assertEffectiveIDDescriptorBoundExecutableByteCap
  , testCase "map a checker exception to the closed failed class"
      assertEffectiveIDDescriptorBoundCheckerException
  , testCase
      "cancel a blocked final access observation without allocating a child"
      assertEffectiveIDDescriptorBoundFinalCheckCancellation
  , testCase "classify effective-ID sealed-image exec failure and cleanup"
      assertEffectiveIDDescriptorBoundExecFailure
  ]
#else
  [ testCase "fail closed before demanding unsupported-platform inputs"
      assertEffectiveIDDescriptorBoundUnsupported
  ]
#endif

execveCheckDescriptorBoundProcessTests :: TestTree
execveCheckDescriptorBoundProcessTests = testGroup
  "AT_EXECVE_CHECK descriptor-bound executable launch"
#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
  [ testCase "publish exact support, strength, and process schema"
      assertExecveCheckDescriptorBoundStrengths
  , testCase
      "route two source pairs and one staged check over borrowed descriptors"
      assertExecveCheckDescriptorBoundOrderedSuccess
  , testCase
      "stop each exec check result at its exact site without allocating a child"
      assertExecveCheckDescriptorBoundCheckFailures
  , testCase
      "preserve source-shape, access, pin, inspection, and hook precedence"
      assertExecveCheckDescriptorBoundPrecedence
  , testCase
      "cancel and expire the post-seal hook before final checks or child"
      assertExecveCheckDescriptorBoundHookControl
  , testCase "classify injected-image exec failure and reap its child"
      assertExecveCheckDescriptorBoundExecFailure
  , testCase
      "fail the native kernel path closed or run its complete mechanism"
      assertExecveCheckDescriptorBoundNativeOutcome
  ]
#else
  [ testCase "fail closed before demanding unsupported-platform inputs"
      assertExecveCheckDescriptorBoundUnsupported
  ]
#endif

#ifndef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
assertDescriptorBoundUnsupported :: IO ()
assertDescriptorBoundUnsupported = do
  Process.lengthSMTLibDescriptorBoundExecutableLaunchSupported @?= False
  opened <- Process.openLengthSMTLibDescriptorBoundProcess
    (error "unsupported launch demanded limits")
    (error "unsupported launch demanded cancellation")
    (error "unsupported launch demanded deadline")
    (error "unsupported launch demanded profile")
    (error "unsupported launch demanded workspace path")
    (error "unsupported launch demanded workspace descriptor")
  assertZ3DescriptorOpenFailure
    Process.LengthSMTLibProcessSpawnPhase
    Process.LengthSMTLibProcessDescriptorBoundLaunchUnavailable
    Nothing opened

assertEffectiveIDDescriptorBoundUnsupported :: IO ()
assertEffectiveIDDescriptorBoundUnsupported = do
  Process.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchSupported
    @?= False
  opened <-
    Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcess
      (error "unsupported effective-ID launch demanded limits")
      (error "unsupported effective-ID launch demanded cancellation")
      (error "unsupported effective-ID launch demanded deadline")
      (error "unsupported effective-ID launch demanded profile")
      (error "unsupported effective-ID launch demanded workspace path")
      (error "unsupported effective-ID launch demanded workspace descriptor")
  assertZ3DescriptorOpenFailure
    Process.LengthSMTLibProcessSnapshotPhase
    Process.LengthSMTLibProcessEffectiveIDExecutableAccessCheckUnavailable
    Nothing opened

assertExecveCheckDescriptorBoundUnsupported :: IO ()
assertExecveCheckDescriptorBoundUnsupported = do
  Process.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunchSupported
    @?= False
  opened <-
    Process.openLengthSMTLibDescriptorBoundExecveCheckExecutableAccessProcess
      (error "unsupported exec-check launch demanded limits")
      (error "unsupported exec-check launch demanded cancellation")
      (error "unsupported exec-check launch demanded deadline")
      (error "unsupported exec-check launch demanded profile")
      (error "unsupported exec-check launch demanded workspace path")
      (error "unsupported exec-check launch demanded workspace descriptor")
  assertZ3DescriptorOpenFailure
    Process.LengthSMTLibProcessSnapshotPhase
    Process.LengthSMTLibProcessSourceExecveCheckUnavailable
    Nothing opened
#endif

assertZ3DescriptorOpenFailure
  :: Process.LengthSMTLibProcessPhase
  -> Process.LengthSMTLibProcessFailureClass
  -> Maybe Process.LengthSMTLibProcessCleanupStatus
  -> Either Process.LengthSMTLibProcessError Process.LengthSMTLibProcess
  -> IO ()
assertZ3DescriptorOpenFailure phase failureClass cleanup opened = case opened of
  Left failure -> do
    Process.lengthSMTLibProcessErrorPhase failure @?= phase
    Process.lengthSMTLibProcessErrorClass failure @?= failureClass
    Process.lengthSMTLibProcessErrorObservedAtLeast failure @?= Nothing
    Process.lengthSMTLibProcessErrorCleanupStatus failure @?= cleanup
  Right process -> do
    _ <- Process.closeLengthSMTLibProcess process
    assertFailure $ "expected descriptor launch failure: " ++ show failureClass

#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
foreign import ccall unsafe "djex_z3_create_staged_executable"
  c_createPredecessorTestStagedExecutable :: IO CInt

foreign import ccall unsafe
  "djex_z3_seal_effective_id_access_staged_executable"
  c_sealPredecessorTestStagedExecutable :: CInt -> Int64 -> IO CInt

assertDescriptorBoundStrengths :: IO ()
assertDescriptorBoundStrengths = do
  Process.lengthSMTLibDescriptorBoundExecutableLaunchSupported @?= True
  Process.lengthSMTLibExecutableSnapshotStrengthTag @?=
    "path-snapshot-then-direct-spawn/stable-namespace-assumption/v1"
  Process.lengthSMTLibDescriptorBoundExecutableLaunchStrengthTag @?=
    "opened-source-hash-copy-sealed-memfd-execveat/main-image-bytes/v1"
  Process.lengthSMTLibProcessSchemaTag @?=
    "djex-length-z3-raw-process/v2"
  Process.lengthSMTLibDescriptorBoundProcessSchemaTag @?=
    "djex-length-z3-descriptor-bound-sealed-main-image-process/v1"

assertDescriptorSpawnExecStatusHandleOwnership :: IO ()
assertDescriptorSpawnExecStatusHandleOwnership = do
  withTemporaryStatusHandle $ \statusHandle -> do
    bytes <- Z3Process.readZ3SMTLibDescriptorSpawnExecStatusWith
      (\_ -> pure BS.empty) statusHandle
    bytes @?= BS.empty
    hIsClosed statusHandle >>= (@?= True)

  withTemporaryStatusHandle $ \statusHandle -> do
    attempted <- tryIOError $
      Z3Process.readZ3SMTLibDescriptorSpawnExecStatusWith
        (\_ -> ioError $ userError "synthetic exec-status read failure")
        statusHandle
    case attempted of
      Left _ -> pure ()
      Right () -> assertFailure "exec-status read failure was not propagated"
    hIsClosed statusHandle >>= (@?= True)

  withTemporaryStatusHandle $ \statusHandle -> do
    entered <- newEmptyMVar
    release <- newEmptyMVar
    outcome <- newEmptyMVar
    worker <- forkIO $ do
      attempted <- try
        (Z3Process.readZ3SMTLibDescriptorSpawnExecStatusWith
          (\_ -> putMVar entered () >> takeMVar release)
          statusHandle)
        :: IO (Either LiveAsynchronousCallbackException ByteString)
      putMVar outcome attempted
    _ <- expectWithin "exec-status read entrance" 3000000 $ takeMVar entered
    throwTo worker LiveAsynchronousCallbackException
    attempted <- expectWithin "interrupted exec-status read" 3000000
      $ takeMVar outcome
    case attempted of
      Left failure -> failure @?= LiveAsynchronousCallbackException
      Right _ -> assertFailure "interrupted exec-status read returned"
    hIsClosed statusHandle >>= (@?= True)

assertDescriptorSpawnAcquiredHandoffOwnership :: IO ()
assertDescriptorSpawnAcquiredHandoffOwnership = do
  temporaryRoot <- getTemporaryDirectory
  cancellation <- Z3Process.newZ3SMTLibProcessCancellation
  deadline <- expectRight =<<
    Z3Process.z3SMTLibProcessDeadlineAfterMilliseconds 3000
  observedMask <- newEmptyMVar
  acquiredPair <- newEmptyMVar
  entered <- newEmptyMVar
  release <- newEmptyMVar
  outcome <- newEmptyMVar
  consumerEntered <- newIORef False
  let cleanup (path, handle) = do
        ignoreIOError $ hClose handle
        ignoreIOError $ removeFile path
      acquire = do
        state <- getMaskingState
        putMVar observedMask state
        pair <- openTempFile temporaryRoot "djex-z3-acquired"
        putMVar acquiredPair pair
        pure pair
  worker <- forkIO $ do
    attempted <- try
      (Z3Process.handoffZ3SMTLibProcessAcquiredWith
        (Z3Process.runBeforeZ3SMTLibProcessDeadlineMaskedAction
          cancellation deadline acquire cleanup)
        cleanup
        (putMVar entered () >> takeMVar release)
        (\_ _ -> writeIORef consumerEntered True >> pure (Right ())))
      :: IO
          (Either
            LiveAsynchronousCallbackException
            (Either Z3Process.Z3SMTLibProcessError ()))
    putMVar outcome attempted
  pair@(path, acquiredHandle) <-
    expectWithin "descriptor worker acquisition" 3000000 $ takeMVar acquiredPair
  flip finally (cleanup pair) $ do
    maskingState <- expectWithin "descriptor worker masking state" 3000000
      $ takeMVar observedMask
    maskingState @?= MaskedInterruptible
    _ <- expectWithin "descriptor acquired-handoff entrance" 3000000
      $ takeMVar entered
    throwTo worker LiveAsynchronousCallbackException
    attempted <- expectWithin "interrupted descriptor acquired handoff" 3000000
      $ takeMVar outcome
    case attempted of
      Left failure -> failure @?= LiveAsynchronousCallbackException
      Right _ -> assertFailure "interrupted acquired handoff returned"
    hIsClosed acquiredHandle >>= (@?= True)
    doesPathExist path >>= (@?= False)
    readIORef consumerEntered >>= (@?= False)

withTemporaryStatusHandle :: (Handle -> IO result) -> IO result
withTemporaryStatusHandle use = do
  temporaryRoot <- getTemporaryDirectory
  bracket
    (openTempFile temporaryRoot "djex-z3-exec-status")
    (\(path, handle) -> do
      ignoreIOError $ hClose handle
      ignoreIOError $ removeFile path)
    (use . snd)

assertEffectiveIDDescriptorBoundStrengths :: IO ()
assertEffectiveIDDescriptorBoundStrengths = do
  Process.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchSupported
    @?= True
  Process.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchStrengthTag
    @?= BSC.pack (concat
      [ "opened-source-two-point-faccessat2-x-ok-at-empty-path-at-eaccess-"
      , "hash-copy-sealed-memfd-execveat/point-in-time-effective-id-source-"
      , "vfs-executable-access-and-main-image-bytes/v1"
      ])
  Process.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessSchemaTag
    @?= BSC.pack (concat
      [ "djex-length-z3-descriptor-bound-effective-id-executable-access-"
      , "sealed-main-image-process/v1"
      ])

assertExecveCheckDescriptorBoundStrengths :: IO ()
assertExecveCheckDescriptorBoundStrengths = do
  Process.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunchSupported
    @?= True
  Process.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunchStrengthTag
    @?= BSC.pack (concat
      [ "opened-source-two-point-faccessat2-x-ok-at-empty-path-at-eaccess-plus-"
      , "execveat-at-empty-path-at-execve-check-hash-copy-mfd-exec-fixed-0500-"
      , "f-seal-exec-sealed-memfd-staged-execve-check-then-execveat/"
      , "point-in-time-source-and-staged-kernel-executable-access-and-main-"
      , "image-bytes/v1"
      ])
  Process.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessProcessSchemaTag
    @?= BSC.pack (concat
      [ "djex-length-z3-descriptor-bound-execve-check-executable-access-"
      , "sealed-main-image-process/v1"
      ])

assertDescriptorBoundSealedImage :: IO ()
assertDescriptorBoundSealedImage = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    let retired = executable ++ ".retired-source"
        sentinelPath = executable ++ ".unrelated-parent-descriptor"
        invalidImage = "descriptor-bound-path-fallback-must-fail"
    BS.writeFile sentinelPath "unrelated-parent-authority"
    bracket
      (openReadOnlyDescriptor sentinelPath)
      closeFd
      $ \sentinelDescriptor -> do
          setFdOption sentinelDescriptor CloseOnExec False
          profile <- descriptorBoundProfile executable Nothing
          limits <- descriptorBoundLimits
          cancellation <- Process.newLengthSMTLibProcessCancellation
          deadline <- expectRight =<<
            Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
          opened <- Process.openLengthSMTLibProcessWithPreDescriptorExecHook
            limits cancellation deadline profile workingDirectory
            workingDescriptor $ do
              renameFile executable retired
              -- Retire the exact opened source inode as well as replacing its
              -- configured pathname.  Only the already sealed copy remains a
              -- healthy executable after this point.
              BS.writeFile retired invalidImage
              BS.writeFile executable invalidImage
          process <- expectRight opened
          Process.lengthSMTLibProcessUsesDescriptorBoundExecutableLaunch process
            @?= True
          Process.lengthSMTLibExecutableSnapshotSHA256
              (Process.lengthSMTLibProcessSnapshot process) @?=
            SHA256.hash image
          Process.lengthSMTLibExecutableSnapshotByteCount
              (Process.lengthSMTLibProcessSnapshot process) @?=
            byteStringLength image
          current <- BS.readFile executable
          retiredBytes <- BS.readFile retired
          current @?= invalidImage
          retiredBytes @?= invalidImage
          events <- readFakeZ3EventsAfterStart executable
          start <- expectFakeZ3Event "start" events
          assertSingleFakeField "mode" "healthy" start
          assertSingleFakeField "executable-basename"
            (utf8Bytes $ takeFileName executable) start
          assertBool "descriptor launcher leaked an unrelated parent fd"
            $ utf8Bytes sentinelPath `notElem`
                fakeZ3FieldValues "open-descriptor-target" start
          cleanup <- Process.closeLengthSMTLibProcess process
          assertCompleteZ3Cleanup "sealed-image success" cleanup

assertDescriptorBoundDigestMismatch :: IO ()
assertDescriptorBoundDigestMismatch = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    hookReached <- newIORef False
    profile <- descriptorBoundProfile executable
      $ Just $ alterDigest $ SHA256.hash image
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    opened <- Process.openLengthSMTLibProcessWithPreDescriptorExecHook
      limits cancellation deadline profile workingDirectory workingDescriptor
      $ writeIORef hookReached True
    assertZ3DescriptorOpenFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessExecutableDigestMismatch
      Nothing opened
    readIORef hookReached >>= (@?= False)
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "digest mismatch allocated the fake child" $ not spawned

assertDescriptorBoundSourceFailures :: IO ()
assertDescriptorBoundSourceFailures =
  withFreshTestDirectory $ \sourceRoot ->
  withDescriptorWorkingDirectory $ \workingDirectory workingDescriptor -> do
    let missing = sourceRoot </> "missing-z3"
        directory = sourceRoot </> "directory-z3"
        nonExecutable = sourceRoot </> "nonexecutable-z3"
        link = sourceRoot </> "symlink-z3"
    createDirectory directory
    BS.writeFile nonExecutable "not executable"
    createFileLink nonExecutable link
    forM_
      [ ( "missing source"
        , missing
        , Process.LengthSMTLibProcessExecutableUnavailable
        )
      , ( "final symlink"
        , link
        , Process.LengthSMTLibProcessExecutableUnavailable
        )
      , ( "nonregular source"
        , directory
        , Process.LengthSMTLibProcessExecutableNotRegular
        )
      , ( "nonexecutable source"
        , nonExecutable
        , Process.LengthSMTLibProcessExecutableNotExecutable
        )
      ] $ \(label, executable, expectedClass) -> do
          hookReached <- newIORef False
          profile <- descriptorBoundProfile executable Nothing
          limits <- descriptorBoundLimits
          cancellation <- Process.newLengthSMTLibProcessCancellation
          deadline <- expectRight =<<
            Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
          opened <- Process.openLengthSMTLibProcessWithPreDescriptorExecHook
            limits cancellation deadline profile workingDirectory
            workingDescriptor $ writeIORef hookReached True
          assertZ3DescriptorOpenFailure
            Process.LengthSMTLibProcessSnapshotPhase expectedClass Nothing opened
          reached <- readIORef hookReached
          assertBool (label ++ " reached the post-seal hook") $ not reached

assertDescriptorBoundExecutableByteCap :: IO ()
assertDescriptorBoundExecutableByteCap = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    let imageBytes = byteStringLength image
        withMaximum maximumBytes source = source
          { Process.lengthSMTLibProcessLimitSourceExecutableBytes =
              maximumBytes }
    assertBool "fake executable unexpectedly had at most one byte"
      $ imageBytes > 1
    profile <- descriptorBoundProfile executable Nothing
    exactLimits <- expectRight $ Process.mkLengthSMTLibProcessLimits
      $ withMaximum imageBytes Process.defaultLengthSMTLibProcessLimitSource
    exactCancellation <- Process.newLengthSMTLibProcessCancellation
    exactDeadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    exact <- Process.openLengthSMTLibDescriptorBoundProcess exactLimits
      exactCancellation exactDeadline profile workingDirectory workingDescriptor
    exactProcess <- expectRight exact
    Process.lengthSMTLibExecutableSnapshotByteCount
        (Process.lengthSMTLibProcessSnapshot exactProcess) @?= imageBytes
    exactCleanup <- Process.closeLengthSMTLibProcess exactProcess
    assertCompleteZ3Cleanup "descriptor exact executable cap" exactCleanup

    overflowLimits <- expectRight $ Process.mkLengthSMTLibProcessLimits
      $ withMaximum (imageBytes - 1)
          Process.defaultLengthSMTLibProcessLimitSource
    overflowCancellation <- Process.newLengthSMTLibProcessCancellation
    overflowDeadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    hookReached <- newIORef False
    overflow <- Process.openLengthSMTLibProcessWithPreDescriptorExecHook
      overflowLimits overflowCancellation overflowDeadline profile
      workingDirectory workingDescriptor $ writeIORef hookReached True
    case overflow of
      Left failure -> do
        Process.lengthSMTLibProcessErrorPhase failure @?=
          Process.LengthSMTLibProcessSnapshotPhase
        Process.lengthSMTLibProcessErrorClass failure @?=
          Process.LengthSMTLibProcessExecutableByteLimitExceeded
        Process.lengthSMTLibProcessErrorObservedAtLeast failure @?=
          Just imageBytes
        Process.lengthSMTLibProcessErrorCleanupStatus failure @?= Nothing
      Right process -> do
        _ <- Process.closeLengthSMTLibProcess process
        assertFailure "descriptor maximum-plus-one source unexpectedly opened"
    readIORef hookReached >>= (@?= False)

assertDescriptorBoundExecFailure :: IO ()
assertDescriptorBoundExecFailure =
  withFreshTestDirectory $ \sourceRoot ->
  withDescriptorWorkingDirectory $ \workingDirectory workingDescriptor -> do
    let executable = sourceRoot </> "executable-garbage"
    BS.writeFile executable "not-an-elf-or-script"
    permissions <- getPermissions executable
    setPermissions executable $ setOwnerExecutable True permissions
    hookReached <- newIORef False
    profile <- descriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    opened <- Process.openLengthSMTLibProcessWithPreDescriptorExecHook
      limits cancellation deadline profile workingDirectory workingDescriptor
      $ writeIORef hookReached True
    cleanup <- case opened of
      Left failure -> do
        Process.lengthSMTLibProcessErrorPhase failure @?=
          Process.LengthSMTLibProcessSpawnPhase
        Process.lengthSMTLibProcessErrorClass failure @?=
          Process.LengthSMTLibProcessDescriptorBoundExecFailed
        Process.lengthSMTLibProcessErrorObservedAtLeast failure @?= Nothing
        maybe
          (assertFailure "descriptor exec failure omitted child cleanup")
          pure
          $ Process.lengthSMTLibProcessErrorCleanupStatus failure
      Right process -> do
        _ <- Process.closeLengthSMTLibProcess process
        assertFailure "invalid sealed image unexpectedly executed"
    readIORef hookReached >>= (@?= True)
    assertCompleteZ3Cleanup "descriptor exec failure" cleanup

assertDescriptorBoundHookCancellation :: IO ()
assertDescriptorBoundHookCancellation = withFakeZ3Mode "healthy"
  $ \executable _ -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    profile <- descriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    hookEntered <- newEmptyMVar
    hookRelease <- newEmptyMVar
    outcome <- newEmptyMVar
    _ <- forkIO $ do
      result <- Process.openLengthSMTLibProcessWithPreDescriptorExecHook
        limits cancellation deadline profile workingDirectory workingDescriptor
        $ putMVar hookEntered () >> takeMVar hookRelease
      putMVar outcome result
    _ <- expectWithin "cancelled descriptor hook entrance" 3000000
      $ takeMVar hookEntered
    Process.cancelLengthSMTLibProcess cancellation
    opened <- expectWithin "cancelled descriptor hook" 3000000
      $ takeMVar outcome
    putMVar hookRelease ()
    assertZ3DescriptorOpenFailure
      Process.LengthSMTLibProcessDeadlinePhase
      Process.LengthSMTLibProcessCancelled Nothing opened
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "cancelled post-seal hook allocated a child" $ not spawned

assertDescriptorBoundHookDeadline :: IO ()
assertDescriptorBoundHookDeadline = withFakeZ3Mode "healthy"
  $ \executable _ -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    profile <- descriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 300
    hookEntered <- newEmptyMVar
    hookRelease <- newEmptyMVar
    outcome <- newEmptyMVar
    _ <- forkIO $ do
      result <- Process.openLengthSMTLibProcessWithPreDescriptorExecHook
        limits cancellation deadline profile workingDirectory workingDescriptor
        $ putMVar hookEntered () >> takeMVar hookRelease
      putMVar outcome result
    _ <- expectWithin "expiring descriptor hook entrance" 3000000
      $ takeMVar hookEntered
    opened <- expectWithin "expired descriptor hook" 3000000
      $ takeMVar outcome
    putMVar hookRelease ()
    assertZ3DescriptorOpenFailure
      Process.LengthSMTLibProcessDeadlinePhase
      Process.LengthSMTLibProcessDeadlineExceeded Nothing opened
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "expired post-seal hook allocated a child" $ not spawned

assertEffectiveIDDescriptorBoundSealedImage :: IO ()
assertEffectiveIDDescriptorBoundSealedImage = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    let retired = executable ++ ".effective-id-retired-source"
        sentinelPath = executable ++ ".effective-id-unrelated-parent-fd"
        invalidImage = "effective-id-path-fallback-must-fail"
    BS.writeFile sentinelPath "unrelated-parent-authority"
    bracket
      (openReadOnlyDescriptor sentinelPath)
      closeFd
      $ \sentinelDescriptor -> do
          setFdOption sentinelDescriptor CloseOnExec False
          profile <- descriptorBoundProfile executable Nothing
          limits <- descriptorBoundLimits
          cancellation <- Process.newLengthSMTLibProcessCancellation
          deadline <- expectRight =<<
            Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
          results <- newIORef
            [ Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
            , Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
            ]
          observations <- newIORef []
          order <- newIORef ([] :: [String])
          let checker descriptor = do
                modifyIORef' order (++ ["access"])
                nextEffectiveIDAccessResult results observations descriptor
              hook = do
                modifyIORef' order (++ ["hook"])
                renameFile executable retired
                BS.writeFile retired invalidImage
                BS.writeFile executable invalidImage
          opened <-
            Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessWithHooks
              limits cancellation deadline profile workingDirectory
              workingDescriptor checker hook
          process <- expectRight opened
          Process.lengthSMTLibProcessUsesDescriptorBoundExecutableLaunch process
            @?= False
          Process.lengthSMTLibProcessUsesDescriptorBoundEffectiveIDExecutableAccessLaunch
              process @?= True
          readIORef order >>= (@?= ["access", "hook", "access"])
          borrowed <- readIORef observations
          case borrowed of
            [first, second] -> first @?= second
            _ -> assertFailure $ "expected two borrowed descriptor checks: " ++
              show borrowed
          Process.lengthSMTLibExecutableSnapshotSHA256
              (Process.lengthSMTLibProcessSnapshot process) @?=
            SHA256.hash image
          Process.lengthSMTLibExecutableSnapshotByteCount
              (Process.lengthSMTLibProcessSnapshot process) @?=
            byteStringLength image
          let identity = Process.lengthSMTLibProcessFingerprintField process
          case identity of
            Fingerprint.FingerprintTag root
                (Fingerprint.FingerprintBytes schema : _) -> do
              root @?= ascii (concat
                [ "length-z3-descriptor-bound-effective-id-executable-"
                , "access-launched-transport"
                ])
              schema @?= BS.unpack
                Process.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessSchemaTag
            _ -> assertFailure
              "effective-ID process identity lost its nominal Length envelope"
          countExactFingerprintBytes
              (ascii
                "fixed-owner-read-execute-mode-0500-not-source-metadata-authority")
              identity @?= 1
          countExactFingerprintBytes
              (ascii "no-pathname-or-launch-strategy-retry") identity @?= 1
          events <- readFakeZ3EventsAfterStart executable
          start <- expectFakeZ3Event "start" events
          assertSingleFakeField "mode" "healthy" start
          assertBool "effective-ID launcher leaked an unrelated parent fd"
            $ utf8Bytes sentinelPath `notElem`
                fakeZ3FieldValues "open-descriptor-target" start
          cleanup <- Process.closeLengthSMTLibProcess process
          assertCompleteZ3Cleanup "effective-ID sealed-image success" cleanup

assertEffectiveIDDescriptorBoundPrecedence :: IO ()
assertEffectiveIDDescriptorBoundPrecedence = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    profile <- descriptorBoundProfile executable
      $ Just $ alterDigest $ SHA256.hash image
    results <- newIORef
      [ Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
      , Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
      ]
    observations <- newIORef []
    hookReached <- newIORef False
    mismatch <-
      Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessWithHooks
        limits cancellation deadline profile workingDirectory workingDescriptor
        (nextEffectiveIDAccessResult results observations)
        (writeIORef hookReached True)
    assertZ3DescriptorOpenFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessExecutableDigestMismatch Nothing mismatch
    length <$> readIORef observations >>= (@?= 1)
    readIORef hookReached >>= (@?= False)
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "effective-ID digest mismatch allocated a child" $ not spawned

    withFreshTestDirectory $ \sourceRoot -> do
      let missing = sourceRoot </> "missing-z3"
          directory = sourceRoot </> "directory-z3"
          nonExecutable = sourceRoot </> "nonexecutable-z3"
          link = sourceRoot </> "symlink-z3"
      createDirectory directory
      BS.writeFile nonExecutable "not executable"
      createFileLink nonExecutable link
      forM_
        [ (missing, Process.LengthSMTLibProcessExecutableUnavailable)
        , (link, Process.LengthSMTLibProcessExecutableUnavailable)
        , (directory, Process.LengthSMTLibProcessExecutableNotRegular)
        , (nonExecutable, Process.LengthSMTLibProcessExecutableNotExecutable)
        ] $ \(source, expectedClass) -> do
          sourceProfile <- descriptorBoundProfile source Nothing
          sourceResults <- newIORef
            [Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted]
          sourceObservations <- newIORef []
          sourceHook <- newIORef False
          sourceCancellation <- Process.newLengthSMTLibProcessCancellation
          sourceDeadline <- expectRight =<<
            Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
          opened <-
            Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessWithHooks
              limits sourceCancellation sourceDeadline sourceProfile
              workingDirectory workingDescriptor
              (nextEffectiveIDAccessResult
                sourceResults sourceObservations)
              (writeIORef sourceHook True)
          assertZ3DescriptorOpenFailure
            Process.LengthSMTLibProcessSnapshotPhase expectedClass Nothing opened
          readIORef sourceObservations >>= (@?= [])
          readIORef sourceHook >>= (@?= False)

assertEffectiveIDDescriptorBoundAccessFailures :: IO ()
assertEffectiveIDDescriptorBoundAccessFailures = withFakeZ3Mode "healthy"
  $ \executable _ -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    profile <- descriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    forM_ accessCases $ \(label, resultsToReturn, expectedClass,
        expectedHook, expectedCalls) -> do
      results <- newIORef resultsToReturn
      observations <- newIORef []
      hookReached <- newIORef False
      cancellation <- Process.newLengthSMTLibProcessCancellation
      deadline <- expectRight =<<
        Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
      opened <-
        Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessWithHooks
          limits cancellation deadline profile workingDirectory
          workingDescriptor
          (nextEffectiveIDAccessResult results observations)
          (writeIORef hookReached True)
      assertZ3DescriptorOpenFailure
        Process.LengthSMTLibProcessSnapshotPhase expectedClass Nothing opened
      readIORef hookReached >>= (@?= expectedHook)
      borrowed <- readIORef observations
      length borrowed @?= expectedCalls
      case borrowed of
        [first, second] -> first @?= second
        _ -> pure ()
      spawned <- doesPathExist $ fakeZ3EventPath executable
      assertBool (label ++ " allocated the fake child") $ not spawned
 where
  admitted = Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
  denied = Process.LengthSMTLibEffectiveIDExecutableAccessDenied
  unavailable =
    Process.LengthSMTLibEffectiveIDExecutableAccessCheckUnavailable
  failed = Process.LengthSMTLibEffectiveIDExecutableAccessCheckFailed
  accessCases =
    [ ( "initial denial"
      , [denied]
      , Process.LengthSMTLibProcessEffectiveIDExecutableAccessDenied
      , False
      , 1
      )
    , ( "initial unavailable check"
      , [unavailable]
      , Process.LengthSMTLibProcessEffectiveIDExecutableAccessCheckUnavailable
      , False
      , 1
      )
    , ( "initial failed check"
      , [failed]
      , Process.LengthSMTLibProcessEffectiveIDExecutableAccessCheckFailed
      , False
      , 1
      )
    , ( "final denial"
      , [admitted, denied]
      , Process.LengthSMTLibProcessEffectiveIDExecutableAccessDenied
      , True
      , 2
      )
    , ( "final unavailable check"
      , [admitted, unavailable]
      , Process.LengthSMTLibProcessEffectiveIDExecutableAccessCheckUnavailable
      , True
      , 2
      )
    , ( "final failed check"
      , [admitted, failed]
      , Process.LengthSMTLibProcessEffectiveIDExecutableAccessCheckFailed
      , True
      , 2
      )
    ]

assertEffectiveIDDescriptorBoundExecutableByteCap :: IO ()
assertEffectiveIDDescriptorBoundExecutableByteCap = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    let imageBytes = byteStringLength image
        withMaximum maximumBytes source = source
          { Process.lengthSMTLibProcessLimitSourceExecutableBytes =
              maximumBytes }
    assertBool "fake executable unexpectedly had at most one byte"
      $ imageBytes > 1
    profile <- descriptorBoundProfile executable Nothing
    exactLimits <- expectRight $ Process.mkLengthSMTLibProcessLimits
      $ withMaximum imageBytes Process.defaultLengthSMTLibProcessLimitSource
    exactCancellation <- Process.newLengthSMTLibProcessCancellation
    exactDeadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    exact <-
      Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcess
        exactLimits exactCancellation exactDeadline profile workingDirectory
        workingDescriptor
    exactProcess <- expectRight exact
    Process.lengthSMTLibExecutableSnapshotByteCount
        (Process.lengthSMTLibProcessSnapshot exactProcess) @?= imageBytes
    exactCleanup <- Process.closeLengthSMTLibProcess exactProcess
    assertCompleteZ3Cleanup "effective-ID exact executable cap" exactCleanup

    overflowLimits <- expectRight $ Process.mkLengthSMTLibProcessLimits
      $ withMaximum (imageBytes - 1)
          Process.defaultLengthSMTLibProcessLimitSource
    overflowCancellation <- Process.newLengthSMTLibProcessCancellation
    overflowDeadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    results <- newIORef
      [ Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
      , Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
      ]
    observations <- newIORef []
    hookReached <- newIORef False
    overflow <-
      Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessWithHooks
        overflowLimits overflowCancellation overflowDeadline profile
        workingDirectory workingDescriptor
        (nextEffectiveIDAccessResult results observations)
        (writeIORef hookReached True)
    case overflow of
      Left failure -> do
        Process.lengthSMTLibProcessErrorPhase failure @?=
          Process.LengthSMTLibProcessSnapshotPhase
        Process.lengthSMTLibProcessErrorClass failure @?=
          Process.LengthSMTLibProcessExecutableByteLimitExceeded
        Process.lengthSMTLibProcessErrorObservedAtLeast failure @?=
          Just imageBytes
        Process.lengthSMTLibProcessErrorCleanupStatus failure @?= Nothing
      Right process -> do
        _ <- Process.closeLengthSMTLibProcess process
        assertFailure
          "effective-ID maximum-plus-one source unexpectedly opened"
    length <$> readIORef observations >>= (@?= 1)
    readIORef hookReached >>= (@?= False)

assertEffectiveIDDescriptorBoundCheckerException :: IO ()
assertEffectiveIDDescriptorBoundCheckerException = withFakeZ3Mode "healthy"
  $ \executable _ -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    profile <- descriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    hookReached <- newIORef False
    opened <-
      Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessWithHooks
        limits cancellation deadline profile workingDirectory
        workingDescriptor
        (const $ throwIO LiveSynchronousCallbackException)
        (writeIORef hookReached True)
    assertZ3DescriptorOpenFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessEffectiveIDExecutableAccessCheckFailed
      Nothing opened
    readIORef hookReached >>= (@?= False)
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "throwing effective-ID checker allocated a child" $ not spawned

assertEffectiveIDDescriptorBoundFinalCheckCancellation :: IO ()
assertEffectiveIDDescriptorBoundFinalCheckCancellation =
  withFakeZ3Mode "healthy" $ \executable _ ->
  withDescriptorWorkingDirectory $ \workingDirectory workingDescriptor -> do
    profile <- descriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    callCount <- newIORef (0 :: Int)
    finalEntered <- newEmptyMVar
    finalRelease <- newEmptyMVar
    hookReached <- newIORef False
    outcome <- newEmptyMVar
    let checker _ = do
          modifyIORef' callCount (+ 1)
          observed <- readIORef callCount
          if observed == 1
            then pure Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
            else putMVar finalEntered () >> takeMVar finalRelease >>
              pure Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
    _ <- forkIO $ do
      opened <-
        Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessWithHooks
          limits cancellation deadline profile workingDirectory
          workingDescriptor checker (writeIORef hookReached True)
      putMVar outcome opened
    _ <- expectWithin "effective-ID final check entrance" 3000000
      $ takeMVar finalEntered
    Process.cancelLengthSMTLibProcess cancellation
    opened <- expectWithin "effective-ID final check cancellation" 3000000
      $ takeMVar outcome
    putMVar finalRelease ()
    assertZ3DescriptorOpenFailure
      Process.LengthSMTLibProcessDeadlinePhase
      Process.LengthSMTLibProcessCancelled Nothing opened
    readIORef hookReached >>= (@?= True)
    readIORef callCount >>= (@?= 2)
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "cancelled effective-ID final check allocated a child"
      $ not spawned

assertEffectiveIDDescriptorBoundExecFailure :: IO ()
assertEffectiveIDDescriptorBoundExecFailure =
  withFreshTestDirectory $ \sourceRoot ->
  withDescriptorWorkingDirectory $ \workingDirectory workingDescriptor -> do
    let executable = sourceRoot </> "effective-id-executable-garbage"
    BS.writeFile executable "not-an-elf-or-script"
    permissions <- getPermissions executable
    setPermissions executable $ setOwnerExecutable True permissions
    profile <- descriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    results <- newIORef
      [ Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
      , Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
      ]
    observations <- newIORef []
    hookReached <- newIORef False
    opened <-
      Process.openLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessProcessWithHooks
        limits cancellation deadline profile workingDirectory workingDescriptor
        (nextEffectiveIDAccessResult results observations)
        (writeIORef hookReached True)
    cleanup <- case opened of
      Left failure -> do
        Process.lengthSMTLibProcessErrorPhase failure @?=
          Process.LengthSMTLibProcessSpawnPhase
        Process.lengthSMTLibProcessErrorClass failure @?=
          Process.LengthSMTLibProcessDescriptorBoundExecFailed
        Process.lengthSMTLibProcessErrorObservedAtLeast failure @?= Nothing
        maybe
          (assertFailure "effective-ID exec failure omitted child cleanup")
          pure
          $ Process.lengthSMTLibProcessErrorCleanupStatus failure
      Right process -> do
        _ <- Process.closeLengthSMTLibProcess process
        assertFailure "invalid effective-ID sealed image unexpectedly executed"
    readIORef hookReached >>= (@?= True)
    length <$> readIORef observations >>= (@?= 2)
    assertCompleteZ3Cleanup "effective-ID exec failure" cleanup

assertExecveCheckDescriptorBoundOrderedSuccess :: IO ()
assertExecveCheckDescriptorBoundOrderedSuccess = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    let retired = executable ++ ".execve-check-retired-source"
        sentinelPath = executable ++ ".execve-check-unrelated-parent-fd"
        invalidImage = "execve-check-path-fallback-must-fail"
    BS.writeFile sentinelPath "unrelated-parent-authority"
    bracket
      (openReadOnlyDescriptor sentinelPath)
      closeFd
      $ \sentinelDescriptor -> do
          setFdOption sentinelDescriptor CloseOnExec False
          profile <- execveCheckDescriptorBoundProfile executable Nothing
          limits <- descriptorBoundLimits
          cancellation <- Process.newLengthSMTLibProcessCancellation
          deadline <- expectRight =<<
            Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
          accessResults <- newIORef
            [ Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
            , Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
            ]
          execveResults <- newIORef
            [ Process.LengthSMTLibExecveCheckAdmitted
            , Process.LengthSMTLibExecveCheckAdmitted
            , Process.LengthSMTLibExecveCheckAdmitted
            ]
          accessDescriptors <- newIORef []
          execveDescriptors <- newIORef []
          inspections <- newIORef []
          order <- newIORef ([] :: [String])
          let accessCheck descriptor = do
                modifyIORef' order (++ ["source-faccess"])
                nextEffectiveIDAccessResult
                  accessResults accessDescriptors descriptor
              execveCheck descriptor = do
                modifyIORef' order (++ ["execve-check"])
                nextExecveCheckResult
                  execveResults execveDescriptors descriptor
              creator = modifyIORef' order (++ ["create"]) >>
                c_createPredecessorTestStagedExecutable
              sealer descriptor count = do
                modifyIORef' order (++ ["seal"])
                c_sealPredecessorTestStagedExecutable descriptor count
              inspect descriptor = do
                modifyIORef' order (++ ["inspect"])
                observed <- Process.inspectLengthSMTLibExecveCheckStagedImage
                  descriptor
                modifyIORef' inspections (++ [observed])
              hook = do
                modifyIORef' order (++ ["hook"])
                renameFile executable retired
                BS.writeFile retired invalidImage
                BS.writeFile executable invalidImage
          opened <- openExecveCheckWithInjectedStage
            limits cancellation deadline profile workingDirectory
            workingDescriptor accessCheck execveCheck creator sealer inspect hook
          process <- expectRight opened
          Process.lengthSMTLibProcessUsesDescriptorBoundExecutableLaunch process
            @?= False
          Process.lengthSMTLibProcessUsesDescriptorBoundEffectiveIDExecutableAccessLaunch
              process @?= False
          Process.lengthSMTLibProcessUsesDescriptorBoundExecveCheckExecutableAccessLaunch
              process @?= True
          readIORef order >>= (@?=
            [ "source-faccess", "execve-check", "create", "seal"
            , "inspect", "hook", "source-faccess", "execve-check"
            , "execve-check"
            ])
          accessObserved <- readIORef accessDescriptors
          execveObserved <- readIORef execveDescriptors
          case (accessObserved, execveObserved) of
            ([accessFirst, accessSecond],
                [execveFirst, execveSecond, staged]) -> do
              accessFirst @?= accessSecond
              accessFirst @?= execveFirst
              accessFirst @?= execveSecond
              assertBool "staged exec check reused the source descriptor"
                $ staged /= accessFirst
            _ -> assertFailure $ "unexpected borrowed descriptor trace: " ++
              show (accessObserved, execveObserved)
          readIORef inspections >>= (@?= [Just
            Process.LengthSMTLibExecveCheckStagedImageInspection
              { Process.lengthSMTLibExecveCheckStagedImageRequestedCreationFlags =
                  0x13
              , Process.lengthSMTLibExecveCheckStagedImageRegularFile = True
              , Process.lengthSMTLibExecveCheckStagedImageMode = 0o500
              , Process.lengthSMTLibExecveCheckStagedImageByteCount =
                  fromIntegral $ BS.length image
              , Process.lengthSMTLibExecveCheckStagedImageSeals = 0x0f
              }])
          Process.lengthSMTLibExecutableSnapshotSHA256
              (Process.lengthSMTLibProcessSnapshot process) @?=
            SHA256.hash image
          Process.lengthSMTLibExecutableSnapshotByteCount
              (Process.lengthSMTLibProcessSnapshot process) @?=
            byteStringLength image
          let identity = Process.lengthSMTLibProcessFingerprintField process
          case identity of
            Fingerprint.FingerprintTag root
                (Fingerprint.FingerprintBytes schema : _) -> do
              root @?= ascii (concat
                [ "length-z3-descriptor-bound-execve-check-executable-"
                , "access-launched-transport"
                ])
              schema @?= BS.unpack
                Process.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessProcessSchemaTag
            _ -> assertFailure
              "exec-check process identity lost its nominal Length envelope"
          countExactFingerprintBytes
              (ascii
                "linux-memfd-create-close-on-exec-allow-sealing-mfd-exec")
              identity @?= 1
          countExactFingerprintBytes
              (ascii "seal-write-grow-shrink-future-write-exec-seal-verified")
              identity @?= 1
          events <- readFakeZ3EventsAfterStart executable
          start <- expectFakeZ3Event "start" events
          assertSingleFakeField "mode" "healthy" start
          assertBool "exec-check launcher leaked an unrelated parent fd"
            $ utf8Bytes sentinelPath `notElem`
                fakeZ3FieldValues "open-descriptor-target" start
          cleanup <- Process.closeLengthSMTLibProcess process
          assertCompleteZ3Cleanup "exec-check injected-stage success" cleanup

assertExecveCheckDescriptorBoundCheckFailures :: IO ()
assertExecveCheckDescriptorBoundCheckFailures = withFakeZ3Mode "healthy"
  $ \executable _ -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    profile <- execveCheckDescriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    forM_ cases $ \(label, resultsToReturn, expectedClass,
        expectedAccessCalls, expectedHook, expectedInspection) -> do
      accessResults <- newIORef $ replicate expectedAccessCalls
        Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
      execveResults <- newIORef resultsToReturn
      accessDescriptors <- newIORef []
      execveDescriptors <- newIORef []
      hookReached <- newIORef False
      inspectionReached <- newIORef False
      cancellation <- Process.newLengthSMTLibProcessCancellation
      deadline <- expectRight =<<
        Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
      opened <- openExecveCheckWithInjectedStage
        limits cancellation deadline profile workingDirectory
        workingDescriptor
        (nextEffectiveIDAccessResult accessResults accessDescriptors)
        (nextExecveCheckResult execveResults execveDescriptors)
        c_createPredecessorTestStagedExecutable
        c_sealPredecessorTestStagedExecutable
        (const $ writeIORef inspectionReached True)
        (writeIORef hookReached True)
      assertZ3DescriptorOpenFailure
        Process.LengthSMTLibProcessSnapshotPhase expectedClass Nothing opened
      length <$> readIORef accessDescriptors >>= (@?= expectedAccessCalls)
      length <$> readIORef execveDescriptors >>= (@?= length resultsToReturn)
      readIORef hookReached >>= (@?= expectedHook)
      readIORef inspectionReached >>= (@?= expectedInspection)
      spawned <- doesPathExist $ fakeZ3EventPath executable
      assertBool (label ++ " allocated the fake child") $ not spawned
 where
  admitted = Process.LengthSMTLibExecveCheckAdmitted
  resultCases =
    [ ( "denied", Process.LengthSMTLibExecveCheckDenied
      , Process.LengthSMTLibProcessSourceExecveCheckDenied
      , Process.LengthSMTLibProcessStagedExecveCheckDenied
      )
    , ( "unavailable", Process.LengthSMTLibExecveCheckUnavailable
      , Process.LengthSMTLibProcessSourceExecveCheckUnavailable
      , Process.LengthSMTLibProcessStagedExecveCheckUnavailable
      )
    , ( "failed", Process.LengthSMTLibExecveCheckFailed
      , Process.LengthSMTLibProcessSourceExecveCheckFailed
      , Process.LengthSMTLibProcessStagedExecveCheckFailed
      )
    ]
  cases = concatMap (\(resultLabel, result, sourceClass, stagedClass) ->
    [ ( "initial source " ++ resultLabel
      , [result], sourceClass, 1, False, False
      )
    , ( "final source " ++ resultLabel
      , [admitted, result], sourceClass, 2, True, True
      )
    , ( "staged " ++ resultLabel
      , [admitted, admitted, result], stagedClass, 2, True, True
      )
    ]) resultCases

assertExecveCheckDescriptorBoundPrecedence :: IO ()
assertExecveCheckDescriptorBoundPrecedence = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    limits <- descriptorBoundLimits
    let admittedAccess =
          Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
        admittedExecve = Process.LengthSMTLibExecveCheckAdmitted

    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    profile <- execveCheckDescriptorBoundProfile executable
      $ Just $ alterDigest $ SHA256.hash image
    accessResults <- newIORef [admittedAccess, admittedAccess]
    execveResults <- newIORef
      [admittedExecve, admittedExecve, admittedExecve]
    accessDescriptors <- newIORef []
    execveDescriptors <- newIORef []
    inspectionReached <- newIORef False
    hookReached <- newIORef False
    mismatch <- openExecveCheckWithInjectedStage
      limits cancellation deadline profile workingDirectory workingDescriptor
      (nextEffectiveIDAccessResult accessResults accessDescriptors)
      (nextExecveCheckResult execveResults execveDescriptors)
      c_createPredecessorTestStagedExecutable
      c_sealPredecessorTestStagedExecutable
      (const $ writeIORef inspectionReached True)
      (writeIORef hookReached True)
    assertZ3DescriptorOpenFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessExecutableDigestMismatch Nothing mismatch
    length <$> readIORef accessDescriptors >>= (@?= 1)
    length <$> readIORef execveDescriptors >>= (@?= 1)
    readIORef inspectionReached >>= (@?= False)
    readIORef hookReached >>= (@?= False)

    deniedAccessResults <- newIORef
      [Process.LengthSMTLibEffectiveIDExecutableAccessDenied]
    deniedAccessDescriptors <- newIORef []
    deniedExecveDescriptors <- newIORef ([] :: [Int])
    deniedCancellation <- Process.newLengthSMTLibProcessCancellation
    deniedDeadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    admittedProfile <- execveCheckDescriptorBoundProfile executable Nothing
    denied <- openExecveCheckWithInjectedStage
      limits deniedCancellation deniedDeadline admittedProfile
      workingDirectory workingDescriptor
      (nextEffectiveIDAccessResult
        deniedAccessResults deniedAccessDescriptors)
      (const $ modifyIORef' deniedExecveDescriptors (++ [0]) >>
        pure admittedExecve)
      c_createPredecessorTestStagedExecutable
      c_sealPredecessorTestStagedExecutable
      (const $ assertFailure "initial access denial reached inspection")
      (assertFailure "initial access denial reached hook")
    assertZ3DescriptorOpenFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessEffectiveIDExecutableAccessDenied
      Nothing denied
    length <$> readIORef deniedAccessDescriptors >>= (@?= 1)
    readIORef deniedExecveDescriptors >>= (@?= [])

    inspectionFailureAccess <- newIORef [admittedAccess, admittedAccess]
    inspectionFailureExecve <- newIORef
      [admittedExecve, admittedExecve, admittedExecve]
    inspectionAccessDescriptors <- newIORef []
    inspectionExecveDescriptors <- newIORef []
    inspectionHook <- newIORef False
    inspectionCancellation <- Process.newLengthSMTLibProcessCancellation
    inspectionDeadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    inspectionFailure <- openExecveCheckWithInjectedStage
      limits inspectionCancellation inspectionDeadline admittedProfile
      workingDirectory workingDescriptor
      (nextEffectiveIDAccessResult
        inspectionFailureAccess inspectionAccessDescriptors)
      (nextExecveCheckResult
        inspectionFailureExecve inspectionExecveDescriptors)
      c_createPredecessorTestStagedExecutable
      c_sealPredecessorTestStagedExecutable
      (const $ throwIO LiveSynchronousCallbackException)
      (writeIORef inspectionHook True)
    assertZ3DescriptorOpenFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessDescriptorBoundStagingFailed
      Nothing inspectionFailure
    length <$> readIORef inspectionAccessDescriptors >>= (@?= 1)
    length <$> readIORef inspectionExecveDescriptors >>= (@?= 1)
    readIORef inspectionHook >>= (@?= False)

    withFreshTestDirectory $ \sourceRoot -> do
      let missing = sourceRoot </> "missing-z3"
          directory = sourceRoot </> "directory-z3"
          nonExecutable = sourceRoot </> "nonexecutable-z3"
          link = sourceRoot </> "symlink-z3"
      createDirectory directory
      BS.writeFile nonExecutable "not executable"
      createFileLink nonExecutable link
      forM_
        [ (missing, Process.LengthSMTLibProcessExecutableUnavailable)
        , (link, Process.LengthSMTLibProcessExecutableUnavailable)
        , (directory, Process.LengthSMTLibProcessExecutableNotRegular)
        , (nonExecutable, Process.LengthSMTLibProcessExecutableNotExecutable)
        ] $ \(source, expectedClass) -> do
          sourceProfile <- execveCheckDescriptorBoundProfile source Nothing
          observations <- newIORef ([] :: [Int])
          sourceCancellation <- Process.newLengthSMTLibProcessCancellation
          sourceDeadline <- expectRight =<<
            Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
          opened <- openExecveCheckWithInjectedStage
            limits sourceCancellation sourceDeadline sourceProfile
            workingDirectory workingDescriptor
            (const $ modifyIORef' observations (++ [1]) >> pure admittedAccess)
            (const $ modifyIORef' observations (++ [2]) >> pure admittedExecve)
            c_createPredecessorTestStagedExecutable
            c_sealPredecessorTestStagedExecutable
            (const $ modifyIORef' observations (++ [3]))
            (modifyIORef' observations (++ [4]))
          assertZ3DescriptorOpenFailure
            Process.LengthSMTLibProcessSnapshotPhase expectedClass Nothing opened
          readIORef observations >>= (@?= [])
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "exec-check precedence failures allocated a child" $ not spawned

assertExecveCheckDescriptorBoundHookControl :: IO ()
assertExecveCheckDescriptorBoundHookControl = do
  assertControlled True
  assertControlled False
 where
  assertControlled cancel = withFakeZ3Mode "healthy"
    $ \executable _ -> withDescriptorWorkingDirectory
    $ \workingDirectory workingDescriptor -> do
      profile <- execveCheckDescriptorBoundProfile executable Nothing
      limits <- descriptorBoundLimits
      cancellation <- Process.newLengthSMTLibProcessCancellation
      deadline <- expectRight =<<
        Process.lengthSMTLibProcessDeadlineAfterMilliseconds
          (if cancel then 3000 else 150)
      accessResults <- newIORef
        [ Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
        , Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
        ]
      execveResults <- newIORef
        [ Process.LengthSMTLibExecveCheckAdmitted
        , Process.LengthSMTLibExecveCheckAdmitted
        , Process.LengthSMTLibExecveCheckAdmitted
        ]
      accessDescriptors <- newIORef []
      execveDescriptors <- newIORef []
      inspected <- newIORef False
      hookEntered <- newEmptyMVar
      hookRelease <- newEmptyMVar
      outcome <- newEmptyMVar
      _ <- forkIO $ do
        opened <- openExecveCheckWithInjectedStage
          limits cancellation deadline profile workingDirectory
          workingDescriptor
          (nextEffectiveIDAccessResult accessResults accessDescriptors)
          (nextExecveCheckResult execveResults execveDescriptors)
          c_createPredecessorTestStagedExecutable
          c_sealPredecessorTestStagedExecutable
          (const $ writeIORef inspected True)
          (putMVar hookEntered () >> takeMVar hookRelease)
        putMVar outcome opened
      _ <- expectWithin "exec-check post-seal hook entrance" 3000000
        $ takeMVar hookEntered
      if cancel
        then Process.cancelLengthSMTLibProcess cancellation
        else pure ()
      opened <- expectWithin "exec-check post-seal hook control" 3000000
        $ takeMVar outcome
      putMVar hookRelease ()
      assertZ3DescriptorOpenFailure
        Process.LengthSMTLibProcessDeadlinePhase
        (if cancel
          then Process.LengthSMTLibProcessCancelled
          else Process.LengthSMTLibProcessDeadlineExceeded)
        Nothing opened
      readIORef inspected >>= (@?= True)
      length <$> readIORef accessDescriptors >>= (@?= 1)
      length <$> readIORef execveDescriptors >>= (@?= 1)
      spawned <- doesPathExist $ fakeZ3EventPath executable
      assertBool "controlled exec-check hook allocated a child" $ not spawned

assertExecveCheckDescriptorBoundExecFailure :: IO ()
assertExecveCheckDescriptorBoundExecFailure =
  withFreshTestDirectory $ \sourceRoot ->
  withDescriptorWorkingDirectory $ \workingDirectory workingDescriptor -> do
    let executable = sourceRoot </> "execve-check-executable-garbage"
    BS.writeFile executable "not-an-elf-or-script"
    permissions <- getPermissions executable
    setPermissions executable $ setOwnerExecutable True permissions
    profile <- execveCheckDescriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    accessResults <- newIORef
      [ Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
      , Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
      ]
    execveResults <- newIORef
      [ Process.LengthSMTLibExecveCheckAdmitted
      , Process.LengthSMTLibExecveCheckAdmitted
      , Process.LengthSMTLibExecveCheckAdmitted
      ]
    accessDescriptors <- newIORef []
    execveDescriptors <- newIORef []
    inspected <- newIORef False
    hooked <- newIORef False
    opened <- openExecveCheckWithInjectedStage
      limits cancellation deadline profile workingDirectory workingDescriptor
      (nextEffectiveIDAccessResult accessResults accessDescriptors)
      (nextExecveCheckResult execveResults execveDescriptors)
      c_createPredecessorTestStagedExecutable
      c_sealPredecessorTestStagedExecutable
      (const $ writeIORef inspected True)
      (writeIORef hooked True)
    cleanup <- case opened of
      Left failure -> do
        Process.lengthSMTLibProcessErrorPhase failure @?=
          Process.LengthSMTLibProcessSpawnPhase
        Process.lengthSMTLibProcessErrorClass failure @?=
          Process.LengthSMTLibProcessDescriptorBoundExecFailed
        maybe
          (assertFailure "exec-check exec failure omitted child cleanup")
          pure
          $ Process.lengthSMTLibProcessErrorCleanupStatus failure
      Right process -> do
        _ <- Process.closeLengthSMTLibProcess process
        assertFailure "invalid injected exec-check image unexpectedly executed"
    readIORef inspected >>= (@?= True)
    readIORef hooked >>= (@?= True)
    length <$> readIORef accessDescriptors >>= (@?= 2)
    length <$> readIORef execveDescriptors >>= (@?= 3)
    assertCompleteZ3Cleanup "exec-check exec failure" cleanup

assertExecveCheckDescriptorBoundNativeOutcome :: IO ()
assertExecveCheckDescriptorBoundNativeOutcome = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    profile <- execveCheckDescriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    opened <-
      Process.openLengthSMTLibDescriptorBoundExecveCheckExecutableAccessProcess
        limits cancellation deadline profile workingDirectory workingDescriptor
    case opened of
      Left failure -> do
        Process.lengthSMTLibProcessErrorPhase failure @?=
          Process.LengthSMTLibProcessSnapshotPhase
        Process.lengthSMTLibProcessErrorClass failure @?=
          Process.LengthSMTLibProcessSourceExecveCheckUnavailable
        Process.lengthSMTLibProcessErrorCleanupStatus failure @?= Nothing
        spawned <- doesPathExist $ fakeZ3EventPath executable
        assertBool "unavailable native exec check used a launch fallback"
          $ not spawned
      Right process -> do
        Process.lengthSMTLibProcessUsesDescriptorBoundExecveCheckExecutableAccessLaunch
            process @?= True
        Process.lengthSMTLibExecutableSnapshotSHA256
            (Process.lengthSMTLibProcessSnapshot process) @?= SHA256.hash image
        cleanup <- Process.closeLengthSMTLibProcess process
        assertCompleteZ3Cleanup "native exec-check success" cleanup
        assertNativeExecveCheckStagedImagePolicy

assertNativeExecveCheckStagedImagePolicy :: IO ()
assertNativeExecveCheckStagedImagePolicy = withFakeZ3Mode "healthy"
  $ \executable image -> withDescriptorWorkingDirectory
  $ \workingDirectory workingDescriptor -> do
    profile <- execveCheckDescriptorBoundProfile executable Nothing
    limits <- descriptorBoundLimits
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    execveCall <- newIORef (0 :: Int)
    observedInspection <- newIORef Nothing
    let accessCheck _ = pure
          Process.LengthSMTLibEffectiveIDExecutableAccessAdmitted
        execveCheck descriptor = do
          modifyIORef' execveCall (+ 1)
          call <- readIORef execveCall
          if call == 3
            then Process.inspectLengthSMTLibExecveCheckStagedImage descriptor
              >>= writeIORef observedInspection
            else pure ()
          pure Process.LengthSMTLibExecveCheckAdmitted
    process <- expectRight =<<
      Process.openLengthSMTLibDescriptorBoundExecveCheckExecutableAccessProcessWithHooks
        limits cancellation deadline profile workingDirectory
        workingDescriptor accessCheck execveCheck (pure ())
    readIORef execveCall >>= (@?= 3)
    readIORef observedInspection >>= (@?= Just
      Process.LengthSMTLibExecveCheckStagedImageInspection
        { Process.lengthSMTLibExecveCheckStagedImageRequestedCreationFlags =
            0x13
        , Process.lengthSMTLibExecveCheckStagedImageRegularFile = True
        , Process.lengthSMTLibExecveCheckStagedImageMode = 0o500
        , Process.lengthSMTLibExecveCheckStagedImageByteCount =
            fromIntegral $ BS.length image
        , Process.lengthSMTLibExecveCheckStagedImageSeals = 0x3f
        })
    cleanup <- Process.closeLengthSMTLibProcess process
    assertCompleteZ3Cleanup "native staged policy inspection" cleanup

openExecveCheckWithInjectedStage
  :: Process.LengthSMTLibProcessLimits
  -> Process.LengthSMTLibProcessCancellation
  -> Process.LengthSMTLibProcessDeadline
  -> Z3Execution.Z3SMTLibExecutionProfile
  -> FilePath
  -> Process.LengthSMTLibWorkingDirectoryDescriptor
  -> (CInt -> IO Process.LengthSMTLibEffectiveIDExecutableAccessCheckResult)
  -> (CInt -> IO Process.LengthSMTLibExecveCheckResult)
  -> IO CInt
  -> (CInt -> Int64 -> IO CInt)
  -> (CInt -> IO ())
  -> IO ()
  -> IO (Either Process.LengthSMTLibProcessError Process.LengthSMTLibProcess)
openExecveCheckWithInjectedStage =
  Process.openLengthSMTLibDescriptorBoundExecveCheckExecutableAccessProcessWithTestHooks

nextExecveCheckResult
  :: IORef [Process.LengthSMTLibExecveCheckResult]
  -> IORef [Int]
  -> CInt
  -> IO Process.LengthSMTLibExecveCheckResult
nextExecveCheckResult results observations descriptor = do
  modifyIORef' observations (++ [fromIntegral descriptor])
  remaining <- readIORef results
  case remaining of
    [] -> assertFailure "exec-check checker was called too many times"
    result : rest -> writeIORef results rest >> pure result

nextEffectiveIDAccessResult
  :: IORef [Process.LengthSMTLibEffectiveIDExecutableAccessCheckResult]
  -> IORef [Int]
  -> CInt
  -> IO Process.LengthSMTLibEffectiveIDExecutableAccessCheckResult
nextEffectiveIDAccessResult results observations descriptor = do
  modifyIORef' observations (++ [fromIntegral descriptor])
  remaining <- readIORef results
  case remaining of
    [] -> assertFailure "effective-ID checker was called too many times"
    result : rest -> writeIORef results rest >> pure result

descriptorBoundProfile
  :: FilePath
  -> Maybe ByteString
  -> IO Z3Execution.Z3SMTLibExecutionProfile
descriptorBoundProfile executable expectedDigest = do
  execution <- descriptorBoundLiveExecutionConfig executable expectedDigest
  pure $ Execution.lengthSMTLibExecutionZ3Profile execution

execveCheckDescriptorBoundProfile
  :: FilePath
  -> Maybe ByteString
  -> IO Z3Execution.Z3SMTLibExecutionProfile
execveCheckDescriptorBoundProfile executable expectedDigest = do
  execution <- execveCheckDescriptorBoundLiveExecutionConfig
    executable expectedDigest
  pure $ Execution.lengthSMTLibExecutionZ3Profile execution

descriptorBoundLimits :: IO Process.LengthSMTLibProcessLimits
descriptorBoundLimits = expectRight $ Process.mkLengthSMTLibProcessLimits
  Process.defaultLengthSMTLibProcessLimitSource

withDescriptorWorkingDirectory
  :: (FilePath -> Process.LengthSMTLibWorkingDirectoryDescriptor -> IO result)
  -> IO result
withDescriptorWorkingDirectory use = withFreshTestDirectory
  $ \workingDirectory -> bracket
      (openReadOnlyDescriptor workingDirectory)
      closeFd
      $ \descriptor -> use workingDirectory
      $ Process.mkLengthSMTLibWorkingDirectoryDescriptor
      $ descriptorNumber descriptor

openReadOnlyDescriptor :: FilePath -> IO Fd
#if MIN_VERSION_unix(2,8,0)
openReadOnlyDescriptor path = openFd path ReadOnly defaultFileFlags
#else
openReadOnlyDescriptor path = openFd path ReadOnly Nothing defaultFileFlags
#endif

descriptorNumber :: Fd -> Int
descriptorNumber (Fd raw) = fromIntegral raw

assertCompleteZ3Cleanup
  :: String
  -> Process.LengthSMTLibProcessCleanupStatus
  -> IO ()
assertCompleteZ3Cleanup label cleanup = do
  assertBool (label ++ " remained incomplete")
    $ Process.lengthSMTLibProcessCleanupEscalation cleanup /=
        Process.LengthSMTLibProcessCleanupIncomplete
  Process.lengthSMTLibProcessCleanupFailureCount cleanup @?= 0
  Process.lengthSMTLibProcessCleanupReadersStopped cleanup @?= True

expectWithin :: String -> Int -> IO value -> IO value
expectWithin label microseconds action = do
  bounded <- timeout microseconds action
  case bounded of
    Nothing -> assertFailure $ label ++ " exceeded its outer bound"
    Just value -> pure value
#endif

assertRawProcessCancellationPrecedence :: IO ()
assertRawProcessCancellationPrecedence = do
  cancellation <- Process.newLengthSMTLibProcessCancellation
  Process.cancelLengthSMTLibProcess cancellation
  deadline <- expectRight =<<
    Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
  opened <- Process.openLengthSMTLibProcess
    (error "cancelled raw Process demanded its limits")
    cancellation deadline
    (error "cancelled raw Process demanded its launch profile")
    (error "cancelled raw Process demanded its working directory")
  assertRawProcessOpenFailure Process.LengthSMTLibProcessSnapshotPhase
    Process.LengthSMTLibProcessCancelled opened

assertRawProcessWorkingDirectoryPrecedence :: IO ()
assertRawProcessWorkingDirectoryPrecedence = do
  cancellation <- Process.newLengthSMTLibProcessCancellation
  deadline <- expectRight =<<
    Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
  opened <- Process.openLengthSMTLibProcess
    (error "relative cwd rejection demanded the process limits")
    cancellation deadline
    (error "relative cwd rejection demanded the launch profile")
    "relative-process-working-directory"
  assertRawProcessOpenFailure
    Process.LengthSMTLibProcessWorkingDirectoryPhase
    Process.LengthSMTLibProcessWorkingDirectoryNotAbsolute opened

assertRawProcessProfileIdentity :: IO ()
assertRawProcessProfileIdentity = withFakeZ3Mode "healthy"
  $ \executable _ -> withFreshTestDirectory $ \workingDirectory -> do
    execution <- liveExecutionConfig executable Nothing
    limits <- expectRight $ Process.mkLengthSMTLibProcessLimits
      Process.defaultLengthSMTLibProcessLimitSource
    cancellation <- Process.newLengthSMTLibProcessCancellation
    deadline <- expectRight =<<
      Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
    process <- expectRight =<< Process.openLengthSMTLibProcess
      limits cancellation deadline
        (Execution.lengthSMTLibExecutionZ3Profile execution)
        workingDirectory
    (do
      canonicalWorkingDirectory <- canonicalizePath workingDirectory
      Process.lengthSMTLibProcessSchemaTag @?=
        utf8Bytes "djex-length-z3-raw-process/v2"
      let rawIdentity = Process.lengthSMTLibProcessFingerprintField process
          repeatedIdentity =
            Process.lengthSMTLibProcessFingerprintField process
          completePolicy = Fingerprint.fingerprintCanonicalBytes
            $ Execution.lengthSMTLibExecutionPolicyFingerprint execution
      repeatedIdentity @?= rawIdentity
      Process.lengthSMTLibProcessLimitsFingerprintField
          (Process.lengthSMTLibProcessLimits process) @?=
        Process.lengthSMTLibProcessLimitsFingerprintField limits
      countExactFingerprintBytes completePolicy rawIdentity @?= 0
      case rawIdentity of
        Fingerprint.FingerprintTag root fields -> do
          root @?= ascii "length-z3-launched-transport"
          length fields @?= 17
          case fields of
            Fingerprint.FingerprintBytes schema
                : snapshot : _cwd : _emptiness : pid : remaining -> do
              schema @?= BS.unpack Process.lengthSMTLibProcessSchemaTag
              snapshot @?=
                Process.lengthSMTLibExecutableSnapshotFingerprintField
                  (Process.lengthSMTLibProcessSnapshot process)
              assertRawProcessPidField pid
              rawIdentity @?= expectedRawProcessFingerprintField
                process canonicalWorkingDirectory deadline limits pid
              last remaining @?=
                Process.lengthSMTLibProcessLimitsFingerprintField limits
            _ -> assertFailure "raw process identity lost its schema prefix"
        _ -> assertFailure "raw process identity lost its Length root")
      `onException` (Process.closeLengthSMTLibProcess process >> pure ())
    cleanup <- Process.closeLengthSMTLibProcess process
    assertBool "profile-only Process cleanup remained incomplete"
      $ Process.lengthSMTLibProcessCleanupEscalation cleanup /=
          Process.LengthSMTLibProcessCleanupIncomplete
    Process.lengthSMTLibProcessCleanupFailureCount cleanup @?= 0
    Process.lengthSMTLibProcessCleanupReadersStopped cleanup @?= True

expectedRawProcessFingerprintField
  :: Process.LengthSMTLibProcess
  -> FilePath
  -> Process.LengthSMTLibProcessDeadline
  -> Process.LengthSMTLibProcessLimits
  -> Fingerprint.FingerprintField
  -> Fingerprint.FingerprintField
expectedRawProcessFingerprintField
    process workingDirectory deadline limits pid =
  Fingerprint.FingerprintTag (ascii "length-z3-launched-transport")
    [ Fingerprint.FingerprintBytes
        $ BS.unpack Process.lengthSMTLibProcessSchemaTag
    , Process.lengthSMTLibExecutableSnapshotFingerprintField
        $ Process.lengthSMTLibProcessSnapshot process
    , Fingerprint.FingerprintTag
        (ascii "canonical-working-directory-observation")
        [fingerprintTextField workingDirectory]
    , rawProcessWorkingDirectoryEmptinessField
    , pid
    , Fingerprint.FingerprintTag (ascii "alive-at-open-snapshot") []
    , Fingerprint.FingerprintTag (ascii "separate-binary-pipes") []
    , Fingerprint.FingerprintTag
        (ascii "stderr-first-byte-poisons-session") []
    , Fingerprint.FingerprintTag
        (ascii "stderr-post-poison-discard-count-capped-at-max-plus-one/v1")
        []
    , Fingerprint.FingerprintTag
        (ascii "stdout-cumulative-charge-before-fifo-enqueue/v1") []
    , Fingerprint.FingerprintTag
        (ascii "stdout-chunks-before-terminal-fifo/v1") []
    , Fingerprint.FingerprintTag
        (ascii "writes-exact-bytes-then-flush/v1") []
    , Fingerprint.FingerprintTag
        (ascii "control-priority-cancel-deadline-poison-output/v1") []
    , Fingerprint.FingerprintTag
        (ascii "cleanup-leader-close-wait-term-wait-kill-wait/v1") []
    , Fingerprint.FingerprintTag
        (ascii
          "descendant-cleanup-best-effort-no-post-reap-group-signal/v1")
        []
    , Fingerprint.FingerprintTag
        (ascii "absolute-monotonic-deadline-nanoseconds")
        [Fingerprint.FingerprintNatural $ rawProcessDeadlineNanoseconds deadline]
    , Process.lengthSMTLibProcessLimitsFingerprintField limits
    ]

rawProcessDeadlineNanoseconds
  :: Process.LengthSMTLibProcessDeadline
  -> Natural
rawProcessDeadlineNanoseconds deadline = case
    Process.lengthSMTLibProcessDeadlineFingerprintField deadline of
  Fingerprint.FingerprintTag method
      [Fingerprint.FingerprintBytes clock, Fingerprint.FingerprintNatural value]
    | method == ascii "absolute-monotonic-deadline"
    , clock == ascii "clock_gettime-monotonic-nanoseconds/v1" -> value
  other -> error $ "unexpected raw Process deadline field: " ++ show other

rawProcessWorkingDirectoryEmptinessField :: Fingerprint.FingerprintField
rawProcessWorkingDirectoryEmptinessField = Fingerprint.FingerprintTag
  (ascii $ if SystemInfo.os == "mingw32"
    then "working-directory-observed-empty-windows-list-fallback-no-read-bound/v1"
    else "working-directory-observed-empty-posix-dir-stream-at-most-three-reads/v1")
  []

fingerprintTextField :: String -> Fingerprint.FingerprintField
fingerprintTextField = Fingerprint.FingerprintSequence
  . map (Fingerprint.FingerprintNatural . fromIntegral . ord)

assertRawProcessPidField :: Fingerprint.FingerprintField -> IO ()
assertRawProcessPidField field = case field of
  Fingerprint.FingerprintTag tag []
    | tag == ascii "pid-unavailable" -> pure ()
  Fingerprint.FingerprintTag tag [Fingerprint.FingerprintSequence digits]
    | tag == ascii "pid-observed"
    , not $ null digits
    , all decimalNatural digits -> pure ()
  _ -> assertFailure $ "raw Process identity lost its PID observation: "
    ++ show field
 where
  decimalNatural value = case value of
    Fingerprint.FingerprintNatural byte ->
      byte >= fromIntegral (ord '0') && byte <= fromIntegral (ord '9')
    _ -> False

assertRawProcessStdoutLimitPrefix :: IO ()
assertRawProcessStdoutLimitPrefix = do
  observations <- forM [4, 1] $ \readChunkBytes ->
    withFakeZ3Mode "healthy" $ \executable _ ->
      withFreshTestDirectory $ \workingDirectory -> do
        execution <- liveExecutionConfig executable Nothing
        limits <- expectRight $ Process.mkLengthSMTLibProcessLimits
          $ Process.defaultLengthSMTLibProcessLimitSource
              { Process.lengthSMTLibProcessLimitSourceStdoutBytes = 3
              , Process.lengthSMTLibProcessLimitSourceReadChunkBytes =
                  readChunkBytes
              }
        cancellation <- Process.newLengthSMTLibProcessCancellation
        deadline <- expectRight =<<
          Process.lengthSMTLibProcessDeadlineAfterMilliseconds 3000
        process <- expectRight =<< Process.openLengthSMTLibProcess
          limits cancellation deadline
            (Execution.lengthSMTLibExecutionZ3Profile execution)
            workingDirectory
        (prefix, terminal) <- collectRawProcessPrefix
          process cancellation deadline
        rejected <- Process.writeLengthSMTLibProcess
          process cancellation deadline "(check-sat)\n"
        case rejected of
          Left failure -> failure @?= terminal
          Right () -> assertFailure
            "stdout-limit terminal admitted a subsequent write"
        observed <- Process.lengthSMTLibProcessObservedStdoutBytes process
        cleanup <- Process.closeLengthSMTLibProcess process
        assertBool "stdout-limit Process cleanup remained incomplete"
          $ Process.lengthSMTLibProcessCleanupEscalation cleanup /=
              Process.LengthSMTLibProcessCleanupIncomplete
        Process.lengthSMTLibProcessCleanupFailureCount cleanup @?= 0
        Process.lengthSMTLibProcessCleanupReadersStopped cleanup @?= True
        pure (prefix, terminal, observed)
  forM_ observations $ \(prefix, terminal, observed) -> do
    prefix @?= "\"ca"
    Process.lengthSMTLibProcessErrorPhase terminal @?=
      Process.LengthSMTLibProcessStdoutPhase
    Process.lengthSMTLibProcessErrorClass terminal @?=
      Process.LengthSMTLibProcessStdoutByteLimitExceeded
    Process.lengthSMTLibProcessErrorObservedAtLeast terminal @?= Just 4
    observed @?= 4
  case observations of
    [(_, wholeTerminal, _), (_, singletonTerminal, _)] ->
      wholeTerminal @?= singletonTerminal
    _ -> assertFailure "internal stdout-limit test matrix changed shape"

collectRawProcessPrefix
  :: Process.LengthSMTLibProcess
  -> Process.LengthSMTLibProcessCancellation
  -> Process.LengthSMTLibProcessDeadline
  -> IO (ByteString, Process.LengthSMTLibProcessError)
collectRawProcessPrefix process cancellation deadline = do
  written <- Process.writeLengthSMTLibProcess
    process cancellation deadline "(echo \"cap\")\n"
  _ <- expectRight written
  go []
 where
  go chunks = do
    received <- Process.nextLengthSMTLibProcessStdoutChunk
      process cancellation deadline
    case received of
      Right chunk -> go
        $ SMTLibStdoutChunk.smtLibCausalStdoutChunkBytes chunk : chunks
      Left terminal -> pure (BS.concat $ reverse chunks, terminal)

liveSessionTests :: TestTree
liveSessionTests = testGroup "live Session integration"
  [ testCase "open healthy worker with exact launch isolation and cleanup"
      assertLiveHealthyIsolation
  , descriptorBoundLiveSessionTests
  , effectiveIDDescriptorBoundLiveSessionTests
  , execveCheckDescriptorBoundLiveSessionTests
  , testCase "accept matching executable digest pin"
      assertLiveMatchingDigest
  , testCase "complete capability probe with split and drip output"
      assertLiveChunkModes
  , testCase "reject digest mismatch before spawning"
      assertLiveDigestMismatch
  , testCase "reject exact capability fault modes"
      assertLiveCapabilityFaults
  , liveStderrFaultTests
  , liveTerminationFaultTests
  , testCase "bound cleanup of a worker stubborn after stdin EOF"
      assertLiveStubbornCleanup
  , testCase "enforce executable snapshot byte cap at exact and maximum plus one"
      assertLiveExecutableByteCap
  , testCase "reject a ready identity at the first byte past its cap"
      assertLiveReadyIdentityByteCap
  , testCase "distinguish independently opened worker identities"
      assertLiveIdentityFreshness
  , posixWorkspaceReplacementTest
  , callbackExceptionTests
  ]

descriptorBoundLiveSessionTests :: TestTree
descriptorBoundLiveSessionTests
  | Process.lengthSMTLibDescriptorBoundExecutableLaunchSupported = testGroup
      "descriptor-bound Session routing"
      [ testCase "open a sealed-image worker and bind its exact strength"
          assertLiveDescriptorBoundHealthy
      , testCase "reject a pinned mismatch without a child and remove workspace"
          assertLiveDescriptorBoundDigestMismatch
      , testCase "apply the ordinary opener deadline and durable cleanup"
          assertLiveDescriptorBoundDeadline
      ]
  | otherwise = testCase
      "fail a descriptor policy closed without pathname fallback"
      assertLiveDescriptorBoundUnsupported

effectiveIDDescriptorBoundLiveSessionTests :: TestTree
effectiveIDDescriptorBoundLiveSessionTests
  | Process.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchSupported =
      testGroup "effective-ID descriptor-bound Session routing"
        [ testCase "open, probe, identify, and clean an effective-ID worker"
            assertLiveEffectiveIDDescriptorBoundHealthy
        , testCase "preserve digest-mismatch precedence and workspace cleanup"
            assertLiveEffectiveIDDescriptorBoundDigestMismatch
        , testCase "apply the ordinary opener deadline and durable cleanup"
            assertLiveEffectiveIDDescriptorBoundDeadline
        ]
  | otherwise = testCase
      "fail an effective-ID descriptor policy closed without fallback"
      assertLiveEffectiveIDDescriptorBoundUnsupported

execveCheckDescriptorBoundLiveSessionTests :: TestTree
execveCheckDescriptorBoundLiveSessionTests = testGroup
  "AT_EXECVE_CHECK descriptor-bound Session routing"
  [ testCase
      "fail unavailable closed or bind the native ready-worker identity"
      assertLiveExecveCheckDescriptorBoundOutcome
  ]

assertLiveDescriptorBoundHealthy :: IO ()
assertLiveDescriptorBoundHealthy = withFakeZ3Mode "healthy"
  $ \executable image -> do
    config <- descriptorBoundLiveSessionConfig executable Nothing id id
    scoped <- runReadyWorkerBounded 6000000 config $ \worker -> do
      Session.lengthSMTLibReadyWorkerExecutableSnapshotStrengthTag worker @?=
        Process.lengthSMTLibDescriptorBoundExecutableLaunchStrengthTag
      Session.lengthSMTLibReadyWorkerExecutableSHA256 worker @?=
        SHA256.hash image
      Session.lengthSMTLibReadyWorkerExecutableByteCount worker @?=
        byteStringLength image
      let readyIdentity = BS.pack $ Fingerprint.fingerprintCanonicalBytes
            $ Session.lengthSMTLibReadyWorkerIdentityFingerprint worker
      assertBool "descriptor ready identity omitted its sealed-image schema"
        $ "djex-length-z3-capability-probed-sealed-main-image-ready-worker/v1"
            `BS.isInfixOf` readyIdentity
      assertBool "descriptor ready identity omitted its exact strength"
        $ Process.lengthSMTLibDescriptorBoundExecutableLaunchStrengthTag
            `BS.isInfixOf` readyIdentity
      assertBool "descriptor ready identity omitted fail-closed fd isolation"
        $ "close-range-required-fail-closed-when-unavailable"
            `BS.isInfixOf` readyIdentity
      assertBool "descriptor ready identity acquired the legacy ready schema"
        $ not $ BS.pack Session.lengthSMTLibReadyWorkerSchemaTag
            `BS.isInfixOf` readyIdentity
      events <- readFakeZ3Events executable
      start <- expectFakeZ3Event "start" events
      assertSingleFakeField "mode" "healthy" start
      fakeZ3FieldValues "argv" start @?= map utf8Bytes liveArgumentVector
      assertSingleFakeField "environment-count" "0" start
      pure $ Session.lengthSMTLibReadyWorkerWorkingDirectory worker
    workspace <- expectRight scoped
    retained <- doesPathExist workspace
    assertBool "descriptor Session retained its workspace" $ not retained

assertLiveDescriptorBoundDigestMismatch :: IO ()
assertLiveDescriptorBoundDigestMismatch = withFakeZ3Mode "healthy"
  $ \executable image -> do
    config <- descriptorBoundLiveSessionConfig executable
      (Just $ alterDigest $ SHA256.hash image) id id
    scoped <- runReadyWorkerBounded 6000000 config $ \_ ->
      assertFailure "descriptor digest mismatch reached the worker callback"
    cleanup <- expectProcessScopeFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessExecutableDigestMismatch
      Nothing scoped
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "descriptor digest mismatch spawned the fake worker" $ not spawned
    Session.lengthSMTLibSessionProcessCleanupStatus cleanup @?= Nothing
    Session.lengthSMTLibSessionWorkspaceCleanupStatus cleanup @?=
      Session.LengthSMTLibSessionWorkspaceRemoved 0

assertLiveDescriptorBoundDeadline :: IO ()
assertLiveDescriptorBoundDeadline = withFakeZ3Mode "hang"
  $ \executable _ -> do
    config <- descriptorBoundLiveSessionConfig executable Nothing id $ \source ->
      source
        { Session.lengthSMTLibSessionLimitSourceOpenerDeadlineMilliseconds =
            1000 }
    scoped <- runReadyWorkerBounded 5000000 config $ \_ ->
      assertFailure "hung descriptor worker reached the callback"
    cleanup <- expectDeadlineScopeFailure scoped
    assertWorkspaceWasRemoved "descriptor hang" cleanup
    case Session.lengthSMTLibSessionProcessCleanupStatus cleanup of
      Nothing -> assertFailure "descriptor deadline omitted child cleanup"
      Just processCleanup -> assertBool
        "descriptor deadline left child cleanup incomplete"
        $ Process.lengthSMTLibProcessCleanupEscalation processCleanup /=
            Process.LengthSMTLibProcessCleanupIncomplete

assertLiveDescriptorBoundUnsupported :: IO ()
assertLiveDescriptorBoundUnsupported =
  withFreshTestDirectory $ \sourceRoot -> do
    let executable = sourceRoot </> "unavailable-descriptor-z3"
    config <- descriptorBoundLiveSessionConfig executable Nothing id id
    scoped <- runReadyWorkerBounded 3000000 config $ \_ ->
      assertFailure "unsupported descriptor policy used a pathname fallback"
    cleanup <- expectProcessScopeFailure
      Process.LengthSMTLibProcessSpawnPhase
      Process.LengthSMTLibProcessDescriptorBoundLaunchUnavailable
      Nothing scoped
    Session.lengthSMTLibSessionProcessCleanupStatus cleanup @?= Nothing
    assertWorkspaceWasRemoved "unsupported descriptor launch" cleanup

assertLiveEffectiveIDDescriptorBoundHealthy :: IO ()
assertLiveEffectiveIDDescriptorBoundHealthy = withFakeZ3Mode "healthy"
  $ \executable image -> do
    config <- effectiveIDDescriptorBoundLiveSessionConfig
      executable Nothing id id
    scoped <- runReadyWorkerBounded 6000000 config $ \worker -> do
      Session.lengthSMTLibReadyWorkerExecutableSnapshotStrengthTag worker @?=
        Process.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchStrengthTag
      Session.lengthSMTLibReadyWorkerExecutableSHA256 worker @?=
        SHA256.hash image
      Session.lengthSMTLibReadyWorkerExecutableByteCount worker @?=
        byteStringLength image
      let readyIdentity = BS.pack $ Fingerprint.fingerprintCanonicalBytes
            $ Session.lengthSMTLibReadyWorkerIdentityFingerprint worker
      assertBool "effective-ID ready identity omitted its nominal schema"
        $ BSC.pack (concat
            [ "djex-length-z3-capability-probed-effective-id-executable-"
            , "access-sealed-main-image-ready-worker/v1"
            ]) `BS.isInfixOf` readyIdentity
      assertBool "effective-ID ready identity omitted its exact strength"
        $ Process.lengthSMTLibDescriptorBoundEffectiveIDExecutableAccessLaunchStrengthTag
            `BS.isInfixOf` readyIdentity
      assertBool "effective-ID ready identity omitted fixed staged mode"
        $ "fixed-owner-read-execute-mode-0500-not-source-metadata-authority"
            `BS.isInfixOf` readyIdentity
      assertBool "effective-ID ready identity acquired the old descriptor schema"
        $ not $ BSC.pack
            "djex-length-z3-capability-probed-sealed-main-image-ready-worker/v1"
              `BS.isInfixOf` readyIdentity
      events <- readFakeZ3Events executable
      start <- expectFakeZ3Event "start" events
      assertSingleFakeField "mode" "healthy" start
      fakeZ3FieldValues "argv" start @?= map utf8Bytes liveArgumentVector
      assertSingleFakeField "environment-count" "0" start
      pure $ Session.lengthSMTLibReadyWorkerWorkingDirectory worker
    workspace <- expectRight scoped
    retained <- doesPathExist workspace
    assertBool "effective-ID Session retained its workspace" $ not retained

assertLiveEffectiveIDDescriptorBoundDigestMismatch :: IO ()
assertLiveEffectiveIDDescriptorBoundDigestMismatch =
  withFakeZ3Mode "healthy" $ \executable image -> do
    config <- effectiveIDDescriptorBoundLiveSessionConfig executable
      (Just $ alterDigest $ SHA256.hash image) id id
    scoped <- runReadyWorkerBounded 6000000 config $ \_ ->
      assertFailure "effective-ID digest mismatch reached the worker callback"
    cleanup <- expectProcessScopeFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessExecutableDigestMismatch Nothing scoped
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "effective-ID digest mismatch spawned the fake worker"
      $ not spawned
    Session.lengthSMTLibSessionProcessCleanupStatus cleanup @?= Nothing
    Session.lengthSMTLibSessionWorkspaceCleanupStatus cleanup @?=
      Session.LengthSMTLibSessionWorkspaceRemoved 0

assertLiveEffectiveIDDescriptorBoundDeadline :: IO ()
assertLiveEffectiveIDDescriptorBoundDeadline = withFakeZ3Mode "hang"
  $ \executable _ -> do
    config <- effectiveIDDescriptorBoundLiveSessionConfig
      executable Nothing id $ \source -> source
        { Session.lengthSMTLibSessionLimitSourceOpenerDeadlineMilliseconds =
            1000 }
    scoped <- runReadyWorkerBounded 5000000 config $ \_ ->
      assertFailure "hung effective-ID worker reached the callback"
    cleanup <- expectDeadlineScopeFailure scoped
    assertWorkspaceWasRemoved "effective-ID descriptor hang" cleanup
    case Session.lengthSMTLibSessionProcessCleanupStatus cleanup of
      Nothing -> assertFailure "effective-ID deadline omitted child cleanup"
      Just processCleanup -> assertBool
        "effective-ID deadline left child cleanup incomplete"
        $ Process.lengthSMTLibProcessCleanupEscalation processCleanup /=
            Process.LengthSMTLibProcessCleanupIncomplete

assertLiveEffectiveIDDescriptorBoundUnsupported :: IO ()
assertLiveEffectiveIDDescriptorBoundUnsupported =
  withFreshTestDirectory $ \sourceRoot -> do
    let executable = sourceRoot </> "unavailable-effective-id-z3"
    config <- effectiveIDDescriptorBoundLiveSessionConfig
      executable Nothing id id
    scoped <- runReadyWorkerBounded 3000000 config $ \_ ->
      assertFailure "unsupported effective-ID policy used a launch fallback"
    cleanup <- expectProcessScopeFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessEffectiveIDExecutableAccessCheckUnavailable
      Nothing scoped
    Session.lengthSMTLibSessionProcessCleanupStatus cleanup @?= Nothing
    assertWorkspaceWasRemoved "unsupported effective-ID descriptor launch"
      cleanup

assertLiveExecveCheckDescriptorBoundOutcome :: IO ()
assertLiveExecveCheckDescriptorBoundOutcome = withFakeZ3Mode "healthy"
  $ \executable image -> do
    config <- execveCheckDescriptorBoundLiveSessionConfig
      executable Nothing id id
    scoped <- runReadyWorkerBounded 6000000 config $ \worker -> do
      Session.lengthSMTLibReadyWorkerExecutableSnapshotStrengthTag worker @?=
        Process.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunchStrengthTag
      Session.lengthSMTLibReadyWorkerExecutableSHA256 worker @?=
        SHA256.hash image
      Session.lengthSMTLibReadyWorkerExecutableByteCount worker @?=
        byteStringLength image
      let readyIdentity = BS.pack $ Fingerprint.fingerprintCanonicalBytes
            $ Session.lengthSMTLibReadyWorkerIdentityFingerprint worker
      assertBool "exec-check ready identity omitted its nominal schema"
        $ BSC.pack (concat
            [ "djex-length-z3-capability-probed-execve-check-executable-"
            , "access-sealed-main-image-ready-worker/v1"
            ]) `BS.isInfixOf` readyIdentity
      assertBool "exec-check ready identity omitted its launch strength"
        $ Process.lengthSMTLibDescriptorBoundExecveCheckExecutableAccessLaunchStrengthTag
            `BS.isInfixOf` readyIdentity
      assertBool "exec-check ready identity reused effective-ID schema"
        $ not $ BSC.pack (concat
            [ "djex-length-z3-capability-probed-effective-id-executable-"
            , "access-sealed-main-image-ready-worker/v1"
            ]) `BS.isInfixOf` readyIdentity
      pure $ Session.lengthSMTLibReadyWorkerWorkingDirectory worker
    case scoped of
      Right workspace -> do
        retained <- doesPathExist workspace
        assertBool "exec-check Session retained its workspace" $ not retained
      Left _ -> do
        cleanup <- expectProcessScopeFailure
          Process.LengthSMTLibProcessSnapshotPhase
          Process.LengthSMTLibProcessSourceExecveCheckUnavailable
          Nothing scoped
        Session.lengthSMTLibSessionProcessCleanupStatus cleanup @?= Nothing
        assertWorkspaceWasRemoved "unavailable exec-check descriptor launch"
          cleanup
        spawned <- doesPathExist $ fakeZ3EventPath executable
        assertBool "unavailable exec-check Session used a fallback" $ not spawned

assertLiveHealthyIsolation :: IO ()
assertLiveHealthyIsolation = withFakeZ3Mode "healthy" $ \executable image -> do
  execution <- liveExecutionConfig executable Nothing
  config <- liveSessionConfig executable Nothing id id
  scoped <- runReadyWorkerBounded 6000000 config $ \worker -> do
    let workspace = Session.lengthSMTLibReadyWorkerWorkingDirectory worker
        tracePath = fakeZ3EventPath executable
    present <- doesDirectoryExist workspace
    assertBool "live callback received a missing workspace" present
    tracePresent <- doesPathExist tracePath
    assertBool "fake worker did not create its event trace" tracePresent
    events <- expectRight . parseFakeZ3Events =<< BS.readFile tracePath
    start <- expectFakeZ3Event "start" events
    assertSingleFakeField "trace-schema" "length-delimited/v1" start
    assertSingleFakeField "mode" "healthy" start
    assertSingleFakeField "executable-basename"
      (utf8Bytes $ takeFileName executable) start
    assertSingleFakeField "argv-count" "5" start
    fakeZ3FieldValues "argv" start @?= map utf8Bytes liveArgumentVector
    assertSingleFakeField "environment-count" "0" start
    fakeZ3FieldValues "environment-name" start @?= []
    fakeZ3FieldValues "environment-value" start @?= []
    assertSingleFakeField "cwd" (utf8Bytes workspace) start
    assertSingleFakeField "initial-listing-count" "0" start
    fakeZ3FieldValues "initial-listing-entry" start @?= []
    entries <- listDirectory workspace
    entries @?= []
    Session.lengthSMTLibReadyWorkerExecutableSHA256 worker @?=
      SHA256.hash image
    Session.lengthSMTLibReadyWorkerExecutableByteCount worker @?=
      byteStringLength image
    Session.lengthSMTLibReadyWorkerObservedStderrBytes worker @?= 0
    assertBool "capability probe observed no stdout"
      $ Session.lengthSMTLibReadyWorkerObservedStdoutBytes worker > 0
    Session.lengthSMTLibReadyWorkerCapabilityTranscriptByteCount worker @?=
      Session.lengthSMTLibReadyWorkerObservedStdoutBytes worker
    BS.length (Session.lengthSMTLibReadyWorkerCapabilityTranscriptSHA256 worker)
      @?= 32
    let completePolicy = Fingerprint.fingerprintCanonicalBytes
          $ Execution.lengthSMTLibExecutionPolicyFingerprint execution
        readyIdentity = Fingerprint.fingerprintCanonicalBytes
          $ Session.lengthSMTLibReadyWorkerIdentityFingerprint worker
    Session.lengthSMTLibReadyWorkerSchemaTag @?=
      ascii "djex-length-z3-capability-probed-ready-worker/v4"
    countContiguous completePolicy readyIdentity @?= 1
    pure workspace
  workspace <- expectRight scoped
  retained <- doesPathExist workspace
  assertBool "successful Session scope retained its workspace" $ not retained

assertLiveMatchingDigest :: IO ()
assertLiveMatchingDigest = withFakeZ3Mode "healthy" $ \executable image -> do
  let digest = SHA256.hash image
  config <- liveSessionConfig executable (Just digest) id id
  scoped <- runReadyWorkerBounded 6000000 config $ \worker -> do
    Session.lengthSMTLibReadyWorkerExecutableSHA256 worker @?= digest
  _ <- expectRight scoped
  pure ()

assertLiveChunkModes :: IO ()
assertLiveChunkModes = forM_ ["split-output", "drip-output"] $ \mode ->
  withFakeZ3Mode mode $ \executable _ -> do
    config <- liveSessionConfig executable Nothing id id
    scoped <- runReadyWorkerBounded 7000000 config $ \worker -> do
      Session.lengthSMTLibReadyWorkerObservedStderrBytes worker @?= 0
      assertBool (mode ++ " produced no capability transcript")
        $ Session.lengthSMTLibReadyWorkerCapabilityTranscriptByteCount worker > 0
      Session.lengthSMTLibReadyWorkerCapabilityTranscriptByteCount worker @?=
        Session.lengthSMTLibReadyWorkerObservedStdoutBytes worker
      pure $ Session.lengthSMTLibReadyWorkerWorkingDirectory worker
    workspace <- expectRight scoped
    retained <- doesPathExist workspace
    assertBool (mode ++ " retained its workspace") $ not retained

assertLiveDigestMismatch :: IO ()
assertLiveDigestMismatch = withFakeZ3Mode "healthy" $ \executable image -> do
  let mismatched = alterDigest $ SHA256.hash image
  config <- liveSessionConfig executable (Just mismatched) id id
  scoped <- runReadyWorkerBounded 6000000 config $ \_ ->
    assertFailure "digest mismatch reached the worker callback"
  cleanup <- expectProcessScopeFailure
    Process.LengthSMTLibProcessSnapshotPhase
    Process.LengthSMTLibProcessExecutableDigestMismatch
    Nothing scoped
  spawned <- doesPathExist $ fakeZ3EventPath executable
  assertBool "digest mismatch spawned the fake worker" $ not spawned
  Session.lengthSMTLibSessionProcessCleanupStatus cleanup @?= Nothing
  Session.lengthSMTLibSessionWorkspaceCleanupStatus cleanup @?=
    Session.LengthSMTLibSessionWorkspaceRemoved 0

assertLiveCapabilityFaults :: IO ()
assertLiveCapabilityFaults = forM_ faultCases $ \(mode, expected) ->
  withFakeZ3Mode mode $ \executable _ -> do
    config <- liveSessionConfig executable Nothing id id
    scoped <- runReadyWorkerBounded 6000000 config $ \_ ->
      assertFailure $ mode ++ " reached the worker callback"
    cleanup <- expectCapabilityScopeFailure expected scoped
    assertWorkspaceWasRemoved mode cleanup
 where
  faultCases =
    [ ( "wrong-echo"
      , Capability.LengthSMTLibCapabilityBarrierMismatch
          Capability.LengthSMTLibCapabilityStartupBarrier
      )
    , ( "wrong-status"
      , Capability.LengthSMTLibCapabilityUnexpectedExactResponse
          Capability.LengthSMTLibCapabilityCheckStatusPhase
      )
    , ( "wrong-value"
      , Capability.LengthSMTLibCapabilityUnexpectedExactResponse
          Capability.LengthSMTLibCapabilityInputValuePhase
      )
    , ( "unsolicited-reset-success"
      , Capability.LengthSMTLibCapabilityUnexpectedExactResponse
          Capability.LengthSMTLibCapabilityCheckStatusPhase
      )
    ]

liveStderrFaultTests :: TestTree
liveStderrFaultTests = testGroup
  "poison on one stderr byte and a finite pipe-sized flood"
  [testCase mode $ assertLiveStderrFault mode
  | mode <- ["stderr-byte", "stderr-flood"]]

assertLiveStderrFault :: String -> IO ()
assertLiveStderrFault mode =
  withFakeZ3Mode mode $ \executable _ -> do
    config <- liveSessionConfig executable Nothing id id
    scoped <- runReadyWorkerBounded 6000000 config $ \_ ->
      assertFailure $ mode ++ " reached the worker callback"
    cleanup <- expectObservedStderrFailure mode scoped
    assertWorkspaceWasRemoved mode cleanup

liveTerminationFaultTests :: TestTree
liveTerminationFaultTests = testGroup
  "bound EOF, exit, closed stdout, and deadline failures"
  ( [ testCase mode $ assertLiveTerminationFault mode
    | mode <-
        [ "immediate-eof"
        , "immediate-exit-nonzero"
        , "stdout-eof-hang"
        ]
    ]
    ++ [testCase "deadline" assertLiveDeadlineFault]
  )

assertLiveTerminationFault :: String -> IO ()
assertLiveTerminationFault mode =
  withFakeZ3Mode mode $ \executable _ -> do
    config <- liveSessionConfig executable Nothing id id
    scoped <- runReadyWorkerBounded 6000000 config $ \_ ->
      assertFailure $ mode ++ " reached the worker callback"
    cleanup <- expectTerminationFailure mode scoped
    assertWorkspaceWasRemoved mode cleanup

assertLiveDeadlineFault :: IO ()
assertLiveDeadlineFault =
  withFakeZ3Mode "hang" $ \executable _ -> do
    config <- liveSessionConfig executable Nothing id $ \source -> source
      { Session.lengthSMTLibSessionLimitSourceOpenerDeadlineMilliseconds =
          1000 }
    scoped <- runReadyWorkerBounded 5000000 config $ \_ ->
      assertFailure "hung worker reached the callback"
    cleanup <- expectDeadlineScopeFailure scoped
    assertWorkspaceWasRemoved "hang" cleanup

assertLiveStubbornCleanup :: IO ()
assertLiveStubbornCleanup = withFakeZ3Mode "stubborn-eof"
  $ \executable _ -> do
    config <- liveSessionConfig executable Nothing id id
    scoped <- runReadyWorkerBounded 5000000 config $ \worker -> do
      present <- doesDirectoryExist
        $ Session.lengthSMTLibReadyWorkerWorkingDirectory worker
      assertBool "stubborn worker callback workspace was missing" present
    _ <- expectRight scoped
    pure ()

assertLiveExecutableByteCap :: IO ()
assertLiveExecutableByteCap = withFakeZ3Mode "healthy"
  $ \executable image -> do
    let imageBytes = byteStringLength image
        withMaximum maximumBytes source = source
          { Process.lengthSMTLibProcessLimitSourceExecutableBytes =
              maximumBytes }
    assertBool "fake executable unexpectedly had at most one byte"
      $ imageBytes > 1
    exactConfig <- liveSessionConfig executable Nothing
      (withMaximum imageBytes) id
    exact <- runReadyWorkerBounded 6000000 exactConfig $ \worker -> pure
      $ Session.lengthSMTLibReadyWorkerExecutableByteCount worker
    observed <- expectRight exact
    observed @?= imageBytes
    removeFile $ fakeZ3EventPath executable

    let admitted = imageBytes - 1
    overflowConfig <- liveSessionConfig executable Nothing
      (withMaximum admitted) id
    overflow <- runReadyWorkerBounded 6000000 overflowConfig $ \_ ->
      assertFailure "maximum-plus-one executable reached the callback"
    cleanup <- expectProcessScopeFailure
      Process.LengthSMTLibProcessSnapshotPhase
      Process.LengthSMTLibProcessExecutableByteLimitExceeded
      (Just imageBytes) overflow
    spawned <- doesPathExist $ fakeZ3EventPath executable
    assertBool "executable maximum-plus-one failure spawned the fake worker"
      $ not spawned
    Session.lengthSMTLibSessionProcessCleanupStatus cleanup @?= Nothing
    Session.lengthSMTLibSessionWorkspaceCleanupStatus cleanup @?=
      Session.LengthSMTLibSessionWorkspaceRemoved 0

assertLiveReadyIdentityByteCap :: IO ()
assertLiveReadyIdentityByteCap = withFakeZ3Mode "healthy"
  $ \executable _ -> do
    let maximumBytes = 1
        withMaximum source = source
          { Session.lengthSMTLibSessionLimitSourceIdentityFingerprintBytes =
              maximumBytes }
    overflowConfig <- liveSessionConfig executable Nothing id withMaximum
    overflow <- runReadyWorkerBounded 6000000 overflowConfig $ \_ ->
      assertFailure "maximum-plus-one ready identity reached the callback"
    case overflow of
      Left scope -> do
        Session.lengthSMTLibSessionScopePrimaryError scope @?=
          Session.LengthSMTLibSessionIdentityFingerprintByteLimitExceeded
            maximumBytes (maximumBytes + 1)
        let cleanup = Session.lengthSMTLibSessionScopeCleanupStatus scope
        case Session.lengthSMTLibSessionProcessCleanupStatus cleanup of
          Nothing -> assertFailure
            "ready identity rejection omitted process cleanup"
          Just processCleanup -> do
            assertBool "ready identity rejection left process cleanup incomplete"
              $ Process.lengthSMTLibProcessCleanupEscalation processCleanup /=
                  Process.LengthSMTLibProcessCleanupIncomplete
            Process.lengthSMTLibProcessCleanupFailureCount processCleanup @?= 0
            Process.lengthSMTLibProcessCleanupReadersStopped processCleanup @?=
              True
        Session.lengthSMTLibSessionWorkspaceCleanupStatus cleanup @?=
          Session.LengthSMTLibSessionWorkspaceRemoved 0
      Right _ -> assertFailure "oversized ready identity was admitted"

assertLiveIdentityFreshness :: IO ()
assertLiveIdentityFreshness = withFakeZ3Mode "healthy"
  $ \executable _ -> do
    config <- liveSessionConfig executable Nothing id id
    first <- expectRight =<< runReadyWorkerBounded 6000000 config
      (pure . Session.lengthSMTLibReadyWorkerIdentityFingerprint)
    second <- expectRight =<< runReadyWorkerBounded 6000000 config
      (pure . Session.lengthSMTLibReadyWorkerIdentityFingerprint)
    assertBool "two independently opened workers shared an identity"
      $ first /= second

posixWorkspaceReplacementTest :: TestTree
posixWorkspaceReplacementTest
  | SystemInfo.os == "mingw32" = testGroup
      "POSIX workspace replacement (not available on Windows)" []
  | otherwise = testCase
      "retain a replaced callback root without following its symlink"
      assertLivePosixWorkspaceReplacement

assertLivePosixWorkspaceReplacement :: IO ()
assertLivePosixWorkspaceReplacement =
  withFakeZ3Mode "healthy" $ \executable _ ->
    withFreshTestDirectory $ \attackRoot -> do
      let externalDirectory = attackRoot </> "external"
          sentinelPath = externalDirectory </> "sentinel"
          movedWorkspace = attackRoot </> "moved-workspace"
      createDirectory externalDirectory
      BS.writeFile sentinelPath "external-sentinel"
      workspace <- bracket
        (newIORef Nothing)
        (cleanupWorkspaceReplacement
          movedWorkspace externalDirectory sentinelPath)
        $ \workspaceRef -> do
            config <- liveSessionConfig executable Nothing id id
            scoped <- runReadyWorkerBounded 6000000 config $ \worker -> do
              let original =
                    Session.lengthSMTLibReadyWorkerWorkingDirectory worker
              writeIORef workspaceRef $ Just original
              renameDirectory original movedWorkspace
              createDirectoryLink externalDirectory original
            original <- readIORef workspaceRef >>= maybe
              (assertFailure "workspace replacement callback was not reached")
              pure
            case scoped of
              Left scope -> do
                Session.lengthSMTLibSessionScopePrimaryError scope @?=
                  Session.LengthSMTLibSessionCleanupFailure
                Session.lengthSMTLibSessionWorkspaceCleanupStatus
                    (Session.lengthSMTLibSessionScopeCleanupStatus scope) @?=
                  Session.LengthSMTLibSessionWorkspaceRetained
                    Session.LengthSMTLibSessionWorkspacePostconditionFailed
                    Nothing
              Right () -> assertFailure
                "replaced workspace root passed Session cleanup"
            linked <- pathIsSymbolicLink original
            assertBool "Session removed the substituted workspace symlink"
              linked
            moved <- doesDirectoryExist movedWorkspace
            assertBool "Session removed the descriptor-owned moved workspace"
              moved
            sentinel <- BS.readFile sentinelPath
            sentinel @?= "external-sentinel"
            pure original
      oldPathPresent <- doesPathExist workspace
      oldPathLink <- symbolicLinkExists workspace
      movedPathPresent <- doesPathExist movedWorkspace
      externalPresent <- doesPathExist externalDirectory
      assertBool "test cleanup retained the substituted workspace path"
        $ not oldPathPresent && not oldPathLink
      assertBool "test cleanup retained the moved workspace"
        $ not movedPathPresent
      assertBool "test cleanup retained the external sentinel directory"
        $ not externalPresent

cleanupWorkspaceReplacement
  :: FilePath
  -> FilePath
  -> FilePath
  -> IORef (Maybe FilePath)
  -> IO ()
cleanupWorkspaceReplacement movedWorkspace externalDirectory sentinelPath
    workspaceRef = do
  workspace <- readIORef workspaceRef
  case workspace of
    Nothing -> pure ()
    Just original -> do
      linked <- symbolicLinkExists original
      if linked
        then ignoreIOError $ removeFile original
        else pure ()
  moved <- doesDirectoryExist movedWorkspace
  if moved
    then ignoreIOError $ removeDirectory movedWorkspace
    else pure ()
  sentinel <- doesFileExist sentinelPath
  if sentinel
    then ignoreIOError $ removeFile sentinelPath
    else pure ()
  external <- doesDirectoryExist externalDirectory
  if external
    then ignoreIOError $ removeDirectory externalDirectory
    else pure ()

symbolicLinkExists :: FilePath -> IO Bool
symbolicLinkExists path = do
  observed <- tryIOError $ pathIsSymbolicLink path
  pure $ case observed of
    Left _ -> False
    Right linked -> linked

ignoreIOError :: IO value -> IO ()
ignoreIOError action = do
  _ <- tryIOError action
  pure ()

callbackExceptionTests :: TestTree
callbackExceptionTests = testGroup "callback exception cleanup"
  [ testCase "rethrow a synchronous exception after removing the workspace"
      assertLiveSynchronousCallbackException
  , testCase "rethrow a throwTo exception after removing the workspace"
      assertLiveAsynchronousCallbackException
  , testCase
      "public facade rethrows a synchronous exception after workspace cleanup"
      assertLiveFacadeSynchronousCallbackException
  , testCase
      "public facade rethrows a throwTo exception after workspace cleanup"
      assertLiveFacadeAsynchronousCallbackException
  ]

data LiveSynchronousCallbackException = LiveSynchronousCallbackException
  deriving (Eq, Show)

instance Exception LiveSynchronousCallbackException

data LiveAsynchronousCallbackException = LiveAsynchronousCallbackException
  deriving (Eq, Show)

instance Exception LiveAsynchronousCallbackException

assertLiveSynchronousCallbackException :: IO ()
assertLiveSynchronousCallbackException =
  withFakeZ3Mode "healthy" $ \executable _ -> do
    workspaceRef <- newIORef Nothing
    config <- liveSessionConfig executable Nothing id id
    attempted <- try $ runReadyWorkerBounded 6000000 config $ \worker -> do
      writeIORef workspaceRef $ Just
        $ Session.lengthSMTLibReadyWorkerWorkingDirectory worker
      throwIO LiveSynchronousCallbackException
    case attempted of
      Left failure -> failure @?= LiveSynchronousCallbackException
      Right _ -> assertFailure
        "synchronous callback exception was not rethrown"
    assertCapturedWorkspaceRemoved
      "synchronous callback exception" workspaceRef

assertLiveAsynchronousCallbackException :: IO ()
assertLiveAsynchronousCallbackException =
  withFakeZ3Mode "healthy" $ \executable _ -> do
    workspaceRef <- newIORef Nothing
    target <- myThreadId
    throwerFinished <- newEmptyMVar
    callbackBlock <- newEmptyMVar
    config <- liveSessionConfig executable Nothing id id
    attempted <- try $ runReadyWorkerBounded 6000000 config $ \worker -> do
      writeIORef workspaceRef $ Just
        $ Session.lengthSMTLibReadyWorkerWorkingDirectory worker
      _ <- forkIO $ throwTo target LiveAsynchronousCallbackException
        `finally` putMVar throwerFinished ()
      takeMVar callbackBlock
    case attempted of
      Left failure -> failure @?= LiveAsynchronousCallbackException
      Right _ -> assertFailure "throwTo callback exception was not rethrown"
    thrower <- timeout 1000000 $ takeMVar throwerFinished
    case thrower of
      Nothing -> assertFailure "throwTo callback helper did not terminate"
      Just () -> pure ()
    assertCapturedWorkspaceRemoved "throwTo callback exception" workspaceRef

assertLiveFacadeSynchronousCallbackException :: IO ()
assertLiveFacadeSynchronousCallbackException =
  withFakeZ3Mode "healthy" $ \executable _ -> do
    execution <- liveFacadeExecutionConfig executable
      PublicExecution.LengthSMTLibInputValuesAfterSatisfiable
    attempted <- try $ runLiveFacadeSessionBounded 8000000 execution
      $ \_ -> throwIO LiveSynchronousCallbackException
    case attempted of
      Left failure -> failure @?= LiveSynchronousCallbackException
      Right _ -> assertFailure
        "public facade did not rethrow the synchronous callback exception"
    assertFakeWorkerWorkspaceRemoved
      "public synchronous callback exception" executable

assertLiveFacadeAsynchronousCallbackException :: IO ()
assertLiveFacadeAsynchronousCallbackException =
  withFakeZ3Mode "healthy" $ \executable _ -> do
    target <- myThreadId
    throwerFinished <- newEmptyMVar
    callbackBlock <- newEmptyMVar
    execution <- liveFacadeExecutionConfig executable
      PublicExecution.LengthSMTLibInputValuesAfterSatisfiable
    attempted <- try $ runLiveFacadeSessionBounded 8000000 execution $ \_ -> do
      _ <- forkIO $ throwTo target LiveAsynchronousCallbackException
        `finally` putMVar throwerFinished ()
      takeMVar callbackBlock
    case attempted of
      Left failure -> failure @?= LiveAsynchronousCallbackException
      Right _ -> assertFailure
        "public facade did not rethrow the throwTo callback exception"
    thrower <- timeout 1000000 $ takeMVar throwerFinished
    case thrower of
      Nothing -> assertFailure "public facade throwTo helper did not terminate"
      Just () -> pure ()
    assertFakeWorkerWorkspaceRemoved
      "public throwTo callback exception" executable

assertFakeWorkerWorkspaceRemoved :: String -> FilePath -> IO ()
assertFakeWorkerWorkspaceRemoved label executable = do
  events <- readFakeZ3Events executable
  start <- expectFakeZ3Event "start" events
  workspace <- case fakeZ3FieldValues "cwd" start of
    [raw] -> pure $ BSC.unpack raw
    _ -> assertFailure $ label ++ " trace omitted its unique cwd"
  retained <- doesPathExist workspace
  assertBool (label ++ " retained its hidden workspace") $ not retained

assertCapturedWorkspaceRemoved
  :: String
  -> IORef (Maybe FilePath)
  -> IO ()
assertCapturedWorkspaceRemoved label workspaceRef = do
  workspace <- readIORef workspaceRef >>= maybe
    (assertFailure $ label ++ " callback was not reached") pure
  retained <- doesPathExist workspace
  assertBool (label ++ " retained its Session workspace") $ not retained

liveSessionConfig
  :: FilePath
  -> Maybe ByteString
  -> (Process.LengthSMTLibProcessLimitSource
      -> Process.LengthSMTLibProcessLimitSource)
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> IO Session.LengthSMTLibSessionConfig
liveSessionConfig executable expectedDigest changeProcess changeSession = do
  execution <- liveExecutionConfig executable expectedDigest
  liveSessionConfigWithExecution execution changeProcess changeSession

descriptorBoundLiveSessionConfig
  :: FilePath
  -> Maybe ByteString
  -> (Process.LengthSMTLibProcessLimitSource
      -> Process.LengthSMTLibProcessLimitSource)
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> IO Session.LengthSMTLibSessionConfig
descriptorBoundLiveSessionConfig executable expectedDigest
    changeProcess changeSession = do
  execution <- descriptorBoundLiveExecutionConfig executable expectedDigest
  liveSessionConfigWithExecution execution changeProcess changeSession

effectiveIDDescriptorBoundLiveSessionConfig
  :: FilePath
  -> Maybe ByteString
  -> (Process.LengthSMTLibProcessLimitSource
      -> Process.LengthSMTLibProcessLimitSource)
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> IO Session.LengthSMTLibSessionConfig
effectiveIDDescriptorBoundLiveSessionConfig executable expectedDigest
    changeProcess changeSession = do
  execution <- effectiveIDDescriptorBoundLiveExecutionConfig
    executable expectedDigest
  liveSessionConfigWithExecution execution changeProcess changeSession

execveCheckDescriptorBoundLiveSessionConfig
  :: FilePath
  -> Maybe ByteString
  -> (Process.LengthSMTLibProcessLimitSource
      -> Process.LengthSMTLibProcessLimitSource)
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> IO Session.LengthSMTLibSessionConfig
execveCheckDescriptorBoundLiveSessionConfig executable expectedDigest
    changeProcess changeSession = do
  execution <- execveCheckDescriptorBoundLiveExecutionConfig
    executable expectedDigest
  liveSessionConfigWithExecution execution changeProcess changeSession

liveSessionConfigWithExecution
  :: Execution.LengthSMTLibExecutionConfig
  -> (Process.LengthSMTLibProcessLimitSource
      -> Process.LengthSMTLibProcessLimitSource)
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> IO Session.LengthSMTLibSessionConfig
liveSessionConfigWithExecution execution changeProcess changeSession = do
  process <- expectRight $ Process.mkLengthSMTLibProcessLimits
    $ changeProcess Process.defaultLengthSMTLibProcessLimitSource
  session <- expectRight $ Session.mkLengthSMTLibSessionLimits
    $ changeSession
    $ Session.defaultLengthSMTLibSessionLimitSource
      { Session.lengthSMTLibSessionLimitSourceOpenerDeadlineMilliseconds =
          3000 }
  expectRight $ Session.sealLengthSMTLibSessionConfig
    session process Capability.defaultLengthSMTLibCapabilityLimits
    Protocol.defaultLengthSMTLibProtocolLimits execution

-- | Test-only entry point for typed public-facade fixtures owned by @Spec.hs@.
-- The concrete executable is exposed only to the test callback so it can
-- inspect the fake worker's output-only sidecar; the public session remains
-- the sole query authority.
withLiveFacadeSession
  :: String
  -> PublicExecution.LengthSMTLibArtifactPolicy
  -> (forall epoch.
      FilePath
      -> Live.LengthSMTLibLiveSession epoch
      -> IO result)
  -> IO (Either Live.LengthSMTLibLiveSessionError result)
withLiveFacadeSession mode artifactPolicy use =
  withFakeZ3Mode mode $ \executable _ -> do
    execution <- liveFacadeExecutionConfig executable artifactPolicy
    runLiveFacadeSessionBounded 8000000 execution $ use executable

-- | Descriptor-bound twin of 'withLiveFacadeSession'.  Every response,
-- timeout, resource, artifact, and query policy remains identical; only the
-- sealed launch strategy differs.
withDescriptorBoundLiveFacadeSession
  :: String
  -> PublicExecution.LengthSMTLibArtifactPolicy
  -> (forall epoch.
      FilePath
      -> Live.LengthSMTLibLiveSession epoch
      -> IO result)
  -> IO (Either Live.LengthSMTLibLiveSessionError result)
withDescriptorBoundLiveFacadeSession mode artifactPolicy use =
  withFakeZ3Mode mode $ \executable _ -> do
    execution <- descriptorBoundLiveFacadeExecutionConfig
      executable artifactPolicy
    runLiveFacadeSessionBounded 8000000 execution $ use executable

withEffectiveIDDescriptorBoundLiveFacadeSession
  :: String
  -> PublicExecution.LengthSMTLibArtifactPolicy
  -> (forall epoch.
      FilePath
      -> Live.LengthSMTLibLiveSession epoch
      -> IO result)
  -> IO (Either Live.LengthSMTLibLiveSessionError result)
withEffectiveIDDescriptorBoundLiveFacadeSession mode artifactPolicy use =
  withFakeZ3Mode mode $ \executable _ -> do
    execution <- effectiveIDDescriptorBoundLiveFacadeExecutionConfig
      executable artifactPolicy
    runLiveFacadeSessionBounded 8000000 execution $ use executable

withExecveCheckDescriptorBoundLiveFacadeSession
  :: String
  -> PublicExecution.LengthSMTLibArtifactPolicy
  -> (forall epoch.
      FilePath
      -> Live.LengthSMTLibLiveSession epoch
      -> IO result)
  -> IO (Either Live.LengthSMTLibLiveSessionError result)
withExecveCheckDescriptorBoundLiveFacadeSession mode artifactPolicy use =
  withFakeZ3Mode mode $ \executable _ -> do
    execution <- execveCheckDescriptorBoundLiveFacadeExecutionConfig
      executable artifactPolicy
    runLiveFacadeSessionBounded 8000000 execution $ use executable

liveFacadeExecutionConfig
  :: FilePath
  -> PublicExecution.LengthSMTLibArtifactPolicy
  -> IO PublicExecution.LengthSMTLibExecutionConfig
liveFacadeExecutionConfig executable artifactPolicy = expectRight
  $ liveFacadeExecutionConfigWith
      PublicExecution.mkLengthSMTLibExecutionConfig
      executable artifactPolicy

descriptorBoundLiveFacadeExecutionConfig
  :: FilePath
  -> PublicExecution.LengthSMTLibArtifactPolicy
  -> IO PublicExecution.LengthSMTLibExecutionConfig
descriptorBoundLiveFacadeExecutionConfig executable artifactPolicy =
  expectRight $ liveFacadeExecutionConfigWith
    PublicExecution.mkLengthSMTLibDescriptorBoundExecutionConfig
    executable artifactPolicy

effectiveIDDescriptorBoundLiveFacadeExecutionConfig
  :: FilePath
  -> PublicExecution.LengthSMTLibArtifactPolicy
  -> IO PublicExecution.LengthSMTLibExecutionConfig
effectiveIDDescriptorBoundLiveFacadeExecutionConfig executable artifactPolicy =
  expectRight $ liveFacadeExecutionConfigWith
    PublicExecution.mkLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessExecutionConfig
    executable artifactPolicy

execveCheckDescriptorBoundLiveFacadeExecutionConfig
  :: FilePath
  -> PublicExecution.LengthSMTLibArtifactPolicy
  -> IO PublicExecution.LengthSMTLibExecutionConfig
execveCheckDescriptorBoundLiveFacadeExecutionConfig executable artifactPolicy =
  expectRight $ liveFacadeExecutionConfigWith
    PublicExecution.mkLengthSMTLibDescriptorBoundExecveCheckExecutableAccessExecutionConfig
    executable artifactPolicy

liveFacadeExecutionConfigWith
  :: (PublicExecution.LengthSMTLibExecutionLimits
      -> PublicExecution.LengthSMTLibExecutionConfigSource
      -> Either
          PublicExecution.LengthSMTLibExecutionConfigError
          PublicExecution.LengthSMTLibExecutionConfig)
  -> FilePath
  -> PublicExecution.LengthSMTLibArtifactPolicy
  -> Either
      PublicExecution.LengthSMTLibExecutionConfigError
      PublicExecution.LengthSMTLibExecutionConfig
liveFacadeExecutionConfigWith seal executable artifactPolicy =
  seal
      PublicExecution.defaultLengthSMTLibExecutionLimits
    $ (PublicExecution.defaultLengthSMTLibExecutionConfigSource
      executable Nothing)
    { PublicExecution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
        liveSolverTimeoutMilliseconds
    , PublicExecution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
        liveSolverResourceLimit
    , PublicExecution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
        artifactPolicy
    , PublicExecution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
        liveQueryHostDeadlineMilliseconds
    }

runLiveFacadeSessionBounded
  :: Int
  -> PublicExecution.LengthSMTLibExecutionConfig
  -> (forall epoch. Live.LengthSMTLibLiveSession epoch -> IO result)
  -> IO (Either Live.LengthSMTLibLiveSessionError result)
runLiveFacadeSessionBounded microseconds execution use = do
  bounded <- timeout microseconds
    $ Live.withLengthSMTLibLiveSession execution use
  case bounded of
    Nothing -> assertFailure $ "public live facade exceeded outer bound of " ++
      show microseconds ++ " microseconds"
    Just result -> pure result

-- | Test-only entry point for typed live-query fixtures owned by @Spec.hs@.
-- The fake mode remains selected solely by the copied executable basename.
withLiveQueryWorker
  :: String
  -> Execution.LengthSMTLibArtifactPolicy
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> (forall epoch.
      FilePath
      -> Session.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO (Either Session.LengthSMTLibSessionScopeError result)
withLiveQueryWorker mode artifactPolicy changeSession use =
  withLiveQueryWorkerLimits mode artifactPolicy id changeSession use

-- | Test-only entry point for independently nondefault process and Session
-- limits while retaining the same exact live-query fixture construction.
withLiveQueryWorkerLimits
  :: String
  -> Execution.LengthSMTLibArtifactPolicy
  -> (Process.LengthSMTLibProcessLimitSource
      -> Process.LengthSMTLibProcessLimitSource)
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> (forall epoch.
      FilePath
      -> Session.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO (Either Session.LengthSMTLibSessionScopeError result)
withLiveQueryWorkerLimits mode artifactPolicy changeProcess changeSession use =
  withFakeZ3Mode mode $ \executable _ -> do
    execution <- liveExecutionConfigWith executable Nothing $ \source -> source
      { Execution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
          artifactPolicy
      , Execution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
          liveQueryHostDeadlineMilliseconds
      }
    process <- expectRight $ Process.mkLengthSMTLibProcessLimits
      $ changeProcess Process.defaultLengthSMTLibProcessLimitSource
    session <- expectRight $ Session.mkLengthSMTLibSessionLimits
      $ changeSession
      $ Session.defaultLengthSMTLibSessionLimitSource
          { Session.lengthSMTLibSessionLimitSourceOpenerDeadlineMilliseconds =
              3000 }
    config <- expectRight $ Session.sealLengthSMTLibSessionConfig
      session process Capability.defaultLengthSMTLibCapabilityLimits
      Protocol.defaultLengthSMTLibProtocolLimits execution
    runReadyWorkerBounded 8000000 config $ use executable

-- | Descriptor-bound twin of 'withLiveQueryWorker'.  The helper deliberately
-- duplicates the legacy fixture shape so query identities and wire bytes can
-- be compared with only the launch authority changed.
withDescriptorBoundLiveQueryWorker
  :: String
  -> Execution.LengthSMTLibArtifactPolicy
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> (forall epoch.
      FilePath
      -> Session.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO (Either Session.LengthSMTLibSessionScopeError result)
withDescriptorBoundLiveQueryWorker mode artifactPolicy changeSession use =
  withFakeZ3Mode mode $ \executable _ -> do
    execution <- descriptorBoundLiveExecutionConfigWith executable Nothing
      $ \source -> source
          { Execution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
              artifactPolicy
          , Execution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
              liveQueryHostDeadlineMilliseconds
          }
    process <- expectRight $ Process.mkLengthSMTLibProcessLimits
      Process.defaultLengthSMTLibProcessLimitSource
    session <- expectRight $ Session.mkLengthSMTLibSessionLimits
      $ changeSession
      $ Session.defaultLengthSMTLibSessionLimitSource
          { Session.lengthSMTLibSessionLimitSourceOpenerDeadlineMilliseconds =
              3000 }
    config <- expectRight $ Session.sealLengthSMTLibSessionConfig
      session process Capability.defaultLengthSMTLibCapabilityLimits
      Protocol.defaultLengthSMTLibProtocolLimits execution
    runReadyWorkerBounded 8000000 config $ use executable

withEffectiveIDDescriptorBoundLiveQueryWorker
  :: String
  -> Execution.LengthSMTLibArtifactPolicy
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> (forall epoch.
      FilePath
      -> Session.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO (Either Session.LengthSMTLibSessionScopeError result)
withEffectiveIDDescriptorBoundLiveQueryWorker
    mode artifactPolicy changeSession use =
  withFakeZ3Mode mode $ \executable _ -> do
    execution <- effectiveIDDescriptorBoundLiveExecutionConfigWith
      executable Nothing $ \source -> source
        { Execution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
            artifactPolicy
        , Execution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
            liveQueryHostDeadlineMilliseconds
        }
    process <- expectRight $ Process.mkLengthSMTLibProcessLimits
      Process.defaultLengthSMTLibProcessLimitSource
    session <- expectRight $ Session.mkLengthSMTLibSessionLimits
      $ changeSession
      $ Session.defaultLengthSMTLibSessionLimitSource
          { Session.lengthSMTLibSessionLimitSourceOpenerDeadlineMilliseconds =
              3000 }
    config <- expectRight $ Session.sealLengthSMTLibSessionConfig
      session process Capability.defaultLengthSMTLibCapabilityLimits
      Protocol.defaultLengthSMTLibProtocolLimits execution
    runReadyWorkerBounded 8000000 config $ use executable

withExecveCheckDescriptorBoundLiveQueryWorker
  :: String
  -> Execution.LengthSMTLibArtifactPolicy
  -> (Session.LengthSMTLibSessionLimitSource
      -> Session.LengthSMTLibSessionLimitSource)
  -> (forall epoch.
      FilePath
      -> Session.LengthSMTLibReadyWorker epoch
      -> IO result)
  -> IO (Either Session.LengthSMTLibSessionScopeError result)
withExecveCheckDescriptorBoundLiveQueryWorker
    mode artifactPolicy changeSession use =
  withFakeZ3Mode mode $ \executable _ -> do
    execution <- execveCheckDescriptorBoundLiveExecutionConfigWith
      executable Nothing $ \source -> source
        { Execution.lengthSMTLibExecutionConfigSourceArtifactPolicy =
            artifactPolicy
        , Execution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
            liveQueryHostDeadlineMilliseconds
        }
    process <- expectRight $ Process.mkLengthSMTLibProcessLimits
      Process.defaultLengthSMTLibProcessLimitSource
    session <- expectRight $ Session.mkLengthSMTLibSessionLimits
      $ changeSession
      $ Session.defaultLengthSMTLibSessionLimitSource
          { Session.lengthSMTLibSessionLimitSourceOpenerDeadlineMilliseconds =
              3000 }
    config <- expectRight $ Session.sealLengthSMTLibSessionConfig
      session process Capability.defaultLengthSMTLibCapabilityLimits
      Protocol.defaultLengthSMTLibProtocolLimits execution
    runReadyWorkerBounded 8000000 config $ use executable

liveExecutionConfig
  :: FilePath
  -> Maybe ByteString
  -> IO Execution.LengthSMTLibExecutionConfig
liveExecutionConfig executable expectedDigest =
  liveExecutionConfigWith executable expectedDigest id

descriptorBoundLiveExecutionConfig
  :: FilePath
  -> Maybe ByteString
  -> IO Execution.LengthSMTLibExecutionConfig
descriptorBoundLiveExecutionConfig executable expectedDigest =
  descriptorBoundLiveExecutionConfigWith executable expectedDigest id

effectiveIDDescriptorBoundLiveExecutionConfig
  :: FilePath
  -> Maybe ByteString
  -> IO Execution.LengthSMTLibExecutionConfig
effectiveIDDescriptorBoundLiveExecutionConfig executable expectedDigest =
  effectiveIDDescriptorBoundLiveExecutionConfigWith
    executable expectedDigest id

execveCheckDescriptorBoundLiveExecutionConfig
  :: FilePath
  -> Maybe ByteString
  -> IO Execution.LengthSMTLibExecutionConfig
execveCheckDescriptorBoundLiveExecutionConfig executable expectedDigest =
  execveCheckDescriptorBoundLiveExecutionConfigWith
    executable expectedDigest id

liveExecutionConfigWith
  :: FilePath
  -> Maybe ByteString
  -> (Execution.LengthSMTLibExecutionConfigSource
      -> Execution.LengthSMTLibExecutionConfigSource)
  -> IO Execution.LengthSMTLibExecutionConfig
liveExecutionConfigWith executable expectedDigest changeSource =
  liveExecutionConfigWithSealer Execution.mkLengthSMTLibExecutionConfig
    executable expectedDigest changeSource

descriptorBoundLiveExecutionConfigWith
  :: FilePath
  -> Maybe ByteString
  -> (Execution.LengthSMTLibExecutionConfigSource
      -> Execution.LengthSMTLibExecutionConfigSource)
  -> IO Execution.LengthSMTLibExecutionConfig
descriptorBoundLiveExecutionConfigWith executable expectedDigest changeSource =
  liveExecutionConfigWithSealer
    Execution.mkLengthSMTLibDescriptorBoundExecutionConfig
    executable expectedDigest changeSource

effectiveIDDescriptorBoundLiveExecutionConfigWith
  :: FilePath
  -> Maybe ByteString
  -> (Execution.LengthSMTLibExecutionConfigSource
      -> Execution.LengthSMTLibExecutionConfigSource)
  -> IO Execution.LengthSMTLibExecutionConfig
effectiveIDDescriptorBoundLiveExecutionConfigWith
    executable expectedDigest changeSource =
  liveExecutionConfigWithSealer
    Execution.mkLengthSMTLibDescriptorBoundEffectiveIDExecutableAccessExecutionConfig
    executable expectedDigest changeSource

execveCheckDescriptorBoundLiveExecutionConfigWith
  :: FilePath
  -> Maybe ByteString
  -> (Execution.LengthSMTLibExecutionConfigSource
      -> Execution.LengthSMTLibExecutionConfigSource)
  -> IO Execution.LengthSMTLibExecutionConfig
execveCheckDescriptorBoundLiveExecutionConfigWith
    executable expectedDigest changeSource =
  liveExecutionConfigWithSealer
    Execution.mkLengthSMTLibDescriptorBoundExecveCheckExecutableAccessExecutionConfig
    executable expectedDigest changeSource

liveExecutionConfigWithSealer
  :: (Execution.LengthSMTLibExecutionLimits
      -> Execution.LengthSMTLibExecutionConfigSource
      -> Either
          Execution.LengthSMTLibExecutionConfigError
          Execution.LengthSMTLibExecutionConfig)
  -> FilePath
  -> Maybe ByteString
  -> (Execution.LengthSMTLibExecutionConfigSource
      -> Execution.LengthSMTLibExecutionConfigSource)
  -> IO Execution.LengthSMTLibExecutionConfig
liveExecutionConfigWithSealer seal executable expectedDigest changeSource =
  expectRight $ seal
    Execution.defaultLengthSMTLibExecutionLimits
    $ changeSource
    $ (Execution.defaultLengthSMTLibExecutionConfigSource executable
        $ BS.unpack <$> expectedDigest)
      { Execution.lengthSMTLibExecutionConfigSourceSolverTimeoutMilliseconds =
          liveSolverTimeoutMilliseconds
      , Execution.lengthSMTLibExecutionConfigSourceSolverResourceLimit =
          liveSolverResourceLimit
      , Execution.lengthSMTLibExecutionConfigSourceHostDeadlineMilliseconds =
          liveHostDeadlineMilliseconds
      }

runReadyWorkerBounded
  :: Int
  -> Session.LengthSMTLibSessionConfig
  -> (forall epoch. Session.LengthSMTLibReadyWorker epoch -> IO result)
  -> IO (Either Session.LengthSMTLibSessionScopeError result)
runReadyWorkerBounded microseconds config use = do
  bounded <- timeout microseconds
    $ Session.withLengthSMTLibReadyWorker config use
  case bounded of
    Nothing -> assertFailure $ "live Session exceeded outer bound of " ++
      show microseconds ++ " microseconds"
    Just result -> pure result

withFakeZ3Mode
  :: String
  -> (FilePath -> ByteString -> IO result)
  -> IO result
withFakeZ3Mode mode action = withFreshTestDirectory $ \root -> do
  source <- findExecutable "djex-fake-z3" >>= maybe
    (assertFailure "cannot locate the djex-fake-z3 test build tool")
    canonicalizePath
  let target = root </> fakeZ3ExecutableName mode
  copyFile source target
  permissions <- getPermissions source
  setPermissions target $ setOwnerExecutable True permissions
  canonicalTarget <- canonicalizePath target
  image <- BS.readFile canonicalTarget
  action canonicalTarget image

withFreshTestDirectory :: (FilePath -> IO result) -> IO result
withFreshTestDirectory = bracket create removePathForcibly
 where
  create = do
    temporaryRoot <- getTemporaryDirectory
    (path, handle) <- openTempFile temporaryRoot "djex-fake-z3-fixture"
    hClose handle
    removeFile path
    createDirectory path
    canonicalizePath path

fakeZ3ExecutableName :: String -> FilePath
fakeZ3ExecutableName mode =
  "djex-fake-z3-" ++ mode ++ executableExtension
 where
  executableExtension
    | SystemInfo.os == "mingw32" = ".exe"
    | otherwise = ""

fakeZ3EventPath :: FilePath -> FilePath
fakeZ3EventPath executable = executable ++ ".events"

liveArgumentVector :: [String]
liveArgumentVector =
  [ "-in"
  , "-smt2"
  , "smtlib2_compliant=true"
  , "timeout=" ++ show liveSolverTimeoutMilliseconds
  , "rlimit=" ++ show liveSolverResourceLimit
  ]

liveSolverTimeoutMilliseconds :: Int
liveSolverTimeoutMilliseconds = 100

liveSolverResourceLimit :: Int
liveSolverResourceLimit = 4242

liveHostDeadlineMilliseconds :: Int
liveHostDeadlineMilliseconds = 400

liveQueryHostDeadlineMilliseconds :: Int
liveQueryHostDeadlineMilliseconds = 1000

alterDigest :: ByteString -> ByteString
alterDigest digest = case BS.uncons digest of
  Nothing -> BS.singleton 1
  Just (first, remaining) -> BS.cons
    (if first == 0 then 1 else 0) remaining

byteStringLength :: ByteString -> Natural
byteStringLength = fromIntegral . BS.length

expectProcessScopeFailure
  :: Process.LengthSMTLibProcessPhase
  -> Process.LengthSMTLibProcessFailureClass
  -> Maybe Natural
  -> Either Session.LengthSMTLibSessionScopeError value
  -> IO Session.LengthSMTLibSessionCleanupStatus
expectProcessScopeFailure expectedPhase expectedClass expectedObserved result =
  case result of
    Left scope -> case Session.lengthSMTLibSessionScopePrimaryError scope of
      Session.LengthSMTLibSessionProcessFailure failure -> do
        Process.lengthSMTLibProcessErrorPhase failure @?= expectedPhase
        Process.lengthSMTLibProcessErrorClass failure @?= expectedClass
        Process.lengthSMTLibProcessErrorObservedAtLeast failure @?=
          expectedObserved
        pure $ Session.lengthSMTLibSessionScopeCleanupStatus scope
      other -> assertFailure $ "unexpected Session primary failure: " ++
        show other
    Right _ -> assertFailure "expected a Session process failure"

expectCapabilityScopeFailure
  :: Capability.LengthSMTLibCapabilityError
  -> Either Session.LengthSMTLibSessionScopeError value
  -> IO Session.LengthSMTLibSessionCleanupStatus
expectCapabilityScopeFailure expected result = case result of
  Left scope -> case Session.lengthSMTLibSessionScopePrimaryError scope of
    Session.LengthSMTLibSessionCapabilityFailure actual -> do
      actual @?= expected
      pure $ Session.lengthSMTLibSessionScopeCleanupStatus scope
    other -> assertFailure $ "unexpected Session primary failure: " ++
      show other
  Right _ -> assertFailure "expected a Session capability failure"

expectObservedStderrFailure
  :: String
  -> Either Session.LengthSMTLibSessionScopeError value
  -> IO Session.LengthSMTLibSessionCleanupStatus
expectObservedStderrFailure mode result = case result of
  Left scope -> case Session.lengthSMTLibSessionScopePrimaryError scope of
    Session.LengthSMTLibSessionProcessFailure failure -> do
      Process.lengthSMTLibProcessErrorPhase failure @?=
        Process.LengthSMTLibProcessStderrPhase
      Process.lengthSMTLibProcessErrorClass failure @?=
        Process.LengthSMTLibProcessStderrObserved
      case Process.lengthSMTLibProcessErrorObservedAtLeast failure of
        Just observed -> assertBool (mode ++ " retained no stderr count")
          $ observed >= 1
        Nothing -> assertFailure $ mode ++ " omitted its stderr count"
      pure $ Session.lengthSMTLibSessionScopeCleanupStatus scope
    other -> assertFailure $ mode ++ " produced the wrong failure: " ++
      show other
  Right _ -> assertFailure $ mode ++ " unexpectedly opened"

expectTerminationFailure
  :: String
  -> Either Session.LengthSMTLibSessionScopeError value
  -> IO Session.LengthSMTLibSessionCleanupStatus
expectTerminationFailure mode result = case result of
  Left scope -> do
    let primary = Session.lengthSMTLibSessionScopePrimaryError scope
        acceptable = case primary of
          Session.LengthSMTLibSessionCapabilityFailure
              (Capability.LengthSMTLibCapabilityUnexpectedEOF
                Capability.LengthSMTLibCapabilityStartupBarrierPhase) -> True
          Session.LengthSMTLibSessionProcessFailure failure ->
            Process.lengthSMTLibProcessErrorClass failure `elem`
              [ Process.LengthSMTLibProcessStdoutEOF
              , Process.LengthSMTLibProcessStderrEOF
              , Process.LengthSMTLibProcessExited
              , Process.LengthSMTLibProcessWriteFailed
              ]
          _ -> False
    assertBool (mode ++ " produced an unrelated failure: " ++ show primary)
      acceptable
    pure $ Session.lengthSMTLibSessionScopeCleanupStatus scope
  Right _ -> assertFailure $ mode ++ " unexpectedly opened"

expectDeadlineScopeFailure
  :: Either Session.LengthSMTLibSessionScopeError value
  -> IO Session.LengthSMTLibSessionCleanupStatus
expectDeadlineScopeFailure result = case result of
  Left scope -> do
    let primary = Session.lengthSMTLibSessionScopePrimaryError scope
        processFailure = case primary of
          Session.LengthSMTLibSessionProcessFailure failure -> Just failure
          Session.LengthSMTLibSessionDeadlineFailure failure -> Just failure
          _ -> Nothing
    case processFailure of
      Nothing -> assertFailure $ "hung worker produced the wrong failure: " ++
        show primary
      Just failure -> Process.lengthSMTLibProcessErrorClass failure @?=
        Process.LengthSMTLibProcessDeadlineExceeded
    pure $ Session.lengthSMTLibSessionScopeCleanupStatus scope
  Right _ -> assertFailure "hung worker unexpectedly opened"

assertWorkspaceWasRemoved
  :: String
  -> Session.LengthSMTLibSessionCleanupStatus
  -> IO ()
assertWorkspaceWasRemoved label cleanup = case
    Session.lengthSMTLibSessionWorkspaceCleanupStatus cleanup of
  Session.LengthSMTLibSessionWorkspaceRemoved _ -> pure ()
  status -> assertFailure $ label ++ " retained its Session workspace: " ++
    show status

data FakeZ3Event = FakeZ3Event
  { fakeZ3EventTag :: ByteString
  , fakeZ3EventFields :: [(ByteString, ByteString)]
  }

readFakeZ3Events :: FilePath -> IO [FakeZ3Event]
readFakeZ3Events executable =
  expectRight . parseFakeZ3Events =<< BS.readFile (fakeZ3EventPath executable)

#ifdef DJEX_HAVE_DESCRIPTOR_BOUND_Z3_LAUNCH
-- The exec-status pipe closes when the kernel has installed the staged image,
-- before the newly scheduled child necessarily reaches its first user-space
-- write.  Under aggregate-suite load, wait for the complete start record
-- instead of treating that scheduler gap as a missing launch event.
readFakeZ3EventsAfterStart :: FilePath -> IO [FakeZ3Event]
readFakeZ3EventsAfterStart executable = do
  observed <- timeout 3000000 waitForStart
  case observed of
    Just events -> pure events
    Nothing -> readFakeZ3Events executable
 where
  waitForStart = do
    attempted <- tryIOError $ BS.readFile $ fakeZ3EventPath executable
    case attempted of
      Right bytes -> case parseFakeZ3Events bytes of
        Right events
          | any ((== "start") . fakeZ3EventTag) events -> pure events
        _ -> threadDelay 5000 >> waitForStart
      Left _ -> threadDelay 5000 >> waitForStart
#endif

parseFakeZ3Events :: ByteString -> Either String [FakeZ3Event]
parseFakeZ3Events bytes
  | BS.null bytes = Right []
  | otherwise = do
      (header, afterHeader) <- takeTraceLine bytes
      (tag, fieldCount) <- parseEventHeader header
      (fields, afterFields) <- parseTraceFields fieldCount afterHeader
      (end, remaining) <- takeTraceLine afterFields
      if end /= "END"
        then Left "fake Z3 trace event omitted END"
        else (FakeZ3Event tag fields :) <$> parseFakeZ3Events remaining

parseEventHeader :: ByteString -> Either String (ByteString, Int)
parseEventHeader header = case BSC.words header of
  ["EVENT", tag, rawCount] -> do
    count <- parseTraceNatural "event field count" rawCount
    pure (tag, count)
  _ -> Left "malformed fake Z3 event header"

parseTraceFields
  :: Int
  -> ByteString
  -> Either String ([(ByteString, ByteString)], ByteString)
parseTraceFields 0 bytes = Right ([], bytes)
parseTraceFields count bytes = do
  (header, afterHeader) <- takeTraceLine bytes
  (name, payloadLength) <- case BSC.words header of
    ["FIELD", fieldName, rawLength] -> do
      parsed <- parseTraceNatural "field byte length" rawLength
      pure (fieldName, parsed)
    _ -> Left "malformed fake Z3 field header"
  if BS.length afterHeader < payloadLength + 1
    then Left "truncated fake Z3 field payload"
    else do
      let (payload, afterPayload) = BS.splitAt payloadLength afterHeader
      case BS.uncons afterPayload of
        Just (10, remaining) -> do
          (fields, rest) <- parseTraceFields (count - 1) remaining
          pure ((name, payload) : fields, rest)
        _ -> Left "fake Z3 field payload omitted delimiter"

parseTraceNatural :: String -> ByteString -> Either String Int
parseTraceNatural label bytes = case BSC.readInt bytes of
  Just (value, remaining)
    | value >= 0 && BS.null remaining -> Right value
  _ -> Left $ "invalid fake Z3 " ++ label

takeTraceLine :: ByteString -> Either String (ByteString, ByteString)
takeTraceLine bytes = case BS.elemIndex 10 bytes of
  Nothing -> Left "unterminated fake Z3 trace line"
  Just index -> Right
    (BS.take index bytes, BS.drop (index + 1) bytes)

expectFakeZ3Event :: ByteString -> [FakeZ3Event] -> IO FakeZ3Event
expectFakeZ3Event tag events = case find ((== tag) . fakeZ3EventTag) events of
  Nothing -> assertFailure $ "missing fake Z3 event: " ++ BSC.unpack tag
  Just event -> pure event

fakeZ3FieldValues :: ByteString -> FakeZ3Event -> [ByteString]
fakeZ3FieldValues name =
  map snd . filter ((== name) . fst) . fakeZ3EventFields

assertSingleFakeField
  :: ByteString
  -> ByteString
  -> FakeZ3Event
  -> IO ()
assertSingleFakeField name expected event =
  fakeZ3FieldValues name event @?= [expected]

utf8Bytes :: String -> ByteString
utf8Bytes = BS.pack . concatMap encodeUTF8Character

encodeUTF8Character :: Char -> [Word8]
encodeUTF8Character character
  | code <= 0x7f = [byte code]
  | code <= 0x7ff =
      [ byte $ 0xc0 + shiftR code 6
      , byte $ 0x80 + (code .&. 0x3f)
      ]
  | code <= 0xffff =
      [ byte $ 0xe0 + shiftR code 12
      , byte $ 0x80 + (shiftR code 6 .&. 0x3f)
      , byte $ 0x80 + (code .&. 0x3f)
      ]
  | otherwise =
      [ byte $ 0xf0 + shiftR code 18
      , byte $ 0x80 + (shiftR code 12 .&. 0x3f)
      , byte $ 0x80 + (shiftR code 6 .&. 0x3f)
      , byte $ 0x80 + (code .&. 0x3f)
      ]
 where
  code = ord character
  byte = fromIntegral

data CapabilityFixtureIdentity

type CapabilityPlan =
  Capability.LengthSMTLibCapabilityPlan CapabilityFixtureIdentity

data CapabilityFixture = CapabilityFixture
  { fixturePlan :: CapabilityPlan
  , fixtureStartupSentinel :: SMTLibStream.SMTLibEchoSentinel
  , fixtureCheckSentinel :: SMTLibStream.SMTLibEchoSentinel
  , fixtureValueSentinel :: SMTLibStream.SMTLibEchoSentinel
  , fixtureReadySentinel :: SMTLibStream.SMTLibEchoSentinel
  }

data CapabilityReceivers = CapabilityReceivers
  { receiverStartupBarrier
      :: Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity
  , receiverCheckStatus
      :: Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity
  , receiverCheckBarrier
      :: Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity
  , receiverInputValue
      :: Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity
  , receiverInputValueBarrier
      :: Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity
  , receiverReadyStatus
      :: Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity
  , receiverReadyBarrier
      :: Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity
  }

startupNonce, checkNonce, valueNonce, readyNonce :: [Word8]
startupNonce = [0 .. 31]
checkNonce = [32 .. 63]
valueNonce = [64 .. 95]
readyNonce = [96 .. 127]

fixtureNonces :: [[Word8]]
fixtureNonces = [startupNonce, checkNonce, valueNonce, readyNonce]

fixtureBarriers :: [Capability.LengthSMTLibCapabilityBarrier]
fixtureBarriers =
  [ Capability.LengthSMTLibCapabilityStartupBarrier
  , Capability.LengthSMTLibCapabilityCheckBarrier
  , Capability.LengthSMTLibCapabilityInputValueBarrier
  , Capability.LengthSMTLibCapabilityReadyBarrier
  ]

defaultCapabilityFixture :: IO CapabilityFixture
defaultCapabilityFixture =
  capabilityFixture Capability.defaultLengthSMTLibCapabilityLimits

capabilityFixture
  :: Capability.LengthSMTLibCapabilityLimits
  -> IO CapabilityFixture
capabilityFixture limits = do
  plan <- expectRight $ sealCapability limits fixtureNonces
  Capability.lengthSMTLibCapabilityPlanCumulativeOutputByteLimit plan @?=
    Capability.lengthSMTLibCapabilityCumulativeOutputByteLimit limits
  startup <- expectRight $ SMTLibStream.mkSMTLibEchoSentinel startupNonce
  check <- expectRight $ SMTLibStream.mkSMTLibEchoSentinel checkNonce
  value <- expectRight $ SMTLibStream.mkSMTLibEchoSentinel valueNonce
  ready <- expectRight $ SMTLibStream.mkSMTLibEchoSentinel readyNonce
  pure CapabilityFixture
    { fixturePlan = plan
    , fixtureStartupSentinel = startup
    , fixtureCheckSentinel = check
    , fixtureValueSentinel = value
    , fixtureReadySentinel = ready
    }

sealCapability
  :: Capability.LengthSMTLibCapabilityLimits
  -> [[Word8]]
  -> Either Capability.LengthSMTLibCapabilityPlanError CapabilityPlan
sealCapability limits nonces = case nonces of
  [startup, check, value, ready] ->
    Capability.sealLengthSMTLibCapabilityPlan
      limits startup check value ready
  _ -> error "internal test error: capability requires exactly four nonces"

type ResponseChunker = Int -> [Word8] -> [[Word8]]

wholeChunks :: ResponseChunker
wholeChunks _ bytes = [bytes]

selectedChunks :: ResponseChunker
selectedChunks stage = chunksBySizes [stage + 1, 2, 7, 19]

singletonChunks :: ResponseChunker
singletonChunks _ = map (: [])

emptyInterleavedChunks :: ResponseChunker
emptyInterleavedChunks stage bytes =
  concatMap (\chunk -> [[], chunk]) $ selectedChunks stage bytes

chunksBySizes :: [Int] -> [value] -> [[value]]
chunksBySizes _ [] = []
chunksBySizes [] remaining = [remaining]
chunksBySizes (size : sizes) remaining =
  let (chunk, rest) = splitAt size remaining
  in if null chunk
    then chunksBySizes sizes rest
    else chunk : chunksBySizes sizes rest

assertHealthyCapability :: CapabilityFixture -> ResponseChunker -> IO ()
assertHealthyCapability fixture chunker = do
  assertExactCapabilityWrites fixture
  ready <- driveCapabilityToReady fixture chunker
  outcome <- expectCapabilityComplete =<< feedCapabilityChunks ready
    (chunker 3 $ readyTranscript fixture)
  Capability.lengthSMTLibCapabilityOutcomePlanFingerprint outcome @?=
    Capability.lengthSMTLibCapabilityPlanFingerprint (fixturePlan fixture)

driveCapabilityToReady
  :: CapabilityFixture
  -> ResponseChunker
  -> IO
      (Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity)
driveCapabilityToReady fixture chunker = do
  startup <- expectCapabilityWrite
    Capability.LengthSMTLibCapabilityStartupWrite
    (expectedStartupWrite fixture)
    $ Capability.startLengthSMTLibCapability $ fixturePlan fixture
  Capability.lengthSMTLibCapabilityReceiverPhase startup @?=
    Capability.LengthSMTLibCapabilityStartupBarrierPhase

  check <- expectCapabilityWrite
    Capability.LengthSMTLibCapabilityCheckWrite
    (expectedCheckWrite fixture)
    =<< feedCapabilityChunks startup
      (chunker 0 $ startupTranscript fixture)
  Capability.lengthSMTLibCapabilityReceiverPhase check @?=
    Capability.LengthSMTLibCapabilityCheckStatusPhase

  value <- expectCapabilityWrite
    Capability.LengthSMTLibCapabilityInputValueWrite
    (expectedValueWrite fixture)
    =<< feedCapabilityChunks check
      (chunker 1 $ checkTranscript fixture)
  Capability.lengthSMTLibCapabilityReceiverPhase value @?=
    Capability.LengthSMTLibCapabilityInputValuePhase

  ready <- expectCapabilityWrite
    Capability.LengthSMTLibCapabilityReadyWrite
    (expectedReadyWrite fixture)
    =<< feedCapabilityChunks value
      (chunker 2 $ valueTranscript fixture)
  Capability.lengthSMTLibCapabilityReceiverPhase ready @?=
    Capability.LengthSMTLibCapabilityReadyStatusPhase
  pure ready

assertExactCapabilityWrites :: CapabilityFixture -> IO ()
assertExactCapabilityWrites fixture = do
  Capability.lengthSMTLibCapabilityStartupWriteBytes plan @?=
    expectedStartupWrite fixture
  Capability.lengthSMTLibCapabilityCheckWriteBytes plan @?=
    expectedCheckWrite fixture
  Capability.lengthSMTLibCapabilityInputValueWriteBytes plan @?=
    expectedValueWrite fixture
  Capability.lengthSMTLibCapabilityReadyWriteBytes plan @?=
    expectedReadyWrite fixture
 where
  plan = fixturePlan fixture

expectedStartupWrite :: CapabilityFixture -> [Word8]
expectedStartupWrite fixture =
  capabilityStartupCommand ++
  SMTLibStream.smtLibEchoSentinelCommandBytes
    (fixtureStartupSentinel fixture)

expectedCheckWrite :: CapabilityFixture -> [Word8]
expectedCheckWrite fixture =
  capabilityResetPrefix ++ capabilityCanonicalPreamble ++
  capabilityDeclaration ++ capabilityAssertZero ++ capabilityCheck ++
  SMTLibStream.smtLibEchoSentinelCommandBytes (fixtureCheckSentinel fixture)

expectedValueWrite :: CapabilityFixture -> [Word8]
expectedValueWrite fixture =
  capabilityValueRequest ++
  SMTLibStream.smtLibEchoSentinelCommandBytes (fixtureValueSentinel fixture)

expectedReadyWrite :: CapabilityFixture -> [Word8]
expectedReadyWrite fixture =
  capabilityResetPrefix ++ capabilityCanonicalPreamble ++
  capabilityDeclaration ++ capabilityAssertZero ++ capabilityAssertOne ++
  capabilityCheck ++
  SMTLibStream.smtLibEchoSentinelCommandBytes (fixtureReadySentinel fixture)

startupTranscript :: CapabilityFixture -> [Word8]
startupTranscript fixture = sentinelResponse
  (fixtureStartupSentinel fixture) ++ ascii "\n"

checkTranscript :: CapabilityFixture -> [Word8]
checkTranscript fixture = ascii "sat\n" ++
  sentinelResponse (fixtureCheckSentinel fixture) ++ ascii "\n"

valueTranscript :: CapabilityFixture -> [Word8]
valueTranscript fixture = capabilityValueResponse ++
  sentinelResponse (fixtureValueSentinel fixture) ++ ascii "\n"

readyTranscript :: CapabilityFixture -> [Word8]
readyTranscript fixture = ascii "unsat\n" ++
  sentinelResponse (fixtureReadySentinel fixture) ++ ascii "\n"

sentinelResponse :: SMTLibStream.SMTLibEchoSentinel -> [Word8]
sentinelResponse = SMTLibStream.smtLibEchoSentinelResponseBytes

assertCapabilitySchemasAndAdmission :: IO ()
assertCapabilitySchemasAndAdmission = do
  Capability.lengthSMTLibCapabilityPlanSchemaTag @?=
    ascii "djex-length-z3-smtlib2-capability-plan/v1"
  Capability.lengthSMTLibCapabilityPhaseMachineSchemaTag @?=
    ascii "djex-length-z3-smtlib2-capability-phase-machine/v1"
  Capability.lengthSMTLibCapabilityPostBarrierSchemaTag @?=
    ascii "djex-smtlib2-capability-post-barrier-whitespace/v1"
  Capability.lengthSMTLibCapabilityExactResponseSchemaTag @?=
    ascii "djex-length-z3-capability-exact-responses/v1"
  assertBool "validated capability defaults changed representation"
    $ Capability.mkLengthSMTLibCapabilityLimits
        Capability.defaultLengthSMTLibCapabilityLimitSource ==
      Capability.defaultLengthSMTLibCapabilityLimits
  let defaults = Capability.defaultLengthSMTLibCapabilityLimits
      stream = Capability.lengthSMTLibCapabilityStreamLimits defaults
  stream @?= SMTLibStream.defaultSMTLibStreamLimits
  SMTLibStream.smtLibStreamTotalByteLimit stream @?= 131072
  SMTLibStream.smtLibStreamFrameByteLimit stream @?= 65536
  SMTLibStream.smtLibStreamNestingDepthLimit stream @?= 64
  Capability.lengthSMTLibCapabilityCumulativeOutputByteLimit defaults @?=
    524288
  Capability.lengthSMTLibCapabilityPlanFingerprintByteLimit defaults @?=
    262144

  let tooSmall site fieldName admitted required =
        Capability.LengthSMTLibCapabilityRequiredLimitTooSmall
          site fieldName admitted required
  assertLeft
    (tooSmall Capability.LengthSMTLibCapabilityStartupBarrierFrame
      Capability.LengthSMTLibCapabilityStreamTotalBytes 86 87)
    $ sealCapability (capabilityStreamLimits $ \source -> source
        { SMTLibStream.smtLibStreamLimitSourceTotalBytes = 86 })
      fixtureNonces
  assertLeft
    (tooSmall Capability.LengthSMTLibCapabilityStartupBarrierFrame
      Capability.LengthSMTLibCapabilityStreamFrameBytes 86 87)
    $ sealCapability (capabilityStreamLimits $ \source -> source
        { SMTLibStream.smtLibStreamLimitSourceFrameBytes = 86 })
      fixtureNonces
  assertLeft
    (tooSmall Capability.LengthSMTLibCapabilityCheckBarrierFrame
      Capability.LengthSMTLibCapabilityStreamTotalBytes 87 88)
    $ sealCapability (capabilityStreamLimits $ \source -> source
        { SMTLibStream.smtLibStreamLimitSourceTotalBytes = 87 })
      fixtureNonces
  assertLeft
    (tooSmall Capability.LengthSMTLibCapabilityInputValueFrame
      Capability.LengthSMTLibCapabilityStreamNestingDepth 1 2)
    $ sealCapability (capabilityStreamLimits $ \source -> source
        { SMTLibStream.smtLibStreamLimitSourceNestingDepth = 1 })
      fixtureNonces
  assertLeft
    (Capability.LengthSMTLibCapabilityMinimumOutputByteLimitExceeded 388 389)
    $ sealCapability (capabilityLimits $ \source -> source
        { Capability.lengthSMTLibCapabilityLimitSourceCumulativeOutputBytes =
            388 }) fixtureNonces
  assertLeft
    (Capability.LengthSMTLibCapabilityPlanFingerprintByteLimitExceeded 0 1)
    $ sealCapability (capabilityLimits $ \source -> source
        { Capability.lengthSMTLibCapabilityLimitSourcePlanFingerprintBytes =
            0 }) fixtureNonces

assertCapabilityNonceAdmission :: IO ()
assertCapabilityNonceAdmission = do
  forM_ (zip [0 ..] fixtureBarriers) $ \(index, barrier) ->
    assertLeft
      (Capability.LengthSMTLibCapabilityBarrierNonceError barrier
        $ SMTLibStream.SMTLibEchoSentinelNonceLengthMismatch 32 31)
      $ sealCapability Capability.defaultLengthSMTLibCapabilityLimits
      $ replaceAt index (replicate 31 0) fixtureNonces
  forM_ pairwiseIndices $ \(firstIndex, secondIndex) ->
    assertLeft
      (Capability.LengthSMTLibCapabilityRepeatedBarrierNonce
        (fixtureBarriers !! firstIndex)
        (fixtureBarriers !! secondIndex))
      $ sealCapability Capability.defaultLengthSMTLibCapabilityLimits
      $ replaceAt secondIndex (fixtureNonces !! firstIndex) fixtureNonces
 where
  pairwiseIndices =
    [(first, second) | first <- [0 .. 3], second <- [first + 1 .. 3]]

assertCapabilityPhaseFailures :: IO ()
assertCapabilityPhaseFailures = do
  fixture <- defaultCapabilityFixture
  receivers <- capabilityReceivers fixture
  let wrongExactCases =
        [ ( receiverCheckStatus receivers
          , ascii "unknown\n"
          , Capability.LengthSMTLibCapabilityUnexpectedExactResponse
              Capability.LengthSMTLibCapabilityCheckStatusPhase
          )
        , ( receiverInputValue receivers
          , ascii "((djex_capability_input 1))"
          , Capability.LengthSMTLibCapabilityUnexpectedExactResponse
              Capability.LengthSMTLibCapabilityInputValuePhase
          )
        , ( receiverReadyStatus receivers
          , ascii "sat\n"
          , Capability.LengthSMTLibCapabilityUnexpectedExactResponse
              Capability.LengthSMTLibCapabilityReadyStatusPhase
          )
        ]
      wrongBarrierCases =
        [ ( receiverStartupBarrier receivers
          , fixtureCheckSentinel fixture
          , Capability.LengthSMTLibCapabilityStartupBarrier
          )
        , ( receiverCheckBarrier receivers
          , fixtureStartupSentinel fixture
          , Capability.LengthSMTLibCapabilityCheckBarrier
          )
        , ( receiverInputValueBarrier receivers
          , fixtureReadySentinel fixture
          , Capability.LengthSMTLibCapabilityInputValueBarrier
          )
        , ( receiverReadyBarrier receivers
          , fixtureValueSentinel fixture
          , Capability.LengthSMTLibCapabilityReadyBarrier
          )
        ]
      eofCases =
        [ ( Capability.LengthSMTLibCapabilityStartupBarrierPhase
          , receiverStartupBarrier receivers)
        , ( Capability.LengthSMTLibCapabilityCheckStatusPhase
          , receiverCheckStatus receivers)
        , ( Capability.LengthSMTLibCapabilityCheckBarrierPhase
          , receiverCheckBarrier receivers)
        , ( Capability.LengthSMTLibCapabilityInputValuePhase
          , receiverInputValue receivers)
        , ( Capability.LengthSMTLibCapabilityInputValueBarrierPhase
          , receiverInputValueBarrier receivers)
        , ( Capability.LengthSMTLibCapabilityReadyStatusPhase
          , receiverReadyStatus receivers)
        , ( Capability.LengthSMTLibCapabilityReadyBarrierPhase
          , receiverReadyBarrier receivers)
        ]
  forM_ wrongExactCases $ \(receiver, bytes, expected) ->
    assertLeft expected $ Capability.feedLengthSMTLibCapability receiver bytes
  assertLeft
    (Capability.LengthSMTLibCapabilityUnexpectedExactResponse
      Capability.LengthSMTLibCapabilityCheckStatusPhase)
    $ Capability.feedLengthSMTLibCapability
        (receiverCheckStatus receivers)
    $ ascii "unknown\n" ++
        error "capability exact-response rejection forced its frame tail"
  forM_ wrongBarrierCases $ \(receiver, sentinel, barrier) ->
    assertLeft
      (Capability.LengthSMTLibCapabilityBarrierMismatch barrier)
      $ Capability.feedLengthSMTLibCapability receiver
      $ sentinelResponse sentinel ++ ascii "\n"
  assertLeft
    (Capability.LengthSMTLibCapabilityBarrierMismatch
      Capability.LengthSMTLibCapabilityCheckBarrier)
    $ Capability.feedLengthSMTLibCapability
        (receiverCheckBarrier receivers)
    $ sentinelResponse (fixtureStartupSentinel fixture) ++
        ascii "\n" ++
        error "capability barrier mismatch forced its frame tail"
  forM_ eofCases $ \(phase, receiver) -> do
    Capability.lengthSMTLibCapabilityReceiverPhase receiver @?= phase
    assertLeft
      (Capability.LengthSMTLibCapabilityUnexpectedEOF phase)
      $ Capability.finishLengthSMTLibCapability receiver

assertCapabilityCausalBoundaries :: IO ()
assertCapabilityCausalBoundaries = do
  fixture <- defaultCapabilityFixture
  receivers <- capabilityReceivers fixture
  assertPostBarrierByte 40
    $ Capability.feedLengthSMTLibCapability
        (receiverCheckStatus receivers)
    $ ascii "sat\n" ++
      sentinelResponse (fixtureCheckSentinel fixture) ++ ascii "\n" ++
      capabilityValueResponse
  assertPostBarrierByte 117
    $ Capability.feedLengthSMTLibCapability
        (receiverInputValue receivers)
    $ capabilityValueResponse ++
      sentinelResponse (fixtureValueSentinel fixture) ++ ascii "\nunsat\n"

assertCapabilityAccounting :: IO ()
assertCapabilityAccounting = do
  let exactLimits = capabilityLimits $ \source -> source
        { Capability.lengthSMTLibCapabilityLimitSourceCumulativeOutputBytes =
            minimumCapabilityTranscriptBytes }
  exactFixture <- capabilityFixture exactLimits
  cappedStartup <- expectCapabilityWrite
    Capability.LengthSMTLibCapabilityStartupWrite
    (expectedStartupWrite exactFixture)
    $ Capability.startLengthSMTLibCapability $ fixturePlan exactFixture
  cappedPending <- expectCapabilityAwait =<< expectRight
    (Capability.feedLengthSMTLibCapability cappedStartup
      $ replicate (fromIntegral minimumCapabilityTranscriptBytes) 32)
  assertLeft
    (Capability.LengthSMTLibCapabilityCumulativeOutputByteLimitExceeded
      minimumCapabilityTranscriptBytes
      (minimumCapabilityTranscriptBytes + 1))
    $ Capability.feedLengthSMTLibCapability cappedPending [32]

  assertHealthyCapability exactFixture wholeChunks
  exactReady <- driveCapabilityToReady exactFixture wholeChunks
  assertLeft
    (Capability.LengthSMTLibCapabilityCumulativeOutputByteLimitExceeded
      minimumCapabilityTranscriptBytes
      (minimumCapabilityTranscriptBytes + 1))
    $ Capability.feedLengthSMTLibCapability exactReady
    $ readyTranscript exactFixture ++ ascii " "

  let tieLimits = Capability.mkLengthSMTLibCapabilityLimits
        $ Capability.defaultLengthSMTLibCapabilityLimitSource
          { Capability.lengthSMTLibCapabilityLimitSourceStreamLimits =
              SMTLibStream.defaultSMTLibStreamLimitSource
                { SMTLibStream.smtLibStreamLimitSourceTotalBytes = 88 }
          , Capability.lengthSMTLibCapabilityLimitSourceCumulativeOutputBytes =
              minimumCapabilityTranscriptBytes
          }
  tieFixture <- capabilityFixture tieLimits
  tieReady <- driveCapabilityToReady tieFixture wholeChunks
  assertLeft
    (Capability.LengthSMTLibCapabilityFramingFailure
      Capability.LengthSMTLibCapabilityReadyBarrierPhase
      $ SMTLibStream.SMTLibStreamTotalByteLimitExceeded 88 89)
    $ Capability.feedLengthSMTLibCapability tieReady
    $ ascii " unsat\n " ++
      sentinelResponse (fixtureReadySentinel tieFixture) ++ ascii "\n"

assertCapabilityNoScanning :: IO ()
assertCapabilityNoScanning = do
  fixture <- defaultCapabilityFixture
  receivers <- capabilityReceivers fixture
  assertLeft
    (Capability.LengthSMTLibCapabilityUnexpectedExactResponse
      Capability.LengthSMTLibCapabilityCheckStatusPhase)
    $ Capability.feedLengthSMTLibCapability
        (receiverCheckStatus receivers)
    $ ascii "unknown\nsat\n" ++
      sentinelResponse (fixtureCheckSentinel fixture) ++ ascii "\n"
  assertLeft
    (Capability.LengthSMTLibCapabilityBarrierMismatch
      Capability.LengthSMTLibCapabilityCheckBarrier)
    $ Capability.feedLengthSMTLibCapability
        (receiverCheckBarrier receivers)
    $ sentinelResponse (fixtureStartupSentinel fixture) ++ ascii "\n" ++
      sentinelResponse (fixtureCheckSentinel fixture) ++ ascii "\n"
  assertLeft
    (Capability.LengthSMTLibCapabilityUnexpectedExactResponse
      Capability.LengthSMTLibCapabilityInputValuePhase)
    $ Capability.feedLengthSMTLibCapability
        (receiverInputValue receivers)
    $ ascii "((djex_capability_input 1))" ++ capabilityValueResponse ++
      sentinelResponse (fixtureValueSentinel fixture) ++ ascii "\n"

capabilityReceivers :: CapabilityFixture -> IO CapabilityReceivers
capabilityReceivers fixture = do
  startup <- expectCapabilityWrite
    Capability.LengthSMTLibCapabilityStartupWrite
    (expectedStartupWrite fixture)
    $ Capability.startLengthSMTLibCapability $ fixturePlan fixture
  check <- expectCapabilityWrite
    Capability.LengthSMTLibCapabilityCheckWrite
    (expectedCheckWrite fixture)
    =<< expectRight (Capability.feedLengthSMTLibCapability startup
      $ startupTranscript fixture)
  checkBarrier <- expectCapabilityAwait =<< expectRight
    (Capability.feedLengthSMTLibCapability check $ ascii "sat\n")
  value <- expectCapabilityWrite
    Capability.LengthSMTLibCapabilityInputValueWrite
    (expectedValueWrite fixture)
    =<< expectRight (Capability.feedLengthSMTLibCapability checkBarrier
      $ sentinelResponse (fixtureCheckSentinel fixture) ++ ascii "\n")
  valueBarrier <- expectCapabilityAwait =<< expectRight
    (Capability.feedLengthSMTLibCapability value capabilityValueResponse)
  ready <- expectCapabilityWrite
    Capability.LengthSMTLibCapabilityReadyWrite
    (expectedReadyWrite fixture)
    =<< expectRight (Capability.feedLengthSMTLibCapability valueBarrier
      $ sentinelResponse (fixtureValueSentinel fixture) ++ ascii "\n")
  readyBarrier <- expectCapabilityAwait =<< expectRight
    (Capability.feedLengthSMTLibCapability ready $ ascii "unsat\n")
  pure CapabilityReceivers
    { receiverStartupBarrier = startup
    , receiverCheckStatus = check
    , receiverCheckBarrier = checkBarrier
    , receiverInputValue = value
    , receiverInputValueBarrier = valueBarrier
    , receiverReadyStatus = ready
    , receiverReadyBarrier = readyBarrier
    }

expectCapabilityWrite
  :: Capability.LengthSMTLibCapabilityWriteKind
  -> [Word8]
  -> Capability.LengthSMTLibCapabilityAction CapabilityFixtureIdentity
  -> IO
      (Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity)
expectCapabilityWrite expectedKind expectedBytes action = case action of
  SMTLibCausal.SMTLibCausalWrite kind bytes receiver -> do
    kind @?= expectedKind
    bytes @?= expectedBytes
    pure receiver
  SMTLibCausal.SMTLibCausalAwait{} ->
    assertFailure "expected a capability write action, observed await"
  SMTLibCausal.SMTLibCausalComplete{} ->
    assertFailure "expected a capability write action, observed completion"

expectCapabilityAwait
  :: Capability.LengthSMTLibCapabilityAction CapabilityFixtureIdentity
  -> IO
      (Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity)
expectCapabilityAwait action = case action of
  SMTLibCausal.SMTLibCausalAwait receiver -> pure receiver
  SMTLibCausal.SMTLibCausalWrite{} ->
    assertFailure "expected capability await, observed write"
  SMTLibCausal.SMTLibCausalComplete{} ->
    assertFailure "expected capability await, observed completion"

expectCapabilityComplete
  :: Capability.LengthSMTLibCapabilityAction CapabilityFixtureIdentity
  -> IO (Capability.LengthSMTLibCapabilityOutcome CapabilityFixtureIdentity)
expectCapabilityComplete action = case action of
  SMTLibCausal.SMTLibCausalComplete outcome -> pure outcome
  SMTLibCausal.SMTLibCausalWrite{} ->
    assertFailure "expected capability completion, observed write"
  SMTLibCausal.SMTLibCausalAwait{} ->
    assertFailure "expected capability completion, observed await"

feedCapabilityChunks
  :: Capability.LengthSMTLibCapabilityReceiver CapabilityFixtureIdentity
  -> [[Word8]]
  -> IO (Capability.LengthSMTLibCapabilityAction CapabilityFixtureIdentity)
feedCapabilityChunks receiver chunks = case chunks of
  [] -> pure $ SMTLibCausal.SMTLibCausalAwait receiver
  chunk : remaining -> do
    action <- expectRight
      $ Capability.feedLengthSMTLibCapability receiver chunk
    case action of
      SMTLibCausal.SMTLibCausalAwait next ->
        feedCapabilityChunks next remaining
      _
        | null remaining -> pure action
        | otherwise -> assertFailure
            "capability produced an action before all response chunks"

assertPostBarrierByte
  :: Word8
  -> Either
      Capability.LengthSMTLibCapabilityError
      (Capability.LengthSMTLibCapabilityAction CapabilityFixtureIdentity)
  -> IO ()
assertPostBarrierByte expected result = case result of
  Left (Capability.LengthSMTLibCapabilityUnexpectedPostBarrierByte _ byte) ->
    byte @?= expected
  Left other -> assertFailure $ "unexpected causal-boundary error: " ++
    show other
  Right _ -> assertFailure "pre-write capability output was accepted"

assertLeft :: (Eq failure, Show failure) => failure -> Either failure value -> IO ()
assertLeft expected result = case result of
  Left actual -> actual @?= expected
  Right _ -> assertFailure $ "expected rejection: " ++ show expected

expectRight :: Show failure => Either failure value -> IO value
expectRight result = case result of
  Left failure -> assertFailure $ "unexpected rejection: " ++ show failure
  Right value -> pure value

capabilityLimits
  :: (Capability.LengthSMTLibCapabilityLimitSource
      -> Capability.LengthSMTLibCapabilityLimitSource)
  -> Capability.LengthSMTLibCapabilityLimits
capabilityLimits change = Capability.mkLengthSMTLibCapabilityLimits
  $ change Capability.defaultLengthSMTLibCapabilityLimitSource

capabilityStreamLimits
  :: (SMTLibStream.SMTLibStreamLimitSource
      -> SMTLibStream.SMTLibStreamLimitSource)
  -> Capability.LengthSMTLibCapabilityLimits
capabilityStreamLimits change = capabilityLimits $ \source -> source
  { Capability.lengthSMTLibCapabilityLimitSourceStreamLimits =
      change SMTLibStream.defaultSMTLibStreamLimitSource }

replaceAt :: Int -> value -> [value] -> [value]
replaceAt target replacement values =
  [if index == target then replacement else value
  | (index, value) <- zip [0 ..] values]

countExactFingerprintBytes
  :: [Word8]
  -> Fingerprint.FingerprintField
  -> Int
countExactFingerprintBytes target field = case field of
  Fingerprint.FingerprintNatural _ -> 0
  Fingerprint.FingerprintBytes bytes -> fromEnum $ bytes == target
  Fingerprint.FingerprintSequence fields ->
    sum $ map (countExactFingerprintBytes target) fields
  Fingerprint.FingerprintTag _ fields ->
    sum $ map (countExactFingerprintBytes target) fields
  Fingerprint.FingerprintName _ -> 0

countContiguous :: Eq value => [value] -> [value] -> Int
countContiguous needle haystack
  | null needle = 0
  | otherwise = length
      $ filter (needle `isPrefixOf`)
      $ tails haystack

assertRawProcessOpenFailure
  :: Process.LengthSMTLibProcessPhase
  -> Process.LengthSMTLibProcessFailureClass
  -> Either Process.LengthSMTLibProcessError Process.LengthSMTLibProcess
  -> IO ()
assertRawProcessOpenFailure expectedPhase expectedClass opened = case opened of
  Left failure -> do
    Process.lengthSMTLibProcessErrorPhase failure @?= expectedPhase
    Process.lengthSMTLibProcessErrorClass failure @?= expectedClass
    Process.lengthSMTLibProcessErrorObservedAtLeast failure @?= Nothing
  Right process -> do
    _ <- Process.closeLengthSMTLibProcess process
    assertFailure "raw Process unexpectedly opened"

minimumCapabilityTranscriptBytes :: Natural
minimumCapabilityTranscriptBytes = 389

capabilityStartupCommand :: [Word8]
capabilityStartupCommand = ascii "(set-option :print-success false)\n"

capabilityResetPrefix :: [Word8]
capabilityResetPrefix = ascii
  "(reset)\n(set-option :print-success false)\n"

capabilityCanonicalPreamble :: [Word8]
capabilityCanonicalPreamble = ascii $ concat
  [ "(set-option :produce-models true)\n"
  , "(set-option :random-seed 1)\n"
  , "(set-logic QF_LIA)\n"
  , "(define-fun djex_nat_monus ((x Int) (y Int)) Int "
  , "(ite (<= y x) (- x y) 0))\n"
  , "(define-fun djex_nat_min ((x Int) (y Int)) Int "
  , "(ite (<= x y) x y))\n"
  , "(define-fun djex_nat_max ((x Int) (y Int)) Int "
  , "(ite (<= x y) y x))\n"
  ]

capabilityDeclaration :: [Word8]
capabilityDeclaration =
  ascii "(declare-const djex_capability_input Int)\n"

capabilityAssertZero :: [Word8]
capabilityAssertZero = ascii "(assert (= djex_capability_input 0))\n"

capabilityAssertOne :: [Word8]
capabilityAssertOne = ascii "(assert (= djex_capability_input 1))\n"

capabilityCheck :: [Word8]
capabilityCheck = ascii "(check-sat)\n"

capabilityValueRequest :: [Word8]
capabilityValueRequest =
  ascii "(get-value (djex_capability_input))\n"

capabilityValueResponse :: [Word8]
capabilityValueResponse = ascii "((djex_capability_input 0))"

ascii :: String -> [Word8]
ascii = map $ fromIntegral . fromEnum
