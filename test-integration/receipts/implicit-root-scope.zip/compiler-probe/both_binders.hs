{-# LANGUAGE RankNTypes, ImpredicativeTypes, TypeApplications, TypeAbstractions, ScopedTypeVariables, NoPolyKinds #-}
type Inner = forall b. b -> b
type Phantom a = Inner
f :: Phantom erased
f @erased @inner x = x
main = print (f @Bool @Int 37)
