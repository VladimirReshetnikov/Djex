{-# LANGUAGE RankNTypes, ImpredicativeTypes, TypeApplications, TypeAbstractions, ScopedTypeVariables, NoPolyKinds #-}
type Inner = forall b. b -> b
type Phantom a = Inner
f :: Phantom erased
f @inner x = x
main = print (f @Int 37)
