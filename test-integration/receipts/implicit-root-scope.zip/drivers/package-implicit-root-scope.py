from pathlib import Path
import hashlib, json, zipfile
ROOT = Path('C:/Djex')
RUN = ROOT / 'dist-newstyle/implicit-root-regression-v2'
CORPUS = ROOT / 'dist-newstyle/implicit-root-signatures-v1'
reg = json.loads((RUN / 'regression/results.json').read_text(encoding='utf-8'))
corpus = json.loads((CORPUS / 'results.json').read_text(encoding='utf-8'))
assert reg['status'] == corpus['status'] == 'passed'
assert reg['sources_unchanged'] and reg['helpers_unchanged'] and corpus['unchanged']
assert sum(r['passed_count'] for r in reg['rows']) == 361
files = {}
for label, directory in [('regression', RUN), ('signatures', CORPUS),
                         ('compiler-probe', ROOT / 'dist-newstyle/phantom-root-probe-v1')]:
    for path in directory.rglob('*'):
        if path.is_file():
            files[label + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
for name, expected in reg['source_hashes_after'].items():
    path = Path(name)
    # Cabal may rewrite its plan while building the separate corpus harness.
    # Preserve the exact plan from the completed frontend run in that case.
    raw = ((RUN / 'plan.snapshot.json').read_bytes()
           if path == ROOT / 'dist-newstyle/cache/plan.json' else path.read_bytes())
    assert hashlib.sha256(raw).hexdigest() == expected, name
    if path.is_relative_to(ROOT):
        files['source/' + path.relative_to(ROOT).as_posix()] = raw
for name in ['validate-implicit-root-regression-v2.py', 'validate-implicit-root-signatures.py',
             'probe-phantom-root.py', 'package-implicit-root-scope.py']:
    files['drivers/' + name] = (ROOT / 'dist-newstyle' / name).read_bytes()
manifest = {name: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
            for name, raw in sorted(files.items())}
archive = ROOT / 'test-integration/receipts/implicit-root-scope.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(files.items()):
        z.writestr(name, raw)
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    for name, entry in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == entry['sha256']
rows = [{k: v for k, v in r.items() if k != 'inventory'} for r in reg['rows']]
receipt = dict(status='accepted_documented_implicit_root_REPL_fragment',
    base_commit='a36a27297fab0907cc9e239781c4aa328c9adf58',
    strict_build='passed -Werror', suites=rows, test_count=361,
    public_fixture=dict(positive_exact_GHC_replays=40, actual_false_controls=20,
                        explicit_forall_rejection_guards=4, engines=['djinn', 'exference'],
                        signatures=5, selection='first', candidate_window=4,
                        djinn_choices=20000, exference_steps=256),
    synonym_fixture=dict(cases=3, same_candidate_graph_identity_checks=True,
                         exact_original_signature_GHC_replays=3,
                         preserved_erased_hint_guard=True),
    signature_corpus=dict(djinn=350, exference=350, compiler='ExitSuccess for each engine',
                          query_timeout_seconds=2, search_steps=10000,
                          evidence='type inhabitation, not full Church behavior'),
    source_and_helper_inputs_unchanged=True,
    archive=dict(path=archive.name, artifacts=len(files), bytes=archive.stat().st_size,
                 sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), all_members_rehashed=True),
    history=dict(prior_failed_receipt='implicit-root-retriage.json',
                 resolution='GHC retains vacuous outer binders; strengthened test distinguishes them from truly erased local binders without weakening production hint ownership.'),
    boundaries=['Only the documented implicit-root contextual REPL fragment is accepted.',
                'One-shot contextual commands, typed list rendering and broader binder/provider evidence remain open.',
                'New implicit queries use first selection; existing explicit-forall selection matrices are separate retained regressions.',
                'Leant dependency remains bfc3692e until native integration of this frontend revision.'])
archive.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
validation = 'Strict builds pass. All **361 tests across six complete affected suites pass**:\n\n'
validation += '| Suite | Tests | Seconds |\n| --- | --- | --- |\n'
validation += ''.join('| ' + r['suite'] + ' | ' + str(r['passed_count']) + ' | ' + str(r['seconds']) + ' |\n' for r in rows)
validation += ('\nThe full Church signature harness also passes **350/350 per Haskell engine**,\n'
               'with GHC compilation at the expanded and original resolved signatures,\n'
               'the existing two-second query timeout and 10,000-step budget. All recorded\n'
               'source and executable integrity checks pass.\n')
draft = (ROOT / 'dist-newstyle/implicit-root-report-draft.md').read_text(encoding='utf-8')
assert draft.count('__VALIDATION__') == 1
report = draft.replace('__VALIDATION__', validation)
report += '\nArchive SHA-256: `' + receipt['archive']['sha256'] + '`.\n'
for root in [ROOT, Path('C:/Leant')]:
    (root / 'docs/reports/2026-09-08-implicit-root-scope.md').write_text(report, encoding='utf-8')
print(json.dumps({'status': receipt['status'], 'archive': receipt['archive'], 'suites': [(r['suite'], r['passed_count']) for r in rows]}))
