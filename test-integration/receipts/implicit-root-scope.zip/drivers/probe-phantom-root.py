from pathlib import Path
import os, sys, json
ROOT = Path('C:/Djex')
sys.path.insert(0, str(ROOT / 'test-church'))
import behavior_runtime as runtime
OUT = runtime.prepare_output_directory(ROOT / 'dist-newstyle/phantom-root-probe-v1')
prefix = '''{-# LANGUAGE RankNTypes, ImpredicativeTypes, TypeApplications, TypeAbstractions, ScopedTypeVariables, NoPolyKinds #-}
type Inner = forall b. b -> b
type Phantom a = Inner
f :: Phantom erased
'''
cases = {
    'both_binders': 'f @erased @inner x = x\nmain = print (f @Bool @Int 37)\n',
    'one_binder': 'f @inner x = x\nmain = print (f @Int 37)\n',
    'explicit_outer': 'f @erased @inner x = x\nmain = print (f @Bool @Int 37)\n',
}
for name, body in cases.items():
    source = prefix.replace('f :: Phantom erased', 'f :: forall erased. Phantom erased') if name == 'explicit_outer' else prefix
    (OUT / (name + '.hs')).write_text(source + body)
compiler = Path('C:/ghcup/ghc/9.12.4/bin/runghc.exe')
paths = [compiler, compiler.with_name('ghc.exe'), *OUT.glob('*.hs')]
before = {str(p): runtime.sha256(p) for p in paths}
processes = runtime.Processes(OUT, 60)
report = {'before': before, 'rows': [], 'status': 'running'}
env = dict(os.environ, PYTHONIOENCODING='utf-8')
try:
    for name in cases:
        result = processes.run(name, [compiler, OUT / (name + '.hs')], cwd=OUT, env=env)
        row = dict(name=name, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)
        report['rows'].append(row)
        print(json.dumps(row, ensure_ascii=True), flush=True)
finally:
    report['after'] = {str(p): runtime.sha256(p) for p in paths}
    report['unchanged'] = before == report['after']
    report['status'] = 'completed' if len(report['rows']) == len(cases) and report['unchanged'] else 'incomplete'
    report['processes'] = processes.rows
    runtime.write_json(OUT / 'results.json', report)
