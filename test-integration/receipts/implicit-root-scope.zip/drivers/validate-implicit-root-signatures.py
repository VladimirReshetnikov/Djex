from pathlib import Path
import json,os,shutil,sys
root=Path('C:/Djex')
sys.path.insert(0,str(root/'test-church'))
import behavior_runtime as runtime
out=runtime.prepare_output_directory(root/'dist-newstyle/implicit-root-signatures-v1')
owned=runtime.Processes(out,900)
build=owned.run('strict-build',['cabal','build','test:djex-church-tests','-j1','--ghc-options=-Werror'],cwd=root)
assert build.returncode==0,'signature harness build failed'
binary=root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17/t/djex-church-tests/build/djex-church-tests/djex-church-tests.exe'
paths=[Path(__file__),binary,root/'djex.cabal',root/'dist-newstyle/cache/plan.json']
for name in ['src','exference','djinn','synthesis','test-church']:
 paths.extend(p for p in (root/name).rglob('*') if p.is_file() and p.suffix in {'.hs','.py','.tsv','.inc'} and not {'__pycache__','results','receipts','dist-newstyle'}.intersection(p.parts))
paths.extend(Path(shutil.which(name)) for name in ['ghc','python','cabal'])
def hashes():return {str(p):runtime.sha256(p) for p in sorted(set(paths))}
report={'status':'running','before':hashes(),'backend':'both','query_seconds':2,'steps':10000}
runtime.write_json(out/'results.json',report)
try:
 env=dict(os.environ,djex_datadir=str(root))
 result=owned.run('whole-corpus',[binary,'--backend','both','--timeout','2','--steps','10000','--report-dir',out/'corpus'],cwd=root,env=env)
 assert result.returncode==0,'whole corpus failed'
 for backend in ['djinn','exference']:
  rows=(out/'corpus'/f'{backend}-results.tsv').read_text().splitlines()
  assert len(rows)==350 and all(row.split('\t')[3]=='synthesized' for row in rows)
  assert f'RESULT {backend}: synthesized=350 failed=0 compiler=ExitSuccess' in result.stdout
 report['status']='passed'
finally:
 report['after']=hashes();report['unchanged']=report['before']==report['after']
 if not report['unchanged']:report['status']='failed'
 report['processes']=owned.rows
 runtime.write_json(out/'results.json',report)
print('Signature corpus:',report['status'],'350 signatures in each Haskell engine')
sys.exit(0 if report['status']=='passed' else 1)
