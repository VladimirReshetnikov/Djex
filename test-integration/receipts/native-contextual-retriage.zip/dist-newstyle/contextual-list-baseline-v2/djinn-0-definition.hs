{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}
module Candidate where
import Methods
selected :: forall a. C a => [Token]
selected = (([] :: forall djexBound0_0. [djexBound0_0]) @(Token))
