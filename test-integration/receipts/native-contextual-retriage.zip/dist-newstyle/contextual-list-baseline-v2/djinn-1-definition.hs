{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}
module Candidate where
import Methods
selected :: C a => [Token]
selected @a = (([] :: forall djexBound0_0. [djexBound0_0]) @(Token))
