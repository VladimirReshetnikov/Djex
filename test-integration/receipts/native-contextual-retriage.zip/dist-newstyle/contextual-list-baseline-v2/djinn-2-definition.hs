{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}
module Candidate where
import Methods
selected :: C a => [a] -> [a]
selected @a = (let { djexPoly44 :: forall djexSkolem44. (C djexSkolem44) => [djexSkolem44] -> [djexSkolem44]; djexPoly44 = ((\(a :: [djexSkolem44]) -> a) :: (C djexSkolem44) => [djexSkolem44] -> [djexSkolem44]) } in djexPoly44)
