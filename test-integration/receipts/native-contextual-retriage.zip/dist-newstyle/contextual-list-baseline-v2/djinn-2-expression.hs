{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}
module Candidate where
import Methods
check :: [Int]
check = (((\ @a -> (let { djexPoly44 :: forall djexSkolem44. (C djexSkolem44) => [djexSkolem44] -> [djexSkolem44]; djexPoly44 = ((\(a :: [djexSkolem44]) -> a) :: (C djexSkolem44) => [djexSkolem44] -> [djexSkolem44]) } in djexPoly44)) :: forall a.   C a => [a] -> [a])) @Int [37,91]
