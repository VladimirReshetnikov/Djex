{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}
module Candidate where
import Methods
selected :: forall a. C a => [(forall b. b -> b)]
selected = (([] :: forall djexBound0_0. [djexBound0_0]) @(forall djexBound0_0. djexBound0_0 -> djexBound0_0))
