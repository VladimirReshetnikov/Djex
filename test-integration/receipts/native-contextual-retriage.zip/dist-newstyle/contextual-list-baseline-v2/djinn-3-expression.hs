{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}
module Candidate where
import Methods
check :: [(forall b. b -> b)]
check = (((\ @a -> (([] :: forall djexBound0_0. [djexBound0_0]) @(forall djexBound0_0. djexBound0_0 -> djexBound0_0))) :: forall a . C a => [(forall b . b -> b)])) @Int
