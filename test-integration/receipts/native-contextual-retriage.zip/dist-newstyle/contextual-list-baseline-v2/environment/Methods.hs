{-# LANGUAGE RankNTypes, ScopedTypeVariables, TypeApplications, AllowAmbiguousTypes, NoPolyKinds #-}
module Methods (Token, C, method, observe) where
data Token = Token Int
class C a where payload :: Int
instance C Int where payload = 37
instance C Bool where payload = 91
method :: forall a. C a => Token
method = Token (payload @a)
observe :: Token -> Int
observe (Token n) = n
