{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}
module Candidate where
import Methods
check :: [Token]
check = (((\ @a -> (([] :: forall djexBound0_0. [djexBound0_0]) @(Methods.Token))) :: forall a.   C a => [Token])) @Int
