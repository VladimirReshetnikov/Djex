{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}
module Candidate where
import Methods
selected :: C a => [a] -> [a]
selected @a = (let { djexPoly55 :: forall djexSkolem55. (Methods.C djexSkolem55) => [djexSkolem55] -> [djexSkolem55]; djexPoly55 = ((\(x :: [djexSkolem55]) -> x) :: (Methods.C djexSkolem55) => [djexSkolem55] -> [djexSkolem55]) } in djexPoly55)
