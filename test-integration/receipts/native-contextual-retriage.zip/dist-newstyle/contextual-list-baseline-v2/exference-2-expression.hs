{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}
module Candidate where
import Methods
check :: [Int]
check = (((\ @a -> (let { djexPoly55 :: forall djexSkolem55. (Methods.C djexSkolem55) => [djexSkolem55] -> [djexSkolem55]; djexPoly55 = ((\(x :: [djexSkolem55]) -> x) :: (Methods.C djexSkolem55) => [djexSkolem55] -> [djexSkolem55]) } in djexPoly55)) :: forall a.   C a => [a] -> [a])) @Int [37,91]
