from pathlib import Path
import os,subprocess,json
root=Path('C:/Djex'); out=root/'dist-newstyle/contextual-list-behavior-baseline-v2';out.mkdir(exist_ok=False)
envdir=root/'dist-newstyle/contextual-list-baseline-v2/environment'
exe=root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17/x/djex/build/djex/djex.exe'
rows=[]
for engine in ('djinn','exference','both'):
 commands=[':set prompt ""',':backend '+engine,':module Methods',':set select first',':set render definition',':set allow-unused on',':set djinn-axioms on',':set quality-window 32',':set candidate-limit 32',':set choice-budget 20000',':set max-steps 20000',':synth selected :: forall a. C a => [Token] where Prelude.map observe (selected @Prelude.Int) == [37] && Prelude.map observe (selected @Prelude.Bool) == [91]',':synth rejected :: forall a. C a => [Token] where Prelude.False',':quit']
 (out/(engine+'.input.txt')).write_text('\n'.join(commands)+'\n',encoding='utf-8')
 p=subprocess.run([str(exe),'repl','--environment',str(envdir),'--ignore-startup'],input='\n'.join(commands)+'\n',cwd=root,env=dict(os.environ,djex_datadir=str(root)),capture_output=True,text=True,encoding='utf-8',timeout=180)
 (out/(engine+'.stdout.txt')).write_text(p.stdout,encoding='utf-8');(out/(engine+'.stderr.txt')).write_text(p.stderr,encoding='utf-8')
 row={'engine':engine,'exit':p.returncode,'definitions':[x for x in p.stdout.splitlines() if x.startswith('selected ')],'stderr_tail':p.stderr[-1000:]};rows.append(row);print(json.dumps(row),flush=True)
(out/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
