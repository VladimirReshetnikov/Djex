from pathlib import Path
import json,os,subprocess,sys
root=Path('C:/Djex')
out=root/'dist-newstyle/contextual-list-baseline-v2'
out.mkdir(exist_ok=False)
envdir=out/'environment';envdir.mkdir()
(envdir/'Methods.hs').write_bytes((root/'dist-newstyle/one-shot-context-public-v1/environment/Methods.hs').read_bytes())
exe=root/'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17/x/djex/build/djex/djex.exe'
env=dict(os.environ,djex_datadir=str(root))
rows=[]
for engine in ('djinn','exference'):
 for i,signature in enumerate(('forall a. C a => [Token]','C a => [Token]','C a => [a] -> [a]','forall a. C a => [(forall b. b -> b)]')):
  for mode in ('definition','expression'):
   label=f'{engine}-{i}-{mode}'
   args=[str(exe),engine,'--environment',str(envdir),'--target','selected','--select','first','--render',mode,'--quality-window','4']+(['--candidate-limit','4','--choice-budget','20000'] if engine=='djinn' else ['--allow-unused','--max-steps','256'])+[signature]
   run=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',timeout=30)
   (out/(label+'.stdout.txt')).write_text(run.stdout,encoding='utf-8');(out/(label+'.stderr.txt')).write_text(run.stderr,encoding='utf-8')
   displayed=[line for line in run.stdout.splitlines() if line.startswith('selected ' if mode=='definition' else '(')]
   row=dict(id=label,signature=signature,exit_code=run.returncode,displayed=displayed,stderr=run.stderr)
   if displayed:
    p=out/(label+'.hs')
    header='{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}\nmodule Candidate where\nimport Methods\n'
    if mode=='definition': body='selected :: '+signature+'\n'+displayed[0]+'\n'
    else:
     result_type='[Token]' if i<2 else '[Int]' if i==2 else '[(forall b. b -> b)]'
     body='check :: '+result_type+'\ncheck = ('+displayed[0]+') @Int'+(' [37,91]' if i==2 else '')+'\n'
    p.write_text(header+body,encoding='utf-8')
    replay=subprocess.run(['ghc','-fno-code','-fforce-recomp','-i'+str(envdir),str(p)],cwd=out,capture_output=True,text=True,encoding='utf-8',timeout=30)
    (out/(label+'.ghc.txt')).write_text(replay.stdout+replay.stderr,encoding='utf-8')
    row['ghc_exit']=replay.returncode;row['ghc_error']=replay.stderr
   rows.append(row)
   print(json.dumps({k:row[k] for k in ('id','exit_code','ghc_exit') if k in row}),flush=True)
(out/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
