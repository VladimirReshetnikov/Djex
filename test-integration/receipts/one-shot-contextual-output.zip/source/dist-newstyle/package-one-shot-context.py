from pathlib import Path
import hashlib, json, zipfile

ROOT = Path('C:/Djex')
RUN = ROOT / 'dist-newstyle/one-shot-context-regression-v3'
PUBLIC = ROOT / 'dist-newstyle/one-shot-context-public-v1'
CORPUS = ROOT / 'dist-newstyle/one-shot-context-signatures-v1'
EXTENDED = ROOT / 'dist-newstyle/one-shot-context-extended-exference-v1'
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
reg = load(RUN / 'regression/results.json')
public = load(PUBLIC / 'results.json')
corpus = load(CORPUS / 'results.json')
extended = load(EXTENDED / 'results.json')
assert reg['status'] == public['status'] == corpus['status'] == extended['status'] == 'passed'
assert reg['sources_unchanged'] and reg['helpers_unchanged'] and public['unchanged'] and corpus['unchanged']
assert len(reg['rows']) == 16 and sum(r['passed_count'] for r in reg['rows']) == 2371
assert all(r['status'] == 'passed' and r['executable_unchanged'] for r in reg['rows'])
assert len(public['positive_queries']) == 64 and len(public['guards']) == 4 and len(public['false_queries']) == 8
assert all(r['status'] == 'passed' for key in ['positive_queries', 'guards', 'false_queries'] for r in public[key])
assert extended['sources_unchanged'] and extended['executables_unchanged']
assert extended['passed_synthesis_cells'] == 13 and extended['passed_false_controls'] == 1
assert all(r['status'] == 'passed' for r in extended['oracle_controls'])
for engine in ('djinn', 'exference'):
    rows = (CORPUS / 'corpus' / f'{engine}-results.tsv').read_text().splitlines()
    assert len(rows) == 350 and all(row.split('\t')[3] == 'synthesized' for row in rows)

files = {}
for label, directory in [('regression', RUN), ('public', PUBLIC), ('signatures', CORPUS), ('extended-exference', EXTENDED),
        ('prior-full-regression', ROOT / 'dist-newstyle/one-shot-context-regression-v2'),
        ('prior-focused', ROOT / 'dist-newstyle/one-shot-context-focused-v4'),
        ('intermediate-focused', ROOT / 'dist-newstyle/one-shot-context-focused-v5'),
        ('focused', ROOT / 'dist-newstyle/one-shot-context-focused-v6')]:
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix not in {'.exe', '.o', '.hi', '.obj', '.pyc'}:
            files[label + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
for mapping, plan in [(reg['source_hashes_after'], RUN / 'plan.snapshot.json'), (corpus['after'], None), (public['after'], None)]:
    for name, expected in mapping.items():
        path = Path(name)
        raw = plan.read_bytes() if plan is not None and path == ROOT / 'dist-newstyle/cache/plan.json' else path.read_bytes()
        assert sha(raw) == expected, name
        if path.is_relative_to(ROOT) and path.suffix not in {'.exe', '.o', '.hi', '.obj', '.pyc'}:
            key = 'source/' + path.relative_to(ROOT).as_posix()
            if key in files and files[key] != raw:
                assert path == ROOT / 'dist-newstyle/cache/plan.json'
                files['source/signature-plan.json'] = raw
            else:
                files[key] = raw
for relative in ['docs/examples/Church.hs', 'test-church/manifest.json',
        'dist-newstyle/validate-one-shot-context-regression-v3.py',
        'dist-newstyle/validate-one-shot-context-public.py',
        'dist-newstyle/validate-one-shot-context-signatures.py',
        'dist-newstyle/package-one-shot-context.py',
        'dist-newstyle/contextual-frontend-compat-focused-v1.log',
        'dist-newstyle/contextual-generalization-replay-v2.log',
        'dist-newstyle/contextual-free-variable-diagnostic.stderr.txt']:
    files['source/' + relative] = (ROOT / relative).read_bytes()
manifest = {name: dict(bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(files.items())}
archive = ROOT / 'test-integration/receipts/one-shot-contextual-output.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(files.items()):
        z.writestr(name, raw)
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    for name, record in manifest.items():
        assert sha(z.read(name)) == record['sha256']
rows = [{k: v for k, v in row.items() if k != 'inventory'} for row in reg['rows']]
receipt = dict(status='accepted_documented_one_shot_contextual_matrix',
    base_commit='1e12b4f9321f68a7d635dbd4494919e299630e2c',
    strict_build='passed -Werror', suites=rows, test_count=2371,
    public_fixture=dict(positive_queries=64, exact_displayed_replays=public['exact_displayed_replays'],
        explicit_forall_guards=4, noninhabitation_queries=8, engines=['djinn', 'exference'],
        original_signatures=[row['signature'] for row in public['positive_queries'][:8:2]],
        selections=['first/balanced', 'best/balanced', 'all/balanced', 'all/legacy'],
        output_modes=['definition', 'expression'], window=4, djinn_choices=20000, exference_steps=256),
    signature_corpus=dict(djinn=350, exference=350, independent_GHC_compilation='passed', query_seconds=2, steps=10000),
    extended_behavior=dict(engine='exference', operations=13, false_controls=1,
        oracle_controls=extended['passed_oracle_controls'], settings=extended['settings']),
    source_and_runtime_inputs_unchanged=True,
    archive=dict(path=archive.name, artifacts=len(files), bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()), all_members_rehashed=True),
    boundaries=[
        'Acceptance covers the stated four original signatures and selection/output matrix, not every contextual query.',
        'Type-only all admits closed instance choices. Controlled checker/renderer tests separately pin their exact type arguments.',
        'Lexical evidence does not turn activated certificate obligations into Given or instance-discharge identity.',
        'Typed list output, applicable one-shot named-where syntax, kinded source binders and broader provider forms remain open.',
        'The 160-cell Church behavior objective is unchanged; signature inhabitation is separate.',
        'Leant remains pinned to bfc3692e; its deadline closure and integration of this canonical revision remain unaccepted.'])
archive.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
validation = 'Strict builds pass with `-Werror`. All **2,371 tests in 16 complete suites pass**:\n\n'
validation += '| Suite | Tests | Seconds |\n| --- | --- | --- |\n'
validation += ''.join(f"| {r['suite']} | {r['passed_count']} | {r['seconds']} |\n" for r in rows)
validation += (f"\nThe separate public run retains **64 positive queries and {public['exact_displayed_replays']} exact displayed alternatives**, "
    'all independently compiled and evaluated, plus **four explicit-forall rejection guards** and **eight noninhabitation queries**. '
    'Both Haskell signature corpora pass **350/350** with GHC checking at expanded and original resolved signatures. '
    f"The accepted Exference extended behavior corpus passes **13/13**, one False query and **{extended['passed_oracle_controls']} isolated oracle controls** at its original settings. "
    'Every recorded source and executable integrity check passes.\n')
report = (ROOT / 'dist-newstyle/one-shot-context-report-draft.md').read_text(encoding='utf-8').replace('__VALIDATION__', validation)
report += '\nArchive SHA-256: `' + receipt['archive']['sha256'] + '`.\n'
name = '2026-09-09-one-shot-contextual-output.md'
for root in (ROOT, Path('C:/Leant')):
    (root / 'docs/reports' / name).write_text(report, encoding='utf-8')
    index = root / 'docs/reports/README.md'
    index.write_text(index.read_text(encoding='utf-8').rstrip() + f'\n- 2026-09-09 — [One-shot contextual output and retained specialization evidence]({name})\n', encoding='utf-8')
    frontier = root / 'docs/reports/2026-09-09-synthesis-after-contextual-frontier.md'
    text = frontier.read_text(encoding='utf-8')
    first, rest = text.split('\n', 1)
    frontier.write_text(first + f'\n\n> Subsequent canonical acceptance: [one-shot contextual output]({name}) closes the stated public matrix and certificate boundary. The deadline repair, remaining frontend forms, native integration and broader goals remain open.\n' + rest, encoding='utf-8')
    readme = root / 'README.md'
    text = readme.read_text(encoding='utf-8')
    if root == ROOT:
        text = text.replace('suites** and **350 Church signatures per Haskell engine** pass. One-shot\ncontextual commands, typed list output and broader binder/provider forms remain\nopen.', f'suites** and **350 Church signatures per Haskell engine** pass. The later\n[one-shot contextual increment](docs/reports/{name}) passes **2,371 tests in 16 suites**,\n**64 public queries**, and both **350-signature** corpora. It preserves lexical\ndictionaries alongside specialization certificates and preserves scope for internal flexible\ntypes. Typed list output, applicable named-`where` one-shot\ncommands and broader binder/provider forms remain open.')
        text = text.replace('The latest local one-shot matrix passes 6/8 cases; Exference all-selection\nexposes a contextual-certificate boundary. The subsequent extension remains\nunbuilt and untested.', f'The [one-shot contextual matrix](docs/reports/{name}) now passes all eight\nengine/selection profiles and 64 public queries, including exact displayed-output\nreplay. Contextual certificates and internal flexible-variable scope are covered\nby 2,371 passing tests across 16 complete suites.')
        needle = 'one-shot operation. The historical `djinn` and `exference` executable names'
        text = text.replace(needle, 'one-shot operation. Both synthesis commands accept `--environment DIR` and use\nthe source workspace\'s normal import/export scope for supplied providers.\nThe historical `djinn` and `exference` executable names')
    else:
        text = text.replace('interrupted without terminal acceptance. Canonical one-shot frontend tests\n  pass 6/8 cases; the subsequent contextual-certificate extension is unvalidated.', f'interrupted without terminal acceptance. The canonical\n  [one-shot contextual increment](docs/reports/{name}) now passes\n  **2,371 tests in 16 suites**, **64 public queries** with exact output replay,\n  **350 signatures per Haskell engine**, and **13/13 Exference extended behaviors**.\n  It is separate from native acceptance; the tested Djex dependency remains pinned.')
    readme.write_text(text, encoding='utf-8')
print(json.dumps(dict(test_count=2371, public_replays=public['exact_displayed_replays'], archive=receipt['archive'])))
