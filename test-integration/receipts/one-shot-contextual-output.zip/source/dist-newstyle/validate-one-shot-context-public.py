"""Retain every public one-shot output and compile the exact alternatives together."""
from pathlib import Path
import ast, json, os, shutil, sys

ROOT = Path('C:/Djex')
sys.path.insert(0, str(ROOT / 'test-church'))
import behavior_runtime as runtime

OUT = runtime.prepare_output_directory(ROOT / 'dist-newstyle/one-shot-context-public-v1')
ENV = OUT / 'environment'
ENV.mkdir()
(ENV / 'Methods.hs').write_text('''{-# LANGUAGE RankNTypes, ScopedTypeVariables, TypeApplications, AllowAmbiguousTypes, NoPolyKinds #-}
module Methods (Token, C, method, observe) where
data Token = Token Int
class C a where payload :: Int
instance C Int where payload = 37
instance C Bool where payload = 91
method :: forall a. C a => Token
method = Token (payload @a)
observe :: Token -> Int
observe (Token n) = n
''', encoding='utf-8')
EXE = ROOT / 'dist-newstyle/build/x86_64-windows/ghc-9.12.4/djex-2026.7.17/x/djex/build/djex/djex.exe'
GHC = Path(shutil.which('ghc'))
paths = [Path(__file__), EXE, GHC, ROOT / 'djex.cabal', ENV / 'Methods.hs']
for folder in ('src', 'synthesis', 'exference', 'djinn'):
    paths.extend((ROOT / folder).rglob('*.hs'))
snapshot = lambda: {str(p): runtime.sha256(p) for p in sorted(set(paths))}
report = dict(status='running', before=snapshot(), positive_queries=[], guards=[], false_queries=[])
receipt = OUT / 'results.json'
processes = runtime.Processes(OUT, 300)
env = dict(os.environ, djex_datadir=str(ROOT))
settings = [('first', 'balanced'), ('best', 'balanced'), ('all', 'balanced'), ('all', 'legacy')]
signatures = [
    ('forall a. C a => Token', ''),
    ('C a => Token', ''),
    ('forall a. C a => (forall b. b -> b) -> Token', ' (\\x -> x)'),
    ('C z => forall b. b -> Token', ' @Prelude.Bool Prelude.True'),
]

def arguments(engine, selection, ranking, mode, signature, target='selected'):
    return [EXE, engine, '--environment', ENV, '--target', target, '--select', selection,
        '--ranking', ranking, '--render', mode, '--quality-window', '4',
        *(['--candidate-limit', '4', '--choice-budget', '20000'] if engine == 'djinn'
          else ['--allow-unused', '--max-steps', '256']), signature]

def persist():
    runtime.write_json(receipt, report)

replays = []
persist()
try:
    for engine in ('djinn', 'exference'):
        for index, signature in enumerate(('forall a. C b => Token', '(forall a. C b => Token)')):
            label = f'{engine}-guard-{index}'
            run = processes.run(label, arguments(engine, 'first', 'balanced', 'definition', signature), cwd=ROOT, env=env)
            assert run.returncode == 1 and not run.stdout.strip()
            assert 'explicit forall leaves unbound type variables' in run.stderr
            report['guards'].append(dict(id=label, status='passed', signature=signature))
            persist()
        for selection, ranking in settings:
            label = f'{engine}-{selection}-{ranking}-false'
            run = processes.run(label, arguments(engine, selection, ranking, 'definition', 'forall a. a', 'impossible'), cwd=ROOT, env=env)
            assert run.returncode == 0, run.stderr
            assert not any(line.startswith('impossible ') for line in run.stdout.splitlines())
            assert 'error [' not in run.stderr
            report['false_queries'].append(dict(id=label, status='passed', signature='forall a. a', stdout=run.stdout, stderr=run.stderr))
            persist()
            for index, (signature, extra) in enumerate(signatures):
                for mode in ('definition', 'expression'):
                    label = f'{engine}-{selection}-{ranking}-{index}-{mode}'
                    run = processes.run(label, arguments(engine, selection, ranking, mode, signature), cwd=ROOT, env=env)
                    assert run.returncode == 0 and 'error [' not in run.stderr, run.stderr
                    prefix = 'selected ' if mode == 'definition' else '('
                    displayed = [line for line in run.stdout.splitlines() if line.startswith(prefix)]
                    assert displayed, label
                    row = dict(id=label, signature=signature, extra_arguments=extra, mode=mode,
                        engine=engine, selection=selection, ranking=ranking, displayed=displayed,
                        status='synthesized', replay_indices=[])
                    for candidate in displayed:
                        number = len(replays)
                        expression = 'selected' if mode == 'definition' else candidate
                        apply = lambda ty: f'observe (({expression}) @Prelude.{ty}{extra})'
                        observed = f'({apply("Int")}, {apply("Bool")})'
                        if mode == 'definition':
                            observed = f'let {{ selected :: {signature}; {candidate} }} in {observed}'
                        replays.append((f'check{number} :: (Int, Int)\ncheck{number} = {observed}', selection))
                        row['replay_indices'].append(number)
                    report['positive_queries'].append(row)
                    persist()
    assert len(report['positive_queries']) == 64 and len(report['guards']) == 4 and len(report['false_queries']) == 8
    source = '\n'.join([
        '{-# LANGUAGE RankNTypes, ImpredicativeTypes, ScopedTypeVariables, TypeApplications, TypeAbstractions, AllowAmbiguousTypes #-}',
        'module Main where', 'import Methods',
        *[source for source, _ in replays],
        'main :: IO ()',
        'main = print [' + ', '.join(f'check{n}' for n in range(len(replays))) + ']', '',
    ])
    main = OUT / 'Main.hs'
    main.write_text(source, encoding='utf-8')
    build = OUT / 'build'
    build.mkdir()
    binary = build / 'replay.exe'
    compiled = processes.run('compile-exact-output', [GHC, '-O0', '-v0', '-fforce-recomp',
        '-i' + str(ENV), '-outputdir', build, main, '-o', binary], cwd=ROOT, env=env)
    assert compiled.returncode == 0, compiled.stderr
    run = processes.run('evaluate-exact-output', [binary], cwd=ROOT, env=env)
    assert run.returncode == 0, run.stderr
    observations = ast.literal_eval(run.stdout.strip())
    assert len(observations) == len(replays)
    for observed, (_, selection) in zip(observations, replays):
        allowed = {(37, 91), (37, 37), (91, 91)} if selection == 'all' else {(37, 91)}
        assert observed in allowed, (observed, selection)
    for row in report['positive_queries']:
        row['status'] = 'passed'
        row['observations'] = [observations[n] for n in row['replay_indices']]
    report.update(status='passed', exact_displayed_replays=len(replays),
        source_sha256=runtime.sha256(main), observations=observations,
        oracle_boundary='Type-only all permits closed Int/Bool selections; controlled engine graph/render regressions separately pin exact selected types. First/best require forwarding.')
finally:
    report['after'] = snapshot()
    report['unchanged'] = report['before'] == report['after']
    report['processes'] = processes.rows
    if not report['unchanged'] or report['status'] != 'passed':
        report['status'] = 'failed'
    persist()
    print(json.dumps({k: report.get(k) for k in ('status', 'exact_displayed_replays', 'unchanged')}), flush=True)
sys.exit(0 if report['status'] == 'passed' else 1)
