"""Complete affected frontend suites after focused ordinary-output acceptance."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import shutil
import sys

ROOT = Path('C:/Djex')
spec = importlib.util.spec_from_file_location('regression', ROOT/'dist-newstyle/run-loaded-provider-regression.py')
regression = importlib.util.module_from_spec(spec)
spec.loader.exec_module(regression)
regression.SUITES += ['djex-parallel-tests']
regression.REQUIRED['djex-cli-tests'] += [
    'ordinary contextual presentation retains typed choices.' + backend + ' ' + selection
    for backend in ['djinn', 'exference', 'both'] for selection in ['first', 'best', 'all']]
regression.REQUIRED['djex-cli-tests'] += ['implicit contextual signatures preserve binding scope.'+e for e in ['djinn','exference']]
regression.REQUIRED['djex-cli-tests'] += [
    'one-shot commands retain contextual source scope.'+e+' '+selection+' '+ranking
    for e in ['djinn','exference']
    for selection,ranking in [('first','balanced'),('best','balanced'),('all','balanced'),('all','legacy')]]
OUT = ROOT/'dist-newstyle/one-shot-context-regression-v3'
OUT.mkdir(exist_ok=False)
own_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
build = ['cabal','build', 'exe:djex', 'exe:exference', 'exe:djinn', 'exe:djex-fake-cabal', 'exe:djex-fake-z3',
         *['test:'+suite for suite in regression.SUITES], '-j1', '--ghc-options=-Werror']
with (OUT/'strict-build.log').open('wb') as capture:
    result = subprocess.run(build, cwd=ROOT, stdout=capture, stderr=subprocess.STDOUT, timeout=1200)
if result.returncode:
    raise SystemExit(result.returncode)
print('Strict build passed; running sixteen complete affected suites.', flush=True)
sys.argv = [str(ROOT/'dist-newstyle/run-loaded-provider-regression.py'), str(OUT/'regression')]
code = regression.main()
shutil.copyfile(ROOT/'dist-newstyle/cache/plan.json', OUT/'plan.snapshot.json')
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == own_hash
(OUT/'driver.json').write_text(json.dumps(dict(driver_sha256=own_hash,build=build,
    suite_count=len(regression.SUITES),status='passed' if code == 0 else 'failed'),indent=2)+'\n')
raise SystemExit(code)
